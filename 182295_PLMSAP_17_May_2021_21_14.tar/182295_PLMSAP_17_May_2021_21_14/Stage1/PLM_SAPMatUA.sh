. /user/uaprod/.bash_profile
tdate=`date +"%d-%h-%Y" --date="0 days ago"`
ydate=`date +"%d-%h-%Y" --date="1 days ago"`
stime="00:00"
inptime="$ydate $stime"
echo "Today's Date is :: $tdate"
echo "Yesterday's Input Date is :: $inptime"

echo "Getting Released ERC DMLs on Date :: $inptime"

/user/plmsap/PLMSAP/liveXfr/GetRelDmlList -u=ercpsup -p=XYT1ESA -d=$inptime

if test -s /user/plmsap/PLMSAP/ErcReleasedDmlList/ErcDmlList_$ydate.txt
then
	for i in `cat /user/plmsap/PLMSAP/ErcReleasedDmlList/ErcDmlList_$ydate.txt`
	do
	echo "Transfering DML Number : $i"
		/user/plmsap/PLMSAP/liveXfr/ercSAPMatUA -u=ercpsup -p=XYT1ESA -d=$i
	done

	nail -s "ERC DML UA to SAP" -a /user/plmsap/PLMSAP/ErcReleasedDmlList/ErcDmlList_$inptime.txt  devkant.kedar@tatatechnologies.com prasad.bhide@tatatechnologies.com amol.narke@tatatechnologies.com < /user/plmsap/PLMSAP/ErcReleasedDmlList/
fi

if test -s /user/plmsap/PLMSAP/AplReleasedDmlList/AplDmlList_$ydate.txt
then
	for i in `cat /user/plmsap/PLMSAP/AplReleasedDmlList/AplDmlList_$ydate.txt`
	do
	echo "Transfering DML Number : $i"
		/user/plmsap/PLMSAP/liveXfr/APL_DML_SAP_MAT_CREATE_UA -u=ercpsup -p=XYT1ESA -d=$i
	done
	nail -s "ERC DML UA to SAP" -a /user/plmsap/PLMSAP/AplReleasedDmlList/AplDmlList_$ydate.txt devkant.kedar@tatatechnologies.com prasad.bhide@tatatechnologies.com amol.narke@tatatechnologies.com < /user/plmsap/PLMSAP/AplReleasedDmlList/
fi
