/***************************************************************************
*  File				        :   TransferColorBOM.c
*  Created By				:   
*  Created On				:
*  Project			        :   SAP Transfer
*  Purpose			        :   non Color sync
*
*  Arguments				:
*  Notes				:
*
*
*  Modification History :
*  S.No    Date		   CR      Modified By            Modification Notes

*
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>

#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

char *iSapServer = NULL;

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

RFC_RC ccap_ecn_create(RFC_HANDLE hRfc,AENR_API01 *eChangeHeader,CSDATA_XFELD *eFlAle,CSDATA_XFELD *eFlCommitAndWait,CSDATA_XFELD *eFlNoCommitWork,AENV_API01 *eObjectBom,AENV_API01 *eObjectBomCus,AENV_API01 *eObjectBomDoc,AENV_API01 *eObjectBomEqui,AENV_API01 *eObjectBomLoc,AENV_API01 *eObjectBomMat,AENV_API01 *eObjectBomPsp,AENV_API01 *eObjectBomStd,AENV_API01 *eObjectChar,AENV_API01 *eObjectCls,AENV_API01 *eObjectClsMaint,AENV_API01 *eObjectConfProf,AENV_API01 *eObjectDep,AENV_API01 *eObjectDoc,AENV_API01 *eObjectHazmat,AENV_API01 *eObjectMat,AENV_API01 *eObjectPhrase,AENV_API01 *eObjectPvs,AENV_API01 *eObjectPvsAlt,AENV_API01 *eObjectPvsRel,AENV_API01 *eObjectPvsVar,AENV_API01 *eObjectSubstance,AENV_API01 *eObjectTlist,AENV_API01 *eObjectTlist2,AENV_API01 *eObjectTlistA,AENV_API01 *eObjectTlistE,AENV_API01 *eObjectTlistM,AENV_API01 *eObjectTlistN,AENV_API01 *eObjectTlistQ,AENV_API01 *eObjectTlistR,AENV_API01 *eObjectTlistS,AENV_API01 *eObjectTlistT,AENV_API01 *eObjectValidMatvers,AENV_API01 *eObjectVarTab,AEEF_API01 *eValueAssign,AENRB_AENNR *iChangeNo,ITAB_H thAltDates,ITAB_H thEffectivity,ITAB_H thObjmgrec,ITAB_H thTextheader,ITAB_H thTextlines,char *xException)
{
	RFC_PARAMETER Exporting[40];
	RFC_PARAMETER Importing[2];
	/*RFC_TABLE Tables[6];*/
	RFC_TABLE Tables[1];
	RFC_RC RfcRc;
	char *RfcException = NULL;
	Exporting[0].name = "CHANGE_HEADER";
	Exporting[0].nlen = 13;
	Exporting[0].type = handleOfAENR_API01;
	Exporting[0].leng = sizeof(AENR_API01);
	Exporting[0].addr = eChangeHeader;

	Exporting[1].name = "FL_ALE";
	Exporting[1].nlen = 6;
	Exporting[1].type = TYPC;
	Exporting[1].leng = sizeof(CSDATA_XFELD);
	Exporting[1].addr = eFlAle;

	Exporting[2].name = "FL_COMMIT_AND_WAIT";
	Exporting[2].nlen = 18;
	Exporting[2].type = TYPC;
	Exporting[2].leng = sizeof(CSDATA_XFELD);
	Exporting[2].addr = eFlCommitAndWait;

	Exporting[3].name = "FL_NO_COMMIT_WORK";
	Exporting[3].nlen = 17;
	Exporting[3].type = TYPC;
	Exporting[3].leng = sizeof(CSDATA_XFELD);
	Exporting[3].addr = eFlNoCommitWork;

	Exporting[4].name = "OBJECT_BOM";
	Exporting[4].nlen = 10;
	Exporting[4].type = handleOfAENV_API01;
	Exporting[4].leng = sizeof(AENV_API01);
	Exporting[4].addr = eObjectBom;

	Exporting[5].name = "OBJECT_BOM_CUS";
	Exporting[5].nlen = 14;
	Exporting[5].type = handleOfAENV_API01;
	Exporting[5].leng = sizeof(AENV_API01);
	Exporting[5].addr = eObjectBomCus;

	Exporting[6].name = "OBJECT_BOM_DOC";
	Exporting[6].nlen = 14;
	Exporting[6].type = handleOfAENV_API01;
	Exporting[6].leng = sizeof(AENV_API01);
	Exporting[6].addr = eObjectBomDoc;

	Exporting[7].name = "OBJECT_BOM_EQUI";
	Exporting[7].nlen = 15;
	Exporting[7].type = handleOfAENV_API01;
	Exporting[7].leng = sizeof(AENV_API01);
	Exporting[7].addr = eObjectBomEqui;

	Exporting[8].name = "OBJECT_BOM_LOC";
	Exporting[8].nlen = 14;
	Exporting[8].type = handleOfAENV_API01;
	Exporting[8].leng = sizeof(AENV_API01);
	Exporting[8].addr = eObjectBomLoc;

	Exporting[9].name = "OBJECT_BOM_MAT";
	Exporting[9].nlen = 14;
	Exporting[9].type = handleOfAENV_API01;
	Exporting[9].leng = sizeof(AENV_API01);
	Exporting[9].addr = eObjectBomMat;

	Exporting[10].name = "OBJECT_BOM_PSP";
	Exporting[10].nlen = 14;
	Exporting[10].type = handleOfAENV_API01;
	Exporting[10].leng = sizeof(AENV_API01);
	Exporting[10].addr = eObjectBomPsp;

	Exporting[11].name = "OBJECT_BOM_STD";
	Exporting[11].nlen = 14;
	Exporting[11].type = handleOfAENV_API01;
	Exporting[11].leng = sizeof(AENV_API01);
	Exporting[11].addr = eObjectBomStd;

	Exporting[12].name = "OBJECT_CHAR";
	Exporting[12].nlen = 11;
	Exporting[12].type = handleOfAENV_API01;
	Exporting[12].leng = sizeof(AENV_API01);
	Exporting[12].addr = eObjectChar;

	Exporting[13].name = "OBJECT_CLS";
	Exporting[13].nlen = 10;
	Exporting[13].type = handleOfAENV_API01;
	Exporting[13].leng = sizeof(AENV_API01);
	Exporting[13].addr = eObjectCls;

	Exporting[14].name = "OBJECT_CLS_MAINT";
	Exporting[14].nlen = 16;
	Exporting[14].type = handleOfAENV_API01;
	Exporting[14].leng = sizeof(AENV_API01);
	Exporting[14].addr = eObjectClsMaint;

	Exporting[15].name = "OBJECT_CONF_PROF";
	Exporting[15].nlen = 16;
	Exporting[15].type = handleOfAENV_API01;
	Exporting[15].leng = sizeof(AENV_API01);
	Exporting[15].addr = eObjectConfProf;

	Exporting[16].name = "OBJECT_DEP";
	Exporting[16].nlen = 10;
	Exporting[16].type = handleOfAENV_API01;
	Exporting[16].leng = sizeof(AENV_API01);
	Exporting[16].addr = eObjectDep;

	Exporting[17].name = "OBJECT_DOC";
	Exporting[17].nlen = 10;
	Exporting[17].type = handleOfAENV_API01;
	Exporting[17].leng = sizeof(AENV_API01);
	Exporting[17].addr = eObjectDoc;

	Exporting[18].name = "OBJECT_HAZMAT";
	Exporting[18].nlen = 13;
	Exporting[18].type = handleOfAENV_API01;
	Exporting[18].leng = sizeof(AENV_API01);
	Exporting[18].addr = eObjectHazmat;

	Exporting[19].name = "OBJECT_MAT";
	Exporting[19].nlen = 10;
	Exporting[19].type = handleOfAENV_API01;
	Exporting[19].leng = sizeof(AENV_API01);
	Exporting[19].addr = eObjectMat;

	Exporting[20].name = "OBJECT_PHRASE";
	Exporting[20].nlen = 13;
	Exporting[20].type = handleOfAENV_API01;
	Exporting[20].leng = sizeof(AENV_API01);
	Exporting[20].addr = eObjectPhrase;

	Exporting[21].name = "OBJECT_PVS";
	Exporting[21].nlen = 10;
	Exporting[21].type = handleOfAENV_API01;
	Exporting[21].leng = sizeof(AENV_API01);
	Exporting[21].addr = eObjectPvs;

	Exporting[22].name = "OBJECT_PVS_ALT";
	Exporting[22].nlen = 14;
	Exporting[22].type = handleOfAENV_API01;
	Exporting[22].leng = sizeof(AENV_API01);
	Exporting[22].addr = eObjectPvsAlt;

	Exporting[23].name = "OBJECT_PVS_REL";
	Exporting[23].nlen = 14;
	Exporting[23].type = handleOfAENV_API01;
	Exporting[23].leng = sizeof(AENV_API01);
	Exporting[23].addr = eObjectPvsRel;

	Exporting[24].name = "OBJECT_PVS_VAR";
	Exporting[24].nlen = 14;
	Exporting[24].type = handleOfAENV_API01;
	Exporting[24].leng = sizeof(AENV_API01);
	Exporting[24].addr = eObjectPvsVar;

	Exporting[25].name = "OBJECT_SUBSTANCE";
	Exporting[25].nlen = 16;
	Exporting[25].type = handleOfAENV_API01;
	Exporting[25].leng = sizeof(AENV_API01);
	Exporting[25].addr = eObjectSubstance;

	Exporting[26].name = "OBJECT_TLIST";
	Exporting[26].nlen = 12;
	Exporting[26].type = handleOfAENV_API01;
	Exporting[26].leng = sizeof(AENV_API01);
	Exporting[26].addr = eObjectTlist;

	Exporting[27].name = "OBJECT_TLIST_2";
	Exporting[27].nlen = 14;
	Exporting[27].type = handleOfAENV_API01;
	Exporting[27].leng = sizeof(AENV_API01);
	Exporting[27].addr = eObjectTlist2;

	Exporting[28].name = "OBJECT_TLIST_A";
	Exporting[28].nlen = 14;
	Exporting[28].type = handleOfAENV_API01;
	Exporting[28].leng = sizeof(AENV_API01);
	Exporting[28].addr = eObjectTlistA;

	Exporting[29].name = "OBJECT_TLIST_E";
	Exporting[29].nlen = 14;
	Exporting[29].type = handleOfAENV_API01;
	Exporting[29].leng = sizeof(AENV_API01);
	Exporting[29].addr = eObjectTlistE;

	Exporting[30].name = "OBJECT_TLIST_M";
	Exporting[30].nlen = 14;
	Exporting[30].type = handleOfAENV_API01;
	Exporting[30].leng = sizeof(AENV_API01);
	Exporting[30].addr = eObjectTlistM;

	Exporting[31].name = "OBJECT_TLIST_N";
	Exporting[31].nlen = 14;
	Exporting[31].type = handleOfAENV_API01;
	Exporting[31].leng = sizeof(AENV_API01);
	Exporting[31].addr = eObjectTlistN;

	Exporting[32].name = "OBJECT_TLIST_Q";
	Exporting[32].nlen = 14;
	Exporting[32].type = handleOfAENV_API01;
	Exporting[32].leng = sizeof(AENV_API01);
	Exporting[32].addr = eObjectTlistQ;

	Exporting[33].name = "OBJECT_TLIST_R";
	Exporting[33].nlen = 14;
	Exporting[33].type = handleOfAENV_API01;
	Exporting[33].leng = sizeof(AENV_API01);
	Exporting[33].addr = eObjectTlistR;

	Exporting[34].name = "OBJECT_TLIST_S";
	Exporting[34].nlen = 14;
	Exporting[34].type = handleOfAENV_API01;
	Exporting[34].leng = sizeof(AENV_API01);
	Exporting[34].addr = eObjectTlistS;

	Exporting[35].name = "OBJECT_TLIST_T";
	Exporting[35].nlen = 14;
	Exporting[35].type = handleOfAENV_API01;
	Exporting[35].leng = sizeof(AENV_API01);
	Exporting[35].addr = eObjectTlistT;

	Exporting[36].name = "OBJECT_VALID_MATVERS";
	Exporting[36].nlen = 20;
	Exporting[36].type = handleOfAENV_API01;
	Exporting[36].leng = sizeof(AENV_API01);
	Exporting[36].addr = eObjectValidMatvers;

	Exporting[37].name = "OBJECT_VAR_TAB";
	Exporting[37].nlen = 14;
	Exporting[37].type = handleOfAENV_API01;
	Exporting[37].leng = sizeof(AENV_API01);
	Exporting[37].addr = eObjectVarTab;

	Exporting[38].name = "VALUE_ASSIGN";
	Exporting[38].nlen = 12;
	Exporting[38].type = handleOfAEEF_API01;
	Exporting[38].leng = sizeof(AEEF_API01);
	Exporting[38].addr = eValueAssign;

	Exporting[39].name = NULL;

	/*Tables[0].name     = "ALT_DATES";
	Tables[0].nlen     = 9;
	Tables[0].type     = handleOfAEDT_API01;
	Tables[0].ithandle = thAltDates;

	Tables[1].name     = "EFFECTIVITY";
	Tables[1].nlen     = 11;
	Tables[1].type     = handleOfAEEF_API01;
	Tables[1].ithandle = thEffectivity;

	Tables[2].name     = "OBJMGREC";
	Tables[2].nlen     = 8;
	Tables[2].type     = handleOfAEOI_API01;
	Tables[2].ithandle = thObjmgrec;

	Tables[3].name     = "TEXTHEADER";
	Tables[3].nlen     = 10;
	Tables[3].type     = handleOfCCTHEAD;
	Tables[3].ithandle = thTextheader;

	Tables[4].name     = "TEXTLINES";
	Tables[4].nlen     = 9;
	Tables[4].type     = handleOfCCTLINE;
	Tables[4].ithandle = thTextlines;

	Tables[5].name = NULL;*/

	Tables[0].name = NULL;


	RfcRc = RfcCall(hRfc,"CCAP_ECN_CREATE",Exporting,Tables);
	//RfcRc = RfcCall(hRfc,"CCAP_ECN_MAINTAIN",Exporting,Tables);



	switch (RfcRc)
	{
		case RFC_OK:
			Importing[0].name = "CHANGE_NO";
			Importing[0].nlen = 9;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(AENRB_AENNR);
			Importing[0].addr = iChangeNo;

			Importing[1].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;

				case RFC_EXCEPTION:
				    strcpy(xException,RfcException);
					break;
				default:;
			}
		default:
			printf("\nYou are in Default case %d",RfcRc);
	}
	return RfcRc;
}
void getTodayDate(char StdDate[11])
{
    struct tm *Sys_T = NULL;
    int Month;
    int Day;
    int Year;
  /*  char StdDate[11]={0};*/
    time_t Tval = 0;
    Tval = time(NULL);
    Sys_T = localtime(&Tval);
    Day=Sys_T->tm_mday;
    Month=Sys_T->tm_mon+1;
    Year=1900 + Sys_T->tm_year;
    /*printf("\nMonth = %d", Month);
    printf("\tDay = %d", Day);
    printf("\tYear = %d", Year);*/
    sprintf(StdDate,"%02d.%02d.%04d",Day,Month,Year);
}
void cll_ccap_ecn_create(char *dmlno)
{
		static RFC_HANDLE hRfc;
		static RFC_RC RfcRc;

		//int noOfParts;
		char StdDate[11] = { 0 };

		AENR_API01 eChangeHeader;
		CSDATA_XFELD eFlAle;
		CSDATA_XFELD eFlCommitAndWait;
		CSDATA_XFELD eFlNoCommitWork;
		AENV_API01 eObjectBom;
		AENV_API01 eObjectBomCus;
		AENV_API01 eObjectBomDoc;
		AENV_API01 eObjectBomEqui;
		AENV_API01 eObjectBomLoc;
		AENV_API01 eObjectBomMat;
		AENV_API01 eObjectBomPsp;
		AENV_API01 eObjectBomStd;
		AENV_API01 eObjectChar;
		AENV_API01 eObjectCls;
		AENV_API01 eObjectClsMaint;
		AENV_API01 eObjectConfProf;
		AENV_API01 eObjectDep;
		AENV_API01 eObjectDoc;
		AENV_API01 eObjectHazmat;
		AENV_API01 eObjectMat;
		AENV_API01 eObjectPhrase;
		AENV_API01 eObjectPvs;
		AENV_API01 eObjectPvsAlt;
		AENV_API01 eObjectPvsRel;
		AENV_API01 eObjectPvsVar;
		AENV_API01 eObjectSubstance;
		AENV_API01 eObjectTlist;
		AENV_API01 eObjectTlist2;
		AENV_API01 eObjectTlistA;
		AENV_API01 eObjectTlistE;
		AENV_API01 eObjectTlistM;
		AENV_API01 eObjectTlistN;
		AENV_API01 eObjectTlistQ;
		AENV_API01 eObjectTlistR;
		AENV_API01 eObjectTlistS;
		AENV_API01 eObjectTlistT;
		AENV_API01 eObjectValidMatvers;
		AENV_API01 eObjectVarTab;
		AEEF_API01 eValueAssign;
		AENRB_AENNR iChangeNo;
		ITAB_H thAltDates = ITAB_NULL;
		ITAB_H thEffectivity = ITAB_NULL;
		ITAB_H thObjmgrec = ITAB_NULL;
		ITAB_H thTextheader = ITAB_NULL;
		ITAB_H thTextlines = ITAB_NULL;
		char xException[256];
		AEOI_API01 *tObjmgrec;

		hRfc = BapiLogon();
		getTodayDate(StdDate);
		printf("\nChangeno:[%s]Date:[%s]",dmlno,StdDate);
		SETCHAR(eChangeHeader.ChangeNo,dmlno);/*dml_no*/
		//SETCHAR(eChangeHeader.ChangeNo,"13SM000108ST");/*dml_no*/
		SETNUM(eChangeHeader.Status,"01");
		SETCHAR(eChangeHeader.AuthGroup,"");
		//SETCHAR(eChangeHeader.ValidFrom,StdDate);/*StdDate*/
		SETCHAR(eChangeHeader.ValidFrom,StdDate);/*StdDate*/
		//SETCHAR(eChangeHeader.ValidFrom,"07.04.2017");/*StdDate*/
		SETCHAR(eChangeHeader.Descript,"partwise rev xfr change no");/*tempstr*/
		//SETCHAR(eChangeHeader.Descript,"FOR Latest IPL updation by 14th Aug13");/*tempstr*/
		SETCHAR(eChangeHeader.ReasonChg,"");
		SETCHAR(eChangeHeader.DeletionMark,"");
		SETCHAR(eChangeHeader.IndateRule,"");
		SETCHAR(eChangeHeader.OutdateRule,"");
		SETCHAR(eChangeHeader.ChangeLeader,"");
		SETCHAR(eChangeHeader.EffectivityType,"");
		SETCHAR(eChangeHeader.OverridingMark,"");
		SETNUM(eChangeHeader.Rank,"");
		
		/*for without release key*/
		SETCHAR(eChangeHeader.Function,"");			//for any material dml or PE MATERIAL
		SETNUM(eChangeHeader.ReleaseKey,"");

		/*for with release key*/
		//SETCHAR(eChangeHeader.Function,"1");		//for PE BOM
		//SETNUM(eChangeHeader.ReleaseKey,"00");

		SETCHAR(eChangeHeader.StatusProfile,"");
		SETCHAR(eChangeHeader.TechRel,"");
		SETCHAR(eChangeHeader.BasicChange,"");
		SETCHAR(eFlAle,"");
		SETCHAR(eFlCommitAndWait,"X");
		SETCHAR(eFlNoCommitWork,"");
		SETCHAR(eObjectBom.Active,"");
		SETCHAR(eObjectBom.Locked,"");
		SETCHAR(eObjectBom.ObjRequ,"");
		SETCHAR(eObjectBom.MgtrecGen,"");
		SETCHAR(eObjectBom.GenNew,"");
		SETCHAR(eObjectBom.GenDialog,"");
		SETCHAR(eObjectBomCus.Active,"");
		SETCHAR(eObjectBomCus.Locked,"");
		SETCHAR(eObjectBomCus.ObjRequ,"");
		SETCHAR(eObjectBomCus.MgtrecGen,"");
		SETCHAR(eObjectBomCus.GenNew,"");
		SETCHAR(eObjectBomCus.GenDialog,"");
		SETCHAR(eObjectBomDoc.Active,"");
		SETCHAR(eObjectBomDoc.Locked,"");
		SETCHAR(eObjectBomDoc.ObjRequ,"");
		SETCHAR(eObjectBomDoc.MgtrecGen,"");
		SETCHAR(eObjectBomDoc.GenNew,"");
		SETCHAR(eObjectBomDoc.GenDialog,"");
		SETCHAR(eObjectBomEqui.Active,"");
		SETCHAR(eObjectBomEqui.Locked,"");
		SETCHAR(eObjectBomEqui.ObjRequ,"");
		SETCHAR(eObjectBomEqui.MgtrecGen,"");
		SETCHAR(eObjectBomEqui.GenNew,"");
		SETCHAR(eObjectBomEqui.GenDialog,"");
		SETCHAR(eObjectBomLoc.Active,"");
		SETCHAR(eObjectBomLoc.Locked,"");
		SETCHAR(eObjectBomLoc.ObjRequ,"");
		SETCHAR(eObjectBomLoc.MgtrecGen,"");
		SETCHAR(eObjectBomLoc.GenNew,"");
		SETCHAR(eObjectBomLoc.GenDialog,"");
		SETCHAR(eObjectBomMat.Active,"X");
		SETCHAR(eObjectBomMat.Locked,"");
		SETCHAR(eObjectBomMat.ObjRequ,"X");
		SETCHAR(eObjectBomMat.MgtrecGen,"X");
		SETCHAR(eObjectBomMat.GenNew,"");
		SETCHAR(eObjectBomMat.GenDialog,"");
		SETCHAR(eObjectBomPsp.Active,"");
		SETCHAR(eObjectBomPsp.Locked,"");
		SETCHAR(eObjectBomPsp.ObjRequ,"");
		SETCHAR(eObjectBomPsp.MgtrecGen,"");
		SETCHAR(eObjectBomPsp.GenNew,"");
		SETCHAR(eObjectBomPsp.GenDialog,"");
		SETCHAR(eObjectBomStd.Active,"");
		SETCHAR(eObjectBomStd.Locked,"");
		SETCHAR(eObjectBomStd.ObjRequ,"");
		SETCHAR(eObjectBomStd.MgtrecGen,"");
		SETCHAR(eObjectBomStd.GenNew,"");
		SETCHAR(eObjectBomStd.GenDialog,"");
		SETCHAR(eObjectChar.Active,"");
		SETCHAR(eObjectChar.Locked,"");
		SETCHAR(eObjectChar.ObjRequ,"");
		SETCHAR(eObjectChar.MgtrecGen,"");
		SETCHAR(eObjectChar.GenNew,"");
		SETCHAR(eObjectChar.GenDialog,"");
		SETCHAR(eObjectCls.Active,"");
		SETCHAR(eObjectCls.Locked,"");
		SETCHAR(eObjectCls.ObjRequ,"");
		SETCHAR(eObjectCls.MgtrecGen,"");
		SETCHAR(eObjectCls.GenNew,"");
		SETCHAR(eObjectCls.GenDialog,"");
		SETCHAR(eObjectClsMaint.Active,"");
		SETCHAR(eObjectClsMaint.Locked,"");
		SETCHAR(eObjectClsMaint.ObjRequ,"");
		SETCHAR(eObjectClsMaint.MgtrecGen,"");
		SETCHAR(eObjectClsMaint.GenNew,"");
		SETCHAR(eObjectClsMaint.GenDialog,"");
		SETCHAR(eObjectConfProf.Active,"");
		SETCHAR(eObjectConfProf.Locked,"");
		SETCHAR(eObjectConfProf.ObjRequ,"");
		SETCHAR(eObjectConfProf.MgtrecGen,"");
		SETCHAR(eObjectConfProf.GenNew,"");
		SETCHAR(eObjectConfProf.GenDialog,"");
		SETCHAR(eObjectDep.Active,"");
		SETCHAR(eObjectDep.Locked,"");
		SETCHAR(eObjectDep.ObjRequ,"");
		SETCHAR(eObjectDep.MgtrecGen,"");
		SETCHAR(eObjectDep.GenNew,"");
		SETCHAR(eObjectDep.GenDialog,"");
		SETCHAR(eObjectDoc.Active,"X");
		SETCHAR(eObjectDoc.Locked,"");
		SETCHAR(eObjectDoc.ObjRequ,"X");
		SETCHAR(eObjectDoc.MgtrecGen,"X");
		SETCHAR(eObjectDoc.GenNew,"");
		SETCHAR(eObjectDoc.GenDialog,"");
		SETCHAR(eObjectHazmat.Active,"");
		SETCHAR(eObjectHazmat.Locked,"");
		SETCHAR(eObjectHazmat.ObjRequ,"");
		SETCHAR(eObjectHazmat.MgtrecGen,"");
		SETCHAR(eObjectHazmat.GenNew,"");
		SETCHAR(eObjectHazmat.GenDialog,"");
		SETCHAR(eObjectMat.Active,"X");
		SETCHAR(eObjectMat.Locked,"");
		SETCHAR(eObjectMat.ObjRequ,"X");
		SETCHAR(eObjectMat.MgtrecGen,"X");
		SETCHAR(eObjectMat.GenNew,"");
		SETCHAR(eObjectMat.GenDialog,"");
		SETCHAR(eObjectPhrase.Active,"");
		SETCHAR(eObjectPhrase.Locked,"");
		SETCHAR(eObjectPhrase.ObjRequ,"");
		SETCHAR(eObjectPhrase.MgtrecGen,"");
		SETCHAR(eObjectPhrase.GenNew,"");
		SETCHAR(eObjectPhrase.GenDialog,"");
		SETCHAR(eObjectPvs.Active,"");
		SETCHAR(eObjectPvs.Locked,"");
		SETCHAR(eObjectPvs.ObjRequ,"");
		SETCHAR(eObjectPvs.MgtrecGen,"");
		SETCHAR(eObjectPvs.GenNew,"");
		SETCHAR(eObjectPvs.GenDialog,"");
		SETCHAR(eObjectPvsAlt.Active,"");
		SETCHAR(eObjectPvsAlt.Locked,"");
		SETCHAR(eObjectPvsAlt.ObjRequ,"");
		SETCHAR(eObjectPvsAlt.MgtrecGen,"");
		SETCHAR(eObjectPvsAlt.GenNew,"");
		SETCHAR(eObjectPvsAlt.GenDialog,"");
		SETCHAR(eObjectPvsRel.Active,"");
		SETCHAR(eObjectPvsRel.Locked,"");
		SETCHAR(eObjectPvsRel.ObjRequ,"");
		SETCHAR(eObjectPvsRel.MgtrecGen,"");
		SETCHAR(eObjectPvsRel.GenNew,"");
		SETCHAR(eObjectPvsRel.GenDialog,"");
		SETCHAR(eObjectPvsVar.Active,"X");
		SETCHAR(eObjectPvsVar.Locked,"");
		SETCHAR(eObjectPvsVar.ObjRequ,"X");
		SETCHAR(eObjectPvsVar.MgtrecGen,"X");
		SETCHAR(eObjectPvsVar.GenNew,"");
		SETCHAR(eObjectPvsVar.GenDialog,"");
		SETCHAR(eObjectSubstance.Active,"");
		SETCHAR(eObjectSubstance.Locked,"");
		SETCHAR(eObjectSubstance.ObjRequ,"");
		SETCHAR(eObjectSubstance.MgtrecGen,"");
		SETCHAR(eObjectSubstance.GenNew,"");
		SETCHAR(eObjectSubstance.GenDialog,"");
		SETCHAR(eObjectTlist.Active,"");
		SETCHAR(eObjectTlist.Locked,"");
		SETCHAR(eObjectTlist.ObjRequ,"");
		SETCHAR(eObjectTlist.MgtrecGen,"");
		SETCHAR(eObjectTlist.GenNew,"");
		SETCHAR(eObjectTlist.GenDialog,"");
		SETCHAR(eObjectTlist2.Active,"");
		SETCHAR(eObjectTlist2.Locked,"");
		SETCHAR(eObjectTlist2.ObjRequ,"");
		SETCHAR(eObjectTlist2.MgtrecGen,"");
		SETCHAR(eObjectTlist2.GenNew,"");
		SETCHAR(eObjectTlist2.GenDialog,"");
		SETCHAR(eObjectTlistA.Active,"");
		SETCHAR(eObjectTlistA.Locked,"");
		SETCHAR(eObjectTlistA.ObjRequ,"");
		SETCHAR(eObjectTlistA.MgtrecGen,"");
		SETCHAR(eObjectTlistA.GenNew,"");
		SETCHAR(eObjectTlistA.GenDialog,"");
		SETCHAR(eObjectTlistE.Active,"");
		SETCHAR(eObjectTlistE.Locked,"");
		SETCHAR(eObjectTlistE.ObjRequ,"");
		SETCHAR(eObjectTlistE.MgtrecGen,"");
		SETCHAR(eObjectTlistE.GenNew,"");
		SETCHAR(eObjectTlistE.GenDialog,"");
		SETCHAR(eObjectTlistM.Active,"");
		SETCHAR(eObjectTlistM.Locked,"");
		SETCHAR(eObjectTlistM.ObjRequ,"");
		SETCHAR(eObjectTlistM.MgtrecGen,"");
		SETCHAR(eObjectTlistM.GenNew,"");
		SETCHAR(eObjectTlistM.GenDialog,"");
		SETCHAR(eObjectTlistN.Active,"");
		SETCHAR(eObjectTlistN.Locked,"");
		SETCHAR(eObjectTlistN.ObjRequ,"");
		SETCHAR(eObjectTlistN.MgtrecGen,"");
		SETCHAR(eObjectTlistN.GenNew,"");
		SETCHAR(eObjectTlistN.GenDialog,"");
		SETCHAR(eObjectTlistQ.Active,"");
		SETCHAR(eObjectTlistQ.Locked,"");
		SETCHAR(eObjectTlistQ.ObjRequ,"");
		SETCHAR(eObjectTlistQ.MgtrecGen,"");
		SETCHAR(eObjectTlistQ.GenNew,"");
		SETCHAR(eObjectTlistQ.GenDialog,"");
		SETCHAR(eObjectTlistR.Active,"");
		SETCHAR(eObjectTlistR.Locked,"");
		SETCHAR(eObjectTlistR.ObjRequ,"");
		SETCHAR(eObjectTlistR.MgtrecGen,"");
		SETCHAR(eObjectTlistR.GenNew,"");
		SETCHAR(eObjectTlistR.GenDialog,"");
		SETCHAR(eObjectTlistS.Active,"");
		SETCHAR(eObjectTlistS.Locked,"");
		SETCHAR(eObjectTlistS.ObjRequ,"");
		SETCHAR(eObjectTlistS.MgtrecGen,"");
		SETCHAR(eObjectTlistS.GenNew,"");
		SETCHAR(eObjectTlistS.GenDialog,"");
		SETCHAR(eObjectTlistT.Active,"");
		SETCHAR(eObjectTlistT.Locked,"");
		SETCHAR(eObjectTlistT.ObjRequ,"");
		SETCHAR(eObjectTlistT.MgtrecGen,"");
		SETCHAR(eObjectTlistT.GenNew,"");
		SETCHAR(eObjectTlistT.GenDialog,"");
		SETCHAR(eObjectValidMatvers.Active,"");
		SETCHAR(eObjectValidMatvers.Locked,"");
		SETCHAR(eObjectValidMatvers.ObjRequ,"");
		SETCHAR(eObjectValidMatvers.MgtrecGen,"");
		SETCHAR(eObjectValidMatvers.GenNew,"");
		SETCHAR(eObjectValidMatvers.GenDialog,"");
		SETCHAR(eObjectVarTab.Active,"");
		SETCHAR(eObjectVarTab.Locked,"");
		SETCHAR(eObjectVarTab.ObjRequ,"");
		SETCHAR(eObjectVarTab.MgtrecGen,"");
		SETCHAR(eObjectVarTab.GenNew,"");
		SETCHAR(eObjectVarTab.GenDialog,"");
		SETCHAR(eValueAssign.ValidFrom,"");
		SETCHAR(eValueAssign.ValidTo,"");
		SETCHAR(eValueAssign.DateMark,"");
		SETCHAR(eValueAssign.Material,"");
		SETCHAR(eValueAssign.SerialnrLow,"");
		SETCHAR(eValueAssign.SerialnrHigh,"");
		SETCHAR(eValueAssign.Class,"");
		SETCHAR(eValueAssign.Classty,"");
		SETCHAR(eValueAssign.Startup,"");
		SETCHAR(eValueAssign.Plant,"");
		SETCHAR(eValueAssign.SernrOi,"");
		SETCHAR(eValueAssign.FlDelete,"");

		if (thObjmgrec==ITAB_NULL)
		{
			thObjmgrec = ItCreate("OBJMGREC", sizeof(AEOI_API01), 0, 0);
			if (thObjmgrec==ITAB_NULL)
				printf("\nItCreate OBJMGREC");
		}
		else if (ItFree(thObjmgrec) != 0)
			printf("\nItFree OBJMGREC");


			tObjmgrec = ItAppLine(thObjmgrec);
			if (tObjmgrec == NULL)
				printf("\nItAppLine OBJMGREC");

	SETCHAR(tObjmgrec->AltDate,"");
	SETNUM(tObjmgrec->ChgObjtyp,"");
	SETNUM(tObjmgrec->ChgObjtyp,"4");
	SETCHAR(tObjmgrec->BomCat,"");
	SETCHAR(tObjmgrec->BomStdObject,"");
	SETCHAR(tObjmgrec->BomUsage,"");
	SETNUM(tObjmgrec->Chgtypeobj,"");
	SETCHAR(tObjmgrec->DescrObj,"");
	SETCHAR(tObjmgrec->DocType,"");
	SETCHAR(tObjmgrec->DocNumber,"");
	SETCHAR(tObjmgrec->DocVers,"");
	SETCHAR(tObjmgrec->DocPart,"");
	SETCHAR(tObjmgrec->Equipment,"");
	SETCHAR(tObjmgrec->FuncLoc,"");
	SETCHAR(tObjmgrec->Material,"2834342054RZZ_7501");
	SETCHAR(tObjmgrec->Plant,"");
	SETCHAR(tObjmgrec->PspElement,"");
	SETCHAR(tObjmgrec->PvsType,"");
	SETCHAR(tObjmgrec->PvsNode,"");
	SETCHAR(tObjmgrec->PvsClassNumber,"");
	SETCHAR(tObjmgrec->PvsClassType,"");
	SETCHAR(tObjmgrec->PvsVariant,"");
	SETCHAR(tObjmgrec->SdOrder,"");
	SETNUM(tObjmgrec->SdOrderI,"");
	SETNUM(tObjmgrec->Textkey,"");
	SETCHAR(tObjmgrec->TlistType,"");
	SETCHAR(tObjmgrec->TlistGrp,"");
	SETCHAR(tObjmgrec->ObjChglock,"");
	SETCHAR(tObjmgrec->StatusProfObj,"");
	SETCHAR(tObjmgrec->FlDelete,"");


	/*tObjmgrec = ItAppLine(thObjmgrec);
	if (tObjmgrec == NULL)
		printf("\nItAppLine OBJMGREC");

	SETCHAR(tObjmgrec->AltDate,"");
	SETNUM(tObjmgrec->ChgObjtyp,"");
	SETNUM(tObjmgrec->ChgObjtyp,"4");
	SETCHAR(tObjmgrec->BomCat,"");
	SETCHAR(tObjmgrec->BomStdObject,"");
	SETCHAR(tObjmgrec->BomUsage,"");
	SETNUM(tObjmgrec->Chgtypeobj,"");
	SETCHAR(tObjmgrec->DescrObj,"");
	SETCHAR(tObjmgrec->DocType,"");
	SETCHAR(tObjmgrec->DocNumber,"");
	SETCHAR(tObjmgrec->DocVers,"");
	SETCHAR(tObjmgrec->DocPart,"");
	SETCHAR(tObjmgrec->Equipment,"");
	SETCHAR(tObjmgrec->FuncLoc,"");
	SETCHAR(tObjmgrec->Material,"2834342054R");
	SETCHAR(tObjmgrec->Plant,"");
	SETCHAR(tObjmgrec->PspElement,"");
	SETCHAR(tObjmgrec->PvsType,"");
	SETCHAR(tObjmgrec->PvsNode,"");
	SETCHAR(tObjmgrec->PvsClassNumber,"");
	SETCHAR(tObjmgrec->PvsClassType,"");
	SETCHAR(tObjmgrec->PvsVariant,"");
	SETCHAR(tObjmgrec->SdOrder,"");
	SETNUM(tObjmgrec->SdOrderI,"");
	SETNUM(tObjmgrec->Textkey,"");
	SETCHAR(tObjmgrec->TlistType,"");
	SETCHAR(tObjmgrec->TlistGrp,"");
	SETCHAR(tObjmgrec->ObjChglock,"");
	SETCHAR(tObjmgrec->StatusProfObj,"");
	SETCHAR(tObjmgrec->FlDelete,"");*/

	RfcRc = ccap_ecn_create(hRfc,&eChangeHeader,&eFlAle,&eFlCommitAndWait,&eFlNoCommitWork,&eObjectBom,&eObjectBomCus,&eObjectBomDoc,&eObjectBomEqui,&eObjectBomLoc,&eObjectBomMat,&eObjectBomPsp,&eObjectBomStd,&eObjectChar,&eObjectCls,&eObjectClsMaint,&eObjectConfProf,&eObjectDep,&eObjectDoc,&eObjectHazmat,&eObjectMat,&eObjectPhrase,&eObjectPvs,&eObjectPvsAlt,&eObjectPvsRel,&eObjectPvsVar,&eObjectSubstance,&eObjectTlist,&eObjectTlist2,&eObjectTlistA,&eObjectTlistE,&eObjectTlistM,&eObjectTlistN,&eObjectTlistQ,&eObjectTlistR,&eObjectTlistS,&eObjectTlistT,&eObjectValidMatvers,&eObjectVarTab,&eValueAssign,&iChangeNo,thAltDates,thEffectivity,thObjmgrec,thTextheader,thTextlines,xException);
	switch (RfcRc)
	{
		case RFC_OK:
			printf("\necn create: %u\n",RFC_OK);
		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception: %s\n",xException);
		break;
		default:;
	}

EXIT:
	RfcClose(hRfc);
}

int ITK_user_main(int argc, char ** argv )
{
	int status;
	char* dmlno = NULL;

	ITK_CALL( ITK_initialize_text_services ( ITK_BATCH_TEXT_MODE ) );
	ITK_CALL( ITK_auto_login ( ) );
	ITK_CALL( ITK_set_journalling ( TRUE ) );
	
	dmlno = ITK_ask_cli_argument("-d=");
	iSapServer = ITK_ask_cli_argument("-s=");

	//strcpy(dmlno,argv[1]);
	if(strlen(dmlno)==12)
	{
		cll_ccap_ecn_create(dmlno);
	}
	else
	{
		printf("\nChange Number should be 12 Character");
	}
	//ITK_CALL(POM_logout(false));
	return status;
}
