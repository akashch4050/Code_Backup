/********************************************************************************************************************************
* Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : ercSAPMatUA.c
* Created By                   : Amol Narke
* Created On                   : 12/04/2018
* Project                      : Tata Motors PLM-CAD BOM
* Methods Defined              :
* Description                  : Creates Basic View in SAP From UA
* Specific Notes               :
*
* Modification History :
* S.No		Date			CR No       Modified By		Modification Notes
************************************************************************************************************************************/
#define TE_MAXLINELEN  128
#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"
#include "t.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>

FILE * fsuccess;
FILE* fp=NULL;
char fsuccess_name[200];

WERKS_D eWerks;
static MATNR eMatnr;

int partCnt=0;
char *dml_numER=NULL;
char *iSapServer=NULL;
char *erc_release_date=NULL;
char *DMLDescription=NULL;
tag_t *SetOfPartTags= NULLTAG;

char *part_noDupDes=NULL;
char *part_noDupDesx=NULL;
char *doc_no=NULL;
char *basic_division=NULL;
char *unit_wt=NULL;
char *volume=NULL;
char *vol_unit=NULL;
char *material_group=NULL;
char *doc_noDup=NULL;
char *dwg_typeDup=NULL;
char *tmpDrwNum1=NULL;
char *tmpDrwNum=NULL;
char *tmpDrwRev=NULL;
char *tmpDrwSeq=NULL;
char *dwg_revDup=NULL;
char *dwg_rev=NULL;
char *OldMatNo=NULL;
char *OldMatNoDup=NULL;
char *sizeDup=NULL;
char *net_wt=NULL;
char *net_wtDup=NULL;
char *gross_weight=NULL;
char *gross_weightDup=NULL;
char *part_noDup=NULL;
char *make_buy_indDup=NULL;
char *make_buy_ind=NULL;
char *mat_type=NULL;
char *store_loc=NULL;
char *store_locDup=NULL;
char *mrp_grp=NULL;
char *mat_grp=NULL;
char *division=NULL;
char *weight_unit=NULL;
char *mrp_type=NULL;
char *abc_ind=NULL;
char *odstatus=NULL;
char *num;
char *drstatus = NULL;
char *drstatusDup = NULL;
char *mm_pp_status = NULL;
char *partClrIndDup = NULL;
char *partClrInd = NULL;
char *quota_arrangement_usage = NULL;
char *mrp_controller = NULL;
char *lot_size_key = NULL;
char *fixed_lot_size = NULL;
char *max_stlvl = NULL;
char *blk_ind = NULL;
char *sched_mar_key = NULL;
char *req_grp = NULL;
char *period_ind = NULL;
char *mixedmrp = NULL;
char *cs1_val = NULL;
char *alternativb = NULL;
char *avail_chk = NULL;
char *splan_mat = NULL;
char *splan_plant = NULL;
char *splan_conv_fact = NULL;
char *ind_collect = NULL;
char *rep_mfg_in = NULL;
char *rep_mfg = NULL;
char *stock_det_group = NULL;
char *uoissue = NULL;
char *qua_ins_ind = NULL;
char *doc_req = NULL;
char *grptime = NULL;
char *certificate_type = NULL;
char *qm_proc_ind = NULL;
char *control_key = NULL;
char *catalog_prof = NULL;
char *valuation_cat = NULL;
char *price_con = NULL;
char *std_price = NULL;
char *moving_avg_price = NULL;
char *val_class = NULL;
char *mat_origin = NULL;
char *cost_lot_size = NULL;
char *variance_key = NULL;
char *with_quantity_structure = NULL;
char *costing_split_valuation = NULL;
char *costing_val_class = NULL;
char *MatCrChFlag = NULL;
char *dml_numAP1 = NULL;
char *PrtRevDup = NULL;
char *OrgIDDup = NULL;
char *plan_calendar = NULL;
char *profit_centre_sap = NULL;
char *overhd_grp = NULL;
char *myzeroDup3 = NULL;
char *myzeroDup1 = NULL;
char *myzeroDup2 = NULL;
char *myzeroDup4 = NULL;
char *sap_msg = NULL;
char *p;


char *meas_unit=NULL;
char *desc=NULL;
char *descDup=NULL;
char *drg_ind=NULL;
char *drg_indDup=NULL;
char *docClass=NULL;
char *spl_proc_key=NULL;
char *OwnerNameDup=NULL;
char *proc_type;

char *inputDML=NULL;


char *SAPpstat=NULL;
char *MRPpstat=NULL;
char pstat;
char pstat_mrp;
char pstat_acc;
char proc_Key;
char spl_Key;
char group;
const char *attrs[2];
const char *values[2];

//drwnum = (char *)malloc(500 * sizeof(char));


#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
void displaying_objects(void);
int GetCSPstat(char cMaterial[15]);
RFC_RC cll_ccap_ecn_create(RFC_HANDLE);
RFC_RC ccap_ecn_create(RFC_HANDLE hRfc,AENR_API01 *,CSDATA_XFELD *,CSDATA_XFELD *,CSDATA_XFELD *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AEEF_API01 *,AENRB_AENNR *,ITAB_H,ITAB_H,ITAB_H,ITAB_H,ITAB_H,char *);
void CLL_BAPI_MATERIAL_SAVEDATA(void);
RFC_RC ZBAPI_MATERIAL_SAVEDATA(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA *,BAPI_MARAX *,RMMG1_AENNR *,BAPIRET2 *,ITAB_H ,ITAB_H ,ITAB_H ,ITAB_H ,ITAB_H ,char *);
int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3]);
RFC_RC WIN_DLL_EXPORT_FLAGS zpprfc_revisionnum_change(RFC_HANDLE hRfc,AENNR *eAennr,CCMATNR *eMatnr,CC_REVLV *eRevlv,BAPIRET2 *iMessg,SYST_SUBRC *iRetval,char *xException);
RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException);
RFC_RC BAPI_MATERIAL_UPDATEDATA(RFC_HANDLE hRfc,BAPIMATHEAD *, BAPI_MARA *, BAPI_MARAX *, BAPIRET2 *,char *);
int pstat_basicFun(void);
int getChassisType(tag_t PartTag,char *part_type,char *part_ColorId);
void descChange(char *Part_Num,char *DescStr,char *dml_no_arg);
RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,char *xException);
void rfc_error(char *);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);


#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;

	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

void displaying_objects(void)
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;

	hRfc = BapiLogon();
	printf("\ncalling the change no creation function");
	RfcRc = cll_ccap_ecn_create(hRfc);
	RfcClose(hRfc);
}

RFC_RC cll_ccap_ecn_create(RFC_HANDLE hRfc)
{
	static RFC_RC RfcRc;
	int status;
	int p=0;
	char *PartNumC=NULL;
	char *part_typeC=NULL;

	tag_t PartTag1= NULLTAG;

	AENR_API01 eChangeHeader;
	CSDATA_XFELD eFlAle;
	CSDATA_XFELD eFlCommitAndWait;
	CSDATA_XFELD eFlNoCommitWork;
	AENV_API01 eObjectBom;
	AENV_API01 eObjectBomCus;
	AENV_API01 eObjectBomDoc;
	AENV_API01 eObjectBomEqui;
	AENV_API01 eObjectBomLoc;
	AENV_API01 eObjectBomMat;
	AENV_API01 eObjectBomPsp;
	AENV_API01 eObjectBomStd;
	AENV_API01 eObjectChar;
	AENV_API01 eObjectCls;
	AENV_API01 eObjectClsMaint;
	AENV_API01 eObjectConfProf;
	AENV_API01 eObjectDep;
	AENV_API01 eObjectDoc;
	AENV_API01 eObjectHazmat;
	AENV_API01 eObjectMat;
	AENV_API01 eObjectPhrase;
	AENV_API01 eObjectPvs;
	AENV_API01 eObjectPvsAlt;
	AENV_API01 eObjectPvsRel;
	AENV_API01 eObjectPvsVar;
	AENV_API01 eObjectSubstance;
	AENV_API01 eObjectTlist;
	AENV_API01 eObjectTlist2;
	AENV_API01 eObjectTlistA;
	AENV_API01 eObjectTlistE;
	AENV_API01 eObjectTlistM;
	AENV_API01 eObjectTlistN;
	AENV_API01 eObjectTlistQ;
	AENV_API01 eObjectTlistR;
	AENV_API01 eObjectTlistS;
	AENV_API01 eObjectTlistT;
	AENV_API01 eObjectValidMatvers;
	AENV_API01 eObjectVarTab;
	AEEF_API01 eValueAssign;
	AENRB_AENNR iChangeNo;
	ITAB_H thAltDates = ITAB_NULL;
	ITAB_H thEffectivity = ITAB_NULL;
	ITAB_H thObjmgrec = ITAB_NULL;
	ITAB_H thTextheader = ITAB_NULL;
	ITAB_H thTextlines = ITAB_NULL;
	char xException[256];

	AEOI_API01 *tObjmgrec;

	//tc_strdup("16.04.2018",&erc_release_date); //Temp Date

	printf("\nChangeNo : %s ",dml_numER);
	printf("\nDMLDescription : %s",DMLDescription);
	printf("\nERC_RELEASE_DATE : %s",erc_release_date);
	
	SETCHAR(eChangeHeader.ChangeNo,dml_numER);
	SETNUM(eChangeHeader.Status,"01");
	SETCHAR(eChangeHeader.AuthGroup,"");

	SETCHAR(eChangeHeader.ValidFrom,erc_release_date);
	SETCHAR(eChangeHeader.Descript,DMLDescription);
	SETCHAR(eChangeHeader.ReasonChg,"");
	SETCHAR(eChangeHeader.DeletionMark,"");
	SETCHAR(eChangeHeader.IndateRule,"");
	SETCHAR(eChangeHeader.OutdateRule,"");
	SETCHAR(eChangeHeader.Function,"");
	SETCHAR(eChangeHeader.ChangeLeader,"");
	SETCHAR(eChangeHeader.EffectivityType,"");
	SETCHAR(eChangeHeader.OverridingMark,"");
	SETNUM(eChangeHeader.Rank,"");
	SETNUM(eChangeHeader.ReleaseKey,"");
	SETCHAR(eChangeHeader.StatusProfile,"");
	SETCHAR(eChangeHeader.TechRel,"");
	SETCHAR(eChangeHeader.BasicChange,"");
	SETCHAR(eFlAle,"");
	SETCHAR(eFlCommitAndWait,"X");
	SETCHAR(eFlNoCommitWork,"");
	SETCHAR(eObjectBom.Active,"");
	SETCHAR(eObjectBom.Locked,"");
	SETCHAR(eObjectBom.ObjRequ,"");
	SETCHAR(eObjectBom.MgtrecGen,"");
	SETCHAR(eObjectBom.GenNew,"");
	SETCHAR(eObjectBom.GenDialog,"");
	SETCHAR(eObjectBomCus.Active,"");
	SETCHAR(eObjectBomCus.Locked,"");
	SETCHAR(eObjectBomCus.ObjRequ,"");
	SETCHAR(eObjectBomCus.MgtrecGen,"");
	SETCHAR(eObjectBomCus.GenNew,"");
	SETCHAR(eObjectBomCus.GenDialog,"");
	SETCHAR(eObjectBomDoc.Active,"");
	SETCHAR(eObjectBomDoc.Locked,"");
	SETCHAR(eObjectBomDoc.ObjRequ,"");
	SETCHAR(eObjectBomDoc.MgtrecGen,"");
	SETCHAR(eObjectBomDoc.GenNew,"");
	SETCHAR(eObjectBomDoc.GenDialog,"");
	SETCHAR(eObjectBomEqui.Active,"");
	SETCHAR(eObjectBomEqui.Locked,"");
	SETCHAR(eObjectBomEqui.ObjRequ,"");
	SETCHAR(eObjectBomEqui.MgtrecGen,"");
	SETCHAR(eObjectBomEqui.GenNew,"");
	SETCHAR(eObjectBomEqui.GenDialog,"");
	SETCHAR(eObjectBomLoc.Active,"");
	SETCHAR(eObjectBomLoc.Locked,"");
	SETCHAR(eObjectBomLoc.ObjRequ,"");
	SETCHAR(eObjectBomLoc.MgtrecGen,"");
	SETCHAR(eObjectBomLoc.GenNew,"");
	SETCHAR(eObjectBomLoc.GenDialog,"");
	SETCHAR(eObjectBomMat.Active,"X");
	SETCHAR(eObjectBomMat.Locked,"");
	SETCHAR(eObjectBomMat.ObjRequ,"X");
	SETCHAR(eObjectBomMat.MgtrecGen,"X");
	SETCHAR(eObjectBomMat.GenNew,"");
	SETCHAR(eObjectBomMat.GenDialog,"");
	SETCHAR(eObjectBomPsp.Active,"");
	SETCHAR(eObjectBomPsp.Locked,"");
	SETCHAR(eObjectBomPsp.ObjRequ,"");
	SETCHAR(eObjectBomPsp.MgtrecGen,"");
	SETCHAR(eObjectBomPsp.GenNew,"");
	SETCHAR(eObjectBomPsp.GenDialog,"");
	SETCHAR(eObjectBomStd.Active,"");
	SETCHAR(eObjectBomStd.Locked,"");
	SETCHAR(eObjectBomStd.ObjRequ,"");
	SETCHAR(eObjectBomStd.MgtrecGen,"");
	SETCHAR(eObjectBomStd.GenNew,"");
	SETCHAR(eObjectBomStd.GenDialog,"");
	SETCHAR(eObjectChar.Active,"");
	SETCHAR(eObjectChar.Locked,"");
	SETCHAR(eObjectChar.ObjRequ,"");
	SETCHAR(eObjectChar.MgtrecGen,"");
	SETCHAR(eObjectChar.GenNew,"");
	SETCHAR(eObjectChar.GenDialog,"");
	SETCHAR(eObjectCls.Active,"");
	SETCHAR(eObjectCls.Locked,"");
	SETCHAR(eObjectCls.ObjRequ,"");
	SETCHAR(eObjectCls.MgtrecGen,"");
	SETCHAR(eObjectCls.GenNew,"");
	SETCHAR(eObjectCls.GenDialog,"");
	SETCHAR(eObjectClsMaint.Active,"");
	SETCHAR(eObjectClsMaint.Locked,"");
	SETCHAR(eObjectClsMaint.ObjRequ,"");
	SETCHAR(eObjectClsMaint.MgtrecGen,"");
	SETCHAR(eObjectClsMaint.GenNew,"");
	SETCHAR(eObjectClsMaint.GenDialog,"");
	SETCHAR(eObjectConfProf.Active,"");
	SETCHAR(eObjectConfProf.Locked,"");
	SETCHAR(eObjectConfProf.ObjRequ,"");
	SETCHAR(eObjectConfProf.MgtrecGen,"");
	SETCHAR(eObjectConfProf.GenNew,"");
	SETCHAR(eObjectConfProf.GenDialog,"");
	SETCHAR(eObjectDep.Active,"");
	SETCHAR(eObjectDep.Locked,"");
	SETCHAR(eObjectDep.ObjRequ,"");
	SETCHAR(eObjectDep.MgtrecGen,"");
	SETCHAR(eObjectDep.GenNew,"");
	SETCHAR(eObjectDep.GenDialog,"");
	SETCHAR(eObjectDoc.Active,"X");
	SETCHAR(eObjectDoc.Locked,"");
	SETCHAR(eObjectDoc.ObjRequ,"X");
	SETCHAR(eObjectDoc.MgtrecGen,"X");
	SETCHAR(eObjectDoc.GenNew,"");
	SETCHAR(eObjectDoc.GenDialog,"");
	SETCHAR(eObjectHazmat.Active,"");
	SETCHAR(eObjectHazmat.Locked,"");
	SETCHAR(eObjectHazmat.ObjRequ,"");
	SETCHAR(eObjectHazmat.MgtrecGen,"");
	SETCHAR(eObjectHazmat.GenNew,"");
	SETCHAR(eObjectHazmat.GenDialog,"");
	SETCHAR(eObjectMat.Active,"X");
	SETCHAR(eObjectMat.Locked,"");
	SETCHAR(eObjectMat.ObjRequ,"X");
	SETCHAR(eObjectMat.MgtrecGen,"X");
	SETCHAR(eObjectMat.GenNew,"");
	SETCHAR(eObjectMat.GenDialog,"");
	SETCHAR(eObjectPhrase.Active,"");
	SETCHAR(eObjectPhrase.Locked,"");
	SETCHAR(eObjectPhrase.ObjRequ,"");
	SETCHAR(eObjectPhrase.MgtrecGen,"");
	SETCHAR(eObjectPhrase.GenNew,"");
	SETCHAR(eObjectPhrase.GenDialog,"");
	SETCHAR(eObjectPvs.Active,"");
	SETCHAR(eObjectPvs.Locked,"");
	SETCHAR(eObjectPvs.ObjRequ,"");
	SETCHAR(eObjectPvs.MgtrecGen,"");
	SETCHAR(eObjectPvs.GenNew,"");
	SETCHAR(eObjectPvs.GenDialog,"");
	SETCHAR(eObjectPvsAlt.Active,"");
	SETCHAR(eObjectPvsAlt.Locked,"");
	SETCHAR(eObjectPvsAlt.ObjRequ,"");
	SETCHAR(eObjectPvsAlt.MgtrecGen,"");
	SETCHAR(eObjectPvsAlt.GenNew,"");
	SETCHAR(eObjectPvsAlt.GenDialog,"");
	SETCHAR(eObjectPvsRel.Active,"");
	SETCHAR(eObjectPvsRel.Locked,"");
	SETCHAR(eObjectPvsRel.ObjRequ,"");
	SETCHAR(eObjectPvsRel.MgtrecGen,"");
	SETCHAR(eObjectPvsRel.GenNew,"");
	SETCHAR(eObjectPvsRel.GenDialog,"");
	SETCHAR(eObjectPvsVar.Active,"");
	SETCHAR(eObjectPvsVar.Locked,"");
	SETCHAR(eObjectPvsVar.ObjRequ,"");
	SETCHAR(eObjectPvsVar.MgtrecGen,"");
	SETCHAR(eObjectPvsVar.GenNew,"");
	SETCHAR(eObjectPvsVar.GenDialog,"");
	SETCHAR(eObjectSubstance.Active,"");
	SETCHAR(eObjectSubstance.Locked,"");
	SETCHAR(eObjectSubstance.ObjRequ,"");
	SETCHAR(eObjectSubstance.MgtrecGen,"");
	SETCHAR(eObjectSubstance.GenNew,"");
	SETCHAR(eObjectSubstance.GenDialog,"");
	SETCHAR(eObjectTlist.Active,"");
	SETCHAR(eObjectTlist.Locked,"");
	SETCHAR(eObjectTlist.ObjRequ,"");
	SETCHAR(eObjectTlist.MgtrecGen,"");
	SETCHAR(eObjectTlist.GenNew,"");
	SETCHAR(eObjectTlist.GenDialog,"");
	SETCHAR(eObjectTlist2.Active,"");
	SETCHAR(eObjectTlist2.Locked,"");
	SETCHAR(eObjectTlist2.ObjRequ,"");
	SETCHAR(eObjectTlist2.MgtrecGen,"");
	SETCHAR(eObjectTlist2.GenNew,"");
	SETCHAR(eObjectTlist2.GenDialog,"");
	SETCHAR(eObjectTlistA.Active,"");
	SETCHAR(eObjectTlistA.Locked,"");
	SETCHAR(eObjectTlistA.ObjRequ,"");
	SETCHAR(eObjectTlistA.MgtrecGen,"");
	SETCHAR(eObjectTlistA.GenNew,"");
	SETCHAR(eObjectTlistA.GenDialog,"");
	SETCHAR(eObjectTlistE.Active,"");
	SETCHAR(eObjectTlistE.Locked,"");
	SETCHAR(eObjectTlistE.ObjRequ,"");
	SETCHAR(eObjectTlistE.MgtrecGen,"");
	SETCHAR(eObjectTlistE.GenNew,"");
	SETCHAR(eObjectTlistE.GenDialog,"");
	SETCHAR(eObjectTlistM.Active,"");
	SETCHAR(eObjectTlistM.Locked,"");
	SETCHAR(eObjectTlistM.ObjRequ,"");
	SETCHAR(eObjectTlistM.MgtrecGen,"");
	SETCHAR(eObjectTlistM.GenNew,"");
	SETCHAR(eObjectTlistM.GenDialog,"");
	SETCHAR(eObjectTlistN.Active,"");
	SETCHAR(eObjectTlistN.Locked,"");
	SETCHAR(eObjectTlistN.ObjRequ,"");
	SETCHAR(eObjectTlistN.MgtrecGen,"");
	SETCHAR(eObjectTlistN.GenNew,"");
	SETCHAR(eObjectTlistN.GenDialog,"");
	SETCHAR(eObjectTlistQ.Active,"");
	SETCHAR(eObjectTlistQ.Locked,"");
	SETCHAR(eObjectTlistQ.ObjRequ,"");
	SETCHAR(eObjectTlistQ.MgtrecGen,"");
	SETCHAR(eObjectTlistQ.GenNew,"");
	SETCHAR(eObjectTlistQ.GenDialog,"");
	SETCHAR(eObjectTlistR.Active,"");
	SETCHAR(eObjectTlistR.Locked,"");
	SETCHAR(eObjectTlistR.ObjRequ,"");
	SETCHAR(eObjectTlistR.MgtrecGen,"");
	SETCHAR(eObjectTlistR.GenNew,"");
	SETCHAR(eObjectTlistR.GenDialog,"");
	SETCHAR(eObjectTlistS.Active,"");
	SETCHAR(eObjectTlistS.Locked,"");
	SETCHAR(eObjectTlistS.ObjRequ,"");
	SETCHAR(eObjectTlistS.MgtrecGen,"");
	SETCHAR(eObjectTlistS.GenNew,"");
	SETCHAR(eObjectTlistS.GenDialog,"");
	SETCHAR(eObjectTlistT.Active,"");
	SETCHAR(eObjectTlistT.Locked,"");
	SETCHAR(eObjectTlistT.ObjRequ,"");
	SETCHAR(eObjectTlistT.MgtrecGen,"");
	SETCHAR(eObjectTlistT.GenNew,"");
	SETCHAR(eObjectTlistT.GenDialog,"");
	SETCHAR(eObjectValidMatvers.Active,"");
	SETCHAR(eObjectValidMatvers.Locked,"");
	SETCHAR(eObjectValidMatvers.ObjRequ,"");
	SETCHAR(eObjectValidMatvers.MgtrecGen,"");
	SETCHAR(eObjectValidMatvers.GenNew,"");
	SETCHAR(eObjectValidMatvers.GenDialog,"");
	SETCHAR(eObjectVarTab.Active,"");
	SETCHAR(eObjectVarTab.Locked,"");
	SETCHAR(eObjectVarTab.ObjRequ,"");
	SETCHAR(eObjectVarTab.MgtrecGen,"");
	SETCHAR(eObjectVarTab.GenNew,"");
	SETCHAR(eObjectVarTab.GenDialog,"");
	SETCHAR(eValueAssign.ValidFrom,"");
	SETCHAR(eValueAssign.ValidTo,"");
	SETCHAR(eValueAssign.DateMark,"");
	SETCHAR(eValueAssign.Material,"");
	SETCHAR(eValueAssign.SerialnrLow,"");
	SETCHAR(eValueAssign.SerialnrHigh,"");
	SETCHAR(eValueAssign.Class,"");
	SETCHAR(eValueAssign.Classty,"");
	SETCHAR(eValueAssign.Startup,"");
	SETCHAR(eValueAssign.Plant,"");
	SETCHAR(eValueAssign.SernrOi,"");
	SETCHAR(eValueAssign.FlDelete,"");


    if (thAltDates==ITAB_NULL)
	{
		thAltDates = ItCreate("ALT_DATES", sizeof(AEDT_API01), 0, 0);
		if (thAltDates == ITAB_NULL)
			printf("\nItCreate ALT_DATES");
	}
    else if (ItFree(thAltDates) != 0)
		printf("\nItFree ALT_DATES");

    if (thEffectivity==ITAB_NULL)
	{
		thEffectivity = ItCreate("EFFECTIVITY", sizeof(AEEF_API01), 0, 0);
		if (thEffectivity == ITAB_NULL)
			printf("\nItCreate EFFECTIVITY");
	}
    else if (ItFree(thEffectivity) != 0)
		printf("\nItFree EFFECTIVITY");

	if (thObjmgrec==ITAB_NULL)
	{
		thObjmgrec = ItCreate("OBJMGREC", sizeof(AEOI_API01), 0, 0);
		if (thObjmgrec==ITAB_NULL)
			printf("\nItCreate OBJMGREC");
	}
    else if (ItFree(thObjmgrec) != 0)
		printf("\nItFree OBJMGREC");

    if (thTextheader==ITAB_NULL)
	{
		thTextheader = ItCreate("TEXTHEADER", sizeof(CCTHEAD), 0, 0);
		if (thTextheader==ITAB_NULL)
			printf("\nItCreate TEXTHEADER");
	 }
    else if (ItFree(thTextheader) != 0)
		printf("\nItFree TEXTHEADER");

    if (thTextlines==ITAB_NULL)
	{
		thTextlines = ItCreate("TEXTLINES", sizeof(CCTLINE), 0, 0);
		if (thTextlines==ITAB_NULL)
			printf("\nItCreate TEXTLINES");
	}
    else if (ItFree(thTextlines) != 0)
		printf("\nItFree TEXTLINES");

	printf("\nSetOfPartTags in Displaying Object %d",partCnt);
	fprintf(fsuccess,"\nSetOfPartTags in Displaying Object %d",partCnt);

	if(partCnt>0)
	{
		for(p=0;p<partCnt;p++)
		{
			PartTag1=SetOfPartTags[p];
			ITK_CALL(AOM_ask_value_string(PartTag1,"item_id",&PartNumC));
			ITK_CALL(AOM_ask_value_string(PartTag1,"t5_PartType",&part_typeC));
			
			//Skipping Dummy,Dummy Assembly/Component,Info Fit Drw Parts
			if(	tc_strcmp(part_typeC,"D")==0 ||
				tc_strcmp(part_typeC,"DA")==0 ||
				tc_strcmp(part_typeC,"DC")==0 ||
				tc_strcmp(part_typeC,"IFD")==0 ||
				tc_strcmp(part_typeC,"IM")==0 ||
				tc_strcmp(part_typeC,"CP")==0)
			{	continue;	}

			printf("\nAdding partno As Part is %s %s", PartNumC,part_typeC);
			fprintf(fsuccess,"\nAdding partno As Part is %s %s", PartNumC,part_typeC);

			tObjmgrec = ItAppLine(thObjmgrec);
			if (tObjmgrec == NULL)
				printf("\nItAppLine OBJMGREC");

			SETCHAR(tObjmgrec->AltDate,"");
			SETNUM(tObjmgrec->ChgObjtyp,"");
			SETNUM(tObjmgrec->ChgObjtyp,"4");
			SETCHAR(tObjmgrec->BomCat,"");
			SETCHAR(tObjmgrec->BomStdObject,"");
			SETCHAR(tObjmgrec->BomUsage,"");
			SETNUM(tObjmgrec->Chgtypeobj,"");
			SETCHAR(tObjmgrec->DescrObj,"");
			SETCHAR(tObjmgrec->DocType,"");
			SETCHAR(tObjmgrec->DocNumber,"");
			SETCHAR(tObjmgrec->DocVers,"");
			SETCHAR(tObjmgrec->DocPart,"");
			SETCHAR(tObjmgrec->Equipment,"");
			SETCHAR(tObjmgrec->FuncLoc,"");
			SETCHAR(tObjmgrec->Material,PartNumC);
			SETCHAR(tObjmgrec->Plant,"");
			SETCHAR(tObjmgrec->PspElement,"");
			SETCHAR(tObjmgrec->PvsType,"");
			SETCHAR(tObjmgrec->PvsNode,"");
			SETCHAR(tObjmgrec->PvsClassNumber,"");
			SETCHAR(tObjmgrec->PvsClassType,"");
			SETCHAR(tObjmgrec->PvsVariant,"");
			SETCHAR(tObjmgrec->SdOrder,"");
			SETNUM(tObjmgrec->SdOrderI,"");
			SETNUM(tObjmgrec->Textkey,"");
			SETCHAR(tObjmgrec->TlistType,"");
			SETCHAR(tObjmgrec->TlistGrp,"");
			SETCHAR(tObjmgrec->ObjChglock,"");
			SETCHAR(tObjmgrec->StatusProfObj,"");
			SETCHAR(tObjmgrec->FlDelete,"");
		}
	}
	RfcRc = ccap_ecn_create(hRfc,&eChangeHeader,&eFlAle,&eFlCommitAndWait,&eFlNoCommitWork,&eObjectBom,&eObjectBomCus,&eObjectBomDoc,&eObjectBomEqui,&eObjectBomLoc,&eObjectBomMat,&eObjectBomPsp,&eObjectBomStd,&eObjectChar,&eObjectCls,&eObjectClsMaint,&eObjectConfProf,&eObjectDep,&eObjectDoc,&eObjectHazmat,&eObjectMat,&eObjectPhrase,&eObjectPvs,&eObjectPvsAlt,&eObjectPvsRel,&eObjectPvsVar,&eObjectSubstance,&eObjectTlist,&eObjectTlist2,&eObjectTlistA,&eObjectTlistE,&eObjectTlistM,&eObjectTlistN,&eObjectTlistQ,&eObjectTlistR,&eObjectTlistS,&eObjectTlistT,&eObjectValidMatvers,&eObjectVarTab,&eValueAssign,&iChangeNo,thAltDates,thEffectivity,thObjmgrec,thTextheader,thTextlines,xException);
	switch (RfcRc)
	{
		case RFC_OK:
			printf("\necn create: %u",RFC_OK);
			fprintf(fsuccess,"\necn create: %u",RFC_OK);
		break;
		case RFC_EXCEPTION :
			printf("\nRFC Exception: %s",xException);
			fprintf(fsuccess,"\nRFC Exception: %s",xException);
		break;
		default:;
	}
	EXIT:
	printf("exit from bapi");
	return RfcRc;
}

RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException)
{
	RFC_RC RfcRc;
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[1];
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfMATNR;
	Exporting[0].leng = sizeof(MATNR);
	Exporting[0].addr = eMatnr;

	Exporting[1].name = "PLANT";
	Exporting[1].nlen = 5;
	Exporting[1].type = handleOfWERKS_D;
	Exporting[1].leng = sizeof(WERKS_D);
	Exporting[1].addr = eWerks;

	Exporting[2].name = NULL;

	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_MATERIAL_GETALL",Exporting,Tables);

	switch (RfcRc)
	{
	  	case RFC_OK :

			Importing[0].name = "CLIENTDATA";
			Importing[0].nlen = 10;
			Importing[0].type = handleOfCLIENTDATA;
			Importing[0].leng = sizeof(CLIENTDATA);
			Importing[0].addr = iView;

			Importing[1].name = "PLANTDATA";
			Importing[1].nlen = 9;
			Importing[1].type = handleOfPLANTDATA;
			Importing[1].leng = sizeof(PLANTDATA);
			Importing[1].addr = iMrpView;

			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
	  			case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				default:;
			}
		default:;
	}
	return RfcRc;
}

int GetCSPstat(char cMaterial[15])
{
	char xException[256];
	RFC_HANDLE hRfc;
	RFC_RC RfcRc;
	MATNR eMatnr;
	WERKS_D eWerks;
	PLANTDATA iMrpView;
	CLIENTDATA iView;

	char *plantcode=NULL;
	tc_strdup("1001",&plantcode);

	printf("\nProcessing GetCSPstat:[%s,%s]",cMaterial,plantcode);

	hRfc = BapiLogon();

	tc_strcpy(SAPpstat,"");
	tc_strcpy(MRPpstat,"");

	SETCHAR(eMatnr.Matnr,cMaterial);
	//SETCHAR(eMatnr.Matnr,part_noDup);
	SETCHAR(eWerks.WerksD,plantcode);

	RfcRc = export_CSpastat(hRfc
							,&eMatnr
							,&eWerks
							,&iMrpView
							,&iView
							,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			//printf("\n In RFC_OK case...\n");	fflush(stdout);
			GETCHAR(iView.MAINT_STAT, SAPpstat);
			//nlsStrTrimTrailWhiteSpace(SAPpstat);
			//nlsStrTrimLeadWhiteSpace(SAPpstat);
			SAPpstat[tc_strlen(SAPpstat)] = '\0';

			GETCHAR(iMrpView.MAINT_STAT, MRPpstat);
			//nlsStrTrimTrailWhiteSpace(MRPpstat);
			//nlsStrTrimLeadWhiteSpace(MRPpstat);
			MRPpstat[tc_strlen(MRPpstat)] = '\0';

		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			exit(0);
		break;
		default:
			printf("\nOther Failure!");
			exit(0);
	}

	RfcClose(hRfc);
	return 0;
}

void CLL_BAPI_MATERIAL_SAVEDATA(void)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256];

	BAPIMATHEAD eBapiMatHead;
	BAPI_MARA	eBasicView;
	BAPI_MARAX	eBasicViewx;
	RMMG1_AENNR eRmmg1_Aennr;
	BAPIRET2	eBapiret2;

	ITAB_H thBapi_Makt = ITAB_NULL;
	ITAB_H thBapi_Marm = ITAB_NULL;
	ITAB_H thBapi_Marmx = ITAB_NULL;
	ITAB_H thBapi_Mean = ITAB_NULL;
	ITAB_H thBAPIE1PAREX3 = ITAB_NULL;
	ITAB_H thBAPIE1PAREXX3 = ITAB_NULL;

	BAPI_MAKT *tBapi_Makt;
	BAPI_MARM *tBapi_Marm;
	BAPI_MARMX *tBapi_Marmx;
	BAPI_MEAN *tBapi_Mean;

	BAPIE1PAREX3 *tBAPIE1PAREX3;
	BAPIE1PAREXX3 *tBAPIE1PAREXX3;

	pstat='0';

	tc_strcpy(SAPpstat,"");
	tc_strcpy(MRPpstat,"");
	pstat='0';
	GetCSPstat(part_noDup);
	printf("\n SAPpstat:[%s][%s][%s]",part_noDup,SAPpstat,MRPpstat) ; fflush(stdout);
	fprintf(fsuccess,"\n SAPpstat:[%s][%s][%s]",part_noDup,SAPpstat,MRPpstat) ; fflush(fsuccess);

	pstat_basicFun();
	printf("\n... pstat Values are :%c:",pstat);fflush(stdout);
	fprintf(fsuccess,"\n... pstat Values are :%c:",pstat);fflush(stdout);
	//pstat='0';
	if (pstat=='K')
	{
			printf("\nMessage for Basic Material Create: Material %s already exists \n", part_noDup);
			printf("\n****************************************************************");
			fprintf(fsuccess, "\nMessage for Basic Material Create: Material %s already exists", part_noDup);
			fprintf(fsuccess, "\n****************************************************************");
	}
	else
	{
		hRfc = BapiLogon();
		SETCHAR(eBapiMatHead.Material,part_noDup);
		SETCHAR(eBapiMatHead.Ind_Sector,"M");
		SETCHAR(eBapiMatHead.Matl_Type,mat_type);
		SETCHAR(eBapiMatHead.Basic_View,"X");
		SETCHAR(eBapiMatHead.Sales_View,"");
		SETCHAR(eBapiMatHead.Purchase_View,"");
		SETCHAR(eBapiMatHead.Mrp_View,"");
		SETCHAR(eBapiMatHead.Forecast_View,"");
		SETCHAR(eBapiMatHead.Work_Sched_View,"");
		SETCHAR(eBapiMatHead.Prt_View,"");
		SETCHAR(eBapiMatHead.Storage_View,"");
		SETCHAR(eBapiMatHead.Warehouse_View,"");
		SETCHAR(eBapiMatHead.Quality_View,"");
		SETCHAR(eBapiMatHead.Account_View,"");
		SETCHAR(eBapiMatHead.Cost_View,"");
		SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
		SETCHAR(eBapiMatHead.Material_External,"");
		SETCHAR(eBapiMatHead.MateriaL_Guid,"");
		SETCHAR(eBapiMatHead.Material_Version,"");
		SETCHAR(eRmmg1_Aennr.Aennr,dml_numER);

		SETCHAR(eBasicView.Del_Flag,"");
		SETCHAR(eBasicView.Matl_Group,mat_grp);

		if(OldMatNoDup == NULL)
		{
			SETCHAR(eBasicView.Old_Mat_No,"");
			SETCHAR(eBasicViewx.Old_Mat_No,"");
		}
		else
		{
			SETCHAR(eBasicView.Old_Mat_No,OldMatNoDup);
			SETCHAR(eBasicViewx.Old_Mat_No,"X");
		}

		SETCHAR(eBasicView.Base_Uom,meas_unit);
		SETCHAR(eBasicView.Base_Uom_Iso,meas_unit);
		SETCHAR(eBasicView.Po_Unit,"");
		SETCHAR(eBasicView.Po_Unit_Iso,"");
		if(doc_noDup == NULL)
		{
			SETCHAR(eBasicView.Document,"");
			SETCHAR(eBasicViewx.Document,"");
		}
		else
		{
			SETCHAR(eBasicView.Document,doc_noDup);
			SETCHAR(eBasicViewx.Document,"X");
		}

		if(dwg_typeDup == NULL)
		{
			SETCHAR(eBasicView.Doc_Type,"");
			SETCHAR(eBasicViewx.Doc_Type,"");
		}
		else
		{
			SETCHAR(eBasicView.Doc_Type,dwg_typeDup);
			SETCHAR(eBasicViewx.Doc_Type,"X");
		}

		if(dwg_revDup == NULL)
		{
			SETCHAR(eBasicView.Doc_Vers,"");
			SETCHAR(eBasicViewx.Doc_Vers,"");
		}
		else
		{
			SETCHAR(eBasicView.Doc_Vers,dwg_revDup);
			SETCHAR(eBasicViewx.Doc_Vers,"X");
		}

		SETCHAR(eBasicView.Doc_Format,"");
		SETCHAR(eBasicView.Doc_Chg_No,"");
		SETCHAR(eBasicView.Page_No,"");
		if(sizeDup == NULL)
		{
			SETNUM(eBasicView.No_Sheets,"");
			SETCHAR(eBasicViewx.No_Sheets,"");
		}
		else
		{
			SETNUM(eBasicView.No_Sheets,sizeDup);
			SETCHAR(eBasicViewx.No_Sheets,"X");
		}

		SETCHAR(eBasicView.Prod_Memo,"");
		SETCHAR(eBasicView.Pageformat,"");
		SETCHAR(eBasicView.Size_Dim,"");
		SETCHAR(eBasicView.Basic_Matl,"");
		SETCHAR(eBasicView.Std_Descr,"");
		SETCHAR(eBasicView.Dsn_Office,"");
		SETCHAR(eBasicView.Pur_Valkey,"");

		SETBCD(eBasicView.Net_Weight,net_wtDup,3);
		SETCHAR(eBasicViewx.Net_Weight,"X");
		if(weight_unit == NULL)
		{
			SETCHAR(eBasicView.Unit_Of_Wt,"");
			SETCHAR(eBasicViewx.Unit_Of_Wt,"");
		}
		else
		{
			SETCHAR(eBasicView.Unit_Of_Wt,weight_unit);
			SETCHAR(eBasicViewx.Unit_Of_Wt,"X");
		}

		if(weight_unit == NULL)
		{
			SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
			SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
		}
		else
		{
			SETCHAR(eBasicView.Unit_Of_Wt_Iso,weight_unit);
			SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"X");
		}

		SETCHAR(eBasicView.Container,"");
		SETCHAR(eBasicView.Stor_Conds,"");
		SETCHAR(eBasicView.Temp_Conds,"");
		SETCHAR(eBasicView.Trans_Grp,"");
		SETCHAR(eBasicView.Haz_Mat_No,"");
		SETCHAR(eBasicView.Division,division);
		SETCHAR(eBasicView.Competitor,"");
		SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);
		SETCHAR(eBasicView.Proc_Rule,"");
		SETCHAR(eBasicView.Sup_Source,"");
		SETCHAR(eBasicView.Season,"");
		SETCHAR(eBasicView.Label_Type,"");
		SETCHAR(eBasicView.Label_Form,"");
		SETCHAR(eBasicView.Prod_Hier,"");
		SETCHAR(eBasicView.Cad_Id,"");
		SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
		SETCHAR(eBasicView.Pack_Wt_Un,"");
		SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
		SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
		SETCHAR(eBasicView.Pack_Vo_Un,"");
		SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
		SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
		SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
		SETCHAR(eBasicView.Var_Ord_Un,"");
		SETCHAR(eBasicView.Batch_Mgmt,"");
		SETCHAR(eBasicView.Sh_Mat_Typ,"");
		SETBCD(eBasicView.Fill_Level,"0",0);
		SETINT2(&eBasicView.Stack_Fact,"0");
		SETCHAR(eBasicView.Mat_Grp_Sm,"");
		SETCHAR(eBasicView.Authoritygroup,"");
		SETCHAR(eBasicView.Qm_Procmnt,"");
		SETCHAR(eBasicView.Catprofile,"");
		SETBCD(eBasicView.Minremlife,"0",0);
		SETBCD(eBasicView.Shelf_Life,"0",0);
		SETBCD(eBasicView.Stor_Pct,"0",0);
		SETCHAR(eBasicView.Pur_Status,"");
		SETCHAR(eBasicView.Sal_Status,"");
		SETDATE(eBasicView.Pvalidfrom,"");
		SETDATE(eBasicView.Svalidfrom,"");
		SETCHAR(eBasicView.Envt_Rlvt,"");
		SETCHAR(eBasicView.Prod_Alloc,"");
		SETCHAR(eBasicView.Qual_Dik,"");
		SETCHAR(eBasicView.Manu_Mat,"");
		SETCHAR(eBasicView.Mfr_No,"");
		SETCHAR(eBasicView.Inv_Mat_No,"");
		SETCHAR(eBasicView.Manuf_Prof,"");
		SETCHAR(eBasicView.Hazmatprof,"");
		SETCHAR(eBasicView.High_Visc,"");
		SETCHAR(eBasicView.Looseorliq,"");
		SETCHAR(eBasicView.Closed_Box,"");
		SETCHAR(eBasicView.Appd_B_Rec,"");
		SETNUM(eBasicView.Matcmpllvl,"00");
		SETCHAR(eBasicView.Par_Eff,"");
		SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
		SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
		SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
		SETCHAR(eBasicView.Item_Cat,"");
		SETCHAR(eBasicView.Haz_Mat_No_External,"");
		SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
		SETCHAR(eBasicView.Haz_Mat_No_Version,"");
		SETCHAR(eBasicView.Inv_Mat_No_External,"");
		SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
		SETCHAR(eBasicView.Inv_Mat_No_Version,"");
		SETCHAR(eBasicView.Material_Fixed,"");
		SETCHAR(eBasicView.Cm_Relevance_Flag,"");
		SETCHAR(eBasicView.Sled_Bbd,"");
		SETCHAR(eBasicView.Gtin_Variant,"");
		SETCHAR(eBasicView.Serialization_Level,"");
		SETCHAR(eBasicView.Pl_Ref_Mat,"");
		SETCHAR(eBasicView.Extmatlgrp,"");
		SETCHAR(eBasicView.Uomusage,"");
		SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
		SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
		SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");

		SETCHAR(eBasicViewx.Del_Flag,"");
		SETCHAR(eBasicViewx.Matl_Group,"X");

		SETCHAR(eBasicViewx.Base_Uom,"X");
		SETCHAR(eBasicViewx.Base_Uom_Iso,"X");
		SETCHAR(eBasicViewx.Po_Unit,"");
		SETCHAR(eBasicViewx.Po_Unit_Iso,"");
		SETCHAR(eBasicViewx.Doc_Format,"");
		SETCHAR(eBasicViewx.Doc_Chg_No,"");
		SETCHAR(eBasicViewx.Page_No,"");

		SETCHAR(eBasicViewx.Prod_Memo,"");
		SETCHAR(eBasicViewx.Pageformat,"");
		SETCHAR(eBasicViewx.Size_Dim,"X");
		SETCHAR(eBasicViewx.Basic_Matl,"");
		SETCHAR(eBasicViewx.Std_Descr,"");
		SETCHAR(eBasicViewx.Dsn_Office,"");
		SETCHAR(eBasicViewx.Pur_Valkey,"");

		SETCHAR(eBasicViewx.Container,"");
		SETCHAR(eBasicViewx.Stor_Conds,"");
		SETCHAR(eBasicViewx.Temp_Conds,"");
		SETCHAR(eBasicViewx.Trans_Grp,"");
		SETCHAR(eBasicViewx.Haz_Mat_No,"");
		SETCHAR(eBasicViewx.Division,"X");
		SETCHAR(eBasicViewx.Competitor,"");
		SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
		SETCHAR(eBasicViewx.Proc_Rule,"");
		SETCHAR(eBasicViewx.Sup_Source,"");
		SETCHAR(eBasicViewx.Season,"");
		SETCHAR(eBasicViewx.Label_Type,"");
		SETCHAR(eBasicViewx.Label_Form,"");
		SETCHAR(eBasicViewx.Prod_Hier,"");
		SETCHAR(eBasicViewx.Cad_Id,"");
		SETCHAR(eBasicViewx.Allowed_Wt,"");
		SETCHAR(eBasicViewx.Pack_Wt_Un,"");
		SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
		SETCHAR(eBasicViewx.Allwd_Vol,"");
		SETCHAR(eBasicViewx.Pack_Vo_Un,"");
		SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
		SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
		SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
		SETCHAR(eBasicViewx.Var_Ord_Un,"");
		SETCHAR(eBasicViewx.Batch_Mgmt,"");
		SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
		SETCHAR(eBasicViewx.Fill_Level,"");
		SETCHAR(eBasicViewx.Stack_Fact,"");
		SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
		SETCHAR(eBasicViewx.Authoritygroup,"");
		SETCHAR(eBasicViewx.Qm_Procmnt,"");
		SETCHAR(eBasicViewx.Catprofile,"");
		SETCHAR(eBasicViewx.Minremlife,"");
		SETCHAR(eBasicViewx.Shelf_Life,"");
		SETCHAR(eBasicViewx.Stor_Pct,"");
		SETCHAR(eBasicViewx.Pur_Status,"");
		SETCHAR(eBasicViewx.Sal_Status,"");
		SETCHAR(eBasicViewx.Pvalidfrom,"");
		SETCHAR(eBasicViewx.Svalidfrom,"");
		SETCHAR(eBasicViewx.Envt_Rlvt,"");
		SETCHAR(eBasicViewx.Prod_Alloc,"");
		SETCHAR(eBasicViewx.Qual_Dik,"");
		SETCHAR(eBasicViewx.Manu_Mat,"");
		SETCHAR(eBasicViewx.Mfr_No,"");
		SETCHAR(eBasicViewx.Inv_Mat_No,"");
		SETCHAR(eBasicViewx.Manuf_Prof,"");
		SETCHAR(eBasicViewx.Hazmatprof,"");
		SETCHAR(eBasicViewx.High_Visc,"");
		SETCHAR(eBasicViewx.Looseorliq,"");
		SETCHAR(eBasicViewx.Closed_Box,"");
		SETCHAR(eBasicViewx.Appd_B_Rec,"");
		SETCHAR(eBasicViewx.Matcmpllvl,"");
		SETCHAR(eBasicViewx.Par_Eff,"");
		SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
		SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
		SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
		SETCHAR(eBasicViewx.Item_Cat,"");
		SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
		SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
		SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
		SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
		SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
		SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
		SETCHAR(eBasicViewx.Material_Fixed,"");
		SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
		SETCHAR(eBasicViewx.Sled_Bbd,"");
		SETCHAR(eBasicViewx.Gtin_Variant,"");
		SETCHAR(eBasicViewx.Serialization_Level,"");
		SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
		SETCHAR(eBasicViewx.Extmatlgrp,"");
		SETCHAR(eBasicViewx.Uomusage,"");
		SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
		SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
		SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");
			
		thBapi_Makt = ITAB_NULL;
		thBapi_Marm = ITAB_NULL;
		thBapi_Marmx = ITAB_NULL;
		thBapi_Mean = ITAB_NULL;

		thBAPIE1PAREX3 = ITAB_NULL;
		thBAPIE1PAREXX3 = ITAB_NULL;

		if (thBapi_Makt==ITAB_NULL)
		{
			thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
			if (thBapi_Makt==ITAB_NULL)
				printf("\nItCreate MATERIALDESCRIPTION");
		}
		else
		  {
			if (ItFree(thBapi_Makt) != 0)
				printf("\nItFree MATERIALDESCRIPTION");
		  }

		if (thBapi_Marm==ITAB_NULL)
		{
			 thBapi_Marm = ItCreate("UNITSOFMEASURE",sizeof(BAPI_MARM),0,0);
			 if (thBapi_Marm==ITAB_NULL)
				 printf("\nItCreate UNITSOFMEASURE");
		}
		else
		{
			if (ItFree(thBapi_Marm)!= 0)
				printf("\nItFree UNITSOFMEASURE");
		}

		if (thBapi_Marmx==ITAB_NULL)
		{
			 thBapi_Marmx = ItCreate("UNITSOFMEASUREX",sizeof(BAPI_MARMX),0,0);
			if (thBapi_Marmx==ITAB_NULL)
				printf("\nItCreate UNITSOFMEASUREX");
		}
		else
		{
			if (ItFree(thBapi_Marmx)!= 0)
				printf("\nItFree UNITSOFMEASUREX");
		}

		if (thBapi_Mean==ITAB_NULL)
		{
			 thBapi_Mean = ItCreate("INTERNATIONALARTNOS",sizeof(BAPI_MEAN),0,0);
			 if (thBapi_Mean==ITAB_NULL)
				 printf("\nItCreate INTERNATIONALARTNOS");
		}
		else
		{
			if (ItFree(thBapi_Mean)!= 0)
				printf("\nItFree INTERNATIONALARTNOS");
		}

		if (thBAPIE1PAREX3==ITAB_NULL)
		{
				thBAPIE1PAREX3 = ItCreate("EXTENSIONIN",sizeof(BAPIE1PAREX3),0,0);
				if (thBAPIE1PAREX3==ITAB_NULL)
					rfc_error("ItCreate EXTENSIONIN");
		}
		else
		{
				if (ItFree(thBAPIE1PAREX3)!= 0)
					rfc_error("ItFree EXTENSIONIN");
		}

		if (thBAPIE1PAREXX3==ITAB_NULL)
		{
			thBAPIE1PAREXX3 = ItCreate("EXTENSIONINX",sizeof(BAPIE1PAREXX3),0,0);
			if (thBAPIE1PAREXX3==ITAB_NULL)
				rfc_error("ItCreate EXTENSIONINX");
		}
		else
		{
			if (ItFree(thBAPIE1PAREXX3)!= 0)
				rfc_error("ItFree EXTENSIONINX");
		}

		printf("\nNO. OF LINES IN OBJ. ARE: %d",ItFill(thBapi_Makt));
		tBapi_Makt = ItAppLine(thBapi_Makt) ;
		tBapi_Marm  = ItAppLine(thBapi_Marm) ;
		tBapi_Marmx = ItAppLine(thBapi_Marmx) ;
		tBapi_Mean =  ItAppLine(thBapi_Mean) ;

		tBAPIE1PAREX3 = ItAppLine(thBAPIE1PAREX3) ;
		tBAPIE1PAREXX3 = ItAppLine(thBAPIE1PAREXX3) ;

		if (tBAPIE1PAREX3 == NULL) rfc_error("ItAppLine BAPIE1PAREX3");
		if (tBAPIE1PAREXX3 == NULL) rfc_error("ItAppLine BAPIE1PAREXX3");


		if (tBapi_Makt == NULL)
		printf("\nItAppLine BAPI_MAKT");

		SETCHAR(tBapi_Makt->Langu,"EN");
		SETCHAR(tBapi_Makt->Langu_Iso,"");
		SETCHAR(tBapi_Makt->Matl_Desc,descDup);
		SETCHAR(tBapi_Makt->Del_Flag,"");

		if (tBapi_Marm == NULL)
		printf("\nItAppLine BAPI_MARM second table");

		SETCHAR(tBapi_Marm->Alt_Unit,meas_unit);
		SETCHAR(tBapi_Marm->Alt_Unit_Iso,meas_unit);
		SETBCD(tBapi_Marm->Numerator,"1",0);
		SETBCD(tBapi_Marm->Denominatr,"1",0);
		SETCHAR(tBapi_Marm->Ean_Upc,"");
		SETCHAR(tBapi_Marm->Ean_Cat,"");
		SETCHAR(tBapi_Marm->Length,"");
		SETCHAR(tBapi_Marm->Width,"");
		SETCHAR(tBapi_Marm->Height,"");
		SETCHAR(tBapi_Marm->Unit_Dim,"");
		SETCHAR(tBapi_Marm->Unit_Dim_Iso,"");
		SETBCD(tBapi_Marm->Volume,volume,3);
		SETCHAR(tBapi_Marm->VolumeUnit,vol_unit);
		SETCHAR(tBapi_Marm->VolumeUnit_Iso,vol_unit);
		SETBCD(tBapi_Marm->Gross_Wt,gross_weightDup,3);
		SETCHAR(tBapi_Marm->Unit_Of_Wt,weight_unit);
		SETCHAR(tBapi_Marm->Unit_Of_Wt_Iso,weight_unit);
		SETCHAR(tBapi_Marm->Del_Flag,"");
		SETCHAR(tBapi_Marm->Sub_Uom,"");
		SETCHAR(tBapi_Marm->Sub_Uom_Iso,"");
		SETCHAR(tBapi_Marm->Gtin_Variant,"");

		if (tBapi_Marmx == NULL)
		printf("\nItAppLine BAPI_MARMX");

		SETCHAR(tBapi_Marmx->Alt_Unit,meas_unit);
		SETCHAR(tBapi_Marmx->Alt_Unit_Iso,meas_unit);
		SETCHAR(tBapi_Marmx->Numerator,"X");
		SETCHAR(tBapi_Marmx->Denominatr,"X");
		SETCHAR(tBapi_Marmx->Ean_Upc,"");
		SETCHAR(tBapi_Marmx->Ean_Cat,"");
		SETCHAR(tBapi_Marmx->Length,"");
		SETCHAR(tBapi_Marmx->Width,"");
		SETCHAR(tBapi_Marmx->Height,"");
		SETCHAR(tBapi_Marmx->Unit_Dim,"");
		SETCHAR(tBapi_Marmx->Unit_Dim_Iso,"");
		SETCHAR(tBapi_Marmx->Volume,"X");
		SETCHAR(tBapi_Marmx->VolumeUnit,"X");
		SETCHAR(tBapi_Marmx->VolumeUnit_Iso,"X");
		SETCHAR(tBapi_Marmx->Gross_Wt,"X");
		SETCHAR(tBapi_Marmx->Unit_Of_Wt,"X");
		SETCHAR(tBapi_Marmx->Unit_Of_Wt_Iso,"X");
		SETCHAR(tBapi_Marmx->Sub_Uom,"");
		SETCHAR(tBapi_Marmx->Sub_Uom_Iso,"");
		SETCHAR(tBapi_Marmx->Gtin_Variant,"");

		SETCHAR(tBAPIE1PAREX3->STRUCTURE,"BAPI_TE_MARA");
		SETCHAR(tBAPIE1PAREX3->VALUEPART1,part_noDupDes);
		SETCHAR(tBAPIE1PAREX3->VALUEPART2,"");
		SETCHAR(tBAPIE1PAREX3->VALUEPART3,"");
		SETCHAR(tBAPIE1PAREX3->VALUEPART4,"");

		SETCHAR(tBAPIE1PAREXX3->STRUCTURE,"BAPI_TE_MARAX");
		SETCHAR(tBAPIE1PAREXX3->VALUEPART1,part_noDupDesx);
		SETCHAR(tBAPIE1PAREXX3->VALUEPART2,"");
		SETCHAR(tBAPIE1PAREXX3->VALUEPART3,"");
		SETCHAR(tBAPIE1PAREXX3->VALUEPART4,"");

		RfcRc = ZBAPI_MATERIAL_SAVEDATA(hRfc,&eBapiMatHead,&eBasicView,&eBasicViewx,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,thBapi_Marm,thBapi_Marmx,thBAPIE1PAREX3,thBAPIE1PAREXX3,xException);
		switch (RfcRc)
		{
			case RFC_OK :
				printf("\nMessage for Basic Material [%s] Create:%s",part_noDup,eBapiret2.Message);
				printf("\n******************************************************");
				fprintf(fsuccess,"\nMessage for Basic Material [%s] Create:%s",part_noDup,eBapiret2.Message);
				fprintf(fsuccess, "\n******************************************************");
			break;
			case RFC_EXCEPTION :
				printf("\nRFC EXCEPTION:%s",xException);
				fprintf(fsuccess,"\nRFC EXCEPTION:%s",xException);
			break;
			case RFC_SYS_EXCEPTION :
				printf("\nsystem exception raised");
				fprintf(fsuccess,"\nsystem exception raised");
			break;
			case RFC_FAILURE :
				printf("\nfailure");
			break;
			default :
				printf("\nother failure");
			break;
		}

		if(ItDelete(thBapi_Makt) != 0)
			printf("ItDelete thBapi_Makt");
		if(ItDelete(thBapi_Marm) != 0)
			printf("ItDelete tBapi_Marm");
		if(ItDelete(thBapi_Marmx) != 0)
			printf("ItDelete thBapi_Marmx");
		if(ItDelete(thBAPIE1PAREX3) != 0)
			rfc_error("ItDelete thBAPIE1PAREX3");
		if(ItDelete(thBAPIE1PAREXX3) != 0)
			rfc_error("ItDelete thBAPIE1PAREXX3");
	}
	RfcClose(RfcRc);
}

RFC_RC ZBAPI_MATERIAL_SAVEDATA(RFC_HANDLE hRfc,
						BAPIMATHEAD *eBapiMatHead,
						BAPI_MARA	*eBasicView,
						BAPI_MARAX	*eBasicViewx,
						RMMG1_AENNR *eRmmg1_Aennr,
						BAPIRET2	*eBapiret2,
						ITAB_H       thBapi_Makt,
						ITAB_H       thBapi_Marm,
						ITAB_H       thBapi_Marmx,
						ITAB_H       thBAPIE1PAREX3,
						ITAB_H       thBAPIE1PAREXX3,
						char *xException)
{
	RFC_PARAMETER Exporting[5];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[6];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "HEADDATA";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfBAPIMATHEAD;
	Exporting[0].leng = sizeof(BAPIMATHEAD);
	Exporting[0].addr = eBapiMatHead;

	Exporting[1].name = "CLIENTDATA";
	Exporting[1].nlen = 10;
	Exporting[1].type = handleOfBAPI_MARA;
	Exporting[1].leng = sizeof(BAPI_MARA);
	Exporting[1].addr = eBasicView;

	Exporting[2].name = "CLIENTDATAX";
	Exporting[2].nlen = 11;
	Exporting[2].type = handleOfBAPI_MARAX;
	Exporting[2].leng = sizeof(BAPI_MARAX);
	Exporting[2].addr = eBasicViewx;

	Exporting[3].name = "CHANGE_NUMBER";
	Exporting[3].nlen = 13;
	Exporting[3].type = handleOfRMMG1_AENNR;
	Exporting[3].leng = sizeof(RMMG1_AENNR);
	Exporting[3].addr = eRmmg1_Aennr;

	Exporting[4].name = NULL;

	Tables[0].name     = "MATERIALDESCRIPTION";
	Tables[0].nlen     = 19;
	Tables[0].type     = handleOfBAPI_MAKT;
	Tables[0].ithandle = thBapi_Makt;

	Tables[1].name     = "UNITSOFMEASURE";
	Tables[1].nlen     = 14;
	Tables[1].type     = handleOfBAPI_MARM;
	Tables[1].ithandle = thBapi_Marm;

	Tables[2].name     = "UNITSOFMEASUREX";
	Tables[2].nlen     = 15;
	Tables[2].type     = handleOfBAPI_MARMX;
	Tables[2].ithandle = thBapi_Marmx;

	Tables[3].name     = "EXTENSIONIN";
	Tables[3].nlen     = 11;
	Tables[3].type     = handleOfBAPIE1PAREX3;
	Tables[3].ithandle = thBAPIE1PAREX3;

	Tables[4].name     = "EXTENSIONINX";
	Tables[4].nlen     = 12;
	Tables[4].type     = handleOfBAPIE1PAREXX3;
	Tables[4].ithandle = thBAPIE1PAREXX3;

	Tables[5].name = NULL;

	RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK :
			Importing[0].name = "RETURN";
			Importing[0].nlen = 6;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = eBapiret2;

			Importing[1].name = NULL;
			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION :
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION :
					strcpy(xException,RfcException);
				break;
				default:;
			}
		break;
		default :
			printf("\nNOT RFC OK");
	}

	return RfcRc;
}

void UPD_BAPI_MATERIAL_SAVEDATA(void)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256];

	BAPIMATHEAD eBapiMatHead;
	BAPI_MARA	eBasicView;
	BAPI_MARAX	eBasicViewx;
	BAPIRET2	eBapiret2;

	printf("\nInside Design Drawing Version update");
	fprintf(fsuccess,"\nInside Design Drawing Version update");

	hRfc = BapiLogon();
	SETCHAR(eBapiMatHead.Material,part_noDup);
	SETCHAR(eBapiMatHead.Ind_Sector,"M");
	SETCHAR(eBapiMatHead.Matl_Type,mat_type);
	SETCHAR(eBapiMatHead.Basic_View,"X");
	SETCHAR(eBapiMatHead.Sales_View,"");
	SETCHAR(eBapiMatHead.Purchase_View,"");
	SETCHAR(eBapiMatHead.Mrp_View,"");
	SETCHAR(eBapiMatHead.Forecast_View,"");
	SETCHAR(eBapiMatHead.Work_Sched_View,"");
	SETCHAR(eBapiMatHead.Prt_View,"");
	SETCHAR(eBapiMatHead.Storage_View,"");
	SETCHAR(eBapiMatHead.Warehouse_View,"");
	SETCHAR(eBapiMatHead.Quality_View,"");
	SETCHAR(eBapiMatHead.Account_View,"");
	SETCHAR(eBapiMatHead.Cost_View,"");
	SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
	SETCHAR(eBapiMatHead.Material_External,"");
	SETCHAR(eBapiMatHead.MateriaL_Guid,"");
	SETCHAR(eBapiMatHead.Material_Version,"");

	SETCHAR(eBasicView.Del_Flag,"");
	SETCHAR(eBasicView.Matl_Group,"");
	SETCHAR(eBasicView.Base_Uom,"");
	SETCHAR(eBasicView.Base_Uom_Iso,"");
	SETCHAR(eBasicView.Po_Unit,"");
	SETCHAR(eBasicView.Po_Unit_Iso,"");
	SETCHAR(eBasicView.Doc_Format,"");
	SETCHAR(eBasicView.Doc_Chg_No,"");
	SETCHAR(eBasicView.Page_No,"");
	SETNUM(eBasicView.No_Sheets,"");
	SETCHAR(eBasicView.Prod_Memo,"");
	SETCHAR(eBasicView.Pageformat,"");
	SETCHAR(eBasicView.Size_Dim,"");
	SETCHAR(eBasicView.Basic_Matl,"");
	SETCHAR(eBasicView.Std_Descr,"");
	SETCHAR(eBasicView.Dsn_Office,"");
	SETCHAR(eBasicView.Pur_Valkey,"");
	SETBCD(eBasicView.Net_Weight,myzeroDup3,3);

	if(OldMatNoDup == NULL)
	{
		SETCHAR(eBasicView.Old_Mat_No,"");
		SETCHAR(eBasicViewx.Old_Mat_No,"");
	}
	else
	{
		SETCHAR(eBasicView.Old_Mat_No,OldMatNoDup);
		SETCHAR(eBasicViewx.Old_Mat_No,"X");
	}
	//Design Drawing Details Update on Basic View 2 Start
	if(doc_noDup == NULL)
	{
		SETCHAR(eBasicView.Document,"");
		SETCHAR(eBasicViewx.Document,"");
	}
	else
	{
		SETCHAR(eBasicView.Document,doc_noDup);
		SETCHAR(eBasicViewx.Document,"X");
	}

	if(dwg_typeDup == NULL)
	{
		SETCHAR(eBasicView.Doc_Type,"");
		SETCHAR(eBasicViewx.Doc_Type,"");
	}
	else
	{
		SETCHAR(eBasicView.Doc_Type,dwg_typeDup);
		SETCHAR(eBasicViewx.Doc_Type,"X");
	}

	if(dwg_revDup == NULL)
	{
		SETCHAR(eBasicView.Doc_Vers,"");
		SETCHAR(eBasicViewx.Doc_Vers,"");
	}
	else
	{
		SETCHAR(eBasicView.Doc_Vers,dwg_revDup);
		SETCHAR(eBasicViewx.Doc_Vers,"X");
	}
	
	//Design Drawing Details Update on Basic View 2 End

	if(weight_unit == NULL)
	{
		SETCHAR(eBasicView.Unit_Of_Wt,"");
		SETCHAR(eBasicViewx.Unit_Of_Wt,"");
	}
	else
	{
		SETCHAR(eBasicView.Unit_Of_Wt,weight_unit);
		SETCHAR(eBasicViewx.Unit_Of_Wt,"X");
	}

	if(weight_unit == NULL)
	{
		SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
		SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
	}
	else
	{
		SETCHAR(eBasicView.Unit_Of_Wt_Iso,weight_unit);
		SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"X");
	}
	SETCHAR(eBasicView.Container,"");
	SETCHAR(eBasicView.Stor_Conds,"");
	SETCHAR(eBasicView.Temp_Conds,"");
	SETCHAR(eBasicView.Trans_Grp,"");
	SETCHAR(eBasicView.Haz_Mat_No,"");
	SETCHAR(eBasicView.Division,"");
	SETCHAR(eBasicView.Competitor,"");
	SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);
	SETCHAR(eBasicView.Proc_Rule,"");
	SETCHAR(eBasicView.Sup_Source,"");
	SETCHAR(eBasicView.Season,"");
	SETCHAR(eBasicView.Label_Type,"");
	SETCHAR(eBasicView.Label_Form,"");
	SETCHAR(eBasicView.Prod_Hier,"");
	SETCHAR(eBasicView.Cad_Id,"");
	SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
	SETCHAR(eBasicView.Pack_Wt_Un,"");
	SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
	SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
	SETCHAR(eBasicView.Pack_Vo_Un,"");
	SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
	SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
	SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
	SETCHAR(eBasicView.Var_Ord_Un,"");
	SETCHAR(eBasicView.Batch_Mgmt,"");
	SETCHAR(eBasicView.Sh_Mat_Typ,"");
	SETBCD(eBasicView.Fill_Level,"0",0);
	SETINT2(&eBasicView.Stack_Fact,"0");
	SETCHAR(eBasicView.Mat_Grp_Sm,"");
	SETCHAR(eBasicView.Authoritygroup,"");
	SETCHAR(eBasicView.Qm_Procmnt,"");
	SETCHAR(eBasicView.Catprofile,"");
	SETBCD(eBasicView.Minremlife,"0",0);
	SETBCD(eBasicView.Shelf_Life,"0",0);
	SETBCD(eBasicView.Stor_Pct,"0",0);
	SETCHAR(eBasicView.Pur_Status,"");
	SETCHAR(eBasicView.Sal_Status,"");
	SETDATE(eBasicView.Pvalidfrom,"");
	SETDATE(eBasicView.Svalidfrom,"");
	SETCHAR(eBasicView.Envt_Rlvt,"");
	SETCHAR(eBasicView.Prod_Alloc,"");
	SETCHAR(eBasicView.Qual_Dik,"");
	SETCHAR(eBasicView.Manu_Mat,"");
	SETCHAR(eBasicView.Mfr_No,"");
	SETCHAR(eBasicView.Inv_Mat_No,"");
	SETCHAR(eBasicView.Manuf_Prof,"");
	SETCHAR(eBasicView.Hazmatprof,"");
	SETCHAR(eBasicView.High_Visc,"");
	SETCHAR(eBasicView.Looseorliq,"");
	SETCHAR(eBasicView.Closed_Box,"");
	SETCHAR(eBasicView.Appd_B_Rec,"");
	SETNUM(eBasicView.Matcmpllvl,"00");
	SETCHAR(eBasicView.Par_Eff,"");
	SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
	SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
	SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
	SETCHAR(eBasicView.Item_Cat,"");
	SETCHAR(eBasicView.Haz_Mat_No_External,"");
	SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
	SETCHAR(eBasicView.Haz_Mat_No_Version,"");
	SETCHAR(eBasicView.Inv_Mat_No_External,"");
	SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
	SETCHAR(eBasicView.Inv_Mat_No_Version,"");
	SETCHAR(eBasicView.Material_Fixed,"");
	SETCHAR(eBasicView.Cm_Relevance_Flag,"");
	SETCHAR(eBasicView.Sled_Bbd,"");
	SETCHAR(eBasicView.Gtin_Variant,"");
	SETCHAR(eBasicView.Serialization_Level,"");
	SETCHAR(eBasicView.Pl_Ref_Mat,"");
	SETCHAR(eBasicView.Extmatlgrp,"");
	SETCHAR(eBasicView.Uomusage,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");

	SETCHAR(eBasicViewx.Del_Flag,"");
	SETCHAR(eBasicViewx.Matl_Group,"");
	SETCHAR(eBasicViewx.Base_Uom,"");
	SETCHAR(eBasicViewx.Base_Uom_Iso,"");
	SETCHAR(eBasicViewx.Po_Unit,"");
	SETCHAR(eBasicViewx.Po_Unit_Iso,"");
	SETCHAR(eBasicViewx.Doc_Format,"");
	SETCHAR(eBasicViewx.Doc_Chg_No,"");
	SETCHAR(eBasicViewx.Page_No,"");
	SETCHAR(eBasicViewx.No_Sheets,"");
	SETCHAR(eBasicViewx.Prod_Memo,"");
	SETCHAR(eBasicViewx.Pageformat,"");
	SETCHAR(eBasicViewx.Size_Dim,"");
	SETCHAR(eBasicViewx.Basic_Matl,"");
	SETCHAR(eBasicViewx.Std_Descr,"");
	SETCHAR(eBasicViewx.Dsn_Office,"");
	SETCHAR(eBasicViewx.Pur_Valkey,"");
	SETCHAR(eBasicViewx.Net_Weight,"");
	SETCHAR(eBasicViewx.Unit_Of_Wt,"");
	SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
	SETCHAR(eBasicViewx.Container,"");
	SETCHAR(eBasicViewx.Stor_Conds,"");
	SETCHAR(eBasicViewx.Temp_Conds,"");
	SETCHAR(eBasicViewx.Trans_Grp,"");
	SETCHAR(eBasicViewx.Haz_Mat_No,"");
	SETCHAR(eBasicViewx.Division,"");
	SETCHAR(eBasicViewx.Competitor,"");
	SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
	SETCHAR(eBasicViewx.Proc_Rule,"");
	SETCHAR(eBasicViewx.Sup_Source,"");
	SETCHAR(eBasicViewx.Season,"");
	SETCHAR(eBasicViewx.Label_Type,"");
	SETCHAR(eBasicViewx.Label_Form,"");
	SETCHAR(eBasicViewx.Prod_Hier,"");
	SETCHAR(eBasicViewx.Cad_Id,"");
	SETCHAR(eBasicViewx.Allowed_Wt,"");
	SETCHAR(eBasicViewx.Pack_Wt_Un,"");
	SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
	SETCHAR(eBasicViewx.Allwd_Vol,"");
	SETCHAR(eBasicViewx.Pack_Vo_Un,"");
	SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
	SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
	SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
	SETCHAR(eBasicViewx.Var_Ord_Un,"");
	SETCHAR(eBasicViewx.Batch_Mgmt,"");
	SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
	SETCHAR(eBasicViewx.Fill_Level,"");
	SETCHAR(eBasicViewx.Stack_Fact,"");
	SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
	SETCHAR(eBasicViewx.Authoritygroup,"");
	SETCHAR(eBasicViewx.Qm_Procmnt,"");
	SETCHAR(eBasicViewx.Catprofile,"");
	SETCHAR(eBasicViewx.Minremlife,"");
	SETCHAR(eBasicViewx.Shelf_Life,"");
	SETCHAR(eBasicViewx.Stor_Pct,"");
	SETCHAR(eBasicViewx.Pur_Status,"");
	SETCHAR(eBasicViewx.Sal_Status,"");
	SETCHAR(eBasicViewx.Pvalidfrom,"");
	SETCHAR(eBasicViewx.Svalidfrom,"");
	SETCHAR(eBasicViewx.Envt_Rlvt,"");
	SETCHAR(eBasicViewx.Prod_Alloc,"");
	SETCHAR(eBasicViewx.Qual_Dik,"");
	SETCHAR(eBasicViewx.Manu_Mat,"");
	SETCHAR(eBasicViewx.Mfr_No,"");
	SETCHAR(eBasicViewx.Inv_Mat_No,"");
	SETCHAR(eBasicViewx.Manuf_Prof,"");
	SETCHAR(eBasicViewx.Hazmatprof,"");
	SETCHAR(eBasicViewx.High_Visc,"");
	SETCHAR(eBasicViewx.Looseorliq,"");
	SETCHAR(eBasicViewx.Closed_Box,"");
	SETCHAR(eBasicViewx.Appd_B_Rec,"");
	SETCHAR(eBasicViewx.Matcmpllvl,"");
	SETCHAR(eBasicViewx.Par_Eff,"");
	SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
	SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
	SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
	SETCHAR(eBasicViewx.Item_Cat,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
	SETCHAR(eBasicViewx.Material_Fixed,"");
	SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
	SETCHAR(eBasicViewx.Sled_Bbd,"");
	SETCHAR(eBasicViewx.Gtin_Variant,"");
	SETCHAR(eBasicViewx.Serialization_Level,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
	SETCHAR(eBasicViewx.Extmatlgrp,"");
	SETCHAR(eBasicViewx.Uomusage,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");

	printf("\nhi");

	RfcRc = BAPI_MATERIAL_UPDATEDATA(hRfc
			,&eBapiMatHead
			,&eBasicView
			,&eBasicViewx
			,&eBapiret2
			/*,thBapi_Makt
			,thBapi_Marm
			,thBapi_Marmx*/
			,xException);

	switch (RfcRc)
	{
		case RFC_OK :
					printf("\nMessage for Basic Material Create:-%s",eBapiret2.Message);
					fflush(stdout);
					break;
		case RFC_EXCEPTION :
					printf("\nRFC EXCEPTION:-%s",xException);
					break;
		case RFC_SYS_EXCEPTION :
					printf("\nsystem exception raised");
					break;
		case RFC_FAILURE :
					printf("\nfailure");
					break;
		default :
					printf("\nother failure");
					break;
	}
	RfcClose(hRfc);
}

RFC_RC BAPI_MATERIAL_UPDATEDATA(RFC_HANDLE hRfc,
						BAPIMATHEAD *eBapiMatHead,
						BAPI_MARA	*eBasicView,
						BAPI_MARAX	*eBasicViewx,
						BAPIRET2	*eBapiret2,
						char *xException)
{
	RFC_PARAMETER Exporting[4];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[1];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	printf("bi");
	Exporting[0].name = "HEADDATA";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfBAPIMATHEAD;
	Exporting[0].leng = sizeof(BAPIMATHEAD);
	Exporting[0].addr = eBapiMatHead;

	Exporting[1].name = "CLIENTDATA";
	Exporting[1].nlen = 10;
	Exporting[1].type = handleOfBAPI_MARA;
	Exporting[1].leng = sizeof(BAPI_MARA);
	Exporting[1].addr = eBasicView;

	Exporting[2].name = "CLIENTDATAX";
	Exporting[2].nlen = 11;
	Exporting[2].type = handleOfBAPI_MARAX;
	Exporting[2].leng = sizeof(BAPI_MARAX);
	Exporting[2].addr = eBasicViewx;

	Exporting[3].name = NULL;

	Tables[0].name = NULL;

	/*Tables[0].name     = "MATERIALDESCRIPTION";
	Tables[0].nlen     = 19;
	Tables[0].type     = handleOfBAPI_MAKT;
	Tables[0].ithandle = thBapi_Makt;

	Tables[1].name = NULL;*/

	RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK :
			 Importing[0].name = "RETURN";  /*RETURN */
			 Importing[0].nlen = 6;
			 Importing[0].type = TYPC;
			 Importing[0].leng = sizeof(BAPIRET2);
			 Importing[0].addr = eBapiret2;

			 Importing[1].name = NULL;
			 RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			printf("\nRfcException:%s",RfcException);
			 switch (RfcRc)
			 {
				 case RFC_SYS_EXCEPTION :
					strcpy(xException,RfcException);
					break;
				 case RFC_EXCEPTION :
					strcpy(xException,RfcException);
					break;
				default: ;
			 }
			break;
			default :
				printf("\nNOT RFC OK");
	}

	return RfcRc;
}

int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3])
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;
	AENNR eAennr;
	CCMATNR eMatnr;
	CC_REVLV eRevlv;
	BAPIRET2 iMessg;
	SYST_SUBRC iRetval;
	char xException[256];
	char s[1024] = { 0 } ;

	hRfc = BapiLogon();

	printf("\nRevision Creation DmlNo.:[%s]\t PartNo.:[%s]\tRevSheetstatus:[%s]",sap_dml_no,sap_part_no,sap_rev_sheet_status);
	fprintf(fsuccess,"\nRevision Creation DmlNo.:[%s]\t PartNo.:[%s]\tRevSheetstatus:[%s]",sap_dml_no,sap_part_no,sap_rev_sheet_status);

	SETCHAR(eAennr.Aennr,sap_dml_no);
	SETCHAR(eMatnr.Ccmatnr,sap_part_no);
	SETCHAR(eRevlv.CcRevlv,sap_rev_sheet_status);

	RfcRc = zpprfc_revisionnum_change(hRfc,&eAennr,&eMatnr,&eRevlv,&iMessg,&iRetval,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\n[%s]Revision Creation Message	:%s",sap_part_no,iMessg.Message);
			fprintf(fsuccess,"\n[%s]Revision Creation Message	:%s",sap_part_no,iMessg.Message);fflush(stdout);
			/*GETCHAR(iMessg.Type,s);
			F_OUTK("TYPE",10,30,s);
			GETCHAR(iMessg.Id,s);
			F_OUTK("ID",10,30,s);
			GETNUM(iMessg.Number,s);
			F_OUTK("NUMBER",10,30,s);
			GETCHAR(iMessg.Message,s);
			F_OUTK("MESSAGE",10,30,s);
			GETCHAR(iMessg.Log_No,s);
			F_OUTK("LOG_NO",10,30,s);
			GETNUM(iMessg.Log_Msg_No,s);
			F_OUTK("LOG_MSG_NO",10,30,s);
			GETCHAR(iMessg.Message_V1,s);
			F_OUTK("MESSAGE_V1",10,30,s);
			GETCHAR(iMessg.Message_V2,s);
			F_OUTK("MESSAGE_V2",10,30,s);
			GETCHAR(iMessg.Message_V3,s);
			F_OUTK("MESSAGE_V3",10,30,s);
			GETCHAR(iMessg.Message_V4,s);
			F_OUTK("MESSAGE_V4",10,30,s);
			GETCHAR(iMessg.Parameter,s);
			F_OUTK("PARAMETER",10,30,s);
			GETINT(iMessg.Row,s);
			F_OUTK("ROW",10,30,s);
			GETCHAR(iMessg.Field,s);
			F_OUTK("FIELD",10,30,s);
			GETCHAR(iMessg.System,s);
			F_OUTK("SYSTEM",10,30,s);*/
			NL;
		break;
		case RFC_EXCEPTION:
			printf("\nRFC_EXCEPTION raised");
			fprintf(fsuccess,"\nRFC_EXCEPTION raised");
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nsystem exception raised");
			fprintf(fsuccess,"\nsystem exception raised");
		break;
		case RFC_FAILURE:
			printf("\nfailure");
		break;
		default:
			printf("\nother failure");
	}
	RfcClose(hRfc);

	return 0;
}

RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,char *xException)
{
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[2];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "HEADDATA";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfBAPIMATHEAD;
	Exporting[0].leng = sizeof(BAPIMATHEAD);
	Exporting[0].addr = eBapiMatHead;

	Exporting[1].name = "CHANGE_NUMBER";
	Exporting[1].nlen = 13;
	Exporting[1].type = handleOfRMMG1_AENNR;
	Exporting[1].leng = sizeof(RMMG1_AENNR);
	Exporting[1].addr = eRmmg1_Aennr;

	Exporting[2].name = NULL;

	Tables[0].name     = "MATERIALDESCRIPTION";
	Tables[0].nlen     = 19;
	Tables[0].type     = handleOfBAPI_MAKT;
	Tables[0].ithandle = thBapi_Makt;


	Tables[1].name = NULL;

	RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			Importing[0].name = "RETURN";
			Importing[0].nlen = 6;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = eBapiret2;

			Importing[1].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
			break;
	}
	return RfcRc;
}

void descChange(char *Part_Num,char *DescStr,char *dml_no_arg)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256];
	char sap_msg[60];
	BAPIMATHEAD eBapiMatHead;
	RMMG1_AENNR eRmmg1_Aennr;
	BAPIRET2 eBapiret2;
	
	ITAB_H thBapi_Makt = ITAB_NULL;
	BAPI_MAKT *tBapi_Makt;

	printf("\nPart Number : [%s] Description : [%s] ChangeNo : [%s]",Part_Num,DescStr,dml_no_arg);
	fprintf(fsuccess,"\nPart Number : [%s] Description : [%s] ChangeNo : [%s]",Part_Num,DescStr,dml_no_arg);
	hRfc = BapiLogon();
	SETCHAR(eBapiMatHead.Material,Part_Num);
	SETCHAR(eBapiMatHead.Ind_Sector,"");
	SETCHAR(eBapiMatHead.Matl_Type,"");
	SETCHAR(eBapiMatHead.Basic_View,"");
	SETCHAR(eBapiMatHead.Sales_View,"");
	SETCHAR(eBapiMatHead.Purchase_View,"");
	SETCHAR(eBapiMatHead.Mrp_View,"");
	SETCHAR(eBapiMatHead.Forecast_View,"");
	SETCHAR(eBapiMatHead.Work_Sched_View,"");
	SETCHAR(eBapiMatHead.Prt_View,"");
	SETCHAR(eBapiMatHead.Storage_View,"");
	SETCHAR(eBapiMatHead.Warehouse_View,"");
	SETCHAR(eBapiMatHead.Quality_View,"");
	SETCHAR(eBapiMatHead.Account_View,"");
	SETCHAR(eBapiMatHead.Cost_View,"");
	SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
	SETCHAR(eBapiMatHead.Material_External,"");
	SETCHAR(eBapiMatHead.MateriaL_Guid,"");
	SETCHAR(eBapiMatHead.Material_Version,"");

	SETCHAR(eRmmg1_Aennr.Aennr,dml_no_arg);

	thBapi_Makt = ITAB_NULL;
	if (thBapi_Makt==ITAB_NULL)
	{
		thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
		if (thBapi_Makt==ITAB_NULL)
		rfc_error("ItCreate MATERIALDESCRIPTION");
	}
	else if (ItFree(thBapi_Makt) != 0)
	{
		rfc_error("ItFree MATERIALDESCRIPTION");
	}

	tBapi_Makt = ItAppLine (thBapi_Makt) ;
	if (tBapi_Makt == NULL)
	{
		rfc_error("ItAppLine BAPI_MAKT");
	}

	SETCHAR(tBapi_Makt->Langu,"EN");
	SETCHAR(tBapi_Makt->Langu_Iso,"");
	SETCHAR(tBapi_Makt->Matl_Desc,DescStr);
	SETCHAR(tBapi_Makt->Del_Flag,"");

	RfcRc = zbapi_material_savedata_mrp(hRfc,&eBapiMatHead,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			sprintf(sap_msg,"%.*s:",sizeof(sap_msg),eBapiret2.Message);
			printf("\n\nDesc Change Message: %s\n",sap_msg);
			fprintf(fsuccess,"\nDesc Change Message:%s",sap_msg);
			break;
		case RFC_EXCEPTION:
			printf("\nRFC EXCEPTION: %s",xException);
			break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			break;
		default:
			printf("\nOther Failure!");
		break;
	}
	if (ItDelete(thBapi_Makt) != 0)
	{
		rfc_error("ItDelete thBapi_Makt");
	}

	RfcClose(hRfc);
}

int getChassisType(tag_t PartTag,char *part_type,char *part_ColorId)
{
	int status;
	int Count = 0;
	tag_t	VehicleRevTag		= NULLTAG;
	tag_t	VehicleMstTag		= NULLTAG;
	tag_t	PartTagDup			= NULLTAG;
	tag_t	*NonColPartTags		= NULLTAG;
	tag_t	*VCChildTags		= NULLTAG;
	
	char *partType = NULL;

	tc_strdup(part_type,&partType);
	PartTagDup = PartTag;

	if (tc_strcmp(part_ColorId,"C")==0)
	{
		ITK_CALL(AOM_ask_value_tags(PartTag,"TC_Is_Represented_By",&Count,&NonColPartTags));
		if (Count>0)
		{
			PartTagDup = NonColPartTags[0];
			ITK_CALL(AOM_ask_value_string(PartTagDup,"t5_PartType",&partType));
		}
		else
		{
			printf("\nColour VC to Non Colour VC relation not found");
			fprintf(fsuccess,"\nColour VC to Non Colour VC relation not found");
		}
	}

	if (tc_strcmp(partType,"VC")==0 || tc_strcmp(partType,"VCCR")==0)
	{
		ITK_CALL(AOM_ask_value_tags(PartTagDup,"ps_children",&Count,&VCChildTags));
		if (Count>0)
		{
			VehicleRevTag = VCChildTags[0];
			ITK_CALL(AOM_ask_value_tag(VehicleRevTag,"items_tag",&VehicleMstTag));
			ITK_CALL(AOM_UIF_ask_value(VehicleMstTag,"T5_HasChassisTypeNo",&OldMatNo));
			tc_strdup(OldMatNo,&OldMatNoDup);
		}
		else
		{
			printf("\nVC Vehicle relation not found");
			fprintf(fsuccess,"\nVC Vehicle relation not found");
		}
	}

	if (tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0)
	{
		ITK_CALL(AOM_ask_value_tag(PartTagDup,"items_tag",&VehicleMstTag));
		ITK_CALL(AOM_UIF_ask_value(VehicleMstTag,"T5_HasChassisTypeNo",&OldMatNo));
		tc_strdup(OldMatNo,&OldMatNoDup);
	}

	printf("\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
	fprintf(fsuccess,"\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
}

extern int ITK_user_main (int argc, char ** argv )
{
    int status;
	int kk=0;
	int is=0;
	int sflag=0;
	int RefDocflag=0;
	int ii=2;
	int doccount=0;
	int *ip=&ii;
	int len=0;
	int Refcount=0;
	int DocPartCnt=0;
	int RefRelPartCnt=0;
	int resultCount =0;
	int n_entries = 1; //no. of query input arg
	int n_tags_found = 0;
	int tskcnt =0,t=0,p=0,ref=0;

	tag_t queryTag = NULLTAG;
	tag_t ErcDmlTag = NULLTAG;
	tag_t *SetOfDmlTasksTag= NULLTAG;
	tag_t PartTag= NULLTAG;
	tag_t PartMasterTag = NULLTAG;

	tag_t docOPtr = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t resultOutputTag = NULLTAG;
    tag_t docRelObjs=NULLTAG;
    tag_t *docObjs=NULLTAG;
	//tag_t *refdocObjs=NULLTAG;
	GRM_relation_t *refdocObjs=NULLTAG;
    tag_t doctag=NULLTAG;
    tag_t specDocRelObj=NULLTAG;
    tag_t refdocRelObj=NULLTAG;
    tag_t objTypeTag=NULLTAG;
    tag_t specParttag=NULLTAG;
    tag_t RefPartTag=NULLTAG;
	//tag_t *DocPartObj = NULLTAG;
	tag_t	*DesignTags	= NULLTAG;

	GRM_relation_t *DocPartObj=NULLTAG;
	GRM_relation_t *RefRelPartObj=NULLTAG;

	date_t DmlRelDate;
	char* sUserName	= NULL;
	char* sPassword = NULL;

	char *DmlRelDateStr=NULL;

	char *DmlId=NULL;
	char *DmlDesc=NULL;
	char *DmlRelType=NULL;
	char *DmlRelStat=NULL;
	char *TaskId=NULL;
	char *PartNum=NULL;
	char *PartNumDup=NULL;
	char *PartRev=NULL;
	char *PartRevDup=NULL;
	char *PartRelStat=NULL;
	char *part_type=NULL;
	char *unit=NULL;
	char *LatRevName=NULL;
	char *chrp=NULL;
	char *part_typeDup=NULL;
	char *unitDup=NULL;
	char *doc_no=NULL;
	char *DmlTagId=NULL;
	char *KeywordDescription=NULL;
	char *KeywordDescriptionDup=NULL;
	char *MaterialClass=NULL;
	char *MaterialClassDup=NULL;
	char *PartFamily=NULL;
	char *PartFamilyDup=NULL;
	char *PartRevision=NULL;
	char *specPartNum=NULL;
	char *specPartRev=NULL;
	char *specPartRevDup=NULL;
	char *specPartRelStat=NULL;
	char *RefDocRelObjType=NULL;
	char *RefPartNum=NULL;
	char *RefPartRev=NULL;
	char *RefPartRelStat=NULL;

	char  type_name[TCTYPE_name_size_c+1];
	const char *cTemp="item_id";
	static RFC_RC RfcRc;

	

	meas_unit=(char *) malloc(500 * sizeof(char));

	tmpDrwNum = (char *)malloc(500 * sizeof(char));
	tmpDrwNum1 = (char *)malloc(500 * sizeof(char));
	tmpDrwRev = (char *)malloc(500 * sizeof(char));
	tmpDrwSeq = (char *)malloc(500 * sizeof(char));

	SAPpstat = (char *)malloc(500 * sizeof(char));
	MRPpstat = (char *)malloc(500 * sizeof(char));
	myzeroDup1 = (char *)malloc(500 * sizeof(char));
	myzeroDup2 = (char *)malloc(500 * sizeof(char));
	myzeroDup3 = (char *)malloc(500 * sizeof(char));
	myzeroDup4 = (char *)malloc(500 * sizeof(char));
	std_price = (char *)malloc(500 * sizeof(char));
	moving_avg_price = (char *)malloc(500 * sizeof(char));
	cost_lot_size = (char *)malloc(500 * sizeof(char));
	mat_type = (char *)malloc(500 * sizeof(char));
	descDup = (char *)malloc(500 * sizeof(char));
	dml_numER=(char *) MEM_alloc(20 * sizeof(char));
	DMLDescription=(char *) MEM_alloc(40 * sizeof(char));
	erc_release_date=(char *) MEM_alloc(40 * sizeof(char));



	//char *qry_entries[1] = {"Name"};
	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	//printf("\n 111111"); fflush(stdout);

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	inputDML = ITK_ask_cli_argument("-d=");
	iSapServer = ITK_ask_cli_argument("-s=");

	if(tc_strcmp(sUserName,"")==0 || tc_strcmp(sPassword,"")==0 || tc_strcmp(inputDML,"")==0 || tc_strcmp(iSapServer,"")==0)
	{
		printf("\nercSAPMatUA -u=userid -p=password -d=dml_number -s=PVP\n");fflush(stdout);
		goto CLEANUP;
	}
	
	sprintf(fsuccess_name,"/user/plmsap/PLMSAP/PLM_SAP_ERC_LOG/Erc_Sap_Mat_%s.log",inputDML);
	//sprintf(fsuccess_name,"Erc_Sap_Mat_%s.log",inputDML);
	fsuccess = fopen(fsuccess_name,"a");

	if(QRY_find("ERCDMLReleased", &queryTag));
	printf("\nAfter ERCDMLReleased : QRY_find \n");fflush(stdout);
	if (queryTag)
	{
		printf("\nFound Query ERCDMLReleased  \n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query ERCDMLReleased");fflush(stdout);
		goto CLEANUP;
	}

	  printf("\n inputDML:%s: \n ", inputDML);fflush(stdout);
	  fprintf(fsuccess,"\nInputDML:%s: \n ", inputDML);fflush(stdout);

      qry_values[0] = inputDML;

	if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));

    printf("\t resultCount :%d:\n", resultCount);fflush(stdout);

	if(resultCount>0)
	{
       ErcDmlTag=outTag[0];
       printf("\nQuery Executed  \n");fflush(stdout);

	}
	
	if (ErcDmlTag != NULLTAG)
	{
		printf("\nDML : %s Found With ERCDMLReleased Query",inputDML);fflush(stdout);
		fprintf(fsuccess,"\nDML : %s Found With ERCDMLReleased Query",inputDML);fflush(stdout);
	}
	else
	{ 
		printf("\nERC DML %s not found in TCUA\n",inputDML);
		fprintf(fsuccess,"\nERC DML %s not found in TCUA\n",inputDML);
		goto CLEANUP;
	}

	if(TCTYPE_ask_object_type(ErcDmlTag,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\nErcDmlTag -> objTypeTag  %s\n", type_name);fflush(stdout);
	fprintf(fsuccess,"\nErcDmlTag -> objTypeTag  %s\n", type_name);fflush(stdout);


	if(strcmp(type_name,"ChangeRequestRevision")==0)
	{
		ITK_CALL(AOM_ask_value_string(ErcDmlTag,"item_id",&DmlId));
		ITK_CALL(AOM_ask_value_string(ErcDmlTag,"current_name",&DmlDesc));
		ITK_CALL(AOM_ask_value_string(ErcDmlTag,"t5_rlstype",&DmlRelType));
		ITK_CALL(AOM_UIF_ask_value(ErcDmlTag,"release_status_list",&DmlRelStat));
		ITK_CALL(AOM_ask_value_date(ErcDmlTag,"date_released",&DmlRelDate));
		//ITK_CALL(ITK_date_to_string(DmlRelDate,&DmlRelDateStr));
		ITK_CALL(DATE_date_to_string(DmlRelDate,"%d/%m/%Y",&DmlRelDateStr));
		printf("\nDmlId [%s]  DmlRelType [%s] LifeCycleState [%s] DmlDesc [%s]\n",DmlId,DmlRelType,DmlRelStat,DmlDesc);	fflush(stdout);
		fprintf(fsuccess,"\nDmlId [%s]  DmlRelType [%s] LifeCycleState [%s] DmlDesc [%s]\n",DmlId,DmlRelType,DmlRelStat,DmlDesc);	fflush(stdout);
		
		printf("\nDmlReleasedDate [%s] \n",DmlRelDateStr);	fflush(stdout);
		fprintf(fsuccess,"\nDmlReleasedDate [%s] \n",DmlRelDateStr);

		//if(strcmp(DmlRelStat,"ERC Released")!=0)
		if(tc_strstr(DmlRelStat,"ERC Released")==NULL)
		{
			printf("\nDML [%s] is not ERC Released LifeCycleState [%s]\n",DmlId,DmlRelStat); fflush(stdout);
			fprintf(fsuccess,"\nDML [%s] is not ERC Released LifeCycleState [%s]\n",DmlId,DmlRelStat); fflush(stdout);
			goto CLEANUP;
		}

		tc_strcpy(dml_numER, DmlId);
		strcat(dml_numER,"ER");
		
		printf("\nDML Change Number [%s]",dml_numER); fflush(stdout);
		fprintf(fsuccess,"\nDML Change Number [%s]",dml_numER); fflush(stdout);

		tc_strcpy(DMLDescription,dml_numER);
		strcat(DMLDescription," ");
		strcat(DMLDescription,DmlDesc);

		printf("\nDML SAP Desc [%s]",DMLDescription); fflush(stdout);
		fprintf(fsuccess,"\nDML SAP Desc [%s]",DMLDescription); fflush(stdout);

		//DmlReleasedDate [11/04/2018]
		strcpy(erc_release_date,"");
		strcpy(erc_release_date,strtok(DmlRelDateStr,"/"));
		strcat(erc_release_date,".");
		strcat(erc_release_date,strtok(NULL,"/"));
		strcat(erc_release_date,".");
		strcat(erc_release_date,strtok(NULL,"/"));

		printf("\nerc_release_date [%s] \n",erc_release_date);	fflush(stdout);
		fprintf(fsuccess,"\nerc_release_date [%s] \n",erc_release_date);	fflush(stdout);

		ITK_CALL(AOM_ask_value_tags(ErcDmlTag,"T5_DMLTaskRelation",&tskcnt,&SetOfDmlTasksTag));
		printf("\nDML Task Count : %d\n",tskcnt);fflush(stdout);
		fprintf(fsuccess,"\nDML Task Count : %d\n",tskcnt);fflush(stdout);
		
		if (tskcnt>0)
		{
			for(t=0;t<tskcnt;t++)
			{
				ITK_CALL(AOM_ask_value_string(SetOfDmlTasksTag[t],"item_id",&TaskId));
				printf("\nDML Task [%s]",TaskId);fflush(stdout);
				fprintf(fsuccess,"\nDML Task [%s]",TaskId);fflush(stdout);
				
				if (tc_strstr(TaskId,"APL")!=NULL)
				{
					printf("\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
					fprintf(fsuccess,"\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
					continue;
				}

				printf("\n******Material Creation Starting for [%s]******",TaskId);fflush(stdout);
				fprintf(fsuccess,"\n******Material Creation Starting for [%s]******",TaskId);fflush(stdout);

				AOM_ask_value_tags(SetOfDmlTasksTag[t],"CMHasSolutionItem",&partCnt,&SetOfPartTags);
				printf("\nNo of Design Rev=%d\n",partCnt);
				fprintf(fsuccess,"\nNo of Design Rev=%d\n",partCnt);
				if (partCnt>0)
				{
					displaying_objects();
					for(p=0;p<partCnt;p++)
					{
						PartTag=SetOfPartTags[p];

						//if(TCTYPE_ask_object_type(PartTag,&objTypeTag));
						//if(TCTYPE_ask_name(objTypeTag,type_name));

						//printf("\nPart Class [%s]",type_name); fflush(stdout);

						ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
						tc_strdup(PartNum,&part_noDup);

						ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
						tc_strdup(PartRev,&PartRevDup);

						ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
						tc_strdup(part_type,&part_typeDup);

						if(	tc_strcmp(part_typeDup,"D")==0 ||
							tc_strcmp(part_typeDup,"DA")==0 ||
							tc_strcmp(part_typeDup,"DC")==0 ||
							tc_strcmp(part_typeDup,"IFD")==0 ||
							tc_strcmp(part_typeDup,"IM")==0 ||
							tc_strcmp(part_typeDup,"CP")==0)
						{
							printf("\nPart %s Part Type %s Skiping...",part_noDup,part_typeDup);
							fprintf(fsuccess,"\nPart %s Part Type %s ! Skiping...",part_noDup,part_typeDup);
							continue;
						}

						//CR-FY21-0218
						if (tc_strlen(part_noDup)==12)
						{
							if(STRNG_find_last_char(part_noDup,'R')!=NULL || STRNG_find_last_char(part_noDup,'L')!=NULL)
							{
								if (
									tc_strcmp(part_typeDup,"VC")==0 ||
									tc_strcmp(part_typeDup,"CCVC")==0 ||
									tc_strcmp(part_typeDup,"VCCR")==0 ||
									tc_strcmp(part_typeDup,"CKDVC") == 0 ||
									tc_strcmp(part_typeDup,"SKDVC") == 0
								 )
								{
									printf("\nPart %s and PartType %s Found OK\n",part_noDup,part_type);
								}
								else
								{
									printf("\nPart %s and PartType %s Its PartType must be either of VC/CCVC/VCCR/CKDVC/SKDVC... NOT OK\n",part_noDup,part_type);
									fprintf(fsuccess,"\nPart %s and PartType %s Its PartType must be either of VC/CCVC/VCCR/CKDVC/SKDVC... NOT OK\n",part_noDup,part_type);
									continue;
								}
							}
							else
							{
								printf("\nPart %s and PartType %s Normal 12-Digit Part\n",part_noDup,part_type);
							}
						}
						
						ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&PartRelStat));

						if(tc_strstr(PartRelStat,"ERC Released")==NULL)
						{
							printf("\nPart [%s] is not ERC Released LifeCycleState [%s] Skipping...",PartNum,PartRelStat); fflush(stdout);
							fprintf(fsuccess,"\nPart [%s] is not ERC Released LifeCycleState [%s] Skipping...",PartNum,PartRelStat); fflush(stdout);
							continue;
						}
						else
						{
							printf("\nPart [%s] Release Status [%s]",PartNum,PartRelStat); fflush(stdout);
							fprintf(fsuccess,"\nPart [%s] Release Status [%s]",PartNum,PartRelStat); fflush(stdout);
						}

						ITK_CALL(AOM_UIF_ask_value(PartTag,"object_desc",&desc));
						tc_strdup(desc,&descDup);
						
						ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&partClrInd));
						tc_strdup(partClrInd,&partClrIndDup);

						ITK_CALL(AOM_ask_value_tag(PartTag,"items_tag",&PartMasterTag));
						
						if ( tc_strcmp(partClrInd,"C") ==0)
						{
							//t5_uom is not found on colour part master/revision

							ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"uom_tag",&unit));
							
							ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_EngineType",&PartFamily));
							tc_strdup(PartFamily,&PartFamilyDup);
						}
						else
						{
							ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"t5_uom",&unit));
							
							ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"t5_EngineType",&PartFamily));
							tc_strdup(PartFamily,&PartFamilyDup);
						}

						ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_CategoryName",&KeywordDescription));
						tc_strdup(KeywordDescription,&KeywordDescriptionDup);

						printf("\nPart Number %s,%s PartType %s ColorInd %s",PartNum,PartRev,part_type,partClrInd);
						fprintf(fsuccess,"\nPart Number %s,%s PartType %s ColorInd %s",PartNum,PartRev,part_type,partClrInd);

						ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_MatlClass",&MaterialClass));
						tc_strdup(MaterialClass,&MaterialClassDup);
						
						printf("\nPartFamilyDup : %s",PartFamilyDup);
						printf("\nCategoryName : %s",KeywordDescriptionDup);
						printf("\nMat Class : %s",MaterialClassDup); fflush(stdout);

						fprintf(fsuccess,"\nPartFamilyDup : %s",PartFamilyDup);
						fprintf(fsuccess,"\nCategoryName : %s",KeywordDescriptionDup);
						fprintf(fsuccess,"\nMat Class : %s",MaterialClassDup); fflush(stdout);

						part_noDupDes = (char *)malloc(500 * sizeof(char));
						part_noDupDesx = (char *)malloc(500 * sizeof(char));

						strcpy(part_noDupDes,part_noDup);
						
						strcpy(part_noDupDesx,part_noDup);

						strcpy(myzeroDup1,"0.0");
						strcpy(myzeroDup2,"0.00");
						strcpy(myzeroDup3,"0.000");
						strcpy(myzeroDup4,"0.0000");

						len = tc_strlen(part_noDup);

						if(strcmp(part_typeDup,"")!=0)
						{
							tc_strcpy(mat_type,"");
							
							if (tc_strcmp(part_typeDup, "C") == 0 ||
								tc_strcmp(part_typeDup, "A") == 0 ||
								tc_strcmp(part_typeDup, "G") == 0 
								)
							{
								tc_strcpy(mat_type,"HALB");
							}
							else if (tc_strcmp(part_typeDup, "M") == 0)		//Module
							{
								tc_strcpy(mat_type,"HALB");
							}
							else if (tc_strcmp(part_typeDup, "V") == 0)
							{
								tc_strcpy(mat_type,"HALB");
							}
							else if (tc_strcmp(part_typeDup, "T") == 0)
							{
								tc_strcpy(mat_type,"HALB");
							}
							else if((tc_strcmp(part_typeDup, "VC") == 0)	||
									(tc_strcmp(part_typeDup, "CKDVC") == 0) ||
									(tc_strcmp(part_typeDup, "SKDVC") == 0) ||
									(tc_strcmp(part_typeDup, "CCVC") == 0)	||
									(tc_strcmp(part_typeDup, "SVR") == 0)	||
									(tc_strcmp(part_typeDup, "VCCR") == 0)
									)
							{
								tc_strcpy(mat_type,"FERT");
							}
							else if (tc_strcmp(part_typeDup,"DTPL")==0)
							{
								tc_strcpy(mat_type, "HALB");
							}
							else if (tc_strcmp(part_typeDup,"SA")==0)
							{
								tc_strcpy(mat_type, "HALB");
							}
							else if (tc_strcmp(part_typeDup,"SP")==0)
							{
								tc_strcpy(mat_type, "HALB");
							}
							else if (len == 12 || len == 14)
							{
								tc_strcpy(mat_type,"HALB");
							}
							else if (len == 10 || len == 11)
							{
								tc_strcpy(mat_type,"ROH");
							}
							else if (len == 14 || len == 16)	/*cabin kit logic by Ashish on 19.11.2013*/
							{
								if((*(part_noDup+10)=='C') && (*(part_noDup+11)=='K'))
								{
									tc_strcpy(mat_type,"HALB");
								}
							}

							printf("\nMaterial Type: %s", mat_type);
							fprintf(fsuccess,"\nMaterial Type: %s", mat_type);
						}
						else
						{
							printf("\nPart Type for the part %s is NULL\n",part_noDup);
							continue;
						}
						
					if(strcmp(mat_type,"")==0)
					{
						printf("\nNo Material Type Matching For Part : %s\n", part_noDup);
						fprintf(fsuccess,"\nNo Material Type Matching For Part : %s\n", part_noDup);
						continue;
					}
					
					printf("\nPLM Unit Of Measure : %s",unit);
					fprintf(fsuccess,"\nPLM Unit Of Measure : %s",unit);

					if(tc_strlen(unit)>0)
					{
						tc_strdup(unit,&unitDup);
						if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
						else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
						else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
						else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
						else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
						else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
						else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
						else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
						else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
						else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
						else
						{
							tc_strdup("EA",&unitDup);
							tc_strcpy(meas_unit,"EA");
						}
					}
					else
					{
						tc_strdup("EA",&unitDup);
						tc_strcpy(meas_unit,"EA");
					}

					//As per CR-FY20-0181
					if (tc_strcmp(part_typeDup, "M") == 0)
					{
						tc_strdup("EA",&unitDup);
						tc_strcpy(meas_unit,"EA");
					}

					printf("\nSAP Unit Of Measure : %s", meas_unit);
					fprintf(fsuccess,"\nSAP Unit Of Measure : %s", meas_unit);

					ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_DrawingInd",&drg_ind));

					if(strcmp(drg_ind,"")!=0)
					{
						tc_strdup(drg_ind,&drg_indDup);
						printf("\nDrawing Indicator: %s\n", drg_indDup);
						fprintf(fsuccess,"\nDrawing Indicator: %s\n", drg_indDup);
					}
					else
					{
						tc_strdup("",&drg_indDup);
						printf("\nDrawing Indicator is NULL!\n");
					}
					
					tc_strdup("",&doc_noDup);
					tc_strdup("",&dwg_typeDup);
					tc_strdup("",&dwg_revDup);
					sflag=0;
					RefDocflag=0;

					if(tc_strcmp(drg_indDup,"D")==0 || tc_strcmp(drg_indDup,"A")==0)
					{
						ITK_CALL(GRM_find_relation_type("IMAN_specification", &specDocRelObj));
						ITK_CALL(GRM_list_secondary_objects_only(PartTag,specDocRelObj,&doccount,&docObjs));
						printf("\nIMAN_specification DocCount Value :%d\n",doccount);fflush(stdout);
						fprintf(fsuccess,"\nIMAN_specification DocCount Value :%d\n",doccount);fflush(stdout);

						if(doccount>0)
						{
							for (is=0;is<doccount;is++ )
							{	
								doctag = docObjs[is];
								if(TCTYPE_ask_object_type(doctag,&docOPtr));
								if(TCTYPE_ask_name2(docOPtr,&docClass));
								printf("\nIMAN_specification docClass :: %s\n", docClass);fflush(stdout);
								fprintf(fsuccess,"\nIMAN_specification docClass :: %s\n", docClass);fflush(stdout);
								
								if(tc_strcmp(drg_indDup,"D")==0 && (tc_strcmp(docClass,"ProDrw")==0 || tc_strcmp(docClass,"CMI2Drawing")==0))
								{
									sflag=1;
									printf("\n%s,%s \n",drg_indDup,docClass);fflush(stdout);
									break;
								}

								if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"A")==0) && (tc_strcmp(docClass,"ProAsm")==0 || tc_strcmp(docClass,"CMI2Product")==0))
								{
									sflag=1;
									printf("\n%s,%s,%s \n",part_type,drg_indDup,docClass);fflush(stdout);
									break;
								}

								if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"C")==0) && (tc_strcmp(docClass,"ProPrt")==0 || tc_strcmp(docClass,"CMI2Part")==0))
								{
									sflag=1;
									printf("\n%s,%s,%s \n",part_type,drg_indDup,docClass);fflush(stdout);
									break;
								}
								
							}

							if(sflag==1)
							{
								ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
								doc_noDup=strtok(doc_no,"/");
								//dwg_revDup=strtok(NULL,";");
								//tc_strdup(doc_no,&doc_noDup);
								tc_strdup("OWN",&dwg_typeDup);
								tc_strdup("1",&sizeDup);
								dwg_revDup=strtok(PartRevDup,";");
								printf("\nDocument Number : [%s] Document Type : [%s] Document Version : [%s]\n",doc_noDup,dwg_typeDup,dwg_revDup);fflush(stdout);
								fprintf(fsuccess,"\nDocument Number : [%s] Document Type : [%s] Document Version : [%s]\n",doc_noDup,dwg_typeDup,dwg_revDup);fflush(stdout);
							}
						}
						
						if(sflag==0)
						{
							ITK_CALL(GRM_find_relation_type("IMAN_reference", &refdocRelObj));
							ITK_CALL(GRM_list_secondary_objects(PartTag,refdocRelObj,&Refcount,&refdocObjs));
							printf("\nIMAN_reference DocCount Value :%d\n",Refcount);fflush(stdout);
							fprintf(fsuccess,"\nIMAN_reference DocCount Value :%d\n",Refcount);fflush(stdout);
							char sRefDoctype_name[TCTYPE_name_size_c+1];
							if(Refcount>0)
							{

								for (is=0;is<Refcount;is++ )
								{	
									doctag = refdocObjs[is].secondary;
									if(TCTYPE_ask_object_type(doctag,&docOPtr));
									if(TCTYPE_ask_name(docOPtr,sRefDoctype_name));
									printf("\nIMAN_reference sRefDoctype_name :: %s\n", sRefDoctype_name);fflush(stdout);
									fprintf(fsuccess,"\nIMAN_reference sRefDoctype_name :: %s\n", sRefDoctype_name);fflush(stdout);

									if(tc_strcmp(drg_indDup,"D")==0 && (tc_strcmp(sRefDoctype_name,"ProDrw")==0 || tc_strcmp(sRefDoctype_name,"CMI2Drawing")==0))
									{
										RefDocflag=1;
										printf("\n%s \n",sRefDoctype_name);fflush(stdout);
										break;
									}

									if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"A")==0) && (tc_strcmp(sRefDoctype_name,"ProAsm")==0 || tc_strcmp(sRefDoctype_name,"CMI2Product")==0))
									{
										RefDocflag=1;
										printf("\n%s,%s,%s \n",part_type,drg_indDup,sRefDoctype_name);fflush(stdout);
										break;
									}

									if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"C")==0) && (tc_strcmp(sRefDoctype_name,"ProPrt")==0 || tc_strcmp(sRefDoctype_name,"CMI2Part")==0))
									{
										RefDocflag=1;
										printf("\n%s,%s,%s \n",part_type,drg_indDup,sRefDoctype_name);fflush(stdout);
										break;
									}
								}

								if(RefDocflag==1)
								{
									ITK_CALL(GRM_find_relation_type("IMAN_specification", &specDocRelObj));
									ITK_CALL(GRM_list_primary_objects(doctag,specDocRelObj,&DocPartCnt,&DocPartObj));
									printf("\nIMAN_specification relation PartObjCnt %d\n",DocPartCnt);	fflush(stdout);
									fprintf(fsuccess,"\nIMAN_specification relation PartObjCnt %d\n",DocPartCnt);	fflush(stdout);
									
									if (DocPartCnt>0)
									{
										specParttag = DocPartObj[0].primary;
										ITK_CALL(AOM_ask_value_string(specParttag,"object_type",&RefDocRelObjType));
										ITK_CALL(AOM_ask_value_string(specParttag,"item_id",&specPartNum));
										ITK_CALL(AOM_ask_value_string(specParttag,"item_revision_id",&specPartRev));
										ITK_CALL(AOM_UIF_ask_value(specParttag,"release_status_list",&specPartRelStat));

										printf("\nDocPartObj object_type : [%s]",RefDocRelObjType);

										if(tc_strstr(specPartRelStat,"ERC Released")!=NULL)
										{
											printf("\nspecPartNum : [%s]	specPartRev : [%s]	specPartRelStat : [%s]\n",specPartNum,specPartRev,specPartRelStat);	fflush(stdout);

											ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
											doc_noDup=strtok(doc_no,"/");
											//dwg_revDup=strtok(NULL,";");
											//tc_strdup(doc_no,&doc_noDup);
											tc_strdup("REF",&dwg_typeDup);
											tc_strdup("1",&sizeDup);
											dwg_revDup=strtok(specPartRev,";");
											printf("\nDocument Number : [%s] Document Type : [%s] Document Version : [%s]\n",doc_noDup,dwg_typeDup,dwg_revDup);fflush(stdout);
											fprintf(fsuccess,"\nDocument Number : [%s] Document Type : [%s] Document Version : [%s]\n",doc_noDup,dwg_typeDup,dwg_revDup);fflush(stdout);
										}
									}
								}
							}
						}
					}


					if ((tc_strcmp(part_typeDup, "VC") == 0) || (tc_strcmp(part_typeDup, "VCCR") == 0)|| (tc_strcmp(part_typeDup, "CKDVC") == 0)|| (tc_strcmp(part_typeDup, "SKDVC") == 0))
					{
						//ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_Weight",&net_wt));
						
						if(tc_strlen(net_wt)>0)
						{
							tc_strdup(net_wt,&net_wtDup);
						}
						else
						{
							tc_strdup("0.000",&net_wtDup);
						}
					}
					else
					{
						tc_strdup("0.000",&net_wtDup);
					}

					tc_strdup("0.000",&gross_weight);
					tc_strdup(gross_weight,&gross_weightDup);
					printf("\nNet Weight: %s", net_wtDup);fflush(stdout);
					printf("\nGross Weight: %s", gross_weight);fflush(stdout);						

					tc_strdup("",&OldMatNoDup);

					tc_strdup("01",&division);
					printf("\ndivision: %s", division);fflush(stdout);
					fprintf(fsuccess,"\ndivision: %s", division);fflush(stdout);

					 /*Weight Unit = KG*/
					tc_strdup("KG",&weight_unit);
					printf("\nWeight Unit: %s", weight_unit);fflush(stdout);
					fprintf(fsuccess,"\nWeight Unit: %s", weight_unit);fflush(stdout);

					/*Volume = 0.000*/
					tc_strdup("0.000",&volume);
					printf("\nVolume: %s", volume);fflush(stdout);
					fprintf(fsuccess,"\nVolume: %s", volume);fflush(stdout);

					/*Volume Unit = M3*/
					tc_strdup("M3",&vol_unit);
					printf("\nVolume Unit: %s", vol_unit);fflush(stdout);
					fprintf(fsuccess,"\nVolume Unit: %s", vol_unit);fflush(stdout);

					/*Material Group = ZZZZZZ*/
					tc_strdup("ZZZZZZ",&mat_grp);
					printf("\nMaterial Group: %s", mat_grp);fflush(stdout);
					fprintf(fsuccess,"\nMaterial Group: %s", mat_grp);fflush(stdout);

					/*Division = 01*/
					tc_strdup("01",&basic_division);
					printf("\nBasic Division: %s", basic_division);fflush(stdout);
					fprintf(fsuccess,"\nBasic Division: %s", basic_division);fflush(stdout);

					group = *part_noDup;
					if (group=='G')
					{
						printf("\nGroup Part : %c", part_noDup);fflush(stdout);
					}
					
					if (tc_strcmp(part_typeDup,"VC")==0 ||
						tc_strcmp(part_typeDup,"VCCR")==0 ||
						tc_strcmp(part_typeDup,"CCVC")==0 ||
						tc_strcmp(part_typeDup,"V")==0)
					{
						//printf("\nGetting Chassis Type Number : %s", part_noDup);fflush(stdout);
						//fprintf(fsuccess,"\nGetting Chassis Type Number : %s", part_noDup);fflush(stdout);
						getChassisType(PartTag,part_typeDup,partClrIndDup);
					}
					else
					{
						tc_strdup("",&OldMatNoDup);
					}

					printf("\nCalling... CLL_BAPI_MATERIAL_SAVEDATA");fflush(stdout);
					fprintf(fsuccess,"\nCalling... CLL_BAPI_MATERIAL_SAVEDATA");fflush(stdout);
					CLL_BAPI_MATERIAL_SAVEDATA();

					if (pstat=='K')
					{
						if( sflag==1 || RefDocflag==1)
						{
							printf("\n****** Document Version Update for part :[%s] ******",part_noDup); fflush(stdout);
							fprintf(fsuccess,"\n****** Document Version Update for part :[%s] ******",part_noDup); fflush(stdout);
							UPD_BAPI_MATERIAL_SAVEDATA();
						}

						printf("\nGoing for Description Change : "); fflush(stdout);
						fprintf(fsuccess,"\nGoing for Description Change : "); fflush(stdout);
						descChange(part_noDup,descDup,dml_numER);
					}
				}
				
				printf("\n******Drawing Revision Creation loop starting for :[%s] ******",TaskId); fflush(stdout);
				fprintf(fsuccess,"\n******Drawing Revision Creation loop starting for :[%s] ******",TaskId);

				for(p=0;p<partCnt;p++)
				{
					PartTag=SetOfPartTags[p];
					ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
					tc_strdup(PartNum,&part_noDup);

					ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
					tc_strdup(part_type,&part_typeDup);

					ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_DrawingInd",&drg_ind));
					tc_strdup(drg_ind,&drg_indDup);
					
					ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
					tc_strdup(PartRev,&PartRevDup);
					PartRevision=strtok(PartRevDup,";");
					printf("\nPartNum [%s] part_type [%s] drg_ind [%s] PartRevision [%s]",part_noDup,part_typeDup,drg_indDup,PartRevision);
					fprintf(fsuccess,"\nPartNum [%s] part_type [%s] drg_ind [%s] PartRevision [%s]",part_noDup,part_typeDup,drg_indDup,PartRevision);

					if(tc_strcmp(part_type,"D")!=0 && tc_strcmp(part_type,"DA")!=0 && tc_strcmp(part_type,"Dummy")!=0 && tc_strcmp(part_type,"DC")!=0 && tc_strcmp(part_type,"IFD")!=0 && tc_strcmp(part_type,"IM")!=0 && tc_strcmp(part_type,"V")!=0 && tc_strcmp(part_type,"T")!=0 && tc_strcmp(part_type,"VC")!=0)
					{
						if(tc_strcmp(drg_indDup,"D")==0 || tc_strcmp(drg_indDup,"A")==0)
						{
							ITK_CALL(GRM_find_relation_type("IMAN_specification", &specDocRelObj));
							ITK_CALL(GRM_list_secondary_objects_only(PartTag,specDocRelObj,&doccount,&docObjs));
							printf("\nIMAN_specification DocCount Value :%d\n",doccount);fflush(stdout);
							fprintf(fsuccess,"\nIMAN_specification DocCount Value :%d\n",doccount);fflush(stdout);

							if(doccount>0)
							{
								for (is=0;is<doccount;is++ )
								{	
									doctag = docObjs[is];
									if(TCTYPE_ask_object_type(doctag,&docOPtr));
									if(TCTYPE_ask_name2(docOPtr,&docClass));
									printf("\nIMAN_specification docClass :: %s\n", docClass);fflush(stdout);
									fprintf(fsuccess,"\nIMAN_specification docClass :: %s\n", docClass);fflush(stdout);
									
									if(tc_strcmp(drg_indDup,"D")==0 && (tc_strcmp(docClass,"ProDrw")==0 || tc_strcmp(docClass,"CMI2Drawing")==0))
									{
										sflag=1;
										printf("\n%s,%s \n",drg_indDup,docClass);fflush(stdout);
										break;
									}

									if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"A")==0) && (tc_strcmp(docClass,"ProAsm")==0 || tc_strcmp(docClass,"CMI2Product")==0))
									{
										sflag=1;
										printf("\n%s,%s,%s \n",part_type,drg_indDup,docClass);fflush(stdout);
										break;
									}

									if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"C")==0) && (tc_strcmp(docClass,"ProPrt")==0 || tc_strcmp(docClass,"CMI2Part")==0))
									{
										sflag=1;
										printf("\n%s,%s,%s \n",part_type,drg_indDup,docClass);fflush(stdout);
										break;
									}
									
								}

								if(sflag==1)
								{
									ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
									tc_strdup(doc_no,&doc_noDup);
									tc_strdup("OWN",&dwg_typeDup);
									tc_strdup("1",&sizeDup);

									printf("\nIMAN_specification relation found, updating Design Revission as SAP Revision level : [%s]\n", PartRevision);fflush(stdout);
									fprintf(fsuccess,"\nIMAN_specification relation found, updating Design Revission as SAP Revision level : [%s]\n", PartRevision);fflush(stdout);
									BapiRevcr(dml_numER,part_noDup,PartRevision);
								}
							}
							
							if(sflag==0)
							{
								ITK_CALL(GRM_find_relation_type("IMAN_reference", &refdocRelObj));
								ITK_CALL(GRM_list_secondary_objects(PartTag,refdocRelObj,&Refcount,&refdocObjs));
								printf("\nIMAN_reference DocCount Value :%d\n",Refcount);fflush(stdout);
								fprintf(fsuccess,"\nIMAN_reference DocCount Value :%d\n",Refcount);fflush(stdout);
								char sRefDoctype_name[TCTYPE_name_size_c+1];
								if(Refcount>0)
								{

									for (is=0;is<Refcount;is++ )
									{	
										doctag = refdocObjs[is].secondary;
										if(TCTYPE_ask_object_type(doctag,&docOPtr));
										if(TCTYPE_ask_name(docOPtr,sRefDoctype_name));
										printf("\nIMAN_reference sRefDoctype_name :: %s\n", sRefDoctype_name);fflush(stdout);
										fprintf(fsuccess,"\nIMAN_reference sRefDoctype_name :: %s\n", sRefDoctype_name);fflush(stdout);

										if(tc_strcmp(drg_indDup,"D")==0 && (tc_strcmp(sRefDoctype_name,"ProDrw")==0 || tc_strcmp(sRefDoctype_name,"CMI2Drawing")==0))
										{
											RefDocflag=1;
											printf("\n%s \n",sRefDoctype_name);fflush(stdout);
											break;
										}

										if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"A")==0) && (tc_strcmp(sRefDoctype_name,"ProAsm")==0 || tc_strcmp(sRefDoctype_name,"CMI2Product")==0))
										{
											RefDocflag=1;
											printf("\n%s,%s,%s \n",part_type,drg_indDup,sRefDoctype_name);fflush(stdout);
											break;
										}

										if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"C")==0) && (tc_strcmp(sRefDoctype_name,"ProPrt")==0 || tc_strcmp(sRefDoctype_name,"CMI2Part")==0))
										{
											RefDocflag=1;
											printf("\n%s,%s,%s \n",part_type,drg_indDup,sRefDoctype_name);fflush(stdout);
											break;
										}
									}

									if(RefDocflag==1)
									{
										ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
										tc_strdup(doc_no,&doc_noDup);
										tc_strdup("REF",&dwg_typeDup);
										tc_strdup("1",&sizeDup);

										ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
										tc_strdup(doc_no,&doc_noDup);
										printf("\nReference Drawing Documents Found, Document Number: %s",doc_noDup);fflush(stdout);
										fprintf(fsuccess,"\nReference Drawing Documents Found, Document Number: %s",doc_noDup);fflush(stdout);

										ITK_CALL(GRM_find_relation_type("IMAN_specification", &specDocRelObj));
										ITK_CALL(GRM_list_primary_objects(doctag,specDocRelObj,&DocPartCnt,&DocPartObj));
										printf("\nIMAN_specification relation PartObjCnt %d\n",DocPartCnt);	fflush(stdout);
										fprintf(fsuccess,"\nIMAN_specification relation PartObjCnt %d\n",DocPartCnt);	fflush(stdout);
										
										if (DocPartCnt>0)
										{
											specParttag = DocPartObj[0].primary;
											ITK_CALL(AOM_ask_value_string(specParttag,"object_type",&RefDocRelObjType));
											ITK_CALL(AOM_ask_value_string(specParttag,"item_id",&specPartNum));
											ITK_CALL(AOM_ask_value_string(specParttag,"item_revision_id",&specPartRev));
											ITK_CALL(AOM_UIF_ask_value(specParttag,"release_status_list",&specPartRelStat));

											printf("\nDocPartObj object_type : [%s]",RefDocRelObjType);

											if(tc_strstr(specPartRelStat,"ERC Released")!=NULL)
											{
												printf("\nspecPartNum : [%s]	specPartRev : [%s]	specPartRelStat : [%s]\n",specPartNum,specPartRev,specPartRelStat);	fflush(stdout);
												tc_strdup(specPartRev,&specPartRevDup);
												PartRevision=strtok(specPartRevDup,";");
												printf("\nspecPartNum : [%s]	PartRevision : [%s]\n",specPartNum,PartRevision);	fflush(stdout);
												fprintf(fsuccess,"\nspecPartNum : [%s]	PartRevision : [%s]\n",specPartNum,PartRevision);	fflush(stdout);
												printf("\nIMAN_reference relation found, updating Reference Doc Part Revision as SAP Revision level : [%s]\n", PartRevision);fflush(stdout);
												fprintf(fsuccess,"\nIMAN_reference relation found, updating Reference Doc Part Revision as SAP Revision level : [%s]\n", PartRevision);fflush(stdout);
												BapiRevcr(dml_numER,part_noDup,PartRevision);

												//Updating all reference relation parts of drawing Document.
												ITK_CALL(GRM_list_primary_objects(doctag,refdocRelObj,&RefRelPartCnt,&RefRelPartObj));
												printf("\nDrawing Document [%s] RefRelPartCnt : [%d]",doc_noDup,RefRelPartCnt);
												
												for (ref=0;ref<RefRelPartCnt;ref++)
												{
													RefPartTag = RefRelPartObj[ref].primary;

													ITK_CALL(AOM_ask_value_string(RefPartTag,"item_id",&RefPartNum));
													ITK_CALL(AOM_ask_value_string(RefPartTag,"item_revision_id",&RefPartRev));
													ITK_CALL(AOM_UIF_ask_value(RefPartTag,"release_status_list",&RefPartRelStat));

													if(tc_strstr(RefPartRelStat,"ERC Released")!=NULL)
													{
														printf("\nDrawing Document [%s] Rev [%s] Updating Revision of RefPartNum : [%s] [%s] [%s]",doc_noDup,PartRevision,RefPartNum,RefPartRev,RefPartRelStat);
														fprintf(fsuccess,"\nDrawing Document [%s] Rev [%s] Updating Revision of RefPartNum : [%s] [%s] [%s]",doc_noDup,PartRevision,RefPartNum,RefPartRev,RefPartRelStat);
														BapiRevcr(dml_numER,RefPartNum,PartRevision);
													}
													else
													{
														printf("\nDrawing Document [%s] RefPartNum : [%s] [%s] skipping from revision update as LCS [%s]",doc_noDup,RefPartNum,RefPartRev,RefPartRelStat);
														fprintf(fsuccess,"\nDrawing Document [%s] RefPartNum : [%s] [%s] skipping from revision update as LCS [%s]",doc_noDup,RefPartNum,RefPartRev,RefPartRelStat);
														continue;
													}

												}
											}
											else
											{
												printf("\nspecPartNum : [%s]	specPartRev : [%s]	specPartRelStat : [%s], hence skipping Revsion Level update for Part [%s]",specPartNum,specPartRev,specPartRelStat,part_noDup);	fflush(stdout);
												fprintf(fsuccess,"\nspecPartNum : [%s]	specPartRev : [%s]	specPartRelStat : [%s], hence skipping Revsion Level update for Part [%s]",specPartNum,specPartRev,specPartRelStat,part_noDup);	fflush(stdout);
												continue;
											}
										
											
										}
									}
								}
							}

							if (Refcount==0)
							{
								printf("\nPart [%s]	Drawing Ind [%s] Updating Part Revision [%s]",part_noDup,drg_indDup,PartRevision);
								fprintf(fsuccess,"\nPart [%s]	Drawing Ind [%s] Updating Part Revision [%s]",part_noDup,drg_indDup,PartRevision);
								BapiRevcr(dml_numER,part_noDup,PartRevision);
							}

							
						
						}
						else if(tc_strcmp(drg_indDup,"N")==0)
						{
							printf("\nPart [%s]	Drawing Ind [%s] Updating Part Revision [%s]",part_noDup,drg_indDup,PartRevision);
							fprintf(fsuccess,"\nPart [%s]	Drawing Ind [%s] Updating Part Revision [%s]",part_noDup,drg_indDup,PartRevision);
							BapiRevcr(dml_numER,part_noDup,PartRevision);
						}
						else
						{continue;}
					}
				}
			}
		}//task id loop
	}
}
	printf("\nERC DML Transfer Program Completed\n");
	fprintf(fsuccess,"\nERC DML Transfer Program Completed\n");

ITK_CALL(POM_logout(false));
return status;

CLEANUP:
ITK_CALL(POM_logout(false));
printf("\nCLEANUP...\n"); fflush(stdout);

}
;
int pstat_basicFun(void)
{
	//printf("\n In pstat_basicFun function..[%s]\n",sappstat); fflush(stdout);
	if(tc_strlen(SAPpstat)>0 && tc_strstr(SAPpstat,"K"))
	{
		pstat = 'K';
	}
	else
	{
		pstat = '0';
	}

	/*if(!nlsIsStrNull(nlsStrStr(MRPpstat,"D")))
	{
		pstat_mrp = 'D';
	}
	else
	{
		pstat_mrp = '0';
	}

	if(!nlsIsStrNull(nlsStrStr(MRPpstat,"B")))
	{
		pstat_acc = 'B';
	}
	else
	{
		pstat_acc = '0';
	}*/
	//printf("\n..%c:%c:%c..\n",pstat,pstat_mrp,pstat_acc); fflush(stdout);
	return 0;
}
