#define TE_MAXLINELEN  128

#define _CLMAIN_DEFNS

#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>
#include <user_exits/user_exits.h>
//#include <librfc.a>
//#include <ProdSap_functions.a>
//#include "VrCre.h"
#include "wmhelpe.h"
#include "ppe.h"
#include "bapi.h"
#include "time.h"
#include "BOMRule.h"
#include <pie/pie.h>

struct node
{
	char sr_no[5];
	char *part;
	float qty;
	char uq[4];
	char *formula;
	char* Potx1;
	struct node *next;
};


struct node_mis
{
	char sr_no[5];
	char *part;
	char *qty;
	char *BomNo;
	struct node_mis *next;
};

char *iSapServer = NULL;
static RFC_RC RfcRc;
struct node *start=NULL;
char *sr_no=NULL;
char *o1Context_VariantRule=NULL;
char *o2Context_VariantRule=NULL;
char *ostr=NULL;
char *ostr1=NULL;

//RFC_RC RfcRc;
static RFC_HANDLE hRfc;
char bomnum1[1024] = { 0 };
static char sap_proc_type[2] = {0};
static char sap_spproc_type[3] = {0};
static char SAPpstat[15] = {0};
static char MRPpstat[15] = {0};
static char pstat;
static char pstat_mrp;
static char pstat_acc;

char fsuccess_name[2000];

FILE * fsuccess;

RFC_HANDLE BapiLogon(void);
void rfc_error(char *operation);
#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
void trimTrailing(char * str);
char* subString(char* mainStringf ,int fromCharf ,int toCharf);
//void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str);

struct node* createnode(char sr_no[5],char *part,float* qty,char uq[4],char *formula,char *Potx1);
void cll_MB_BOM_OPEN(struct node *head,char *assy_noDup , char *SapChangeNo);
RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException);
int GetCSPstat(char cMaterial[50]);

void cll_MB_BOM_MAINTAIN(struct node *head,char *assy_noDup);
RFC_RC  cad_create_bom_with_sub_items(RFC_HANDLE hRfc, DRAW_LOEDK *eIAutoPosnr, CAD_BICSK *eIBomHeader, CAD_BICSK *iEBomHeader, MESSAGE_MSGTX *iEMessage, CAD_RETURN_MESSAGE_LEN *iEMessageLen, CAD_RETURN_VALUE *iEReturn, ITAB_H thBomItem, char *xException);

void cll_MB_BOM_CLOSE();
RFC_RC cad_display_bom_with_sub_items(RFC_HANDLE hRfc,RC29L_STLAL *eIBomAlternative,RC29L_STLAN *eIBomType,RC29L_AENNR *eIChangeNumber,DRAW_LOEDK *eIDisplayFlag,RC29L_MATNR *eIMaterial,RC29L_WERKS *eIPlant,RC29L_REVLV *eIRevisionLevel,BICSK_DATUV *eIValidFrom,CAD_BICSK *iEBomHeader,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_RETURN_VALUE *iEReturn,ITAB_H thBomItem,ITAB_H thBomSubItem,ITAB_H thDmsClassData,ITAB_H thSapFieldData,char *xException);
struct node_mis * cll_cad_display_bom_with_sub_items(char * assy_noDup,char * plantcode);

void display_bom(struct node_mis *head);
struct node_mis* createnode_mis(char sr_no[5],char *part,char* qty,char *BomNo);
FILE* fp=NULL;
#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))

//BomNo
//sr_no
void compare(struct node_mis *p1,struct node_mis *p2,char *AssyNo,char* plantcode)
{
	int	found = 1;
	struct node_mis *s1 = NULL;
	struct node_mis *s2 = NULL;
	printf("\nIn compare");fflush(stdout);
	s1 = p1;
	s2 = p2;
	while(s1!=NULL)
	{
		s2=p2;

		while(s2!=NULL)
		{
			if((strcmp(s2->part,s1->part)==0) && (strcmp(s2->BomNo,s1->BomNo)==0))
			{
				found = 0;
				break;
			}
			else
			{
				found = 1;
			}
			s2=s2->next;
		}
		if(found == 1)
		{
			printf("\n%s Part present in PLM not in SAP %s BomNo[%s] for plant [%s]",AssyNo,s1->part,s1->BomNo,plantcode);fflush(stdout);
			fprintf(fsuccess,"\n%s Part present in PLM not in SAP %s BomNo[%s] for plant [%s]",AssyNo,s1->part,s1->BomNo,plantcode);fflush(stdout);
		}

		s1=s1->next;
	}


	s1 = p1;
	s2 = p2;
	while(s2!=NULL)
	{
		s1=p1;

		while(s1!=NULL)
		{
			if ( (strcmp(s1->part,s2->part)==0) && (strcmp(s1->BomNo,s2->BomNo)==0))
			{
				found = 0;
				break;
			}
			else
			{
				found = 1;
			}
			s1=s1->next;
		}
		if(found == 1)
		{
			printf("\n%s Part present in SAP not in PLM %s BomNo[%s] for plant [%s] Item No [%s]",AssyNo,s2->part,s2->BomNo,plantcode,s2->sr_no);fflush(stdout);
			fprintf(fsuccess,"\n%s Part present in SAP not in PLM %s BomNo[%s] for plant [%s] Item No [%s]",AssyNo,s2->part,s2->BomNo,plantcode,s2->sr_no);fflush(stdout);
		}

		s2=s2->next;
	}

}
void my_free_mis(struct node_mis** start)
{
	struct node_mis* current = *start;
	struct node_mis* ptr;
	printf("\n");
	while (current != NULL)
	{
		printf("#");
		ptr = current->next;
		free(current);
		current = ptr;
	}
	*start = NULL;
	printf("SUCCESSFULLY DELETED ALL NODES OF LINKED LIST\n");
}
/*void my_free_mis(struct node_mis* start)
{
	struct node_mis* prev;
	struct node_mis* ptr;
	printf("\nErazing Linklist Started...\n");
	for(prev = start, ptr = start; ptr != NULL, prev = ptr; ptr = ptr->next)
	{
		printf("#");
		free(prev);
	}
	start = NULL;
	printf("\nErazing Linklist Completed.\n");
}*/

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %s",len,text,str);fflush(stdout);
  //if (stdout!=NULL) fprintf(stdout,"=%s\n>%s\n",text,str);
  return;
}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


/*void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("%*.0s",pos,text);fflush(stdout); printf("%-*s : %s\n",len,text,str);fflush(stdout);
  return;
}*/

void rfc_error(char *operation)
{
	#ifdef SAPonNT
	char s[16];
	#endif
	RFC_ERROR_INFO RfcErrorInfo;

	printf("\noperation/code:%s",operation);fflush(stdout);
	memset(&RfcErrorInfo,0,sizeof(RfcErrorInfo));
	RfcLastError(&RfcErrorInfo);
	printf("\nkey: %s",RfcErrorInfo.key);fflush(stdout);
	printf("\nstatus: %s",RfcErrorInfo.status);fflush(stdout);
	printf("\nmessage: %s",RfcErrorInfo.message);fflush(stdout);
	printf("\ninternal status: %s",RfcErrorInfo.intstat);fflush(stdout);
	RfcClose (RFC_HANDLE_NULL);
	exit(1);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

char *replaceWord(const char *s, const char *oldW,
                                 const char *newW)
{
    char *result;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);


    // Counting the number of times old word
    // occur in the string
    for (i = 0; s[i] != '\0'; i++)
    {
        if (strstr(&s[i], oldW) == &s[i])
        {
            cnt++;

            // Jumping to index after the old word.
            i += oldWlen - 1;
        }
    }

    // Making new string of enough length
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;
    while (*s)
    {
		//printf("\nHere1:[%s]:[%s]",s,oldW);
        // compare the substring with the result
        if (strstr(s, oldW) == s)
        {
			//printf("\nHere2");
            strcpy(&result[i], newW);
            i += newWlen;
            s += oldWlen;
        }
        else
            result[i++] = *s++;
    }

    result[i] = '\0';
    return result;
}
static tag_t ask_item_revision_from_bom_line(tag_t bom_line)
{
    tag_t item_revision = NULLTAG;
    char *item_id = NULL, *rev_id = NULL;

    ITK_CALL(AOM_ask_value_string(bom_line, "bl_item_item_id", &item_id ));
    ITK_CALL(AOM_ask_value_string(bom_line, "bl_rev_item_revision_id", &rev_id));
    ITK_CALL(ITEM_find_rev(item_id, rev_id, &item_revision));

    if (item_id) MEM_free(item_id);
    if (rev_id) MEM_free(rev_id);
    return item_revision;
}

RFC_RC cad_display_bom_with_sub_items(RFC_HANDLE hRfc,RC29L_STLAL *eIBomAlternative,RC29L_STLAN *eIBomType,RC29L_AENNR *eIChangeNumber,DRAW_LOEDK *eIDisplayFlag,RC29L_MATNR *eIMaterial,RC29L_WERKS *eIPlant,RC29L_REVLV *eIRevisionLevel,BICSK_DATUV *eIValidFrom,CAD_BICSK *iEBomHeader,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_RETURN_VALUE *iEReturn,ITAB_H thBomItem,ITAB_H thBomSubItem,ITAB_H thDmsClassData,ITAB_H thSapFieldData,char *xException)
{


  RFC_PARAMETER Exporting[9];
  RFC_PARAMETER Importing[5];
  RFC_TABLE Tables[5];
  RFC_RC RfcRc;
  char *RfcException = NULL;

  Exporting[0].name = "I_BOM_ALTERNATIVE";
  Exporting[0].nlen = 17;
  Exporting[0].type = TYPC;
  Exporting[0].leng = sizeof(RC29L_STLAL);
  Exporting[0].addr = eIBomAlternative;

  Exporting[1].name = "I_BOM_TYPE";
  Exporting[1].nlen = 10;
  Exporting[1].type = TYPC;
  Exporting[1].leng = sizeof(RC29L_STLAN);
  Exporting[1].addr = eIBomType;

  Exporting[2].name = "I_CHANGE_NUMBER";
  Exporting[2].nlen = 15;
  Exporting[2].type = TYPC;
  Exporting[2].leng = sizeof(RC29L_AENNR);
  Exporting[2].addr = eIChangeNumber;

  Exporting[3].name = "I_DISPLAY_FLAG";
  Exporting[3].nlen = 14;
  Exporting[3].type = TYPC;
  Exporting[3].leng = sizeof(DRAW_LOEDK);
  Exporting[3].addr = eIDisplayFlag;

  Exporting[4].name = "I_MATERIAL";
  Exporting[4].nlen = 10;
  Exporting[4].type = TYPC;
  Exporting[4].leng = sizeof(RC29L_MATNR);
  Exporting[4].addr = eIMaterial;

  Exporting[5].name = "I_PLANT";
  Exporting[5].nlen = 7;
  Exporting[5].type = TYPC;
  Exporting[5].leng = sizeof(RC29L_WERKS);
  Exporting[5].addr = eIPlant;

  Exporting[6].name = "I_REVISION_LEVEL";
  Exporting[6].nlen = 16;
  Exporting[6].type = TYPC;
  Exporting[6].leng = sizeof(RC29L_REVLV);
  Exporting[6].addr = eIRevisionLevel;

  Exporting[7].name = "I_VALID_FROM";
  Exporting[7].nlen = 12;
  Exporting[7].type = TYPC;
  Exporting[7].leng = sizeof(BICSK_DATUV);
  Exporting[7].addr = eIValidFrom;

  Exporting[8].name = NULL;



  Tables[0].name     = "BOM_ITEM";
  Tables[0].nlen     = 8;
  Tables[0].type     = handleOfCAD_BOM_ITEM;
  Tables[0].ithandle = thBomItem;

  Tables[1].name     = "BOM_SUB_ITEM";
  Tables[1].nlen     = 12;
  Tables[1].type     = handleOfCSSUBITEM;
  Tables[1].ithandle = thBomSubItem;

  Tables[2].name     = "DMS_CLASS_DATA";
  Tables[2].nlen     = 14;
  Tables[2].type     = handleOfCLS_CHARAC;
  Tables[2].ithandle = thDmsClassData;

  Tables[3].name     = "SAP_FIELD_DATA";
  Tables[3].nlen     = 14;
  Tables[3].type     = handleOfRFCDMSDATA;
  Tables[3].ithandle = thSapFieldData;

  Tables[4].name = NULL;



  RfcRc = RfcCall(hRfc,"CAD_DISPLAY_BOM_WITH_SUB_ITEMS",Exporting,Tables);


  switch (RfcRc)
  {
    case RFC_OK :



      Importing[0].name = "E_BOM_HEADER";
      Importing[0].nlen = 12;
      Importing[0].type = handleOfCAD_BICSK;
      Importing[0].leng = sizeof(CAD_BICSK);
      Importing[0].addr = iEBomHeader;

      Importing[1].name = "E_MESSAGE";
      Importing[1].nlen = 9;
      Importing[1].type = TYPC;
      Importing[1].leng = sizeof(MESSAGE_MSGTX);
      Importing[1].addr = iEMessage;

      Importing[2].name = "E_MESSAGE_LEN";
      Importing[2].nlen = 13;
      Importing[2].type = TYPC;
      Importing[2].leng = sizeof(CAD_RETURN_MESSAGE_LEN);
      Importing[2].addr = iEMessageLen;

      Importing[3].name = "E_RETURN";

      Importing[3].nlen = 8;
      Importing[3].type = TYPC;
      Importing[3].leng = sizeof(CAD_RETURN_VALUE);
      Importing[3].addr = iEReturn;

      Importing[4].name = NULL;



      RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);


      switch (RfcRc)
      {
        case RFC_SYS_EXCEPTION :
				strcpy(xException,RfcException);
				break;
        case RFC_EXCEPTION :
				strcpy(xException,RfcException);
				break;
       }

		break;
	default :
		printf("Error occured");fflush(stdout);
  }

  return RfcRc;
}

struct node_mis* cll_cad_display_bom_with_sub_items(char *assy_noDup,char *plantcode)
{
static RFC_RC RfcRc;
//RFC_HANDLE hRfc;
char s[1024];
/*char comp_part_sap[15];*/
char comp_part_sap[15];

char recstring_sap[25000];
char crecstring_sap[25000];


RC29L_STLAL eIBomAlternative;
RC29L_STLAN eIBomType;
RC29L_AENNR eIChangeNumber;
DRAW_LOEDK eIDisplayFlag;
RC29L_MATNR eIMaterial;
RC29L_WERKS eIPlant;
RC29L_REVLV eIRevisionLevel;
BICSK_DATUV eIValidFrom;
CAD_BICSK iEBomHeader;
MESSAGE_MSGTX iEMessage;
CAD_RETURN_MESSAGE_LEN iEMessageLen;
CAD_RETURN_VALUE iEReturn;
ITAB_H thBomItem = ITAB_NULL;
ITAB_H thBomSubItem = ITAB_NULL;
ITAB_H thDmsClassData = ITAB_NULL;
ITAB_H thSapFieldData = ITAB_NULL;
char xException[256];

int i_sap=0;
int j_sap=0;
int k_sap=0;
int m_sap=0;

/* table row variables */
CAD_BOM_ITEM *tBomItem;
unsigned crow;
char t;
/*char plant_code[5]={0};*/
struct node_mis *start_sap = NULL;
struct node_mis *p_sap = NULL;
struct node_mis *q_sap = NULL;

char sr_no[5] = { 0 };
//char ChildPart[19] = { 0 };
char *ChildPart = NULL;
char *ChildPartVal = NULL;
char *Quantity = NULL;
char *QuantityVal = NULL;
char *BomNo = NULL;
char *BomNoVal = NULL;


p_sap = NULL;
q_sap = NULL;


    printf("\nBOM data received for :%s: ",plantcode);fflush(stdout);

    SETCHAR(eIBomAlternative,"01");
    SETCHAR(eIBomType,"1");
    SETCHAR(eIChangeNumber,"");
    SETCHAR(eIDisplayFlag,"X");
    SETCHAR(eIMaterial,assy_noDup);
    SETCHAR(eIPlant,plantcode);
    SETCHAR(eIRevisionLevel,"");
    SETCHAR(eIValidFrom,"");

	//BapiLogon();

	//hRfc = BapiLogon( );

    if (thBomItem==ITAB_NULL)
	{
      thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
      if (thBomItem==ITAB_NULL)
		  rfc_error("ItCreateBOM_ITEM");
	}
    else
	{
      if (ItFree(thBomItem) != 0)
		  rfc_error("ItFreeBOM_ITEM");
	}
    if (thBomSubItem==ITAB_NULL)
	{
      thBomSubItem = ItCreate("BOM_SUB_ITEM",sizeof(CSSUBITEM),0,0);
      if (thBomSubItem==ITAB_NULL)
		  rfc_error("ItCreateBOM_SUB_ITEM");
	}
    else
	{
      if (ItFree(thBomSubItem) != 0)
		  rfc_error("ItFreeBOM_SUB_ITEM");
	}
    if (thDmsClassData==ITAB_NULL)
	{
      thDmsClassData = ItCreate("DMS_CLASS_DATA",sizeof(CLS_CHARAC),0,0);
      if (thDmsClassData==ITAB_NULL)
		  rfc_error("ItCreateDMS_CLASS_DATA");
	}
    else
	{
      if (ItFree(thDmsClassData) != 0)
		  rfc_error("ItFreeDMS_CLASS_DATA");
	}
    if (thSapFieldData==ITAB_NULL)
	{
      thSapFieldData = ItCreate("SAP_FIELD_DATA",sizeof(RFCDMSDATA),0,0);
      if (thSapFieldData==ITAB_NULL)
		  rfc_error("ItCreateSAP_FIELD_DATA");
	}
    else
	{
      if (ItFree(thSapFieldData) != 0)
		  rfc_error("ItFreeSAP_FIELD_DATA");
	}



      /* call RFC function */
	RfcRc = cad_display_bom_with_sub_items(hRfc,&eIBomAlternative,&eIBomType,&eIChangeNumber,&eIDisplayFlag,&eIMaterial,&eIPlant,&eIRevisionLevel,&eIValidFrom,&iEBomHeader,&iEMessage,&iEMessageLen,&iEReturn,thBomItem,thBomSubItem,thDmsClassData,thSapFieldData,xException);
	switch (RfcRc)
	{

	case RFC_OK :
				  //memset(crecstring_sap,0,sizeof(crecstring_sap));
				  //memset(recstring_sap,0,sizeof(recstring_sap));
				  //strcpy(recstring_sap,"");
				  sprintf(s,"%d lines",ItFill(thBomItem));
				  printf("\nNo of row fetched :%s:",s); fflush(stdout);
				  //t=0;

				  for (crow = 1;crow <= ItFill(thBomItem); crow++)
				  {
					tBomItem = ItGetLine(thBomItem,crow);
					if (tBomItem == NULL)
						rfc_error("ItGetLineBOM_ITEM");
					
					tc_strcpy(sr_no,"");
					
					ChildPart = (char *) MEM_alloc(19 * sizeof(char));
					ChildPartVal = (char *) MEM_alloc(19 * sizeof(char));
					tc_strcpy(ChildPart,"");
					tc_strcpy(ChildPartVal,"");

					Quantity = (char *) MEM_alloc(19 * sizeof(char));
					QuantityVal = (char *) MEM_alloc(19 * sizeof(char));
					tc_strcpy(Quantity,"");
					tc_strcpy(QuantityVal,"");

					BomNo = (char *) MEM_alloc(41 * sizeof(char));
					BomNoVal = (char *) MEM_alloc(41 * sizeof(char));
					
					tc_strcpy(BomNo,"");
					tc_strcpy(BomNoVal,"");

					GETCHAR(tBomItem->Posnr,sr_no);

					GETCHAR(tBomItem->Idnrk,ChildPart);
					//tc_strcpy(ChildPartVal , (char *)stripTrailingBlanks(ChildPart));
					//tc_strcpy(ChildPartVal , (char *)stripBlanks(ChildPart));
					ChildPartVal =  (char *)stripBlanks(ChildPart);
					//printf("\nChildPartVal:[%s]",ChildPartVal);
					
					GETCHAR(tBomItem->Menge,Quantity);
					QuantityVal =  (char *)stripBlanks(Quantity);
					//printf("\tQuantityVal:[%s]",QuantityVal);

					GETCHAR(tBomItem->Potx1,BomNo);
					BomNoVal =  (char *)stripBlanks(BomNo);
					//printf("\tBomNoVal:[%s]",BomNoVal);


				
					if(p_sap == NULL)
					{
						p_sap = createnode_mis(sr_no,ChildPartVal,QuantityVal,BomNoVal);
						start_sap = p_sap;
					}
					else
					{
						q_sap = start_sap;
						while(q_sap->next != NULL)
						{
							 q_sap = q_sap->next;
						}
						q_sap->next = createnode_mis(sr_no,ChildPartVal,QuantityVal,BomNoVal);

					}


				  }
				  //free(ChildPart);
				  //free(ChildPartVal);

				  /*for(i_sap=0;i_sap<strlen(recstring_sap);i_sap=i_sap+18)
				  {
					m_sap=i_sap;

					for(j_sap=0;j_sap<14;j_sap++)
					{
						crecstring_sap[k_sap]=recstring_sap[m_sap];
						k_sap++;
						m_sap++;
					}
				 }*/

				//display_bom(start_sap);

				  sprintf(s,"\nchild parts fetched from sap : %d ",ItFill(thBomItem ));

			         break;

        case RFC_EXCEPTION :
			         /* exception raised */
					 printf("exception"); fflush(stdout);
			         break;
        case RFC_SYS_EXCEPTION :
			         rfc_error("system exception raised");

        case RFC_FAILURE :
					 rfc_error("failure");

        default :
					 rfc_error("other failure");

      }
    /* delete tables */
    if (ItDelete(thBomItem) != 0)
      rfc_error("ItDelete BOM_ITEM");
    if (ItDelete(thBomSubItem) != 0)
      rfc_error("ItDelete BOM_SUB_ITEM");
    if (ItDelete(thDmsClassData) != 0)
      rfc_error("ItDelete DMS_CLASS_DATA");
    if (ItDelete(thSapFieldData) != 0)
      rfc_error("ItDelete SAP_FIELD_DATA");

	RfcClose (hRfc);
	return start_sap;
}

void trimTrailing(char * str)
{
    int index, i;

    /* Set default index */
    index = -1;

    /* Find last index of non-white space character */
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }

        i++;
    }

    /* Mark next character to last non-white space character as NULL */
    str[index + 1] = '\0';
}
extern int ITK_user_main(int argc, char ** argv )
{
//	int status;
	int status = ITK_ok;
	struct usgProbnode *pUP = NULLTAG;
	tag_t ChildOPtr = NULLTAG;
	tag_t ChildOPtrCpy = NULLTAG;
	tag_t PartOPtr = NULLTAG;
	tag_t *partObjs = NULLTAG;
	char *AssyNo = NULL;
	char *plantcode = NULL;
	char *SapChangeNo = NULL;
	char *sRevision = NULL;
	char *sSequence = NULL;
	char *mat_prov_ind = NULL;
	char *meas_unit = NULL;
	char *tempcsrel = NULL;
	char *formula = NULL;
	char *aformula = NULL;
	char *aPotx1 = NULL;

	int ci = 0;
	int ei = 0;
	int grind = 0;
	int iPartIndex;
	int ret;
	int failflag = 0;
	int i = 0;
	//int mfail = OKAY;
	int noOfChilds = 0;
	int stat = 0;
	int taskCount = 0;
	static int sr_no1 = 0;
	//status dstat = OKAY;
	char *AssyPrttype = NULL;
	char *AssyPrttypeDup = NULL;
	char *Revision = NULL;
	char *RevisionDup = NULL;
	char *assy_no = NULL;
	char *assy_noDup = NULL;
	char *date_updated = NULL;
	char *date_updatedDup = NULL;
	char *epaowner = NULL;
	char *epaownerDup = NULL;
	char *eparelzstate = NULL;
	char *eparelzstateDup = NULL;
	char *epataskId = NULL;
	char *epataskIdDup = NULL;
	char *make_buy_ind = NULL;
	char *make_buy_indDup = NULL;
	char *part_no = NULL;
	char *part_noDup = NULL;
	char *taskId = NULL;
	char *taskIdDup = NULL;
	char *unit = NULL;
	char *unitDup = NULL;
	char *DispName = NULL;
	char *DispNameDup = NULL;
	char *PrtCls = NULL;
	char *PrtClsDup = NULL;
	char *cPrtCls = NULL;
	char *owner = NULL;
	char *ownerDup = NULL;
	char *prjcode = NULL;
	char *prjcodeDup = NULL;
	char *prtType = NULL;
	char *prtTypeDup = NULL;
	char *qty = NULL;
	char *qtyDup = NULL;
	char *qty_req_info = NULL;
	char *qty_req_infoDup = NULL;
	char *relzstate = NULL;
	char *relzstateDup = NULL;
	struct node *p=NULL;
	struct node *q=NULL;
	float floatQty= 0.000;
	int mcSeriesRawPartflag = 1;
	char *iOrganizationID=NULL;
	char *StdDate=NULL;
	char *MonYear=NULL;
	char *inputDmlNumber=NULL;
	char *inputPlantCode=NULL;
	tag_t priobjTypeTag = NULLTAG;

	char *ChildPrtCls = NULL;
	//SetOfStrings dbScopeStr = NULL;
	int ic = 0 ;
	tag_t CtxtCntrlLocSet = NULLTAG;
	char *t5Userinfo1 = NULL;
	char *t5Userinfo1Dup = NULL;
	tag_t genContextObj = NULLTAG;
	tag_t CtxtObj = NULLTAG;
	char *viewName = NULLTAG;
	char *confg_class = NULL;
	tag_t MkeBuyControlObjs = NULLTAG;
	tag_t MkeBuyControlObjPtr = NULLTAG;
	char *pMkeBuyIndicator = NULL;
	char *pMkeBuyIndicatorDup = NULL;
	char *AssemblyRevision = NULL;
	char *AssemblyRevisionDup = NULL;
	char *SequenceRevision = NULL;
	char *SequenceRevisionDup = NULL;
	char *OrganizationID = NULL;
	char *OrganizationIDDup = NULL;
	char *epataskIdDup0 = NULL;
	char *epataskIdDup1 = NULL;
	char *epataskIdDup2 = NULL;
	char *taskIdDup0 = NULL;
	char *taskIdDup1 = NULL;
	char *taskIdDup2 = NULL;
	char *carcs = NULL;
	int noValidEpa = 1;
	int noValidDml = 1;
	char *myDate = NULL;
	char  *curentname=NULL;
	char  *priobj_name=NULL;
	tag_t ConfigCtx=NULLTAG;
	tag_t Optfmly_tag=NULLTAG;
	tag_t ConfigCtxObjTypeTag=NULLTAG;
	char   Config_CtxType[TCTYPE_name_size_c+1];
	char *SmVCContext=NULL;
	char *SmCrIDContext=NULL;
	char *ContextobjName=NULL;
	tag_t *rev=NULLTAG;

	//int n_entries;
	int resultCount = 0;
	int CntChildP = 0;
	int CntChildArch = 0;
	int ChildItemTag = 0;
	int Item_ID=0,Item_UoM=0,Item_Owner=0;
	int Child_Item_RevSeq = 0;
	char *LatRevName	= NULL;
	char *POwnerName	= NULL;
	char *POwnerNameDup	= NULL;
	char *InpRevSeq		= NULL;
	char *ChildRevName	= NULL;
	char *Child_Item_RevSeq_str	= NULL;
	char *ChildOwnName	= NULL;
	char *ChildPrtType	= NULL;
	char *ChildPrtQty	= NULL;
	char *ChildQtyDup	= NULL;
	char *ChildPrtUoM	= NULL;

	tag_t queryTag		= NULLTAG;
	tag_t LatestPRev	= NULLTAG;
	tag_t window = NULLTAG;
	tag_t window1 = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t rule1 = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t PerentLine = NULLTAG;
	tag_t PerentLine1 = NULLTAG;
	tag_t *ChildPartLine = NULLTAG;
	tag_t ChildItemRevTag = NULLTAG;
	tag_t ChildItemRev = NULLTAG;
	tag_t item_tag = NULLTAG;
	tag_t item_tag1 = NULLTAG;
	tag_t PlatLatestRev = NULLTAG;
	tag_t Arch_tag = NULLTAG;
	tag_t node_tag = NULLTAG;
	char* sPartType = NULL;

	char *Context_Str=NULL;
	char *Context_VariantRule=NULL;
	char *Context_VariantRuleTok1=NULL;
	char **Options_array  = NULL ;
	char *uContext_VariantRule=NULL;
	char *item_type=NULL;
	char *item_type1=NULL;
	char *objectname=NULL;
	char *objectyp=NULL;
	char *OptValNameCopy=NULL;
	char *oDrwNum1=NULL;
	tag_t *tags_found;
	tag_t *tags_found1;
	tag_t *ChildArchLine;
	tag_t view_relation=NULLTAG;
	tag_t relation_dep=NULLTAG;
	tag_t latestrev=NULLTAG;
	tag_t Archrev=NULLTAG;
	tag_t platformrev=NULLTAG;
	tag_t Anode_tag=NULLTAG;
	char *pltfrm_str=NULL;
	char *childid=NULL;
	int n_tags_found= 0;
	int n_tags_found1= 0;
	int ai= 0;
	int viewcount= 0;
	int n_parents= 0;
	int countConfigCtx = 0;
	tag_t  *ConfigCtxSecObject	= NULLTAG;
	int jd= 0;
	int *levels = 0;
	//char *Context_Str=NULL;
	char *Arch_str=NULL;
	tag_t *parents = NULL;
	tag_t *primary_ref_list=NULLTAG;
	
	const char **attrs = (const char **) MEM_alloc(10 * sizeof(char *));
	const char **values = (const char **) MEM_alloc(10 * sizeof(char *));
	const char **attrs1 = (const char **) MEM_alloc(10 * sizeof(char *));
	const char **values1 = (const char **) MEM_alloc(10 * sizeof(char *));
	
	attrs1[0] ="item_id";

	//tag_t Optfmly_tag = NULLTAG;
	char *OptfmlyName_O=NULL;
	char *OptValName_O=NULL;
	int j=0;
	char *qry_entriesOptFamVal[] = {"Thread ID","ID"};
	char **qry_valuesOptFamVal = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t OptfmlyVal_tag = NULLTAG;
	tag_t queryTagOptFamVal = NULLTAG;
	tag_t *revOptFamVal=NULL;
	int resultCountOptFamVal=0,n_entriesOptFamVal=2,iCnt=0;
	char* OptValName=NULL;
	char* OptfmlyName=NULL;
	char* OptfmlyDesc=NULL;
	char* VariantFormulaStr=NULL;
	char* VariantFormulaStrOptionVal=NULL;
	int vfrl=0;

	char *qry_entriesOptFam[] = {"ID"};
	tag_t queryTagOptFam = NULLTAG;
	tag_t *revOptFam=NULL;
	int resultCountOptFam=0;
	int n_entriesOptFam=1;
	int n_entries = 1;
	int k=0;
	int j1=0;
	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesOptFam = (char **) MEM_alloc(10 * sizeof(char *));



	char *svr_1 = NULL;
	char *svr_2 = NULL;
	/*char svr_1[500] = { 0 };
	char svr_2[500] = { 0 };*/
	char* option_token = NULL;
	char* equaltok = NULL;
	char **attrs_name = NULL;
	int ioc = 0;
	int joc = 0;
	int last_ioc = 0;
	char* tokstr = {"[" };
	int jCnt = 0;

	char *resultRule_1 = NULL;
	char *resultRule_2 = NULL;
	char *resultRule_3 = NULL;
	char *resultRule_4 = NULL;

	char* ClosureRule = NULL;
	PIE_scope_t scope;
	int n_closure_tags;
	tag_t* closure_tags;
	tag_t closure_tag;

	char* ClosureRule1 = NULL;
	PIE_scope_t scope1;
	int n_closure_tags1;
	tag_t* closure_tags1;
	tag_t closure_tag1;
	char *ChildPrtQty_req_info	= NULL;
	char* rev_release_statuses = NULL;
	char *uid = NULL;
	int  bl_config = 0 ;
	logical bl_config_log;


	struct node_mis *start_sap = NULL;
	struct node_mis *start_plm = NULL;
	struct node_mis *p_plm = NULL;
	struct node_mis *q_plm = NULL;

	//char* PartList = { "5442B1A0165001;5442B1A0263001;5442B1B0163001;5442B1B0263001;5442B1B0365001;5442B1B0463001;5442B1C0163001;5442B1C0365001;5442B1C0463001;5442B1C0563001;5442B1D0163001;5442B1E0163001;5442B2A0161001;5442B2A0261001;5442B2A0362001;5442B2B0161001;5442B2B0261001;5442B2B0362001;5442B2B0462001;5442B2C0161001;5442B2C0261001;5442B2D0162001;5442B2E0161001;5442B3A0181001;5442B3A0288001;5442B3A0372001;5442B3A0473001;5442B3A0574001;5442B3A0672001;5442B3A0760001;5442B3A0860001;5445B1A0165001;5445B1A0165002;5445B1A0263001;5445B1B0163001;5445B1B0263001;5445B1B0263002;5445B1B0365001;5445B1B0463001;5445B1C0163001;5445B1C0365001;5445B1C0463001;5445B1C0563001;5445B1D0163001;5445B1E0163001;5445B2A0362001;5445B2B0161001;5445B2B0362001;5445B2B0462001;5445B2C0261001;5445B2D0162001;5445B2E0161001;5445B3A0181001;5445B3A0288001;5445B3A0372001;5445B3A0473001;5445B3A0574001;5445B3A0574002;5445B3A0672001;5445B3A0760001;5445B3A0860001" };

	oDrwNum1 = (char *)malloc(500 * sizeof(char));
	OptValNameCopy= (char *)malloc(500 * sizeof(char));
	formula= (char *)malloc(10000 * sizeof(char));
	//aformula= (char *)malloc(10000 * sizeof(char));
	aPotx1= (char *)malloc(40 * sizeof(char));
	o1Context_VariantRule= (char *)malloc(10000 * sizeof(char));
	o2Context_VariantRule= (char *)malloc(10000 * sizeof(char));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	meas_unit = (char *) malloc(5 * sizeof(char));
	sr_no = (char *) malloc(5 * sizeof(char));

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n");

	AssyNo = ITK_ask_cli_argument("-i=");
	plantcode = ITK_ask_cli_argument("-t=");
	//sRevision	= ITK_ask_cli_argument("-r=");
	//sSequence	= ITK_ask_cli_argument("-s=");
	iSapServer	= ITK_ask_cli_argument("-s=");


	//printf("\nInput ArchNode:%s\n", AssyNo);
	//OUTS("ArchNode",10,30,AssyNo);

	//tc_strdup(sRevision,&AssemblyRevisionDup);
	//tc_strdup(sSequence,&SequenceRevisionDup);
	tc_strdup("ERC",&OrganizationIDDup);

	sprintf(fsuccess_name,"TCUA_SAP_MODULERBOM_CRCH_%s.log",AssyNo);
	fsuccess = fopen(fsuccess_name,"a");
	if(fsuccess == NULL)
	//printf("Unable To open Or Create Log  file\n");
	OUTS("Unable To open Or Create Log  file",10,30,"");



	//plantcode = (char *)MEM_alloc(15);

	//tc_strcpy(plantcode,"1100");



	//exit(0);

	BapiLogon();

	ITK_CALL(ITEM_find_item( AssyNo, &node_tag ));

	/*if(queryTag)
	{
		printf("\nFound Query PartMatQuery\n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query PartMatQuery\n");fflush(stdout);
	}*/

	//Executing query
	//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));

	//printf("\nresultCount :%d:\n",resultCount);fflush(stdout);


	if (node_tag != NULLTAG)
	{
		//printf("PlatForm : %s Found\n",AssyNo);fflush(stdout);
		OUTS("PlatForm",10,30,AssyNo);
		ITK_CALL(ITEM_ask_type2 (node_tag, &item_type));
		//printf("Main item_typeS [%s]\n",item_type);  fflush(stdout);
		OUTS("Main item_type",10,30,item_type);
		//PartOPtr=partObjs[0];
		//goto CLEANUP;
	}
	else
	{
		//printf("PlatForm %s not found in TCUA\n",AssyNo);
		OUTS("PlatForm not found in TCUA",10,30,AssyNo);
		goto CLEANUP;
	}

	//ITK_CALL(ITEM_ask_latest_rev(PartOPtr,&LatestPRev));
	//ITK_CALL(AOM_UIF_ask_value(PartOPtr,"object_string",&LatRevName));
	//ITK_CALL(AOM_UIF_ask_value(PartOPtr,"t5_ArchModuleAddress",&LatRevName));


	//ITK_CALL(AOM_UIF_ask_value(PartOPtr,"owning_user",&POwnerName));
	//tc_strdup(POwnerName,&POwnerNameDup);
	//
	//
	//printf("\nPartName: %s	POwnerName: %s",LatRevName,POwnerName);fflush(stdout);
	//
	//ITK_CALL(AOM_UIF_ask_value(PartOPtr,"bl_item_object_type",&prtType));
	//ITK_CALL(AOM_UIF_ask_value(PartOPtr,"item_id",&assy_no));
	//tc_strdup(prtType,&prtTypeDup);
	//tc_strdup(assy_no,&assy_noDup);

	//printf("\nPart Number: %s",assy_no);fflush(stdout);

	if(tc_strcmp(item_type, "T5_Platform") == 0)	//Expanding Module BOM to TPL
	{
		//SapBomCreate(AssyNo);
		//goto CLEANUP;

		attrs[0] = "item_id";
		values[0] = AssyNo;

		ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

		ITK_CALL(ITEM_ask_latest_rev(node_tag,&latestrev));

		if (latestrev!=NULLTAG)
		{
			ITK_CALL( AOM_ask_value_string(latestrev,"object_string",&curentname));
			//printf("latest revision---------------> %s\n",curentname);fflush(stdout);
			OUTS("T5_Platform latest revision",10,30,curentname);
		}

		//ITK_CALL(PS_where_used_all(latestrev,1,&n_parents,&levels,&parents));
		//printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout);
		//
		//if(n_parents>0)
		//{
		//  for (jd=0;jd<n_parents;jd++ )
		//  {
		//	priobjTypeTag=parents[jd];
		//	ITK_CALL(AOM_ask_value_string(priobjTypeTag,"item_id",&priobj_name));
		//	 printf("\n\n\t\t Platform Name ==> %s\n", priobj_name);fflush(stdout);
		//  }
		//}


		if (n_tags_found == 0)
		{
			//printf("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", AssyNo);
			OUTS("ITEM_find_items_by_key_attributes returns success,  but didn't find",10,30,AssyNo);
			exit(0);
		}
		else if (n_tags_found > 1)
		{
			MEM_free(tags_found);
			EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
			//printf( "More than one items matched with id %s\n", AssyNo);
			OUTS("More than one items matched with id",10,30,AssyNo);
			exit(0);
		}

		ITK_CALL(ITEM_ask_item_of_rev(latestrev, &platformrev));
		ITK_CALL(AOM_ask_value_string(platformrev,"item_id",&pltfrm_str));
		//printf("pltfrm_str String Type is :%s\n",pltfrm_str); fflush(stdout);
		OUTS("pltfrm_str String Type",10,30,pltfrm_str);

		ITK_CALL(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
		if(relation_dep != NULLTAG)
		{
			//printf("Variant ConfigContext relation found......\n");	fflush(stdout);
			OUTS("Variant ConfigContext relation found",10,30,"");
		}

		ITK_CALL(GRM_list_secondary_objects_only(platformrev,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
		printf("Configuration Context count is : %d\n",countConfigCtx);

		//context query dbk
		ConfigCtx=ConfigCtxSecObject[0];
		ITK_CALL(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
		ITK_CALL(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));
		//printf( "Config relation Config_CtxType :%s\n",Config_CtxType);
		OUTS("Config relation Config_CtxType",10,30,Config_CtxType);

		ITK_CALL(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
		//printf("SmVCContext Object String Type is :%s\n",SmVCContext);	fflush(stdout);
		OUTS("SmVCContext Object String Type",10,30,SmVCContext);

		ITK_CALL(AOM_ask_value_string(ConfigCtx,"item_id",&Context_Str));
		//printf("Context_Str :%s\n",Context_Str);	fflush(stdout);
		OUTS("Context_Str",10,30,Context_Str);

		//commented by dbk as not used and called twice
		/*ITK_CALL(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
		printf("SmCrIDContext Object String Type is :%s\n",SmCrIDContext);	fflush(stdout);

		if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
		if (queryTag)
		{
			//printf("Found Query\n");fflush(stdout);
		}
		else
		{
			printf("Not Found Query3\n");fflush(stdout);
		}

		qry_values[0] = SmCrIDContext;
		printf("Querying in table Cfg0OptionFamiliesFromIDs attribute [%s] value [%s]\n",qry_entries[0],qry_values[0]);
		if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
		printf("Cfg0OptionFamiliesFromIDs for %s	 resultCount :%d\n",SmCrIDContext, resultCount); fflush(stdout);*/
		//commented by dbk as not used and called twice
		//--------------------


		if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTagOptFam));
		//printf("After IFERR_REPORT : QRY_find...1111... \n");fflush(stdout);
		if (queryTagOptFam)
		{
			//printf("3.Found Query\n");fflush(stdout);
			OUTS("Found Query",10,30,"");
		}
		else
		{
			//printf("Not Found Query33\n");fflush(stdout);
			OUTS("Not_Found_Query",10,30,"");
		}
		qry_valuesOptFam[0] = Context_Str;
		//printf("Querying in table Cfg0OptionFamiliesFromIDs attribute [%s] value [%s]\n",qry_entriesOptFam[0],qry_valuesOptFam[0]);
		OUTS(qry_entriesOptFam[0],10,30,qry_valuesOptFam[0]);
		if(QRY_execute(queryTagOptFam, n_entriesOptFam, qry_entriesOptFam, qry_valuesOptFam, &resultCountOptFam, &revOptFam));
		printf("Cfg0OptionFamiliesFromIDs for %s resultCountOptFam:%d\n",Context_Str, resultCountOptFam); fflush(stdout);
		//context query dbk



		item_tag= tags_found[0];
		MEM_free(tags_found);

		ITK_CALL(ITEM_ask_latest_rev(item_tag,&PlatLatestRev));

		ITK_CALL(BOM_create_window (&window));
		//ITK_CALL(CFM_find( "Latest by Creation Date", &rule ));
		//ITK_CALL(CFM_find( "ERC release and above", &rule ));
		//ITK_CALL(CFM_find( "APLC Release and above", &rule ));
		ITK_CALL(CFM_find( "STDC Released and Above", &rule ));
		ITK_CALL(BOM_set_window_config_rule( window, rule ));
		ITK_CALL(BOM_set_window_pack_all (window, false));

		//-----------closure rule

		ClosureRule = (char *) MEM_alloc(100 * sizeof(char ));
		//tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLC");
		tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDC");
		//printf("\nClosureRule :[%s]",ClosureRule);
		OUTS("ClosureRule",10,30,ClosureRule);
		ITK_CALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &n_closure_tags, &closure_tags ));
		printf("\nn_closure_tags %s:%d ..............",ClosureRule,n_closure_tags);fflush(stdout);
		if(n_closure_tags > 0)
		{
			closure_tag=closure_tags[0];
			ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
		}
		//-----------closure rule

		ITK_CALL(BOM_set_window_top_line (window, null_tag, PlatLatestRev, null_tag, &PerentLine));
		ITK_CALL(BOM_line_ask_child_lines(PerentLine, &CntChildArch, &ChildArchLine));

		printf("CntChildArch:%d\n",CntChildArch);

		if(CntChildArch>0)
		{
//			start = NULL;
//			p = NULL;
//			q = NULL;
			ret = 0;

			for(ai=0;ai<CntChildArch;ai++)	//expand platform to architecture node
			//for(ai=0;ai<90;ai++)	//architecture node expand	5442T1A0169001 or condition
			{
				Arch_tag=NULLTAG;
				Arch_tag=ChildArchLine[ai];
				printf("Architecture node index ai:[%d]\n\t",ai);fflush(stdout);
				//printf("\n\taobjectname11:%s:",objectname);fflush(stdout);
				if(ChildArchLine[ai])
				{
					if( AOM_ask_value_string(ChildArchLine[ai],"object_string",&objectname)==ITK_ok)
					//printf("latest revision--------------->%s\n\t",objectname);fflush(stdout);
					OUTS("latest revision",10,30,objectname);
					if( AOM_ask_value_string(ChildArchLine[ai],"bl_child_id",&childid)==ITK_ok)
					//printf("child id--------------->%s\n\t",childid);fflush(stdout);
					OUTS("childid",10,30,childid);
					if( AOM_ask_value_string(ChildArchLine[ai],"bl_item_object_type",&objectyp)==ITK_ok)
					//printf("latest revision---------------> %s\n\t",objectyp);fflush(stdout);
					OUTS("objectype",10,30,objectyp);
					//ITK_CALL(AOM_ask_value_string(Arch_tag,"bl_item_item_id",&objectname));
					//ITK_CALL(AOM_UIF_ask_value(Arch_tag,"bl_item_object_type",&objectyp));
				}
				else
				{
					//printf("Tag does not having any value\n\t");fflush(stdout);
					OUTS("Tag does not having any value",10,30,"");
				}
				//printf("objectname:%s:\n\t",objectname);fflush(stdout);
				OUTS("objectname",10,30,objectname);
				//ITK_CALL(ITEM_ask_item_of_rev(Arch_tag, &Anode_tag));
				//ITK_CALL(AOM_ask_value_string(Anode_tag,"item_id",&Arch_str));
				// printf("\n\t Arch_str String Type is :%s",Arch_str); fflush(stdout);

				//AOM_ask_value_string(Arch_tag,"object_type",&objectyp);
				//printf("\n\t objectyp:%s:",objectyp);
				//ITK_CALL(ITEM_find_item( objectname, &Anode_tag ));

				values1[0] = childid;

				//printf("\n1");fflush(stdout);

				ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs1, values1, &n_tags_found1, &tags_found1));
				
				printf("\nArch Item Found %d\n",n_tags_found1);

				item_tag1= tags_found1[0];
				MEM_free(tags_found1);

				ITK_CALL(ITEM_ask_latest_rev(item_tag1,&Archrev));

				//ITK_CALL(ITEM_ask_item_of_rev(Arch_tag, &Archrev));
				ITK_CALL(AOM_ask_value_string(Archrev,"item_id",&Arch_str));
				//printf("Archrev String Type is :%s\n\t",Arch_str); fflush(stdout);
				OUTS("Archrev String Type",10,30,Arch_str);


				if(tc_strcmp(objectyp, "T5_ArchModule") == 0)	//Expanding Module BOM to TPL
				{
					//printf("Expanding %s Arch Module BOM...\n\t",objectname);
					OUTS("Expanding Arch Module BOM",10,30,objectname);

					ITK_CALL(BOM_create_window (&window1));
					//ITK_CALL(CFM_find( "Latest by Creation Date", &rule ));
					//ITK_CALL(CFM_find( "APLC Release and above", &rule1 ));
					ITK_CALL(CFM_find( "STDC Released and Above", &rule1 ));
					ITK_CALL(BOM_set_window_config_rule( window1, rule1 ));


					//-----------closure rule

					ClosureRule1 = (char *) MEM_alloc(100 * sizeof(char ));
					//tc_strcpy(ClosureRule1,"BOMViewClosureRuleAPLC");
					tc_strcpy(ClosureRule1,"BOMViewClosureRuleSTDC");
					//printf("\nClosureRule :[%s]",ClosureRule1);
					OUTS("ClosureRule1",10,30,ClosureRule1);
					ITK_CALL(PIE_find_closure_rules( ClosureRule1,PIE_TEAMCENTER, &n_closure_tags1, &closure_tags1 ));
					printf("\nn_closure_tags %s:%d ..............",ClosureRule1,n_closure_tags1);fflush(stdout);
					if(n_closure_tags1 > 0)
					{
						closure_tag1=closure_tags1[0];
						ITK_CALL(BOM_window_set_closure_rule(window1,closure_tag1,0,NULL,NULL));
					}
					//-----------closure rule
					printf("\nCore_Dump1");
					ITK_CALL(BOM_set_window_pack_all (window1, false));
					printf("\nCore_Dump2");
					ITK_CALL(BOM_set_window_top_line (window1, null_tag, Archrev, null_tag, &PerentLine1));
					printf("\nCore_Dump3");
					ITK_CALL(BOM_line_ask_child_lines(PerentLine1, &CntChildP, &ChildPartLine));
					printf("\nCore_Dump4");

					printf("\nCntChildP:%d\n",CntChildP);


					if(CntChildP>0)
					{
						for(i=0;i<CntChildP;i++)//expand architecture node to module
						{
							/*if ( i == 100)
							{
								break;
							}*/
							printf("\nModule Index:[%d]\n\t\t",i);fflush(stdout);
							//aformula= (char *)malloc(10000 * sizeof(char));
							aformula = (char *)MEM_alloc(10000);  //dbk.07.04
							strcpy(formula,"");
							strcpy(aformula,"");
							strcpy(aPotx1,"");
							ChildOPtr=NULLTAG;
							ChildOPtr=ChildPartLine[i];


							ITK_CALL(AOM_ask_value_string(ChildOPtr,"bl_rev_release_statuses",&rev_release_statuses));

							BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID);
							BOM_line_ask_attribute_string(ChildOPtr, Item_ID, &ChildRevName);

							printf("\nrev_release_statuses:[%s]%s",rev_release_statuses,ChildRevName);fflush(stdout);


							bl_config = 0;
							ITK_CALL( BOM_line_look_up_attribute ("bl_is_occ_configured",&bl_config));
							printf("\nbl_config= [%d]\n", bl_config);

							ITK_CALL(BOM_line_ask_attribute_logical(ChildOPtr, bl_config, &bl_config_log));
							printf("\nbl_config_log ChildRevName %s= [%d]",ChildRevName,bl_config_log);
							//if (bl_config_log == 0)
							if (bl_config_log == false)
							{
								/*printf("\n Inside bl_config_log::Flag ::>>> false \n"); fflush(stdout);
								printf("bl_config_log= [%d]\n",bl_config_log);fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,ITK_err,"Please untick option {Show Unconfigured By Occurance Effectivity }","By sending module to Structure manager ->View ->Show Unconfigured By Occurance Effectivity");
								decision = EPM_nogo;
								return decision;*/
								printf("\tskipping unconfigured %s",ChildRevName);
								continue;
							}

							OUTS("rev_release_statuses",10,30,rev_release_statuses);
							OUTS("ChildRevName",10,30,ChildRevName);

							

							if(tc_strcmp(rev_release_statuses,"")==0)
							{
								//printf("\nPart with /??? no revision found as per rule and closure rule applied %s",ChildRevName);
								OUTS("Part with /??? no revision found as per rule and closure rule applied skipping",10,30,ChildRevName);
								continue;
							}

							/*if(strstr(PartList,ChildRevName) !=NULL)
							{
								printf("\nSkipping %s as per list from Shrikant Bawiskar mail dated 06-Feb-2019", ChildRevName);fflush(stdout);
								continue;
							}*/

							ITK_CALL( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Child_Item_RevSeq));
							ITK_CALL(BOM_line_ask_attribute_string(ChildOPtr, Child_Item_RevSeq, &Child_Item_RevSeq_str));

							OUTS("ChildRevSeq",10,30,Child_Item_RevSeq_str);


							BOM_line_look_up_attribute ("bl_item_uom_tag",&Item_UoM);
							BOM_line_ask_attribute_string(ChildOPtr,Item_UoM,&ChildPrtUoM);

							BOM_line_look_up_attribute ("awb0RevisionOwningUser",&Item_Owner);
							BOM_line_ask_attribute_string(ChildOPtr,Item_Owner,&ChildOwnName);

							AOM_ask_value_string(ChildOPtr,"bl_quantity",&ChildPrtQty);
							tc_strdup(ChildPrtQty,&ChildQtyDup);

							/*if(tc_strlen(ChildPrtUoM)>0)
							{
								tc_strdup(ChildPrtUoM,&unitDup);
								if (tc_strcmp(unitDup,"1") == 0) tc_strcpy(meas_unit,"M ");
								else if (tc_strcmp(unitDup,"2") == 0) tc_strcpy(meas_unit,"KG");
								else if (tc_strcmp(unitDup,"3") == 0) tc_strcpy(meas_unit,"L ");
								else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
								else if (tc_strcmp(unitDup,"5") == 0) tc_strcpy(meas_unit,"M2");
								else if (tc_strcmp(unitDup,"each") == 0) tc_strcpy(meas_unit,"EA");
								else if (tc_strcmp(unitDup,"7") == 0) tc_strcpy(meas_unit,"TO");
								else if (tc_strcmp(unitDup,"8") == 0) tc_strcpy(meas_unit,"M3");
								else if (tc_strcmp(unitDup,"9") == 0) tc_strcpy(meas_unit,"TS");
								else tc_strdup("EA",&unitDup);
							}
							else tc_strcpy(meas_unit,"EA");*/

							if(tc_strlen(ChildPrtUoM)>0)
							{
								tc_strdup(ChildPrtUoM,&unitDup);
								if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
								else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
								else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
								else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
								else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
								else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
								else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
								else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
								else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
								else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
								else
								{
									tc_strdup("EA",&unitDup);
									tc_strcpy(meas_unit,"EA");
								}
							}
							else tc_strcpy(meas_unit,"EA");



							//---------------------------qty logic
							AOM_ask_value_string(ChildOPtr,"bl_occ_t5_Qri",&ChildPrtQty_req_info);
							if ( tc_strcmp ( ChildPrtQty, "0" ) == 0 )
							{
								printf("\tchild %s qty is 0",ChildRevName);
								continue;
							}
							if ( tc_strcmp ( ChildPrtQty, "" ) == 0 )
							{
								printf("\tchild %s qty is null",ChildRevName);
								continue;
							}
							//qty logic commented as it will not applicable in case of X4 and module relation as per meeting on 29.05.2020
							
							/*if(tc_strcmp(ChildPrtQty,"")==0)
							{
								ChildPrtQty		= (char *) malloc(20 * sizeof(char));
								tc_strcpy(ChildPrtQty,"999999");
							}
							else if(tc_strcmp(ChildPrtQty,"99")==0)
							{
								tc_strcpy(ChildPrtQty,"999999");
							}
							else if(tc_strcmp(ChildPrtQty,"97")==0)
							{
								tc_strcpy(ChildPrtQty,"0");
							}
							if((tc_strcmp(ChildPrtQty,"0")==0) && ((tc_strcmp(ChildPrtQty_req_info,"NA")==0) || (tc_strcmp(ChildPrtQty_req_info,"+")==0)))
							{
								printf("\nSkipping Part:[%s] quantity:[%s] quantityInfo:[%s]",ChildRevName,ChildPrtQty,ChildPrtQty_req_info);
								continue;
							}

							if((tc_strcmp(ChildPrtQty,"1")==0) && (tc_strcmp(ChildPrtQty_req_info,"+")==0))
							{
								printf("\nSkipping Part:[%s] quantity:[%s] quantityInfo:[%s]",ChildRevName,ChildPrtQty,ChildPrtQty_req_info);
								continue;
							}

							if ((tc_strcmp(ChildPrtQty,"0")==0) && (tc_strcmp(ChildPrtQty_req_info,"AR")==0))
							{
								printf("\nquantity after AR logic [%s,%s]",ChildRevName,ChildPrtQty);
								tc_strcpy(ChildPrtQty,"1");
							}

							if(tc_strcmp(ChildPrtQty,"999999")==0)
							{

								if ((tc_strcmp(meas_unit,"KG")==0) || (tc_strcmp(meas_unit,"L")==0) || (tc_strcmp(meas_unit,"M")==0) || (tc_strcmp(meas_unit,"M2")==0) || (tc_strcmp(meas_unit,"M3")==0))
								{
									tc_strcpy(ChildPrtQty ,"0.001");
								}
								else
								{
									tc_strcpy(ChildPrtQty ,"1");
								}

								printf("\n%s Quantity for 99 QTY:[%s],[%s]",ChildRevName,ChildPrtQty,meas_unit);fflush(stdout);

							}

							if ((tc_strcmp(ChildPrtQty,"1")==0) && (tc_strcmp(ChildPrtQty_req_info,"AR")==0))
							{
								if ((tc_strcmp(meas_unit,"KG")==0) || (tc_strcmp(meas_unit,"L")==0) || (tc_strcmp(meas_unit,"M")==0) || (tc_strcmp(meas_unit,"M2")==0) || (tc_strcmp(meas_unit,"M3")==0))
								{
									tc_strcpy(ChildPrtQty,"0.001");
								}
								else
								{
									tc_strcpy(ChildPrtQty,"1");
								}
								printf("\n%s Quantity:[1-AR] QTY:[%s],[%s]",ChildRevName,ChildPrtQty,meas_unit);

							}
							if ((tc_strcmp(ChildPrtQty,"0")==0) && (tc_strcmp(ChildPrtQty_req_info,"")==0))
							{
								printf("\nquantity [0] quantityInfo null %s",ChildRevName);
								continue;
							}*/

							//---------------------------qty logic


							//---------------------------part type
							ChildItemRev = ask_item_revision_from_bom_line(ChildOPtr);

							ITK_CALL(AOM_ask_value_string(ChildItemRev,"t5_CarMakeBuyIndicator",&make_buy_indDup));

							if(tc_strlen(make_buy_indDup)>0)
							{
								//tc_strdup(make_buy_ind,&make_buy_indDup);

								if(tc_strcmp(make_buy_indDup,"F18") == 0)
								{
									tc_strdup("L",&mat_prov_ind);
									tc_strdup("1",&tempcsrel);
								}
								else
								{
									tc_strdup("",&mat_prov_ind);
									tc_strdup("X",&tempcsrel);
								}
							}

							ITK_CALL(AOM_ask_value_string(ChildItemRev,"t5_PartType",&sPartType));
							if(tc_strcmp(sPartType,"D")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							else if(tc_strcmp(sPartType,"DA")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							else if(tc_strcmp(sPartType,"DC")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							else if(tc_strcmp(sPartType,"IFD")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							else if(tc_strcmp(sPartType,"IM")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							else if(tc_strcmp(sPartType,"CP")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							//---------------------------part type




							printf("\nChild Part Number [%s] Part Qty [%s]	UoM [%s]	Owner [%s]............Arch_str [%s]",ChildRevName,ChildPrtQty,ChildPrtUoM,ChildOwnName,Arch_str);

							ITK_CALL(AOM_ask_value_string(ChildOPtr,"bl_occ_t5_uidsap",&uid));

							printf("\tuid:[%s]",uid);





							/*if ( tc_strcmp ( ChildRevName, "5442E3A0154001" ) == 0 )//5442E3A0154002//5442E3A0154003
							{
								continue;
							}
							if ( tc_strcmp ( ChildRevName, "5442E3A0154002" ) == 0 )
							{
								continue;
							}
							if ( tc_strcmp ( ChildRevName, "5442E3A0154003" ) == 0 )
							{
								continue;
							}*/

							AOM_ask_value_string(ChildOPtr,"bl_formula",&Context_VariantRule);
							OUTS("formula before",10,30,Context_VariantRule);

							if ( tc_strcmp ( Context_VariantRule, "" ) == 0 )
							{
								printf ( "\nError:Variant formulae blank:%s:%s", ChildRevName, Context_VariantRule );
								continue;
							}

							resultRule_1 = (char *)MEM_alloc(20000);
							resultRule_2 = (char *)MEM_alloc(10000);
							tc_strcpy(resultRule_2,"");
							tc_strcpy(resultRule_2,Context_VariantRule);
							tc_strcpy(resultRule_1,"");
							tc_strcpy(resultRule_1,Context_VariantRule);

//							if ( tc_strcmp(resultRule_2,"(((([Teamcenter]SCHEME-NO = CLRSCM-X4/19/0009 )  & [Teamcenter]'ROOF RAIL' = YES & [Teamcenter]COLOUR-BOM = Y  & [Teamcenter]'VEHICLE AGGREGATE' = BIW & [Teamcenter]'VEHICLE TYPE' = 'MINI SUV' & [Teamcenter]'VEHICLE DRIVE' = RHD & [Teamcenter]'MBOM INCLUSION' = YES & ([Teamcenter]'FUEL TYPE' = DIESEL | [Teamcenter]'FUEL TYPE' = PETROL) & [Teamcenter]'REAR WIPER' = YES)))") == 0)
//							{
//								tc_strcpy(resultRule_2, "(((([Teamcenter]SCHEME-NO = CLRSCM-X4/19/0009) & [Teamcenter]'ROOF RAIL' = YES & [Teamcenter]COLOUR-BOM = Y & [Teamcenter]'VEHICLE AGGREGATE' = BIW & [Teamcenter]'VEHICLE TYPE' = 'MINI SUV' & [Teamcenter]'VEHICLE DRIVE' = RHD & [Teamcenter]'MBOM INCLUSION' = YES & ([Teamcenter]'FUEL TYPE' = DIESEL | [Teamcenter]'FUEL TYPE' = PETROL) & [Teamcenter]'REAR WIPER' = YES)))");
//							}

							//test and comment below 8 line single quote around value 21-feb19
							resultRule_2 = replaceWord(resultRule_2, " = ", " = '");
							resultRule_2 = replaceWord(resultRule_2, ") & ", "') & ");
							resultRule_2 = replaceWord(resultRule_2, " & ", "' & ");
							resultRule_2 = replaceWord(resultRule_2, " | ", "' | ");
							resultRule_2 = replaceWord(resultRule_2, "))))", "'))))");
							resultRule_2 = replaceWord(resultRule_2, ")))", "')))");
							resultRule_2 = replaceWord(resultRule_2, "''", "'");
							resultRule_2 = replaceWord(resultRule_2, "''", "'");
							//test and comment below 8 line single quote around value 21-feb19


							resultRule_2 = replaceWord(resultRule_2, "& ([Teamcenter]", "AND$ ([Teamcenter]");
							resultRule_2 = replaceWord(resultRule_2, "& [Teamcenter]", "AND$ [Teamcenter]");
							resultRule_2 = replaceWord(resultRule_2, "| ([Teamcenter]", "OR$ ([Teamcenter]");
							resultRule_2 = replaceWord(resultRule_2, "| [Teamcenter]", "OR$ [Teamcenter]");
							resultRule_2 = replaceWord(resultRule_2, "[Teamcenter]", "");

							//test and comment below 2 line single quote around value 21-feb19
							resultRule_2 = replaceWord(resultRule_2, "' & ", " & ");
							resultRule_2 = replaceWord(resultRule_2, "')' AND$", "') AND$");
							//test and comment below 2 line single quote around value 21-feb19

							svr_1 = (char *)MEM_alloc(10000);
							attrs_name = (char **)MEM_alloc(1000 * sizeof(char *));
							tc_strcpy(svr_1,Context_VariantRule);
							ioc = 0;
							last_ioc = 0;
							option_token = strtok(svr_1,tokstr);	//tokenize char in string "[Teamcenter]" in rule
							while ( option_token != NULL )
							{

								attrs_name[ioc] = option_token;
								option_token = strtok ( NULL, tokstr );
								ioc = ioc + 1;
							}

							last_ioc = ioc;

							//max last_ioc option will be there considered from row fetched
							OUTS("formula after teamcenter replace",10,30,resultRule_2);

							printf("\nno of options found in rule last_ioc:[%d] [%s]",last_ioc,ChildRevName);
							for (joc = 0 ; joc < last_ioc ; joc++)//dbk.07.04
							//for (joc = 1 ; joc < last_ioc ; joc++)
							{
									if(attrs_name[joc] != NULL)
									{
										printf("attrs_name[%d]:%s\n\t\t",joc,attrs_name[joc]);fflush(stdout);
										equaltok = strstr(attrs_name[joc],"=");
										if (equaltok != NULL )
										{
												*equaltok = '\0';
												resultRule_3 = replaceWord(attrs_name[joc], "Teamcenter]", "");
												resultRule_4 = replaceWord(resultRule_3, "'", "");
												resultRule_4[tc_strlen(resultRule_4)-1] = '\0';
												//printf("Option Name in Rule:[%s]\n\t\t",resultRule_4);fflush(stdout);

												for ( jCnt = 0; jCnt< resultCountOptFam; jCnt++ )
												{
													Optfmly_tag = revOptFam[jCnt];
													OptfmlyDesc=NULL;
													OptfmlyName=NULL;
													ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyName));

													char* resultRule_44 = (char*) MEM_alloc( 100 );
													char* OptfmlyName_new = (char*) MEM_alloc( 100 );
													char* OptfmlyDesc_new = (char*) MEM_alloc( 100 );

													tc_strcpy(resultRule_44,"'");
													tc_strcat(resultRule_44,resultRule_4);
													tc_strcat(resultRule_44,"'");

													tc_strcpy(OptfmlyName_new,"'");
													tc_strcat(OptfmlyName_new,OptfmlyName);
													tc_strcat(OptfmlyName_new,"'");


													if(tc_strcmp(resultRule_44,OptfmlyName_new)==0)
													{
														OUTS(resultRule_44,10,30,OptfmlyName_new);
														ITK_CALL(AOM_ask_value_string(Optfmly_tag,"current_desc",&OptfmlyDesc));
														printf("\nNeed to replace with:[%s][%s]",resultRule_4,OptfmlyDesc);
														printf("\nbefore OptfmlyDesc:[%s]",OptfmlyDesc);
														tc_strcpy(OptfmlyDesc_new,"'");
														tc_strcat(OptfmlyDesc_new,OptfmlyDesc);
														tc_strcat(OptfmlyDesc_new,"'");

														printf("\nafter OptfmlyDesc_new:[%s]",OptfmlyDesc_new);


														resultRule_2 = replaceWord(resultRule_2, resultRule_44, OptfmlyDesc_new);

														//if string is in single inverted quote then need to replce like below COLOUR-BOM SCHEME-NO
														if ( tc_strstr(resultRule_2,"COLOUR-BOM")!=NULL)
														{
															resultRule_2 = replaceWord(resultRule_2, "COLOUR-BOM", "COLOUR_BOM");
														}

														if ( tc_strstr(resultRule_2,"SCHEME-NO")!=NULL)
														{
															resultRule_2 = replaceWord(resultRule_2, "SCHEME-NO", "SCHEME_NO");
														}

														//printf("\nreplaced string:[%s]",resultRule_2);
														OUTS("replaced string",10,30,resultRule_2);

														break;
													}
													//MEM_free(resultRule_44);//dbk 07.04
												}
												
										}
									}
							}

							//printf("\n\nresultRule_2:%s\n",resultRule_2);fflush(stdout);

							//-----------added below code for removing single code of option 14-feb-2019
							resultRule_2 = replaceWord(resultRule_2, "' =", " =");
							resultRule_2 = replaceWord(resultRule_2, "('", "(");
							resultRule_2 = replaceWord(resultRule_2, "AND$ '", "AND$ ");
							resultRule_2 = replaceWord(resultRule_2, "OR$ '", "OR$ ");
							//-----------added below code for removing single code of option 14-feb-2019




							tc_strcpy(aformula,"");
							tc_strcpy(aformula,resultRule_2);

							tc_strcpy(aPotx1,"");
							tc_strcpy(aPotx1,uid);

							OUTS("formula after",10,30,aformula);

							//added on 06-apr-2021 dbk

							printf("\nfirst char of formulae aformula:[%c]",aformula[0]);
							printf("\nlast char of formulae aformula:[%c]",aformula[tc_strlen(aformula)-1]);
							
							if ( aformula[0] == '\'' )//if first char is single quote of option in formulae
							{
								aformula[0] = ' ';
							}

							if ( ( aformula[tc_strlen(aformula)-1] == ')' )	//last char is ')'
									&&
								( isalpha(aformula[tc_strlen(aformula)-2]) > 0 )	//second last is alphabate
								)
							{
								aformula[tc_strlen(aformula)-1] = '\'';//added to add single quote if last char is alphabate
								aformula[tc_strlen(aformula)] = ')';//added to add single quote if last char is alphabate
							}
							
							if ( isalpha(aformula[tc_strlen(aformula)-1]) > 0 )
							{
								aformula[tc_strlen(aformula)] = '\'';//added to add single quote if last char is alphabate
							}
							
							aformula[tc_strlen(aformula)] = '\0';

							printf("\nafter first char of formulae aformula:[%c]",aformula[0]);
							printf("\nsecond last char of formulae aformula:[%c]",aformula[tc_strlen(aformula)-1]);
							
							//aformula = stripBlanks ( aformula );
							//added on 06-apr-2021 dbk

							//free memory used
							printf("\nsvr_1:[%s]",svr_1);fflush(stdout);
							printf("\nContext_VariantRule:[%s]",Context_VariantRule);fflush(stdout);
							printf("\nresultRule_2:[%s]",resultRule_2);fflush(stdout);
							printf("\naformula:[%s]",aformula);fflush(stdout);
									
							
							//Options_array = (char **) MEM_alloc(20 * sizeof(char *));


							tc_strdup(ChildRevName,&part_noDup);
							floatQty = atof(ChildQtyDup);

							vfrl=tc_strlen(Context_VariantRule);
							
							printf("\nFinal Node String [%s][%7.3f][%s][%s][%s]\n\t\t",part_noDup,floatQty,meas_unit,aformula,aPotx1);fflush(stdout);
							fprintf(fsuccess,"\nFinal Node String [%s][%7.3f][%s][%s][%s]\n\t\t",part_noDup,floatQty,meas_unit,aformula,aPotx1);

							strcpy(sap_proc_type,"");
							strcpy(sap_spproc_type,"");
							strcpy(SAPpstat,"");
							strcpy(MRPpstat,"");

							GetCSPstat(part_noDup);

							pstat='0';
							pstat_mrp='0';
							pstat_acc='0';

							pstat_basicFun();

							
							if(vfrl>0)
							{
								if ( pstat_mrp != 'D' )
								{
									printf("\nchild skipped in bom transfer mat not exist:[%s][%s]",part_noDup,Child_Item_RevSeq_str);
								}
								//if ( pstat_mrp == 'D' )
								//{
									tc_strcpy(sr_no,"");
									if(p_plm == NULL)
									{
										sr_no1 = 1 ;
										p_plm = createnode_mis(sr_no,part_noDup,ChildQtyDup,aPotx1);
										start_plm = p_plm;
									}
									else
									{
										q_plm = start_plm;
										while(q_plm->next != NULL)
										{
											 q_plm = q_plm->next;
										}
										sr_no1 = sr_no1 + 1 ;
										q_plm->next = createnode_mis(sr_no,part_noDup,ChildQtyDup,aPotx1);

									}
								//}
								//else
								//{
								//	printf("\nchild skipped in bom transfer mat not exist:[%s]",part_noDup);
								//}

							}
							//dbk.07.04
							if ( svr_1 != NULL )
							{
								MEM_free(svr_1);
							}
							svr_1 = NULL;

							if ( attrs_name != NULL )
							{
								MEM_free(attrs_name);
							}
							attrs_name = NULL;

							if ( Context_VariantRuleTok1 != NULL )
							{
								MEM_free(Context_VariantRuleTok1);
							}
							Context_VariantRuleTok1 = NULL;

							if ( aformula != NULL )
							{
								MEM_free(aformula);
							}
							aformula = NULL;
							//dbk.07.04


						}//archetecture node child for loop

					}
					else
					{
						OUTS("NO Structure found for Node",10,30,assy_noDup);
					}

				}//If Node
			}
		}

		if(sr_no1 < 1)
		{
			//printf("Do not have structure in PLM %s\n",AssyNo);fflush(stdout);
			OUTS("Do not have structure in PLM",10,30,assy_noDup);
			//goto CLEANUP;
			//continue;
		}
		else
		{
			//printf("Modular Bom started");
			OUTS("Modular Bom SAP transfer started",10,30,AssyNo);
			//hRfc = BapiLogon();

			//commented by Devkant on 21feb19 uncomment for bom transfer
			//OUTS("\n\n\ncommented by Devkant on 21feb19 uncomment for bom transfer after value single quote handle\n\n\n",10,30,AssyNo);
			printf("\nPLM BOM");
			display_bom(start_plm);

			start_sap = NULL;

			start_sap = cll_cad_display_bom_with_sub_items(AssyNo, plantcode);
			printf("\nSAP BOM");
			display_bom(start_sap);

			compare(start_plm,start_sap,AssyNo,plantcode);

			my_free_mis(&start_plm);
			my_free_mis(&start_sap);
			goto CLEANUP;

		}
	}//If platform

	MEM_free(attrs);
	MEM_free(values);
	MEM_free(attrs1);
	MEM_free(values1);
	RfcClose(hRfc);

	CLEANUP:
		OUTS("CLEANUP...",10,30,AssyNo);
		RfcClose(hRfc);
		//printf("CLEANUP...\n"); fflush(stdout);
		ITK_CALL(POM_logout(false));
		return status;

	EXIT:
		OUTS("Exiting...",10,30,AssyNo);
		//printf("Exiting...\n");
		ITK_CALL(POM_logout(false));
		return status;
}

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	//static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;

	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

struct node* createnode(char sr_no[5],char *part,float* qty,char uq[4],char *formula,char *Potx1)
{
	struct node* p = NULL;

	p = (struct node*)malloc(sizeof(struct node));
	p->part = part;
	strcpy(p->sr_no,sr_no);
	strcpy(p->uq,uq);
	p->qty = *qty;

	p->formula = (char*) malloc(10000 * sizeof(char));
	tc_strcpy(p->formula,formula);

	p->Potx1 = (char*) malloc(40 * sizeof(char));
	tc_strcpy(p->Potx1,Potx1);

	printf("\nafter copy:%s,%s",Potx1,p->Potx1);
	p->next = NULL;
	return p;
}
void display_bom(struct node_mis *head)
{
	struct node_mis *p2=NULL;
	for(p2=head; p2!=NULL; p2 = p2->next)
	{
		printf("\n[%s][%s][%s][%s]",p2->sr_no,p2->part,p2->qty,p2->BomNo);fflush(stdout);
	}
}

struct node_mis* createnode_mis(char sr_no[5],char *part,char *qty,char *BomNo)
{
	struct node_mis* p = NULL;

	p = (struct node_mis*)malloc(sizeof(struct node_mis));
	tc_strcpy(p->sr_no,sr_no);

	p->part = (char *) MEM_alloc(19 * sizeof(char ));
	tc_strcpy(p->part,part);

	p->qty = (char *) MEM_alloc(19 * sizeof(char ));
	if ( strcmp(qty,"") != 0 )
	{
		tc_strcpy(p->qty,qty);
	}
	else
	{
		tc_strcpy(p->qty,"0.000");
	}

	p->BomNo = (char *) MEM_alloc(41 * sizeof(char ));
	if ( strcmp(BomNo,"") != 0 )
	{
		tc_strcpy(p->BomNo,BomNo);
	}
	else
	{
		tc_strcpy(p->BomNo,"NA");
	}

	p->next = NULL;
	return p;
}

int search(struct node* start,char *part,float* qty)
{
	struct node* p;
	int found = 1 ;

	p=start;
	/*while(p->next!=NULL)*/
	while(p!=NULL)
	{
			if(strcmp(p->part,part)==0)
			{
					//found;
					p->qty = p->qty + *qty;
					found = 0;
					break;
			}
			else
			{
				p=p->next;
				found = 1 ;
			}

		}
	return found;
}

char* subString(char* mainStringf ,int fromCharf ,	int toCharf)
{
    int i;
    char *retStringf;
    retStringf = (char*) malloc(toCharf+1);
    for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
    *(retStringf+i) = '\0';
    return retStringf;
}


RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException)
{
	//RFC_RC RfcRc;
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[1];
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfMATNR;
	Exporting[0].leng = sizeof(MATNR);
	Exporting[0].addr = eMatnr;

	Exporting[1].name = "PLANT";
	Exporting[1].nlen = 5;
	Exporting[1].type = handleOfWERKS_D;
	Exporting[1].leng = sizeof(WERKS_D);
	Exporting[1].addr = eWerks;

	Exporting[2].name = NULL;


	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_MATERIAL_GETALL",Exporting,Tables);

	switch (RfcRc)
	{
	  	case RFC_OK :

			Importing[0].name = "CLIENTDATA";
			Importing[0].nlen = 10;
			Importing[0].type = handleOfCLIENTDATA;
			Importing[0].leng = sizeof(CLIENTDATA);
			Importing[0].addr = iView;

			Importing[1].name = "PLANTDATA";
			Importing[1].nlen = 9;
			Importing[1].type = handleOfPLANTDATA;
			Importing[1].leng = sizeof(PLANTDATA);
			Importing[1].addr = iMrpView;

			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
	  			case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
		default: ;
	}
	return RfcRc;
}


int GetCSPstat(char cMaterial[50])
{
char xException[256];
//RFC_HANDLE hRfc;
//RFC_RC RfcRc;
MATNR eMatnr;
WERKS_D eWerks;
PLANTDATA iMrpView;
CLIENTDATA iView;

//printf("Processing GetCSPstat:[%s]\n\t\t",cMaterial);

//hRfc = BapiLogon();

//strcpy(sap_proc_type,"");
//strcpy(sap_spproc_type,"");
strcpy(SAPpstat,"");
strcpy(MRPpstat,"");

SETCHAR(eMatnr.Matnr,cMaterial);
//SETCHAR(eMatnr.Matnr,part_noDup);
SETCHAR(eWerks.WerksD,"1100");

//printf("\nhRfc:%d",hRfc);
RfcRc = export_CSpastat(hRfc,&eMatnr,&eWerks,&iMrpView,&iView,xException);

switch (RfcRc)
{
	case RFC_OK:
		//printf("\n In RFC_OK case...\n");	fflush(stdout);
		//GETCHAR(iMrpView.PROC_TYPE, proc_type1);		OUTS("PROC_TYPE",10,30,proc_type1);
		//GETCHAR(iMrpView.SPPROCTYPE, spproc_type);		OUTS("SPPROCTYPE",10,30,spproc_type);

		GETCHAR(iMrpView.PROC_TYPE, sap_proc_type);		//OUTS("PROC_TYPE",10,30,sap_proc_type);
		GETCHAR(iMrpView.SPPROCTYPE, sap_spproc_type);	//OUTS("SPPROCTYPE",10,30,sap_spproc_type);

		GETCHAR(iView.MAINT_STAT, SAPpstat);
		SAPpstat[14] = '\0';
		//OUTS("SAPpstat",10,30,SAPpstat);

		GETCHAR(iMrpView.MAINT_STAT, MRPpstat);
		MRPpstat[14] = '\0';
		//OUTS("MRPpstat",10,30,MRPpstat);

		//printf("\n...SAPpstat:[%s]\n\n",SAPpstat);
		//printf("\n...Material[%s]; proc_type1:[%s]; spproc_type:[%s]; SAPpstat:[%s]\n\n",cMaterial,proc_type1,spproc_type,SAPpstat);

	break;
	case RFC_EXCEPTION:
		printf("\nRFC Exception : %s\n",xException);
		exit(0);
	break;
	case RFC_SYS_EXCEPTION:
		printf("\nSystem Exception Raised!!!\n");
		exit(0);
	break;
	case RFC_FAILURE:
		printf("\nFailure!!!\n");
		exit(0);
	break;
	default:
		printf("\nOther Failure!\n");
		exit(0);
}

//RfcClose(hRfc);
return 0;
}

int pstat_basicFun(void)
{
	if(tc_strstr(SAPpstat,"K"))
	{
		pstat = 'K';
	}
	else
	{
		pstat = '0';
	}

	if(tc_strstr(MRPpstat,"D"))
	{
		pstat_mrp = 'D';
	}
	else
	{
		pstat_mrp = '0';
	}

	if(tc_strstr(MRPpstat,"B"))
	{
		pstat_acc = 'B';
	}
	else
	{
		pstat_acc = '0';
	}
	return 0;
}

void getTodayDate(char StdDate[11])
{
    struct tm *Sys_T = NULL;
    int Month;
    int Day;
    int Year;
    time_t Tval = 0;
    Tval = time(NULL);
    Sys_T = localtime(&Tval);
    Day=Sys_T->tm_mday;
    Month=Sys_T->tm_mon+1;
    Year=1900 + Sys_T->tm_year;
    sprintf(StdDate,"%02d.%02d.%04d",Day,Month,Year);
}
