/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : ercOldMatUpdateUA.c
* Created By                   : Amol P Narke
* Created On                   : 30/09/2020
* Project                      : Tata Motors TCUA-SAP Interface
* Methods Defined              :
* Description                  : Basic View Old Material Number Update
* Specific Notes               :
*
* Modification History :
* S.No		Date					CR No        Modified By		Modification Notes
***************************************************************************/
#define TE_MAXLINELEN  128
#define _CLMAIN_DEFNS
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>
#include <user_exits/user_exits.h>

#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"

int getChassisType(tag_t PartTag,char *part_type,char *part_ColorId);
void OldMatUpdateCall(char *Part_Num,char *OldMatNumber);

FILE *fsuccess;
char fsuccess_name[200];

char *iSapServer	= NULL;
char *part_noDup	= NULL;
char *OldMatNo		= NULL;
char *OldMatNoDup	= NULL;
char *mat_type		= NULL;
char *meas_unit		= NULL;


#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;

	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

RFC_RC BAPI_MATERIAL_SAVEDATA(RFC_HANDLE hRfc,
						BAPIMATHEAD *eBapiMatHead,
						BAPI_MARA	*eBasicView,
						BAPI_MARAX	*eBasicViewx,
						BAPIRET2	*eBapiret2,
						char *xException)
{


	RFC_PARAMETER Exporting[4];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[1];
	RFC_RC RfcRc;
	char *RfcException = NULL;

    printf("bi");
	Exporting[0].name = "HEADDATA";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfBAPIMATHEAD;
	Exporting[0].leng = sizeof(BAPIMATHEAD);
	Exporting[0].addr = eBapiMatHead;

	Exporting[1].name = "CLIENTDATA";
	Exporting[1].nlen = 10;
	Exporting[1].type = handleOfBAPI_MARA;
	Exporting[1].leng = sizeof(BAPI_MARA);
	Exporting[1].addr = eBasicView;

	Exporting[2].name = "CLIENTDATAX";
	Exporting[2].nlen = 11;
	Exporting[2].type = handleOfBAPI_MARAX;
	Exporting[2].leng = sizeof(BAPI_MARAX);
	Exporting[2].addr = eBasicViewx;

	Exporting[3].name = NULL;

	Tables[0].name = NULL;

	/*Tables[0].name     = "MATERIALDESCRIPTION";
	Tables[0].nlen     = 19;
	Tables[0].type     = handleOfBAPI_MAKT;
	Tables[0].ithandle = thBapi_Makt;

	Tables[1].name = NULL;*/

	RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

	switch (RfcRc)
	{

	case RFC_OK :
				Importing[0].name = "RETURN";  /*RETURN */
				Importing[0].nlen = 6;
				Importing[0].type = TYPC;
				Importing[0].leng = sizeof(BAPIRET2);
				Importing[0].addr = eBapiret2;

				Importing[1].name = NULL;
				RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
				//printf("\nRfcException:%s",RfcException);
				switch (RfcRc)
				{
					case RFC_SYS_EXCEPTION :
						strcpy(xException,RfcException);
					break;
					case RFC_EXCEPTION :
						strcpy(xException,RfcException);
					break;
				}

			break;
	default :
			printf("\nNOT RFC OK");
	}
  return RfcRc;
}

int getChassisType(tag_t PartTag,char *part_type,char *part_ColorId)
{
	int status;
	int Count = 0;
	tag_t	VehicleRevTag		= NULLTAG;
	tag_t	VehicleMstTag		= NULLTAG;
	tag_t	PartTagDup			= NULLTAG;
	tag_t	*NonColPartTags		= NULLTAG;
	tag_t	*VCChildTags		= NULLTAG;
	
	char *partType = NULL;

	tc_strdup(part_type,&partType);
	PartTagDup = PartTag;

	if (tc_strcmp(part_ColorId,"C")==0)
	{
		ITK_CALL(AOM_ask_value_tags(PartTag,"TC_Is_Represented_By",&Count,&NonColPartTags));
		PartTagDup = NonColPartTags[0];
		ITK_CALL(AOM_ask_value_string(PartTagDup,"t5_PartType",&partType));
	}

	if (tc_strcmp(partType,"VC")==0)
	{
		ITK_CALL(AOM_ask_value_tags(PartTagDup,"ps_children",&Count,&VCChildTags));
		VehicleRevTag = VCChildTags[0];

		ITK_CALL(AOM_ask_value_tag(VehicleRevTag,"items_tag",&VehicleMstTag));
		ITK_CALL(AOM_UIF_ask_value(VehicleMstTag,"T5_HasChassisTypeNo",&OldMatNo));
		tc_strdup(OldMatNo,&OldMatNoDup);
		printf("\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
		fprintf(fsuccess,"\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
	}

	if (tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0)
	{
		ITK_CALL(AOM_ask_value_tag(PartTagDup,"items_tag",&VehicleMstTag));
		ITK_CALL(AOM_UIF_ask_value(VehicleMstTag,"T5_HasChassisTypeNo",&OldMatNo));
		tc_strdup(OldMatNo,&OldMatNoDup);
		printf("\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
		fprintf(fsuccess,"\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
	}

}

extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	int kk=0;
	int is=0;
	int sflag=0;
	int i=0;
	int doccount=0;
	int len=0;
	int Refcount=0;
	int resultCount =0;
	int n_entries = 2; //no. of query input arg
	int n_tags_found = 1;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};

	tag_t queryTag = NULLTAG;
	tag_t docOPtr = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t resultOutputTag = NULLTAG;
	tag_t LatestRev=NULLTAG;
    tag_t docRelObjs=NULLTAG;
    tag_t *docObjs=NULLTAG;
    tag_t *refdocObjs=NULLTAG;
    tag_t doctag=NULLTAG;
    tag_t docRelObj=NULLTAG;
    tag_t refdocRelObj=NULLTAG;
	tag_t		*DesignTags			= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;

	char* sUserName	= NULL;
	char* sPassword = NULL;
	char *LatRevName=NULL;
	char *part_type=NULL;
	char *unit=NULL;
	char *part_typeDup=NULL;
	char *unitDup=NULL;
	char *doc_no=NULL;
	char *PrtRev=NULL;
	char* PartRelStatus = NULL;
	char *Lcs = NULL;

	static RFC_RC RfcRc;
	const char *attrs[2];
	const char *values[2];

	char *inputPart=NULL;
	char *dml_no_arg = NULL;
	char *PrtRevDup = NULL;
	char *part_noDup = NULL;
	char *desc = NULL;
	char *descDup = NULL;
	char *partClrIndDup = NULL;
	char *partClrInd = NULL;

	static RFC_HANDLE hRfc;

	//char *qry_entries[1] = {"Name"};
	char *qry_entries[] = {"Item ID","Release Status"};

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	inputPart = ITK_ask_cli_argument("-i=");
	iSapServer = ITK_ask_cli_argument("-s=");
	//dml_no_arg = ITK_ask_cli_argument("-c=");


	if(tc_strcmp(sUserName,"")==0 || tc_strcmp(sPassword,"")==0 || tc_strcmp(inputPart,"")==0 || tc_strcmp(iSapServer,"")==0)
	{
		printf("\nPartDesUpateUA -u=userid -p=password -i=inputPart -s=PVP\n");fflush(stdout);
		goto CLEANUP;
	}

	sprintf(fsuccess_name,"/user/plmsap/PLMSAP/ONE_TIME_LOG/PART_OLD_MAT_UPDATE_ONETIME_%s.log",inputPart);
	//sprintf(fsuccess_name,"PART_OLD_MAT_UPDATE_ONETIME_%s.log",inputPart);
	fsuccess = fopen(fsuccess_name,"a");

	//if(QRY_find("QueryDesignRev", &queryTag));
	if(QRY_find("Driver VC Query", &queryTag));
	
	if (queryTag)
	{
		printf("\nFound Query QueryDesignRev\n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query QueryDesignRev");fflush(stdout);
		goto CLEANUP;
	}
    
    printf("\nQueryig input Part %s\n ", inputPart);fflush(stdout);

	Lcs = (char *) MEM_alloc(1000);
	//tc_strcpy(Lcs,"T5_LcsAplRlzd");
	tc_strcpy(Lcs,"T5_LcsErcRlzd");

    qry_values[0] = inputPart;
    qry_values[1] = Lcs;

	//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));
	//1-Ascending 2- Descending
	ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &outTag));

    printf("\nPart Found Count %d", resultCount);fflush(stdout);

	if(resultCount>0)
	{
		LatestRev=outTag[0];
	}
	else
	{
		printf("\nPart %s Not found ERC Released and above in TCUA\n", inputPart);fflush(stdout);
		goto CLEANUP;
	}

	ITK_CALL(AOM_ask_value_string(LatestRev,"object_string",&LatRevName));
	printf("\nLatRevName:%s \n",LatRevName);fflush(stdout);
	fprintf(fsuccess,"\nLatRevName:%s \n",LatRevName);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&part_noDup));

	ITK_CALL(AOM_ask_value_string(LatestRev,"item_revision_id",&PrtRev));
	
	printf("\nPart [%s] Part Revision [%s]\n",part_noDup,PrtRev);fflush(stdout);
	fprintf(fsuccess,"\nPart [%s] Part Revision [%s]\n",part_noDup,PrtRev);fflush(stdout);

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));

	if(	
		tc_strstr(PartRelStatus,"STDSIC Released")!=NULL ||
		tc_strstr(PartRelStatus,"APLC Released")!=NULL ||
		tc_strstr(PartRelStatus,"ERC Released")!=NULL ||
		tc_strstr(PartRelStatus,"STDSIC Restructured")!=NULL
		)
	{
		printf("\nPartRelStatus: %s\n",PartRelStatus);
		fprintf(fsuccess,"\nPartRelStatus: %s\n",PartRelStatus);
		
	}
	else
	{
		printf("\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
		fprintf(fsuccess,"\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
		goto CLEANUP;
	}
		
	
	ITK_CALL(AOM_ask_value_string(LatestRev,"t5_PartType",&part_type));
	tc_strdup(part_type,&part_typeDup);

	printf("\nPart Type: %s\n", part_typeDup);
	printf("\npart_noDup: %s\n", part_noDup);

	if(	tc_strcmp(part_typeDup,"D")==0 ||
		tc_strcmp(part_typeDup,"DA")==0 ||
		tc_strcmp(part_typeDup,"DC")==0 ||
		tc_strcmp(part_typeDup,"IFD")==0 ||
		tc_strcmp(part_typeDup,"IM")==0 ||
		tc_strcmp(part_typeDup,"CP")==0)
	{
		printf("\nPart %s Has Type %s ! AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
		fprintf(fsuccess,"\nPart %s Has Type %s ! AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
		goto CLEANUP;
	}


	ITK_CALL(AOM_ask_value_string(LatestRev,"object_desc",&desc));

	if(tc_strlen(desc)>0)
	{
		tc_strdup(desc,&descDup);
		printf("\nDescription: %s", descDup);
	}
	else printf("\nDescription is NULL!");

	ITK_CALL(AOM_ask_value_string(LatestRev,"t5_ColourInd",&partClrInd));
	tc_strdup(partClrInd,&partClrIndDup);

	if (tc_strcmp(part_typeDup,"VC")==0 || tc_strcmp(part_typeDup,"CCVC")==0 || tc_strcmp(part_typeDup,"V")==0)
	{
		getChassisType(LatestRev,part_typeDup,partClrIndDup);
	}
	else
	{
		tc_strdup("",&OldMatNoDup);
		goto CLEANUP;
	}

	if (OldMatNoDup==NULL)
	{
		goto CLEANUP;
	}
	else
	{
		OldMatUpdateCall(part_noDup,OldMatNoDup);
	}
	
	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);

}

void OldMatUpdateCall(char *Part_Num,char *OldMatNumber)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256];
	char sap_msg[60];
	BAPIMATHEAD eBapiMatHead;
	RMMG1_AENNR eRmmg1_Aennr;
	BAPIRET2 eBapiret2;
	BAPI_MARA	eBasicView;
	BAPI_MARAX	eBasicViewx;

	ITAB_H thBapi_Makt = ITAB_NULL;
	BAPI_MAKT *tBapi_Makt;

	char *myzeroDup1 = NULL;
	char *myzeroDup3 = NULL;

	tc_strdup("0.0",&myzeroDup1);
	tc_strdup("0.000",&myzeroDup3);

	hRfc = BapiLogon();

	printf("\nGoing for Old Material Updation %s %s",Part_Num,OldMatNumber);
	fprintf(fsuccess,"\nGoing for Old Material Updation %s %s",Part_Num,OldMatNumber);

	SETCHAR(eBapiMatHead.Material,Part_Num);
	SETCHAR(eBapiMatHead.Ind_Sector,"M");
	SETCHAR(eBapiMatHead.Matl_Type,"FERT");
	SETCHAR(eBapiMatHead.Basic_View,"X");
	SETCHAR(eBapiMatHead.Sales_View,"");
	SETCHAR(eBapiMatHead.Purchase_View,"");
	SETCHAR(eBapiMatHead.Mrp_View,"");
	SETCHAR(eBapiMatHead.Forecast_View,"");
	SETCHAR(eBapiMatHead.Work_Sched_View,"");
	SETCHAR(eBapiMatHead.Prt_View,"");
	SETCHAR(eBapiMatHead.Storage_View,"");
	SETCHAR(eBapiMatHead.Warehouse_View,"");
	SETCHAR(eBapiMatHead.Quality_View,"");
	SETCHAR(eBapiMatHead.Account_View,"");
	SETCHAR(eBapiMatHead.Cost_View,"");
	SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
	SETCHAR(eBapiMatHead.Material_External,"");
	SETCHAR(eBapiMatHead.MateriaL_Guid,"");
	SETCHAR(eBapiMatHead.Material_Version,"");

	SETCHAR(eBasicView.Del_Flag,"");
	SETCHAR(eBasicView.Matl_Group,"");
	SETCHAR(eBasicView.Old_Mat_No,OldMatNumber);
	SETCHAR(eBasicView.Base_Uom,"EA");
	SETCHAR(eBasicView.Base_Uom_Iso,"EA");
	SETCHAR(eBasicView.Po_Unit,"");
	SETCHAR(eBasicView.Po_Unit_Iso,"");
	SETCHAR(eBasicView.Document,"");
	SETCHAR(eBasicView.Doc_Type,"");
	SETCHAR(eBasicView.Doc_Vers,"");
	SETCHAR(eBasicView.Doc_Format,"");
	SETCHAR(eBasicView.Doc_Chg_No,"");
	SETCHAR(eBasicView.Page_No,"");
	SETNUM(eBasicView.No_Sheets,"");
	SETCHAR(eBasicView.Prod_Memo,"");
	SETCHAR(eBasicView.Pageformat,"");
	SETCHAR(eBasicView.Size_Dim,"");
	SETCHAR(eBasicView.Basic_Matl,"");
	SETCHAR(eBasicView.Std_Descr,"");
	SETCHAR(eBasicView.Dsn_Office,"");
	SETCHAR(eBasicView.Pur_Valkey,"");
	SETBCD(eBasicView.Net_Weight,myzeroDup3,3);
	SETCHAR(eBasicView.Unit_Of_Wt,"");
	SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
	SETCHAR(eBasicView.Container,"");
	SETCHAR(eBasicView.Stor_Conds,"");
	SETCHAR(eBasicView.Temp_Conds,"");
	SETCHAR(eBasicView.Trans_Grp,"");
	SETCHAR(eBasicView.Haz_Mat_No,"");
	SETCHAR(eBasicView.Division,"");
	SETCHAR(eBasicView.Competitor,"");
	SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);
	SETCHAR(eBasicView.Proc_Rule,"");
	SETCHAR(eBasicView.Sup_Source,"");
	SETCHAR(eBasicView.Season,"");
	SETCHAR(eBasicView.Label_Type,"");
	SETCHAR(eBasicView.Label_Form,"");
	SETCHAR(eBasicView.Prod_Hier,"");
	SETCHAR(eBasicView.Cad_Id,"");
	SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
	SETCHAR(eBasicView.Pack_Wt_Un,"");
	SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
	SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
	SETCHAR(eBasicView.Pack_Vo_Un,"");
	SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
	SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
	SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
	SETCHAR(eBasicView.Var_Ord_Un,"");
	SETCHAR(eBasicView.Batch_Mgmt,"");
	SETCHAR(eBasicView.Sh_Mat_Typ,"");
	SETBCD(eBasicView.Fill_Level,"0",0);
	SETINT2(&eBasicView.Stack_Fact,"0");
	SETCHAR(eBasicView.Mat_Grp_Sm,"");
	SETCHAR(eBasicView.Authoritygroup,"");
	SETCHAR(eBasicView.Qm_Procmnt,"");
	SETCHAR(eBasicView.Catprofile,"");
	SETBCD(eBasicView.Minremlife,"0",0);
	SETBCD(eBasicView.Shelf_Life,"0",0);
	SETBCD(eBasicView.Stor_Pct,"0",0);
	SETCHAR(eBasicView.Pur_Status,"");
	SETCHAR(eBasicView.Sal_Status,"");
	SETDATE(eBasicView.Pvalidfrom,"");
	SETDATE(eBasicView.Svalidfrom,"");
	SETCHAR(eBasicView.Envt_Rlvt,"");
	SETCHAR(eBasicView.Prod_Alloc,"");
	SETCHAR(eBasicView.Qual_Dik,"");
	SETCHAR(eBasicView.Manu_Mat,"");
	SETCHAR(eBasicView.Mfr_No,"");
	SETCHAR(eBasicView.Inv_Mat_No,"");
	SETCHAR(eBasicView.Manuf_Prof,"");
	SETCHAR(eBasicView.Hazmatprof,"");
	SETCHAR(eBasicView.High_Visc,"");
	SETCHAR(eBasicView.Looseorliq,"");
	SETCHAR(eBasicView.Closed_Box,"");
	SETCHAR(eBasicView.Appd_B_Rec,"");
	SETNUM(eBasicView.Matcmpllvl,"00");
	SETCHAR(eBasicView.Par_Eff,"");
	SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
	SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
	SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
	SETCHAR(eBasicView.Item_Cat,"");
	SETCHAR(eBasicView.Haz_Mat_No_External,"");
	SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
	SETCHAR(eBasicView.Haz_Mat_No_Version,"");
	SETCHAR(eBasicView.Inv_Mat_No_External,"");
	SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
	SETCHAR(eBasicView.Inv_Mat_No_Version,"");
	SETCHAR(eBasicView.Material_Fixed,"");
	SETCHAR(eBasicView.Cm_Relevance_Flag,"");
	SETCHAR(eBasicView.Sled_Bbd,"");
	SETCHAR(eBasicView.Gtin_Variant,"");
	SETCHAR(eBasicView.Serialization_Level,"");
	SETCHAR(eBasicView.Pl_Ref_Mat,"");
	SETCHAR(eBasicView.Extmatlgrp,"");
	SETCHAR(eBasicView.Uomusage,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");

	SETCHAR(eBasicViewx.Del_Flag,"");
	SETCHAR(eBasicViewx.Matl_Group,"");
	SETCHAR(eBasicViewx.Old_Mat_No,"X");
	SETCHAR(eBasicViewx.Base_Uom,"X");
	SETCHAR(eBasicViewx.Base_Uom_Iso,"X");
	SETCHAR(eBasicViewx.Po_Unit,"");
	SETCHAR(eBasicViewx.Po_Unit_Iso,"");
	SETCHAR(eBasicViewx.Document,"");
	SETCHAR(eBasicViewx.Doc_Type,"");
	SETCHAR(eBasicViewx.Doc_Vers,"");
	SETCHAR(eBasicViewx.Doc_Format,"");
	SETCHAR(eBasicViewx.Doc_Chg_No,"");
	SETCHAR(eBasicViewx.Page_No,"");
	SETCHAR(eBasicViewx.No_Sheets,"");
	SETCHAR(eBasicViewx.Prod_Memo,"");
	SETCHAR(eBasicViewx.Pageformat,"");
	SETCHAR(eBasicViewx.Size_Dim,"");
	SETCHAR(eBasicViewx.Basic_Matl,"");
	SETCHAR(eBasicViewx.Std_Descr,"");
	SETCHAR(eBasicViewx.Dsn_Office,"");
	SETCHAR(eBasicViewx.Pur_Valkey,"");
	SETCHAR(eBasicViewx.Net_Weight,"");
	SETCHAR(eBasicViewx.Unit_Of_Wt,"");
	SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
	SETCHAR(eBasicViewx.Container,"");
	SETCHAR(eBasicViewx.Stor_Conds,"");
	SETCHAR(eBasicViewx.Temp_Conds,"");
	SETCHAR(eBasicViewx.Trans_Grp,"");
	SETCHAR(eBasicViewx.Haz_Mat_No,"");
	SETCHAR(eBasicViewx.Division,"");
	SETCHAR(eBasicViewx.Competitor,"");
	SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
	SETCHAR(eBasicViewx.Proc_Rule,"");
	SETCHAR(eBasicViewx.Sup_Source,"");
	SETCHAR(eBasicViewx.Season,"");
	SETCHAR(eBasicViewx.Label_Type,"");
	SETCHAR(eBasicViewx.Label_Form,"");
	SETCHAR(eBasicViewx.Prod_Hier,"");
	SETCHAR(eBasicViewx.Cad_Id,"");
	SETCHAR(eBasicViewx.Allowed_Wt,"");
	SETCHAR(eBasicViewx.Pack_Wt_Un,"");
	SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
	SETCHAR(eBasicViewx.Allwd_Vol,"");
	SETCHAR(eBasicViewx.Pack_Vo_Un,"");
	SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
	SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
	SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
	SETCHAR(eBasicViewx.Var_Ord_Un,"");
	SETCHAR(eBasicViewx.Batch_Mgmt,"");
	SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
	SETCHAR(eBasicViewx.Fill_Level,"");
	SETCHAR(eBasicViewx.Stack_Fact,"");
	SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
	SETCHAR(eBasicViewx.Authoritygroup,"");
	SETCHAR(eBasicViewx.Qm_Procmnt,"");
	SETCHAR(eBasicViewx.Catprofile,"");
	SETCHAR(eBasicViewx.Minremlife,"");
	SETCHAR(eBasicViewx.Shelf_Life,"");
	SETCHAR(eBasicViewx.Stor_Pct,"");
	SETCHAR(eBasicViewx.Pur_Status,"");
	SETCHAR(eBasicViewx.Sal_Status,"");
	SETCHAR(eBasicViewx.Pvalidfrom,"");
	SETCHAR(eBasicViewx.Svalidfrom,"");
	SETCHAR(eBasicViewx.Envt_Rlvt,"");
	SETCHAR(eBasicViewx.Prod_Alloc,"");
	SETCHAR(eBasicViewx.Qual_Dik,"");
	SETCHAR(eBasicViewx.Manu_Mat,"");
	SETCHAR(eBasicViewx.Mfr_No,"");
	SETCHAR(eBasicViewx.Inv_Mat_No,"");
	SETCHAR(eBasicViewx.Manuf_Prof,"");
	SETCHAR(eBasicViewx.Hazmatprof,"");
	SETCHAR(eBasicViewx.High_Visc,"");
	SETCHAR(eBasicViewx.Looseorliq,"");
	SETCHAR(eBasicViewx.Closed_Box,"");
	SETCHAR(eBasicViewx.Appd_B_Rec,"");
	SETCHAR(eBasicViewx.Matcmpllvl,"");
	SETCHAR(eBasicViewx.Par_Eff,"");
	SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
	SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
	SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
	SETCHAR(eBasicViewx.Item_Cat,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
	SETCHAR(eBasicViewx.Material_Fixed,"");
	SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
	SETCHAR(eBasicViewx.Sled_Bbd,"");
	SETCHAR(eBasicViewx.Gtin_Variant,"");
	SETCHAR(eBasicViewx.Serialization_Level,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
	SETCHAR(eBasicViewx.Extmatlgrp,"");
	SETCHAR(eBasicViewx.Uomusage,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");

	printf("\nhi");

	RfcRc = BAPI_MATERIAL_SAVEDATA(hRfc
			,&eBapiMatHead
			,&eBasicView
			,&eBasicViewx
			,&eBapiret2
			/*,thBapi_Makt
			,thBapi_Marm
			,thBapi_Marmx*/
			,xException);

	switch (RfcRc)
	{
		case RFC_OK :
					printf("\nMessage for Basic Material Create:-%s",eBapiret2.Message);
					fflush(stdout);
					break;
		case RFC_EXCEPTION :
					printf("\nRFC EXCEPTION:-%s",xException);
					break;
		case RFC_SYS_EXCEPTION :
					printf("\nsystem exception raised");
					break;
		case RFC_FAILURE :
					printf("\nfailure");
					break;
		default :
					printf("\nother failure");
					break;
	}
	RfcClose(hRfc);
}
