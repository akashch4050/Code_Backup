/*
scp uadev@172.22.97.94:/home/uadev/devgroups/dbk/clientcode/PartUaSapBom/VariantCharCreate
1)	BAPI_CHARACT_GETDETAIL � Pass the characteristics and get the existing details for the same.
2)	BAPI_CHARACT_CHANGE � Pass all the values received in step 1 + the additional values for Char
3)	BAPI_TRANSACTION_COMMIT

*/
#define TE_MAXLINELEN  128

#define _CLMAIN_DEFNS

#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>
#include <user_exits/user_exits.h>
//#include <librfc.a>
//#include <ProdSap_functions.a>
#include<time.h>
#include "VrCre.h"
#include "wmhelpe.h"
#include "ppe.h"
#include "bapi.h"


FILE * fsuccess;
char *iSapServer = NULL;

struct node
{
	//char sr_no[5];
	char *value;
	char *desc;
	//float qty;
	//char uq[4];
	//char *formula;
	//char mat_prov_ind[2];
	//char * make_buy_indDup; // added by rajendra on 9.9.16
	//float usgProb;
	struct node *next;
};

struct node *start=NULL;
char *sr_no=NULL;

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

FILE* fp=NULL;
#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
struct node* createnode(/*char sr_no[5],*/char *value,char *desc);
//my_free(struct node* start);

/*void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("%*.0s",pos,text);fflush(stdout); printf("%-*s : %s\n",len,text,str);fflush(stdout);
  fprintf(fsuccess,"%*.0s",pos,text); fprintf(fsuccess,"%-*s : %s\n",len,text,str);
  return;
}*/


void my_free(struct node* start)
{
	struct node* prev;
	struct node* ptr;
	printf("\nErazing Linklist Started...\n");
	//fprintf(fsuccess,"\nErazing Linklist Started...\n");
	for(prev = start, ptr = start; ptr != NULL, prev = ptr; ptr = ptr->next)
	{
		printf("#");
		//fprintf(fsuccess,"#");
		free(prev);
	}
	start = NULL;
	printf("\nErazing Linklist Completed.\n");
	//fprintf(fsuccess,"\nErazing Linklist Completed.\n");

}

struct node* createnode(/*char sr_no[5],*/char *value,char *desc)
{
	struct node* p = NULL;
	p = (struct node*)malloc(sizeof(struct node));
	//strcpy(p->sr_no,sr_no);
	p->value = value;
	p->desc = desc;
	p->next = NULL;
	return p;
}

int search(struct node* start,char *value)
{
	struct node* p;
	int found = 1 ;

	p=start;
	/*while(p->next!=NULL)*/
	while(p!=NULL)
	{
			if(strcmp(p->value,value)==0)
			{
					//found;
					//p->qty = p->qty + *qty;
					found = 0;
					break;
			}
			else
			{
				p=p->next;
				found = 1 ;
			}

		}
	return found;
}


extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	int kk=0;
	int ret;
	int resultCount = 0;
	struct node *p = NULL;
	struct node *q = NULL;
	int n_entries = 1; //no. of query input arg

	tag_t queryTag = NULLTAG;
	tag_t outTag = NULLTAG;
	tag_t ConfigCtx = NULLTAG;
	tag_t platformrev = NULLTAG;
	tag_t platformnode = NULLTAG;
	char *ContextobjName=NULL;
	tag_t *resultOutputTag = NULLTAG;

	tag_t platfrm_tag = NULLTAG;
	tag_t ConfigCtxObjTypeTag = NULLTAG;
	char *item_type = NULL;
	char *Optfmly_type = NULL;
	char *platfrm = NULL;
	char *pltfrm_str = NULL;
	char *mainpltfrm = NULL;
	char *platfrm_name = NULL;
	char Config_CtxType[TCTYPE_name_size_c+1];
	char *SmVCContext = NULL;
	char *Context_Str = NULL;
	char *SmCrIDContext = NULL;
	tag_t *familtopttag = NULLTAG;
	static int sr_no1 = 0;

	char *inputPart = NULL;

	//char *qry_entries[1] = {"Name"};
	char *qry_entries[1] = {"ID"};
	char *OptValName = NULL;
	char *OptValDesc = NULL;
	char *OptfmlyName = NULL;
	char *OptfmlyDesc = NULL;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	OptfmlyName = (char *)malloc(50 * sizeof(char));
	OptfmlyDesc = (char *)malloc(50 * sizeof(char));

	OptValName = (char *)malloc(50 * sizeof(char));
    OptValDesc = (char *)malloc(50 * sizeof(char));
  	sr_no = (char *) malloc(10 * sizeof(char));



	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL( ITK_initialize_text_services ( ITK_BATCH_TEXT_MODE ) );
	ITK_CALL( ITK_auto_login ( ) );
	ITK_CALL( ITK_set_journalling ( TRUE ) );

	platfrm = ITK_ask_cli_argument("-i=");
	iSapServer = ITK_ask_cli_argument("-s=");

	ITK_CALL( ITEM_find_item ( platfrm, &platfrm_tag ) );

	if (platfrm_tag != NULLTAG)
	{
		printf("\nPlatForm :%s Found",platfrm);fflush(stdout);

		ITK_CALL(ITEM_ask_type2 (platfrm_tag, &item_type));
		printf("\nMain item_types: [%s] \n",item_type);  fflush(stdout);

	}
	else
	{
		printf("\nPlatForm %s not found in TCUA",platfrm);
		exit ( 0 );
	}

	if(tc_strcmp(item_type,"T5_Platform")==0)
	{

		    tag_t relation_dep = NULLTAG;
			int countConfigCtx =0;
			tag_t *ConfigCtxSecObject = NULLTAG;

			ITK_CALL(AOM_ask_value_string(platfrm_tag,"item_id",&platfrm_name));
			printf("\n\n\t\tPlatform Name ==> %s\n", platfrm_name);fflush(stdout);

			ITK_CALL(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
			if(relation_dep != NULLTAG)
			{
				printf("\n\tVariant ConfigContext relation found......");	fflush(stdout);
			}

			ITK_CALL(GRM_list_secondary_objects_only(platfrm_tag,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
			printf("\n\tConfiguration Context count is : %d",countConfigCtx);

			if(countConfigCtx>0)
			{
				  tag_t queryTag = NULLTAG;
				  tag_t queryTagOptFamVal = NULLTAG;
				  tag_t Optfmly_tag = NULLTAG;
				  tag_t OptfmlyVal_tag = NULLTAG;
				  int j1=0;
				  int resultCountOptFamVal=0,n_entriesOptFamVal=2,i=0;
				  char *qry_entriesOptFamVal[] = {"Thread ID","ID"};
				  tag_t *revOptFamVal=NULL;
				  char **qry_valuesOptFamVal = (char **) MEM_alloc(10 * sizeof(char *));

				  ConfigCtx=ConfigCtxSecObject[0];
				  ITK_CALL(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
				  ITK_CALL(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));
				  printf( "\n\tConfig relation Config_CtxType :%s ..",Config_CtxType);

				  ITK_CALL(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
				  printf("\n\tSmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

				   ITK_CALL(AOM_ask_value_string(ConfigCtx,"item_id",&Context_Str));
				  printf("\n\tContext_Str :%s",Context_Str);	fflush(stdout);

				  ITK_CALL(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
				  printf("\n\tSmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

				  if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
				  if (queryTag)
				  {
					printf("\n\tFound Query");fflush(stdout);
				  }
				  else
				  {
					printf("\n\tNot Found Query");fflush(stdout);
				  }

				  qry_values[0] = SmCrIDContext;

				  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &familtopttag));
				  printf("\n\tresultCount : %d\n", resultCount); fflush(stdout);

				  for ( j1 = 0; j1 < resultCount; j1++ )
				  {
						printf("\nProcessing option [%d]",j1);
						Optfmly_tag = familtopttag[j1];
						ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyDesc));
						//ITK_CALL(AOM_ask_value_string(Optfmly_tag,"current_desc",&OptfmlyName));
						ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_desc",&OptfmlyName));
						printf("\n\tOpt Name:[%-50s] OptName length:[%-3d] OptfmlyDesc:[%-50s]",OptfmlyName,tc_strlen(OptfmlyName),OptfmlyDesc); fflush(stdout);   //Drive, Fuel is a Name if Option family

						//ITK_CALL(ITEM_ask_type2 ( Optfmly_tag, &Optfmly_type ));
						ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_type",&Optfmly_type));
						printf("\tOptfmly type:[%-30s]",Optfmly_type);  fflush(stdout);

						if ( tc_strcmp(Optfmly_type, "Cfg0PackageOptionFamily" ) == 0 )
					    {
							printf("\tSkipping"); fflush(stdout);
							continue;
						}

						printf("\n"); fflush(stdout);

						if(tc_strlen(OptfmlyName) == 0)
						{
							printf("\nError:object_desc is null for object_name:%s raise error with BOM process team",OptfmlyDesc);
							continue;
						}

						if ( tc_strlen ( OptfmlyName ) > 30 )
						{
							printf("\nError:Can not create characteristic for option name [%s] length is more than 30 character contact BOM process team length:%d",OptfmlyName,tc_strlen ( OptfmlyName ));
							exit ( 0 ); //it should show error and come out
							//continue;
						}

						if(QRY_find("__Cfg0OptionValuesFromOptionFamilyIDs", &queryTagOptFamVal));
						printf("\nAfter IFERR_REPORT : QRY_find \n");fflush(stdout);
						if (queryTagOptFamVal)
						{
							printf("\n2.Found Query\n");fflush(stdout);
						}
						else
						{
							printf("\nNot Found Query\n");fflush(stdout);
						}
						qry_valuesOptFamVal[0]= OptfmlyDesc;
						qry_valuesOptFamVal[1]= Context_Str;
						if(QRY_execute(queryTagOptFamVal, n_entriesOptFamVal, qry_entriesOptFamVal, qry_valuesOptFamVal, &resultCountOptFamVal, &revOptFamVal));

						printf("\nresultCountOptFamVal:%d",resultCountOptFamVal);
						start = NULL;
						p = NULL;
						q = NULL;
						ret = 0;

						for ( i = 0; i < resultCountOptFamVal; i++ )
						{
							OptfmlyVal_tag = revOptFamVal[i];
							ITK_CALL(AOM_ask_value_string(OptfmlyVal_tag,"object_name",&OptValName));
							ITK_CALL(AOM_ask_value_string(OptfmlyVal_tag,"current_name",&OptValDesc));
							printf("\n\t%d OptValName:[%s] OptValDesc[%s]",i,OptValName,OptValDesc);	fflush(stdout);

							if ( tc_strlen ( OptValName ) > 30 )
							{
								printf("\nError:Can not create option value [%s] for option name[%s] as value length is more than 30 character contact BOM process team length:%d",OptValName,OptfmlyName,tc_strlen ( OptValName ));
								exit ( 0 );
							}

							if(p==NULL)
							{
								p = createnode(OptValName,OptValDesc);
								start = p;
							}
							else
							{
								ret = search(start,OptValName);
								if(ret==1)
								{
									 q=start;
									 while(q->next!=NULL)
									 {
										 q=q->next;
									 }
									q->next=createnode(OptValName,OptValDesc);
								}
							}

						}

					cll_BAPI_CHARACT_CREATE(start,OptfmlyName,OptfmlyDesc);
					my_free(start);

				   }
			}
	}

	ITK_CALL(POM_logout(false));
	return status;

	CLEANUP:

		 printf("\n CLEANUP"); fflush(stdout);
}
;

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}


RFC_RC BAPI_CHARACT_CREATE(
					RFC_HANDLE hRfc,
					BAPICHARACTDETAIL *eBAPICHARACTDETAIL,
					BAPICHARACTKEY_CHANGENUM *eBAPICHARACTKEY_CHANGENUM,
					BAPICHARACTKEY_KEYDATE *eBAPICHARACTKEY_KEYDATE,
					ITAB_H thBAPICHARACTDESCR,
					ITAB_H thBAPICHARACTVALUESNUM,
					ITAB_H thBAPICHARACTVALUESCHAR,
					ITAB_H thBAPICHARACTVALUESCURR,
					ITAB_H thBAPICHARACTVALUESDESCR,
					ITAB_H thBAPICHARACTREFERENCES,
					ITAB_H thBAPICHARACTRESTRICTIONS,
					ITAB_H thBAPIRET2,
					char *xException )
{
	RFC_PARAMETER Exporting[4];
	RFC_PARAMETER Importing[1];
	RFC_TABLE Tables[9];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "CHARACTDETAIL";
	Exporting[0].nlen = 13;
	Exporting[0].type = handleOfBAPICHARACTDETAIL;
	Exporting[0].leng = sizeof(BAPICHARACTDETAIL);
	Exporting[0].addr = eBAPICHARACTDETAIL;

	Exporting[1].name = "CHANGENUMBER";
	Exporting[1].nlen = 12;
	Exporting[1].type = handleOfBAPICHARACTKEY_CHANGENUM;
	Exporting[1].leng = sizeof(BAPICHARACTKEY_CHANGENUM);
	Exporting[1].addr = eBAPICHARACTKEY_CHANGENUM;

	Exporting[2].name = "KEYDATE";
	Exporting[2].nlen = 7;
	Exporting[2].type = handleOfBAPICHARACTKEY_KEYDATE;
	Exporting[2].leng = sizeof(BAPICHARACTKEY_KEYDATE);
	Exporting[2].addr = eBAPICHARACTKEY_KEYDATE;

	Exporting[3].name = NULL;

	Tables[0].name     = "CHARACTDESCR";
	Tables[0].nlen     = 12;
	Tables[0].type     = handleOfBAPICHARACTDESCR;
	Tables[0].ithandle = thBAPICHARACTDESCR;

	Tables[1].name     = "CHARACTVALUESNUM";
	Tables[1].nlen     = 16;
	Tables[1].type     = handleOfBAPICHARACTVALUESNUM;
	Tables[1].ithandle = thBAPICHARACTVALUESNUM;

	Tables[2].name     = "CHARACTVALUESCHAR";
	Tables[2].nlen     = 17;
	Tables[2].type     = handleOfBAPICHARACTVALUESCHAR;
	Tables[2].ithandle = thBAPICHARACTVALUESCHAR;

	Tables[3].name     = "CHARACTVALUESCURR";
	Tables[3].nlen     = 17;
	Tables[3].type     = handleOfBAPICHARACTVALUESCURR;
	Tables[3].ithandle = thBAPICHARACTVALUESCURR;

	Tables[4].name     = "CHARACTVALUESDESCR";
	Tables[4].nlen     = 18;
	Tables[4].type     = handleOfBAPICHARACTVALUESDESCR;
	Tables[4].ithandle = thBAPICHARACTVALUESDESCR;

	Tables[5].name     = "CHARACTREFERENCES";
	Tables[5].nlen     = 17;
	Tables[5].type     = handleOfBAPICHARACTREFERENCES;
	Tables[5].ithandle = thBAPICHARACTREFERENCES;

	Tables[6].name     = "CHARACTRESTRICTIONS";
	Tables[6].nlen     = 19;
	Tables[6].type     = handleOfBAPICHARACTRESTRICTIONS;
	Tables[6].ithandle = thBAPICHARACTRESTRICTIONS;

	Tables[7].name = "RETURN";
	Tables[7].nlen = 6;
	Tables[7].type = handleOfBAPIRET2;
	Tables[7].ithandle = thBAPIRET2;


	Tables[8].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_CHARACT_CREATE",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\nImporting... RFC OK");

			Importing[0].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					printf("\nRFC_SYS_EXCEPTION:%s",xException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					printf("\nRFC_EXCEPTION:%s",xException);
					break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
			break;
	}
	return RfcRc;
}

RFC_RC BAPI_TRANSACTION_COMMIT(	RFC_HANDLE				    hRfc,
					BAPITA_WAIT*			    eBAPITA_WAIT,
					//BAPIRET2*				    eBapiret2,
					char*					    xException

				 )
{

	RFC_PARAMETER Exporting[2];
	RFC_PARAMETER Importing[1];
	RFC_TABLE Tables[1];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "WAIT";
	Exporting[0].nlen = 4;
	Exporting[0].type = handleOfBAPITA_WAIT;
	Exporting[0].leng = sizeof(BAPITA_WAIT);
	Exporting[0].addr = eBAPITA_WAIT;

	Exporting[1].name = NULL;

	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_TRANSACTION_COMMIT",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\nImporting... RFC OK");

		   /*Importing[0].name = "RETURN";
			Importing[0].nlen = 6;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = eBapiret2;*/
			Importing[0].name = NULL;


			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					printf("\nRFC_SYS_EXCEPTION:%s",xException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					printf("\nRFC_EXCEPTION:%s",xException);
					break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
			break;
	}
	return RfcRc;

}

void getTodayDateCal(char sTodaysDate[9])
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;

	time_t Tval = 0;
	Tval = time(0);
	Sys_T = localtime(&Tval);

	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;

	sprintf(sTodaysDate,"%04d%02d%02d",Year,Month,Day);

}

cll_BAPI_CHARACT_CREATE(struct node *head,char *OptfmlyName,char *OptfmlyDesc)
{

	RFC_RC RfcRc;
	RFC_RC RfcRc1;
	RFC_HANDLE hRfc;
	char xException[256] = { 0 };
	char s[1024] = { 0 };
	char s1[1024] = { 0 };
	int crow=0;
	int crow1=0;
	int var=0;
	int var1=0;
	struct node *p=NULL;
	char value[100];
	char desc[100];
	char srno[5];
	char sTodaysDate[9] = { 0 };

	BAPICHARACTDETAIL eBAPICHARACTDETAIL;
	BAPICHARACTKEY_CHANGENUM eBAPICHARACTKEY_CHANGENUM;
	BAPICHARACTKEY_KEYDATE eBAPICHARACTKEY_KEYDATE;

	BAPITA_WAIT eBAPITA_WAIT;
	//BAPIRET2 eBapiret2;

	BAPICHARACTDESCR* tBAPICHARACTDESCR;
	BAPICHARACTVALUESNUM* tBAPICHARACTVALUESNUM;
	BAPICHARACTVALUESCHAR* tBAPICHARACTVALUESCHAR;
	BAPICHARACTVALUESCURR* tBAPICHARACTVALUESCURR;
	BAPICHARACTVALUESDESCR* tBAPICHARACTVALUESDESCR;
	BAPICHARACTREFERENCES* tBAPICHARACTREFERENCES;
	BAPICHARACTRESTRICTIONS* tBAPICHARACTRESTRICTIONS;
	BAPIRET2* tBAPIRET2;

	ITAB_H thBAPICHARACTDESCR = ITAB_NULL;
	ITAB_H thBAPICHARACTVALUESNUM = ITAB_NULL;
	ITAB_H thBAPICHARACTVALUESCHAR = ITAB_NULL;
	ITAB_H thBAPICHARACTVALUESCURR = ITAB_NULL;
	ITAB_H thBAPICHARACTVALUESDESCR = ITAB_NULL;
	ITAB_H thBAPICHARACTREFERENCES = ITAB_NULL;
	//ITAB_H thBAPICHARACTREFERENCES = ITAB_NULL;
	ITAB_H thBAPICHARACTRESTRICTIONS = ITAB_NULL;
	ITAB_H thBAPIRET2 = ITAB_NULL;

    fsuccess = fopen("test1.txt","a");


	getTodayDateCal(sTodaysDate);

	printf("\nsTodaysDate:%s",sTodaysDate);

	//SETCHAR(eBAPICHARACTDETAIL.CHARACT_NAME,"APPLICABLEFOR");
	SETCHAR(eBAPICHARACTDETAIL.CHARACT_NAME,OptfmlyName);
	SETCHAR(eBAPICHARACTDETAIL.DATA_TYPE,"CHAR");
	SETNUM(eBAPICHARACTDETAIL.LENGTH,"30");
	SETNUM(eBAPICHARACTDETAIL.DECIMALS,"00");
	SETCHAR(eBAPICHARACTDETAIL.CASE_SENSITIV,"");
	SETNUM(eBAPICHARACTDETAIL.EXPONENT_TYPE,"0");
	SETINT2(&eBAPICHARACTDETAIL.EXPONENT,"0");
	SETCHAR(eBAPICHARACTDETAIL.TEMPLATE,"");
	SETCHAR(eBAPICHARACTDETAIL.WITH_SIGN,"");
	SETCHAR(eBAPICHARACTDETAIL.UNIT_OF_MEASUREMENT,"");
	SETCHAR(eBAPICHARACTDETAIL.UNIT_OF_MEASUREMENT_ISO,"");
	SETCHAR(eBAPICHARACTDETAIL.CURRENCY,"");
	SETCHAR(eBAPICHARACTDETAIL.CURRENCY_ISO,"");
	SETCHAR(eBAPICHARACTDETAIL.STATUS,"1");
	SETCHAR(eBAPICHARACTDETAIL.CHARACT_GROUP,"");
	//SETCHAR(eBAPICHARACTDETAIL.VALUE_ASSIGNMENT,"");//Single value radio button
	SETCHAR(eBAPICHARACTDETAIL.VALUE_ASSIGNMENT,"M");//multi value selection radio button
	SETCHAR(eBAPICHARACTDETAIL.NO_ENTRY,"");
	SETCHAR(eBAPICHARACTDETAIL.NO_DISPLAY,"");
	SETCHAR(eBAPICHARACTDETAIL.ENTRY_REQUIRED,"");
	SETCHAR(eBAPICHARACTDETAIL.INTERVAL_ALLOWED,"");
	SETCHAR(eBAPICHARACTDETAIL.SHOW_TEMPLATE,"");
	SETCHAR(eBAPICHARACTDETAIL.DISPLAY_VALUES,"");
	SETCHAR(eBAPICHARACTDETAIL.ADDITIONAL_VALUES,"X");
	SETCHAR(eBAPICHARACTDETAIL.DOCUMENT_NO,"");
	SETCHAR(eBAPICHARACTDETAIL.DOCUMENT_TYPE,"");
	SETCHAR(eBAPICHARACTDETAIL.DOCUMENT_PART,"");
	SETCHAR(eBAPICHARACTDETAIL.DOCUMENT_VERSION,"");
	SETCHAR(eBAPICHARACTDETAIL.CHECK_TABLE,"");
	SETCHAR(eBAPICHARACTDETAIL.CHECK_FUNCTION,"");
	SETCHAR(eBAPICHARACTDETAIL.PLANT,"");
	SETCHAR(eBAPICHARACTDETAIL.SELECTED_SET,"");
	SETCHAR(eBAPICHARACTDETAIL.ADT_CLASS,"");
	SETCHAR(eBAPICHARACTDETAIL.ADT_CLASS_TYPE,"");
	SETCHAR(eBAPICHARACTDETAIL.AGGREGATING,"");
	SETCHAR(eBAPICHARACTDETAIL.BALANCING,"");
	SETCHAR(eBAPICHARACTDETAIL.INPUT_REQUESTED_CONF,"");
	SETCHAR(eBAPICHARACTDETAIL.AUTHORITY_GROUP,"");
	SETCHAR(eBAPICHARACTDETAIL.UNFORMATED,"");



	SETCHAR(eBAPICHARACTKEY_CHANGENUM.CHANGENUM,"");

	//SETCHAR(eBAPICHARACTKEY_KEYDATE.KEYDATE,"20181008");//YYYYMMDD
	//SETCHAR(eBAPICHARACTKEY_KEYDATE.KEYDATE,"20190214");
	SETCHAR(eBAPICHARACTKEY_KEYDATE.KEYDATE,sTodaysDate);

	if (thBAPICHARACTDESCR==ITAB_NULL)
	{
		thBAPICHARACTDESCR = ItCreate("CHARACTDESCR",sizeof(BAPICHARACTDESCR),0,0);
		if (thBAPICHARACTDESCR==ITAB_NULL)
		printf("ItCreate CHARACTDESCR");
	}
	else
	{
			if (ItFree(thBAPICHARACTDESCR) != 0)
			printf("ItFree CHARACTDESCR");
	}

	if (thBAPICHARACTVALUESNUM==ITAB_NULL)
	{
		thBAPICHARACTVALUESNUM = ItCreate("CHARACTVALUESNUM",sizeof(BAPICHARACTVALUESNUM),0,0);
		if (thBAPICHARACTVALUESNUM==ITAB_NULL)
			printf("ItCreate CHARACTVALUESNUM");
	}
	else if (ItFree(thBAPICHARACTVALUESNUM)!= 0)
	{
		printf("ItFree CHARACTVALUESNUM");
	}


	if (thBAPICHARACTVALUESCHAR==ITAB_NULL)
	{
		thBAPICHARACTVALUESCHAR = ItCreate("CHARACTVALUESCHAR",sizeof(BAPICHARACTVALUESCHAR),0,0);
		if (thBAPICHARACTVALUESCHAR==ITAB_NULL)
			printf("ItCreate CHARACTVALUESCHAR");
	}
	else if (ItFree(thBAPICHARACTVALUESCHAR)!= 0)
	{
		printf("ItFree CHARACTVALUESCHAR");
	}


	if (thBAPICHARACTVALUESCURR==ITAB_NULL)
	{
		thBAPICHARACTVALUESCURR = ItCreate("CHARACTVALUESCURR",sizeof(BAPICHARACTVALUESCURR),0,0);
		if (thBAPICHARACTVALUESCURR==ITAB_NULL)
			printf("ItCreate CHARACTVALUESCURR");
	}
	else if (ItFree(thBAPICHARACTVALUESCURR)!= 0)
	{
		printf("ItFree CHARACTVALUESCURR");
	}

	if (thBAPICHARACTVALUESDESCR==ITAB_NULL)
	{
		thBAPICHARACTVALUESDESCR = ItCreate("CHARACTVALUESDESCR",sizeof(BAPICHARACTVALUESDESCR),0,0);
		if (thBAPICHARACTVALUESDESCR==ITAB_NULL)
			printf("ItCreate CHARACTVALUESDESCR");
	}
	else if (ItFree(thBAPICHARACTVALUESDESCR)!= 0)
	{
		printf("ItFree CHARACTVALUESDESCR");
	}


	if (thBAPICHARACTREFERENCES==ITAB_NULL)
	{
		thBAPICHARACTREFERENCES = ItCreate("CHARACTREFERENCES",sizeof(BAPICHARACTREFERENCES),0,0);
		if (thBAPICHARACTREFERENCES==ITAB_NULL)
			printf("ItCreate CHARACTREFERENCES");
	}
	else if (ItFree(thBAPICHARACTREFERENCES)!= 0)
	{
		printf("ItFree CHARACTREFERENCES");
	}

	if (thBAPICHARACTRESTRICTIONS==ITAB_NULL)
	{
		thBAPICHARACTRESTRICTIONS = ItCreate("CHARACTRESTRICTIONS",sizeof(BAPICHARACTRESTRICTIONS),0,0);
		if (thBAPICHARACTRESTRICTIONS==ITAB_NULL)
			printf("ItCreate CHARACTRESTRICTIONS");
	}
	else if (ItFree(thBAPICHARACTRESTRICTIONS)!= 0)
	{
		printf("ItFree CHARACTRESTRICTIONS");
	}

	if (thBAPIRET2==ITAB_NULL)
	{
		thBAPIRET2 = ItCreate("RETURN",sizeof(BAPIRET2),0,0);
		if (thBAPIRET2==ITAB_NULL)
			printf("ItCreateRETURN");
	}
	else if (ItFree(thBAPIRET2)!= 0)
	{
		printf("ItFreeRETURN");
	}

	//tDEPDESCR  = ItAppLine (thDEPDESCR);
	//tDEPSOURCE = ItAppLine (thDEPSOURCE);

	//tBAPICHARACTVALUESNUM = ItAppLine (thBAPICHARACTVALUESNUM);
	//tBAPICHARACTVALUESCHAR = ItAppLine (thBAPICHARACTVALUESCHAR);
	//tBAPICHARACTVALUESCURR = ItAppLine (thBAPICHARACTVALUESCURR);
	//tBAPICHARACTVALUESDESCR = ItAppLine (thBAPICHARACTVALUESDESCR);
	//tBAPICHARACTREFERENCES = ItAppLine (thBAPICHARACTREFERENCES);
	//tBAPICHARACTRESTRICTIONS = ItAppLine (thBAPICHARACTRESTRICTIONS);
	//tBAPIRET2 = ItAppLine (thBAPIRET2);

    tBAPICHARACTDESCR = ItAppLine (thBAPICHARACTDESCR);
	SETCHAR(tBAPICHARACTDESCR->LANGUAGE_INT,"EN");
	SETCHAR(tBAPICHARACTDESCR->LANGUAGE_ISO,"");
	//SETCHAR(tBAPICHARACTDESCR->DESCRIPTION,"applicable for");
	SETCHAR(tBAPICHARACTDESCR->DESCRIPTION,OptfmlyDesc);
	SETCHAR(tBAPICHARACTDESCR->HEADER1,"");
	SETCHAR(tBAPICHARACTDESCR->HEADER2,"");

	//printf("\nI attr values"); fflush(stdout);

	for(p = head; p != NULL; p = p -> next)
	{

		sprintf(value,"%s", p->value);
		//sprintf(srno,"%s",p->sr_no);
		sprintf(desc,"%s",p->desc);
		printf("\n\t[%s]:[%s]",value,desc);fflush(stdout);


		tBAPICHARACTVALUESCHAR  = ItAppLine (thBAPICHARACTVALUESCHAR);
		if (tBAPICHARACTVALUESCHAR == NULL)
		printf("ItAppLineCHARACTVALUESCHAR");fflush(stdout);


		//SETCHAR(tBAPICHARACTVALUESCHAR->VALUE_CHAR,"X451");
		SETCHAR(tBAPICHARACTVALUESCHAR->VALUE_CHAR,value);
		SETCHAR(tBAPICHARACTVALUESCHAR->VALUE_CHAR_HIGH,"");
		SETCHAR(tBAPICHARACTVALUESCHAR->DEFAULT_VALUE,"");
		SETCHAR(tBAPICHARACTVALUESCHAR->DOCUMENT_NO,"");
		SETCHAR(tBAPICHARACTVALUESCHAR->DOCUMENT_TYPE,"");
		SETCHAR(tBAPICHARACTVALUESCHAR->DOCUMENT_PART,"");
		SETCHAR(tBAPICHARACTVALUESCHAR->DOCUMENT_VERSION,"");

		tBAPICHARACTVALUESDESCR  = ItAppLine (thBAPICHARACTVALUESDESCR);
		if (tBAPICHARACTVALUESDESCR == NULL)
		printf("ItAppLineCHARACTVALUESDESCR");fflush(stdout);

		SETCHAR(tBAPICHARACTVALUESDESCR->LANGUAGE_INT,"EN");
		SETCHAR(tBAPICHARACTVALUESDESCR->LANGUAGE_ISO,"");
		SETCHAR(tBAPICHARACTVALUESDESCR->VALUE_CHAR,value);
		SETCHAR(tBAPICHARACTVALUESDESCR->DESCRIPTION,desc);


	}

	tBAPICHARACTRESTRICTIONS = ItAppLine (thBAPICHARACTRESTRICTIONS);
	SETCHAR(tBAPICHARACTRESTRICTIONS->CLASS_TYPE,"300");
	//SETCHAR(tDEPSOURCE->LINE,"ORVM_STYLING_COLOR = 'BODY COLOR'");
	printf("\ncalling BAPI_CHARACT_CREATE"); fflush(stdout);

	hRfc = BapiLogon();

    RfcRc = BAPI_CHARACT_CREATE(
				hRfc,
				&eBAPICHARACTDETAIL,
				&eBAPICHARACTKEY_CHANGENUM,
				&eBAPICHARACTKEY_KEYDATE,
				thBAPICHARACTDESCR,
				thBAPICHARACTVALUESNUM,
				thBAPICHARACTVALUESCHAR,
				thBAPICHARACTVALUESCURR,
				thBAPICHARACTVALUESDESCR,
				thBAPICHARACTREFERENCES,
				thBAPICHARACTRESTRICTIONS,
				thBAPIRET2,
				xException
		      );

	switch (RfcRc)
	{
		case RFC_OK:

            printf("\n*********BAPI_CHARACT_CREATE************\n");fflush(stdout);

			printf("ItFill(thBAPICHARACTDESCR):%d\n",ItFill(thBAPICHARACTDESCR));

			for (crow = 1;crow <= ItFill(thBAPICHARACTDESCR); crow++)
			{
				tBAPICHARACTDESCR = ItGetLine(thBAPICHARACTDESCR,crow);
				if (tBAPICHARACTDESCR == NULL)
					printf("ItGetLineCHARACTDESCR");

				GETCHAR(tBAPICHARACTDESCR->LANGUAGE_INT,s);F_OUTK("CHARACTDESCR",10,30,s);
				GETCHAR(tBAPICHARACTDESCR->LANGUAGE_ISO,s);F_OUTK("CHARACTDESCR",10,30,s);
				GETNUM(tBAPICHARACTDESCR->DESCRIPTION,s);F_OUTK("CHARACTDESCR",10,30,s);
				GETCHAR(tBAPICHARACTDESCR->HEADER1,s);F_OUTK("CHARACTDESCR",10,30,s);
				GETCHAR(tBAPICHARACTDESCR->HEADER2,s);F_OUTK("CHARACTDESCR",10,30,s);
				//GETCHAR(tBAPIRET2->LOG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETNUM(tBAPIRET2->LOG_MSG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V1,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V2,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V3,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V4,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->PARAMETER,s);F_OUTK("RETURN",10,30,s);
				//GETINT(tBAPIRET2->ROW,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->FIELD,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->SYSTEM,s);F_OUTK("RETURN",10,30,s);

			}

			printf("ItFill(thBAPICHARACTVALUESDESCR):%d\n",ItFill(thBAPICHARACTVALUESDESCR));

		    for (crow = 1;crow <= ItFill(thBAPICHARACTVALUESDESCR); crow++)
			{
				tBAPICHARACTVALUESDESCR = ItGetLine(thBAPICHARACTVALUESDESCR,crow);
				if (tBAPICHARACTVALUESDESCR == NULL)
					printf("ItGetLineCHARACTVALUESDESCR");

				GETCHAR(tBAPICHARACTVALUESDESCR->LANGUAGE_INT,s);F_OUTK("CHARACTVALUESDESCR",10,30,s);
				GETCHAR(tBAPICHARACTVALUESDESCR->LANGUAGE_ISO,s);F_OUTK("CHARACTVALUESDESCR",10,30,s);
				GETNUM(tBAPICHARACTVALUESDESCR->VALUE_CHAR,s);F_OUTK("CHARACTVALUESDESCR",10,30,s);
				GETCHAR(tBAPICHARACTVALUESDESCR->DESCRIPTION,s);F_OUTK("CHARACTVALUESDESCR",10,30,s);
				//GETCHAR(tBAPIRET2->LOG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETNUM(tBAPIRET2->LOG_MSG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V1,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V2,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V3,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V4,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->PARAMETER,s);F_OUTK("RETURN",10,30,s);
				//GETINT(tBAPIRET2->ROW,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->FIELD,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->SYSTEM,s);F_OUTK("RETURN",10,30,s);

			}

			printf("ItFill(thBAPIRET2):%d\n",ItFill(thBAPIRET2));

			for (crow1 = 1;crow1 <= ItFill(thBAPIRET2); crow1++)
			{
				tBAPIRET2 = ItGetLine(thBAPIRET2,crow1);
				if (tBAPIRET2 == NULL)
					printf("ItGetLineRETURN");

				GETCHAR(tBAPIRET2->TYPE,s);F_OUTK("TYPE",10,30,s);
				GETCHAR(tBAPIRET2->ID,s);F_OUTK("ID",10,30,s);
				GETNUM(tBAPIRET2->NUMBER,s);F_OUTK("NUMBER",10,30,s);
				GETCHAR(tBAPIRET2->MESSAGE,s);F_OUTK("MESSAGE",10,30,s);

				printf("\nOptfmlyName:%s,OptfmlyDesc:%s,Message:%s",OptfmlyName,OptfmlyDesc,s);
				//GETCHAR(tBAPIRET2->LOG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETNUM(tBAPIRET2->LOG_MSG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V1,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V2,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V3,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V4,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->PARAMETER,s);F_OUTK("RETURN",10,30,s);
				//GETINT(tBAPIRET2->ROW,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->FIELD,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->SYSTEM,s);F_OUTK("RETURN",10,30,s);
			}

			//SETCHAR(eBAPITA_WAIT.WAIT," ");
            //RfcRc1 = testcommit(hRfc,&eBAPITA_WAIT,xException);

		break;
		case RFC_EXCEPTION:
			printf("\nRFC EXCEPTION: %s",xException);
			rfc_error("RFC_EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			rfc_error("RFC_SYS_EXCEPTION");
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			rfc_error("RFC_FAILURE");
		break;
		default:
			printf("\nOther Failure!");
		break;
	}

	SETCHAR(eBAPITA_WAIT.WAIT," ");
    RfcRc1 = BAPI_TRANSACTION_COMMIT(hRfc,&eBAPITA_WAIT,xException);

	switch (RfcRc1)
	{
		case RFC_OK:

             printf("\n*********Commit************\n");fflush(stdout);
			 break;
		case RFC_EXCEPTION:
			printf("\ntestcommit..RFC EXCEPTION: %s",xException);
			rfc_error("RFC_EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION:
			printf("\ntestcommit..System Exception Raised!!!");
			rfc_error("RFC_SYS_EXCEPTION");
		break;
		case RFC_FAILURE:
			printf("\ntestcommit..Failure!!!");
			rfc_error("RFC_FAILURE");
		break;
		default:
			printf("\ntestcommit..Other Failure!");
		break;
    }

	if (ItDelete(thBAPICHARACTDESCR) != 0)
	printf("ItDelete thBAPICHARACTDESCR");

	if (ItDelete(thBAPICHARACTVALUESNUM) != 0)
	printf("ItDelete thBAPICHARACTVALUESNUM");

	if (ItDelete(thBAPICHARACTVALUESCHAR) != 0)
	printf("ItDelete thBAPICHARACTVALUESCHAR");

	if (ItDelete(thBAPICHARACTVALUESCURR) != 0)
	printf("ItDelete thBAPICHARACTVALUESCURR");

	if (ItDelete(thBAPICHARACTVALUESDESCR) != 0)
	printf("ItDelete thBAPICHARACTVALUESDESCR");

	if (ItDelete(thBAPICHARACTREFERENCES) != 0)
	printf("ItDelete thBAPICHARACTREFERENCES");

	if (ItDelete(thBAPICHARACTRESTRICTIONS) != 0)
	printf("ItDelete thBAPICHARACTRESTRICTIONS");

	if (ItDelete(thBAPIRET2) != 0)
	printf("ItDelete thBAPIRET2");

   fclose(fsuccess);
	RfcClose(hRfc);
/*
CLEANUP:
	printf("\nCleaning up memory"); fflush(stdout);

EXIT:
	printf("\nExiting from program\n"); fflush(stdout);*/
}
