/*
scp uadev@172.22.97.94:/home/uadev/devgroups/dbk/clientcode/PartUaSapBom/VariantCharCreate
1)	BAPI_CHARACT_GETDETAIL � Pass the characteristics and get the existing details for the same.
2)	BAPI_CHARACT_CHANGE � Pass all the values received in step 1 + the additional values for Char
3)	BAPI_TRANSACTION_COMMIT

*/
#define TE_MAXLINELEN  128

#define _CLMAIN_DEFNS

#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>
#include <user_exits/user_exits.h>
//#include <librfc.a>
//#include <ProdSap_functions.a>
#include<time.h>
//#include "VrCre.h"
#include "wmhelpe.h"
#include "ppe.h"
#include "bapi.h"
//---------------------------------Getdetail bapi header-------------------------------start
/*#ifndef SAP_FT_BAPICHARACTKEY_CHARACTNAME
#define SAP_FT_BAPICHARACTKEY_CHARACTNAME
typedef RFC_CHAR BAPICHARACTKEY_CHARACTNAME[30];
#endif

#ifndef SAP_FT_BAPICHARACTKEY_KEYDATE
#define SAP_FT_BAPICHARACTKEY_KEYDATE
typedef RFC_DATE BAPICHARACTKEY_KEYDATE[8];
#endif*/

#ifndef SAP_FT_BAPIFIELDSCACL_BAPILANGUA
#define SAP_FT_BAPIFIELDSCACL_BAPILANGUA
typedef RFC_CHAR BAPIFIELDSCACL_BAPILANGUA[1];
#endif
/*
#ifndef SAP_ST_BAPICHARACTDETAIL
#define SAP_ST_BAPICHARACTDETAIL
typedef struct {
  RFC_CHAR charact_name[30];
  RFC_CHAR data_type[18];
  RFC_CHAR length[2];
  RFC_CHAR decimals[2];
  RFC_CHAR case_sensitiv[1];
  RFC_CHAR exponent_type[1];
  RFC_CHAR exponent[2];
  RFC_CHAR template[30];
  RFC_CHAR with_sign[1];
  RFC_CHAR unit_of_measurement[3];
  RFC_CHAR unit_of_measurement_iso[3];
  RFC_CHAR currency[5];
  RFC_CHAR currency_iso[3];
  RFC_CHAR status[1];
  RFC_CHAR charact_group[10];
  RFC_CHAR value_assignment[1];
  RFC_CHAR no_entry[1];
  RFC_CHAR no_display[1];
  RFC_CHAR entry_required[1];
  RFC_CHAR interval_allowed[1];
  RFC_CHAR show_template[1];
  RFC_CHAR display_values[1];
  RFC_CHAR additional_values[1];
  RFC_CHAR document_no[25];
  RFC_CHAR document_type[3];
  RFC_CHAR document_part[3];
  RFC_CHAR document_version[2];
  RFC_CHAR check_table[30];
  RFC_CHAR check_function[30];
  RFC_CHAR plant[4];
  RFC_CHAR selected_set[8];
  RFC_CHAR adt_class[18];
  RFC_CHAR adt_class_type[3];
  RFC_CHAR aggregating[1];
  RFC_CHAR balancing[1];
  RFC_CHAR input_requested_conf[1];
  RFC_CHAR authority_group[3];
  RFC_CHAR unformated[1];
} BAPICHARACTDETAIL;
#endif
#ifndef SAP_TH_BAPICHARACTDETAIL
#define SAP_TH_BAPICHARACTDETAIL
static RFC_TYPEHANDLE handleOfBAPICHARACTDETAIL;

static RFC_TYPE_ELEMENT typeOfBAPICHARACTDETAIL[] = {
  {"CHARACT_NAME" , TYPC, 30 , 0},
  {"DATA_TYPE" , TYPC, 18 , 0},
  {"LENGTH" , TYPC, 2 , 0},
  {"DECIMALS" , TYPC, 2 , 0},
  {"CASE_SENSITIV" , TYPC, 1 , 0},
  {"EXPONENT_TYPE" , TYPC, 1 , 0},
  {"EXPONENT" , TYPC, 2 , 0},
  {"TEMPLATE" , TYPC, 30 , 0},
  {"WITH_SIGN" , TYPC, 1 , 0},
  {"UNIT_OF_MEASUREMENT" , TYPC, 3 , 0},
  {"UNIT_OF_MEASUREMENT_ISO" , TYPC, 3 , 0},
  {"CURRENCY" , TYPC, 5 , 0},
  {"CURRENCY_ISO" , TYPC, 3 , 0},
  {"STATUS" , TYPC, 1 , 0},
  {"CHARACT_GROUP" , TYPC, 10 , 0},
  {"VALUE_ASSIGNMENT" , TYPC, 1 , 0},
  {"NO_ENTRY" , TYPC, 1 , 0},
  {"NO_DISPLAY" , TYPC, 1 , 0},
  {"ENTRY_REQUIRED" , TYPC, 1 , 0},
  {"INTERVAL_ALLOWED" , TYPC, 1 , 0},
  {"SHOW_TEMPLATE" , TYPC, 1 , 0},
  {"DISPLAY_VALUES" , TYPC, 1 , 0},
  {"ADDITIONAL_VALUES" , TYPC, 1 , 0},
  {"DOCUMENT_NO" , TYPC, 25 , 0},
  {"DOCUMENT_TYPE" , TYPC, 3 , 0},
  {"DOCUMENT_PART" , TYPC, 3 , 0},
  {"DOCUMENT_VERSION" , TYPC, 2 , 0},
  {"CHECK_TABLE" , TYPC, 30 , 0},
  {"CHECK_FUNCTION" , TYPC, 30 , 0},
  {"PLANT" , TYPC, 4 , 0},
  {"SELECTED_SET" , TYPC, 8 , 0},
  {"ADT_CLASS" , TYPC, 18 , 0},
  {"ADT_CLASS_TYPE" , TYPC, 3 , 0},
  {"AGGREGATING" , TYPC, 1 , 0},
  {"BALANCING" , TYPC, 1 , 0},
  {"INPUT_REQUESTED_CONF" , TYPC, 1 , 0},
  {"AUTHORITY_GROUP" , TYPC, 3 , 0},
  {"UNFORMATED" , TYPC, 1 , 0},
};
#endif
#ifndef SAP_ST_BAPICHARACTDESCR
#define SAP_ST_BAPICHARACTDESCR
typedef struct {
  RFC_CHAR language_int[1];
  RFC_CHAR language_iso[2];
  RFC_CHAR description[30];
  RFC_CHAR header1[30];
  RFC_CHAR header2[30];
} BAPICHARACTDESCR;
#endif
#ifndef SAP_TH_BAPICHARACTDESCR
#define SAP_TH_BAPICHARACTDESCR
static RFC_TYPEHANDLE handleOfBAPICHARACTDESCR;

static RFC_TYPE_ELEMENT typeOfBAPICHARACTDESCR[] = {
  {"LANGUAGE_INT" , TYPC, 1 , 0},
  {"LANGUAGE_ISO" , TYPC, 2 , 0},
  {"DESCRIPTION" , TYPC, 30 , 0},
  {"HEADER1" , TYPC, 30 , 0},
  {"HEADER2" , TYPC, 30 , 0},
};
#endif
#ifndef SAP_ST_BAPICHARACTREFERENCES
#define SAP_ST_BAPICHARACTREFERENCES
typedef struct {
  RFC_CHAR reference_table[30];
  RFC_CHAR reference_field[30];
} BAPICHARACTREFERENCES;
#endif
#ifndef SAP_TH_BAPICHARACTREFERENCES
#define SAP_TH_BAPICHARACTREFERENCES
static RFC_TYPEHANDLE handleOfBAPICHARACTREFERENCES;

static RFC_TYPE_ELEMENT typeOfBAPICHARACTREFERENCES[] = {
  {"REFERENCE_TABLE" , TYPC, 30 , 0},
  {"REFERENCE_FIELD" , TYPC, 30 , 0},
};
#endif
#ifndef SAP_ST_BAPICHARACTRESTRICTIONS
#define SAP_ST_BAPICHARACTRESTRICTIONS
typedef struct {
  RFC_CHAR class_type[3];
} BAPICHARACTRESTRICTIONS;
#endif
#ifndef SAP_TH_BAPICHARACTRESTRICTIONS
#define SAP_TH_BAPICHARACTRESTRICTIONS
static RFC_TYPEHANDLE handleOfBAPICHARACTRESTRICTIONS;

static RFC_TYPE_ELEMENT typeOfBAPICHARACTRESTRICTIONS[] = {
  {"CLASS_TYPE" , TYPC, 3 , 0},
};
#endif
#ifndef SAP_ST_BAPICHARACTVALUESCHAR
#define SAP_ST_BAPICHARACTVALUESCHAR
typedef struct {
  RFC_CHAR value_char[30];
  RFC_CHAR value_char_high[30];
  RFC_CHAR default_value[1];
  RFC_CHAR document_no[25];
  RFC_CHAR document_type[3];
  RFC_CHAR document_part[3];
  RFC_CHAR document_version[2];
} BAPICHARACTVALUESCHAR;
#endif
#ifndef SAP_TH_BAPICHARACTVALUESCHAR
#define SAP_TH_BAPICHARACTVALUESCHAR
static RFC_TYPEHANDLE handleOfBAPICHARACTVALUESCHAR;

static RFC_TYPE_ELEMENT typeOfBAPICHARACTVALUESCHAR[] = {
  {"VALUE_CHAR" , TYPC, 30 , 0},
  {"VALUE_CHAR_HIGH" , TYPC, 30 , 0},
  {"DEFAULT_VALUE" , TYPC, 1 , 0},
  {"DOCUMENT_NO" , TYPC, 25 , 0},
  {"DOCUMENT_TYPE" , TYPC, 3 , 0},
  {"DOCUMENT_PART" , TYPC, 3 , 0},
  {"DOCUMENT_VERSION" , TYPC, 2 , 0},
};
#endif
#ifndef SAP_ST_BAPICHARACTVALUESCURR
#define SAP_ST_BAPICHARACTVALUESCURR
typedef struct {
  RFC_FLOAT value_from;
  RFC_FLOAT value_to;
  RFC_CHAR value_relation[1];
  RFC_CHAR currency_from[5];
  RFC_CHAR currency_to[5];
  RFC_CHAR currency_from_iso[3];
  RFC_CHAR currency_to_iso[3];
  RFC_CHAR default_value[1];
  RFC_CHAR document_no[25];
  RFC_CHAR document_type[3];
  RFC_CHAR document_part[3];
  RFC_CHAR document_version[2];
} BAPICHARACTVALUESCURR;
#endif
#ifndef SAP_TH_BAPICHARACTVALUESCURR
#define SAP_TH_BAPICHARACTVALUESCURR
static RFC_TYPEHANDLE handleOfBAPICHARACTVALUESCURR;

static RFC_TYPE_ELEMENT typeOfBAPICHARACTVALUESCURR[] = {
  {"VALUE_FROM" , TYPFLOAT, sizeof(double) , 0},
  {"VALUE_TO" , TYPFLOAT, sizeof(double) , 0},
  {"VALUE_RELATION" , TYPC, 1 , 0},
  {"CURRENCY_FROM" , TYPC, 5 , 0},
  {"CURRENCY_TO" , TYPC, 5 , 0},
  {"CURRENCY_FROM_ISO" , TYPC, 3 , 0},
  {"CURRENCY_TO_ISO" , TYPC, 3 , 0},
  {"DEFAULT_VALUE" , TYPC, 1 , 0},
  {"DOCUMENT_NO" , TYPC, 25 , 0},
  {"DOCUMENT_TYPE" , TYPC, 3 , 0},
  {"DOCUMENT_PART" , TYPC, 3 , 0},
  {"DOCUMENT_VERSION" , TYPC, 2 , 0},
};
#endif
#ifndef SAP_ST_BAPICHARACTVALUESDESCR
#define SAP_ST_BAPICHARACTVALUESDESCR
typedef struct {
  RFC_CHAR language_int[1];
  RFC_CHAR language_iso[2];
  RFC_CHAR value_char[30];
  RFC_CHAR description[30];
} BAPICHARACTVALUESDESCR;
#endif
#ifndef SAP_TH_BAPICHARACTVALUESDESCR
#define SAP_TH_BAPICHARACTVALUESDESCR
static RFC_TYPEHANDLE handleOfBAPICHARACTVALUESDESCR;

static RFC_TYPE_ELEMENT typeOfBAPICHARACTVALUESDESCR[] = {
  {"LANGUAGE_INT" , TYPC, 1 , 0},
  {"LANGUAGE_ISO" , TYPC, 2 , 0},
  {"VALUE_CHAR" , TYPC, 30 , 0},
  {"DESCRIPTION" , TYPC, 30 , 0},
};
#endif
#ifndef SAP_ST_BAPICHARACTVALUESNUM
#define SAP_ST_BAPICHARACTVALUESNUM
typedef struct {
  RFC_FLOAT value_from;
  RFC_FLOAT value_to;
  RFC_CHAR value_relation[1];
  RFC_CHAR unit_from[3];
  RFC_CHAR unit_to[3];
  RFC_CHAR unit_from_iso[3];
  RFC_CHAR unit_to_iso[3];
  RFC_CHAR default_value[1];
  RFC_CHAR document_no[25];
  RFC_CHAR document_type[3];
  RFC_CHAR document_part[3];
  RFC_CHAR document_version[2];
} BAPICHARACTVALUESNUM;
#endif
#ifndef SAP_TH_BAPICHARACTVALUESNUM
#define SAP_TH_BAPICHARACTVALUESNUM
static RFC_TYPEHANDLE handleOfBAPICHARACTVALUESNUM;

static RFC_TYPE_ELEMENT typeOfBAPICHARACTVALUESNUM[] = {
  {"VALUE_FROM" , TYPFLOAT, sizeof(double) , 0},
  {"VALUE_TO" , TYPFLOAT, sizeof(double) , 0},
  {"VALUE_RELATION" , TYPC, 1 , 0},
  {"UNIT_FROM" , TYPC, 3 , 0},
  {"UNIT_TO" , TYPC, 3 , 0},
  {"UNIT_FROM_ISO" , TYPC, 3 , 0},
  {"UNIT_TO_ISO" , TYPC, 3 , 0},
  {"DEFAULT_VALUE" , TYPC, 1 , 0},
  {"DOCUMENT_NO" , TYPC, 25 , 0},
  {"DOCUMENT_TYPE" , TYPC, 3 , 0},
  {"DOCUMENT_PART" , TYPC, 3 , 0},
  {"DOCUMENT_VERSION" , TYPC, 2 , 0},
};
#endif
#ifndef SAP_ST_BAPIRET2
#define SAP_ST_BAPIRET2
typedef struct {
  RFC_CHAR type[1];
  RFC_CHAR id[20];
  RFC_CHAR number[3];
  RFC_CHAR message[220];
  RFC_CHAR log_no[20];
  RFC_CHAR log_msg_no[6];
  RFC_CHAR message_v1[50];
  RFC_CHAR message_v2[50];
  RFC_CHAR message_v3[50];
  RFC_CHAR message_v4[50];
  RFC_CHAR parameter[32];
  RFC_INT row;
  RFC_CHAR field[30];
  RFC_CHAR system[10];
} BAPIRET2;
#endif
#ifndef SAP_TH_BAPIRET2
#define SAP_TH_BAPIRET2
static RFC_TYPEHANDLE handleOfBAPIRET2;

static RFC_TYPE_ELEMENT typeOfBAPIRET2[] = {
  {"TYPE" , TYPC, 1 , 0},
  {"ID" , TYPC, 20 , 0},
  {"NUMBER" , TYPC, 3 , 0},
  {"MESSAGE" , TYPC, 220 , 0},
  {"LOG_NO" , TYPC, 20 , 0},
  {"LOG_MSG_NO" , TYPC, 6 , 0},
  {"MESSAGE_V1" , TYPC, 50 , 0},
  {"MESSAGE_V2" , TYPC, 50 , 0},
  {"MESSAGE_V3" , TYPC, 50 , 0},
  {"MESSAGE_V4" , TYPC, 50 , 0},
  {"PARAMETER" , TYPC, 32 , 0},
  {"ROW" , TYPINT, sizeof(RFC_INT) , 0},
  {"FIELD" , TYPC, 30 , 0},
  {"SYSTEM" , TYPC, 10 , 0},
};
#endif*/
//---------------------------------Getdetail bapi header-------------------------------start end
//-----------------------------------------------------------------header file
//CHARACTNAME
#ifndef SAP_ST_BAPICHARACTKEY_CHARACTNAME
#define SAP_ST_BAPICHARACTKEY_CHARACTNAME
typedef struct {
	
		RFC_CHAR CHARACTNAME[30];
		
}BAPICHARACTKEY_CHARACTNAME;
#endif

#ifndef SAP_TH_BAPICHARACTKEY_CHARACTNAME
#define SAP_TH_BAPICHARACTKEY_CHARACTNAME
static const RFC_TYPEHANDLE handleOfBAPICHARACTKEY_CHARACTNAME;
static const RFC_TYPE_ELEMENT typeOfBAPICHARACTKEY_CHARACTNAME[] = {
		
		{"CHARACTNAME",TYPC,30,0},

};
#endif

//CHANGENUM
#ifndef SAP_ST_BAPICHARACTKEY_CHANGENUM
#define SAP_ST_BAPICHARACTKEY_CHANGENUM
typedef struct {
	
		RFC_CHAR CHANGENUM[12];
		
}BAPICHARACTKEY_CHANGENUM;
#endif

#ifndef SAP_TH_BAPICHARACTKEY_CHANGENUM
#define SAP_TH_BAPICHARACTKEY_CHANGENUM
static const RFC_TYPEHANDLE handleOfBAPICHARACTKEY_CHANGENUM;
static const RFC_TYPE_ELEMENT typeOfBAPICHARACTKEY_CHANGENUM[] = {
		
		{"CHANGENUM",TYPC,12,0},

};
#endif


//KEYDATE
#ifndef SAP_ST_BAPICHARACTKEY_KEYDATE
#define SAP_ST_BAPICHARACTKEY_KEYDATE
typedef struct {

		RFC_DATE KEYDATE;

}BAPICHARACTKEY_KEYDATE;
#endif

#ifndef SAP_TH_BAPICHARACTKEY_KEYDATE
#define SAP_TH_BAPICHARACTKEY_KEYDATE
static const RFC_TYPEHANDLE handleOfBAPICHARACTKEY_KEYDATE;

static const RFC_TYPE_ELEMENT typeOfBAPICHARACTKEY_KEYDATE[] = {
			{"KEYDATE",	TYPDATE,	sizeof(RFC_DATE),	0},
};
#endif
//tables
//CHARACTDETAIL
#ifndef SAP_ST_BAPICHARACTDETAIL
#define SAP_BAPICHARACTDETAIL
typedef struct {

		RFC_CHAR CHARACT_NAME[30];
		RFC_CHAR DATA_TYPE [18];
		RFC_NUM LENGTH [2];
		RFC_NUM DECIMALS[2];
		RFC_CHAR CASE_SENSITIV [1];
		RFC_NUM EXPONENT_TYPE [1];
		RFC_INT2 EXPONENT;
		RFC_CHAR TEMPLATE[30];
		RFC_CHAR WITH_SIGN [1];
		RFC_CHAR UNIT_OF_MEASUREMENT[3];
		RFC_CHAR UNIT_OF_MEASUREMENT_ISO[3];
		RFC_CHAR CURRENCY[5];
		RFC_CHAR CURRENCY_ISO[3];
		RFC_CHAR STATUS [1];
		RFC_CHAR CHARACT_GROUP [10];
		RFC_CHAR VALUE_ASSIGNMENT[1];
		RFC_CHAR NO_ENTRY[1];
		RFC_CHAR NO_DISPLAY[1];
		RFC_CHAR ENTRY_REQUIRED[1];
		RFC_CHAR INTERVAL_ALLOWED[1];
		RFC_CHAR SHOW_TEMPLATE [1];
		RFC_CHAR DISPLAY_VALUES[1];
		RFC_CHAR ADDITIONAL_VALUES[1];
		RFC_CHAR DOCUMENT_NO[25];
		RFC_CHAR DOCUMENT_TYPE [3];
		RFC_CHAR DOCUMENT_PART [3];
		RFC_CHAR DOCUMENT_VERSION[2];
		RFC_CHAR CHECK_TABLE[30];
		RFC_CHAR CHECK_FUNCTION[30];
		RFC_CHAR PLANT[4];
		RFC_CHAR SELECTED_SET[8];
		RFC_CHAR ADT_CLASS [18];
		RFC_CHAR ADT_CLASS_TYPE[3];
		RFC_CHAR AGGREGATING[1];
		RFC_CHAR BALANCING [1];
		RFC_CHAR INPUT_REQUESTED_CONF[1];
		RFC_CHAR AUTHORITY_GROUP [3];
		RFC_CHAR UNFORMATED[1];

}BAPICHARACTDETAIL;
#endif

#ifndef SAP_TH_BAPICHARACTDETAIL
#define SAP_TH_BAPICHARACTDETAIL
static const RFC_TYPEHANDLE handleOfBAPICHARACTDETAIL;
static const RFC_TYPE_ELEMENT typeOfBAPICHARACTDETAIL[] = {

			{"CHARACT_NAME",TYPC,30,0},
			{"DATA_TYPE",TYPC,18,0},
			{"LENGTH",TYPNUM,2,0},
			{"DECIMALS",TYPNUM,2,0},
			{"CASE_SENSITIV",TYPC,1,0},
			{"EXPONENT_TYPE",TYPNUM,1,0},
			{"EXPONENT",	TYPINT2,	sizeof(RFC_INT2),	0},
			{"TEMPLATE",TYPC,30,0},
			{"WITH_SIGN",TYPC,1,0},
			{"UNIT_OF_MEASUREMENT",TYPC,3,0},
			{"UNIT_OF_MEASUREMENT_ISO",TYPC,3,0},
			{"CURRENCY",TYPC,5,0},
			{"CURRENCY_ISO",TYPC,3,0},
			{"STATUS",TYPC,1,0},
			{"CHARACT_GROUP",TYPC,10,0},
			{"VALUE_ASSIGNMENT",TYPC,1,0},
			{"NO_ENTRY",TYPC,1,0},
			{"NO_DISPLAY",TYPC,1,0},
			{"ENTRY_REQUIRED",TYPC,1,0},
			{"INTERVAL_ALLOWED",TYPC,1,0},
			{"SHOW_TEMPLATE",TYPC,1,0},
			{"DISPLAY_VALUES",TYPC,1,0},
			{"ADDITIONAL_VALUES",TYPC,1,0},
			{"DOCUMENT_NO",TYPC,25,0},
			{"DOCUMENT_TYPE",TYPC,3,0},
			{"DOCUMENT_PART",TYPC,3,0},
			{"DOCUMENT_VERSION",TYPC,2,0},
			{"CHECK_TABLE",TYPC,30,0},
			{"CHECK_FUNCTION",TYPC,30,0},
			{"PLANT",TYPC,4,0},
			{"SELECTED_SET",TYPC,8,0},
			{"ADT_CLASS",TYPC,18,0},
			{"ADT_CLASS_TYPE",TYPC,3,0},
			{"AGGREGATING",TYPC,1,0},
			{"BALANCING",TYPC,1,0},
			{"INPUT_REQUESTED_CONF",TYPC,1,0},
			{"AUTHORITY_GROUP",TYPC,3,0},
			{"UNFORMATED",TYPC,1,0},

};
#endif
//CHARACTDESCR
#ifndef SAP_ST_BAPICHARACTDESCR
#define SAP_ST_BAPICHARACTDESCR
typedef struct {
	RFC_CHAR LANGUAGE_INT[1];
	RFC_CHAR LANGUAGE_ISO[2];
	RFC_CHAR DESCRIPTION[30];
	RFC_CHAR HEADER1[30];
	RFC_CHAR HEADER2[30];

}BAPICHARACTDESCR;
#endif

#ifndef SAP_TH_BAPICHARACTDESCR
#define SAP_TH_BAPICHARACTDESCR
static const RFC_TYPEHANDLE handleOfBAPICHARACTDESCR;

static const RFC_TYPE_ELEMENT typeOfBAPICHARACTDESCR[] = {
	{"LANGUAGE_INT",TYPC,1,0},
	{"LANGUAGE_ISO",TYPC,2,0},
	{"DESCRIPTION",TYPC,30,0},
	{"HEADER1",TYPC,30,0},
	{"HEADER2",TYPC,30,0},
};
#endif

//CHARACTVALUESNUM
#ifndef SAP_ST_BAPICHARACTVALUESNUM
#define SAP_ST_BAPICHARACTVALUESNUM
typedef struct {

	RFC_BCD VALUE_FROM[16];
	RFC_BCD VALUE_TO[16];
	RFC_CHAR VALUE_RELATION[1];
	RFC_CHAR UNIT_FROM[3];
	RFC_CHAR UNIT_TO[3];
	RFC_CHAR UNIT_FROM_ISO[3];
	RFC_CHAR UNIT_TO_ISO[3];
	RFC_CHAR DEFAULT_VALUE[1];
	RFC_CHAR DOCUMENT_NO[25];
	RFC_CHAR DOCUMENT_TYPE[3];
	RFC_CHAR DOCUMENT_PART[3];
	RFC_CHAR DOCUMENT_VERSION[2];


}BAPICHARACTVALUESNUM;
#endif

#ifndef SAP_TH_BAPICHARACTVALUESNUM
#define SAP_TH_BAPICHARACTVALUESNUM
static const RFC_TYPEHANDLE handleOfBAPICHARACTVALUESNUM;

static const RFC_TYPE_ELEMENT typeOfBAPICHARACTVALUESNUM[] = {	

		{"VALUE_FROM",TYPP,16,0},
		{"VALUE_TO",TYPP,16,0},
		{"VALUE_RELATION",TYPC,1,0},
		{"UNIT_FROM",TYPC,3,0},
		{"UNIT_TO",TYPC,3,0},
		{"UNIT_FROM_ISO",TYPC,3,0},
		{"UNIT_TO_ISO",TYPC,3,0},
		{"DEFAULT_VALUE",TYPC,1,0},
		{"DOCUMENT_NO",TYPC,25,0},
		{"DOCUMENT_TYPE",TYPC,3,0},
		{"DOCUMENT_PART",TYPC,3,0},
		{"DOCUMENT_VERSION",TYPC,2,0},


};
#endif



//CHARACTVALUESCHAR
#ifndef SAP_ST_BAPICHARACTVALUESCHAR
#define SAP_ST_BAPICHARACTVALUESCHAR
typedef struct {

	RFC_CHAR VALUE_CHAR[30];
	RFC_CHAR VALUE_CHAR_HIGH[30];
	RFC_CHAR DEFAULT_VALUE[1];
	RFC_CHAR DOCUMENT_NO[25];
	RFC_CHAR DOCUMENT_TYPE[3];
	RFC_CHAR DOCUMENT_PART[3];
	RFC_CHAR DOCUMENT_VERSION[2];


}BAPICHARACTVALUESCHAR;
#endif

#ifndef SAP_TH_BAPICHARACTVALUESCHAR
#define SAP_TH_BAPICHARACTVALUESCHAR
static const RFC_TYPEHANDLE handleOfBAPICHARACTVALUESCHAR;

static const RFC_TYPE_ELEMENT typeOfBAPICHARACTVALUESCHAR[] = {	

		{"VALUE_CHAR",TYPC,30,0},
		{"VALUE_CHAR_HIGH",TYPC,30,0},
		{"DEFAULT_VALUE",TYPC,1,0},
		{"DOCUMENT_NO",TYPC,25,0},
		{"DOCUMENT_TYPE",TYPC,3,0},
		{"DOCUMENT_PART",TYPC,3,0},
		{"DOCUMENT_VERSION",TYPC,2,0},


};
#endif


//BAPICHARACTVALUESCURR
#ifndef SAP_ST_BAPICHARACTVALUESCURR
#define SAP_ST_BAPICHARACTVALUESCURR
typedef struct {

	RFC_BCD VALUE_FROM[16];
	RFC_BCD VALUE_TO[16];
	RFC_CHAR VALUE_RELATION[1];
	RFC_CHAR CURRENCY_FROM[5];
	RFC_CHAR CURRENCY_TO[5];
	RFC_CHAR CURRENCY_FROM_ISO[3];
	RFC_CHAR CURRENCY_TO_ISO[3];
	RFC_CHAR DEFAULT_VALUE[1];
	RFC_CHAR DOCUMENT_NO[25];
	RFC_CHAR DOCUMENT_TYPE[3];
	RFC_CHAR DOCUMENT_PART[3];
	RFC_CHAR DOCUMENT_VERSION[2];


}BAPICHARACTVALUESCURR;
#endif

#ifndef SAP_TH_BAPICHARACTVALUESCURR
#define SAP_TH_BAPICHARACTVALUESCURR
static const RFC_TYPEHANDLE handleOfBAPICHARACTVALUESCURR;

static const RFC_TYPE_ELEMENT typeOfBAPICHARACTVALUESCURR[] = {	

		{"VALUE_FROM",TYPP,16,0},
		{"VALUE_TO",TYPP,16,0},
		{"VALUE_RELATION",TYPC,1,0},
		{"CURRENCY_FROM",TYPC,5,0},
		{"CURRENCY_TO",TYPC,5,0},
		{"CURRENCY_FROM_ISO",TYPC,3,0},
		{"CURRENCY_TO_ISO",TYPC,3,0},
		{"DEFAULT_VALUE",TYPC,1,0},
		{"DOCUMENT_NO",TYPC,25,0},
		{"DOCUMENT_TYPE",TYPC,3,0},
		{"DOCUMENT_PART",TYPC,3,0},
		{"DOCUMENT_VERSION",TYPC,2,0},


};
#endif




//BAPICHARACTVALUESDESCR
#ifndef SAP_ST_BAPICHARACTVALUESDESCR
#define SAP_ST_BAPICHARACTVALUESDESCR
typedef struct {
	RFC_CHAR LANGUAGE_INT[1];
	RFC_CHAR LANGUAGE_ISO[2];
	RFC_CHAR VALUE_CHAR[30];
	RFC_CHAR DESCRIPTION[30];
	

}BAPICHARACTVALUESDESCR;
#endif

#ifndef SAP_TH_BAPICHARACTVALUESDESCR
#define SAP_TH_BAPICHARACTVALUESDESCR
static const RFC_TYPEHANDLE handleOfBAPICHARACTVALUESDESCR;

static const RFC_TYPE_ELEMENT typeOfBAPICHARACTVALUESDESCR[] = {
	{"LANGUAGE_INT",TYPC,1,0},
	{"LANGUAGE_ISO",TYPC,2,0},
	{"VALUE_CHAR",TYPC,30,0},
	{"DESCRIPTION",TYPC,30,0},
	
};
#endif


//BAPICHARACTREFERENCES
#ifndef SAP_ST_BAPICHARACTREFERENCES
#define SAP_ST_BAPICHARACTREFERENCES
typedef struct {
	RFC_CHAR REFERENCE_TABLE[30];
	RFC_CHAR REFERENCE_FIELD[30];

}BAPICHARACTREFERENCES;
#endif

#ifndef SAP_TH_BAPICHARACTREFERENCES
#define SAP_TH_BAPICHARACTREFERENCES
static const RFC_TYPEHANDLE handleOfBAPICHARACTREFERENCES;

static const RFC_TYPE_ELEMENT typeOfBAPICHARACTREFERENCES[] = {
	{"REFERENCE_TABLE",TYPC,30,0},
	{"REFERENCE_FIELD",TYPC,30,0},
	
};
#endif

//BAPICHARACTRESTRICTIONS
#ifndef SAP_ST_BAPICHARACTRESTRICTIONS
#define SAP_ST_BAPICHARACTRESTRICTIONS
typedef struct {
	RFC_CHAR CLASS_TYPE[3];
	

}BAPICHARACTRESTRICTIONS;
#endif

#ifndef SAP_TH_BAPICHARACTRESTRICTIONS
#define SAP_TH_BAPICHARACTRESTRICTIONS
static const RFC_TYPEHANDLE handleOfBAPICHARACTRESTRICTIONS;

static const RFC_TYPE_ELEMENT typeOfBAPICHARACTRESTRICTIONS[] = {
	{"CLASS_TYPE",TYPC,3,0},
	
};
#endif
//table end
//BAPITA_WAIT
#ifndef SAP_ST_BAPITA_WAIT
#define SAP_ST_BAPITA_WAIT
typedef struct {
	
		RFC_CHAR WAIT[1];
		
}BAPITA_WAIT;
#endif

#ifndef SAP_TH_BAPITA_WAIT
#define SAP_TH_BAPITA_WAIT
static const RFC_TYPEHANDLE handleOfBAPITA_WAIT;
static const RFC_TYPE_ELEMENT typeOfBAPITA_WAIT[] = {
		
		{"WAIT",TYPC,1,0},

};
#endif


//-----------------------------------------------------------------header file

FILE * fsuccess;
char *iSapServer = NULL;
struct node
{
	//char sr_no[5];
	char *value;
	char *desc;
	//float qty;
	//char uq[4];
	//char *formula;
	//char mat_prov_ind[2];
	//char * make_buy_indDup; // added by rajendra on 9.9.16
	//float usgProb;
	struct node *next;
};

struct node *start=NULL;
char *sr_no=NULL;

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

FILE* fp=NULL;
#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
struct node* createnode(/*char sr_no[5],*/char *value,char *desc);
//my_free(struct node* start);

/*void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("%*.0s",pos,text);fflush(stdout); printf("%-*s : %s\n",len,text,str);fflush(stdout);
  fprintf(fsuccess,"%*.0s",pos,text); fprintf(fsuccess,"%-*s : %s\n",len,text,str);
  return;
}*/
int cl_bapi_charact_getdetail ( char *OptfmlyName, char **SapCharVal, char **SapCharValDesc );

void my_free(struct node* start)
{
	struct node* prev;
	struct node* ptr;
	printf("\nErazing Linklist Started...\n");
	//fprintf(fsuccess,"\nErazing Linklist Started...\n");
	for(prev = start, ptr = start; ptr != NULL, prev = ptr; ptr = ptr->next)
	{
		printf("#");
		//fprintf(fsuccess,"#");
		free(prev);
	}
	start = NULL;
	printf("\nErazing Linklist Completed.\n");
	//fprintf(fsuccess,"\nErazing Linklist Completed.\n");

}

struct node* createnode(/*char sr_no[5],*/char *value,char *desc)
{
	struct node* p = NULL;
	p = (struct node*)malloc(sizeof(struct node));
	//strcpy(p->sr_no,sr_no);
	p->value = value;
	p->desc = desc;
	p->next = NULL;
	return p;
}

int search(struct node* start,char *value)
{
	struct node* p;
	int found = 1 ;

	p=start;
	/*while(p->next!=NULL)*/
	while(p!=NULL)
	{
			printf("\np->value:[%s],value:[%s]",p->value,value);
			if(strcmp(p->value,value)==0)
			{
					//found;
					//p->qty = p->qty + *qty;
					found = 0;
					break;
			}
			else
			{
				p=p->next;
				found = 1 ;
			}

		}
	return found;
}

extern int ITK_user_main ( int argc, char ** argv )
{
    int status;
	int kk=0;
	int ret;
	int resultCount = 0;
	struct node *p = NULL;
	struct node *q = NULL;
	int n_entries = 1; //no. of query input arg
	tag_t queryTag = NULLTAG;
	tag_t outTag = NULLTAG;
	tag_t ConfigCtx = NULLTAG;
	tag_t platformrev = NULLTAG;
	tag_t platformnode = NULLTAG;
	char *ContextobjName=NULL;
	tag_t *resultOutputTag = NULLTAG;
	tag_t platfrm_tag = NULLTAG;
	tag_t ConfigCtxObjTypeTag = NULLTAG;
	char *item_type = NULL;
	char *Optfmly_type = NULL;
	char *platfrm = NULL;
	char *pltfrm_str = NULL;
	char *mainpltfrm = NULL;
	char *platfrm_name = NULL;
	char Config_CtxType[TCTYPE_name_size_c+1];
	char *SmVCContext = NULL;
	char *Context_Str = NULL;
	char *SmCrIDContext = NULL;
	tag_t *familtopttag = NULLTAG;
	static int sr_no1 = 0;
	char *inputPart = NULL;
	//char *qry_entries[1] = {"Name"};
	char *qry_entries[1] = {"ID"};
	char *OptValName = NULL;
	char *OptValDesc = NULL;
	char *OptfmlyName = NULL;
	char *OptfmlyDesc = NULL;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	int iVal_Count = 0 ;
	
	OptfmlyName = (char *)malloc(50 * sizeof(char));
	OptfmlyDesc = (char *)malloc(50 * sizeof(char));
	OptValName = (char *)malloc(50 * sizeof(char));
    OptValDesc = (char *)malloc(50 * sizeof(char));
  	sr_no = (char *) malloc(10 * sizeof(char));





	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL( ITK_initialize_text_services ( ITK_BATCH_TEXT_MODE ) );
	ITK_CALL( ITK_auto_login ( ) );
	ITK_CALL( ITK_set_journalling ( TRUE ) );

	platfrm = ITK_ask_cli_argument("-i=");
	iSapServer = ITK_ask_cli_argument("-s=");

	ITK_CALL( ITEM_find_item ( platfrm, &platfrm_tag ) );

	if (platfrm_tag != NULLTAG)
	{
		printf("\nPlatForm :%s Found",platfrm);fflush(stdout);

		ITK_CALL(ITEM_ask_type2 (platfrm_tag, &item_type));
		printf("\nMain item_types: [%s] \n",item_type);  fflush(stdout);

	}
	else
	{
		printf("\nPlatForm %s not found in TCUA",platfrm);
		exit ( 0 );
	}

	if(tc_strcmp(item_type,"T5_Platform")==0)
	{

		    tag_t relation_dep = NULLTAG;
			int countConfigCtx =0;
			tag_t *ConfigCtxSecObject = NULLTAG;

			ITK_CALL(AOM_ask_value_string(platfrm_tag,"item_id",&platfrm_name));
			printf("\n\n\t\tPlatform Name ==> %s\n", platfrm_name);fflush(stdout);

			ITK_CALL(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
			if(relation_dep != NULLTAG)
			{
				printf("\n\tVariant ConfigContext relation found......");	fflush(stdout);
			}

			ITK_CALL(GRM_list_secondary_objects_only(platfrm_tag,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
			printf("\n\tConfiguration Context count is : %d",countConfigCtx);

			if(countConfigCtx>0)
			{
				  tag_t queryTag = NULLTAG;
				  tag_t queryTagOptFamVal = NULLTAG;
				  tag_t Optfmly_tag = NULLTAG;
				  tag_t OptfmlyVal_tag = NULLTAG;
				  int j1=0;
				  int resultCountOptFamVal=0,n_entriesOptFamVal=2,i=0;
				  char *qry_entriesOptFamVal[] = {"Thread ID","ID"};
				  tag_t *revOptFamVal=NULL;
				  char **qry_valuesOptFamVal = (char **) MEM_alloc(10 * sizeof(char *));

				  ConfigCtx=ConfigCtxSecObject[0];
				  ITK_CALL(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
				  ITK_CALL(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));
				  printf( "\n\tConfig relation Config_CtxType :%s ..",Config_CtxType);

				  ITK_CALL(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
				  printf("\n\tSmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

				   ITK_CALL(AOM_ask_value_string(ConfigCtx,"item_id",&Context_Str));
				  printf("\n\tContext_Str :%s",Context_Str);	fflush(stdout);

				  ITK_CALL(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
				  printf("\n\tSmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

				  if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
				  if (queryTag)
				  {
					printf("\n\tFound Query");fflush(stdout);
				  }
				  else
				  {
					printf("\n\tNot Found Query");fflush(stdout);
				  }

				  qry_values[0] = SmCrIDContext;

				  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &familtopttag));
				  printf("\n\tresultCount : %d\n", resultCount); fflush(stdout);

				  for ( j1 = 0; j1 < resultCount; j1++ )
				  {
						printf("\nProcessing option [%d]",j1);
						Optfmly_tag = familtopttag[j1];
						ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyDesc));
						//ITK_CALL(AOM_ask_value_string(Optfmly_tag,"current_desc",&OptfmlyName));
						ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_desc",&OptfmlyName));
						printf("\n\tOpt Name:[%-50s] OptName length:[%-3d] OptfmlyDesc:[%-50s]",OptfmlyName,tc_strlen(OptfmlyName),OptfmlyDesc); fflush(stdout);   //Drive, Fuel is a Name if Option family

						//ITK_CALL(ITEM_ask_type2 ( Optfmly_tag, &Optfmly_type ));
						ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_type",&Optfmly_type));
						printf("\tOptfmly type:[%-30s]",Optfmly_type);  fflush(stdout);

						if ( tc_strcmp(Optfmly_type, "Cfg0PackageOptionFamily" ) == 0 )
					    {
							printf("\tSkipping"); fflush(stdout);
							continue;
						}

						printf("\n"); fflush(stdout);

						if(tc_strlen(OptfmlyName) == 0)
						{
							printf("\nError:object_desc is null for object_name:%s raise error with BOM process team",OptfmlyDesc);
							continue;
						}

						if ( tc_strlen ( OptfmlyName ) > 30 )
						{
							printf("\nError:Can not create characteristic for option name [%s] length is more than 30 character contact BOM process team length:%d",OptfmlyName,tc_strlen ( OptfmlyName ));
							exit ( 0 ); //it should show error and come out
							//continue;
						}

						//if ( tc_strcmp( OptfmlyName, "STEERING_OPERATION" ) == 0 )
						//if ( tc_strcmp( OptfmlyName, "ACCELERATOR_PEDAL_OPT_TYPE" ) != 0 )
						/*if ( tc_strcmp( OptfmlyName, "FUEL_DELIVERY_CIRCUIT_TYPE" ) != 0 )
						{
							continue;
						}*/

						if ( tc_strcmp( OptfmlyName, "SCHEME_NO" ) != 0 )
						{
							continue;
						}

						if(QRY_find("__Cfg0OptionValuesFromOptionFamilyIDs", &queryTagOptFamVal));
						printf("\nAfter IFERR_REPORT : QRY_find \n");fflush(stdout);
						if (queryTagOptFamVal)
						{
							printf("\n2.Found Query\n");fflush(stdout);
						}
						else
						{
							printf("\nNot Found Query\n");fflush(stdout);
						}
						qry_valuesOptFamVal[0]= OptfmlyDesc;
						qry_valuesOptFamVal[1]= Context_Str;
						if(QRY_execute(queryTagOptFamVal, n_entriesOptFamVal, qry_entriesOptFamVal, qry_valuesOptFamVal, &resultCountOptFamVal, &revOptFamVal));

						
						printf("\nresultCountOptFamVal:%d",resultCountOptFamVal);
						start = NULL;
						p = NULL;
						q = NULL;
						ret = 0;

						/*
						//get values maintained in SAP using below code 19.06.2020
						char **SapCharVal  = (char **) MEM_alloc(50 * sizeof(char *));
						char **SapCharValDesc  = (char **) MEM_alloc(50 * sizeof(char *));
						iVal_Count = cl_bapi_charact_getdetail ( OptfmlyName, SapCharVal, SapCharValDesc ) ; //get existing values
						printf("\niVal_Count:%d",iVal_Count);
						int ic = 0;
						for ( ic = 0; ic <iVal_Count; ic++ )
						{
							printf("\nSapCharVal:[%s]",SapCharVal[ic]);
							if(p==NULL)
							{
								p = createnode(SapCharVal[ic],SapCharValDesc[ic]);
								start = p;
							}
							else
							{
								ret = search(start,SapCharVal[ic]);
								if(ret==1)
								{
									 q=start;
									 while(q->next!=NULL)
									 {
										 q=q->next;
									 }
									q->next=createnode(SapCharVal[ic],SapCharValDesc[ic]);
								}
							}
						}*/

						ret = 0;

						for ( i = 0; i < resultCountOptFamVal; i++ )
						{
							OptfmlyVal_tag = revOptFamVal[i];
							ITK_CALL(AOM_ask_value_string(OptfmlyVal_tag,"object_name",&OptValName));
							ITK_CALL(AOM_ask_value_string(OptfmlyVal_tag,"current_name",&OptValDesc));
							printf("\n\t%d OptValName:[%s] OptValDesc[%s]",i,OptValName,OptValDesc);	fflush(stdout);

							if ( tc_strlen ( OptValName ) > 30 )
							{
								printf("\nError:Can not create option value [%s] for option name[%s] as value length is more than 30 character contact BOM process team length:%d",OptValName,OptfmlyName,tc_strlen ( OptValName ));
								exit ( 0 );
							}

							if(p == NULL)
							{
								p = createnode(OptValName,OptValDesc);
								start = p;
							}
							else
							{
								ret = search(start,OptValName);
								if ( ret == 1 )
								{
									 q = start ;
									 while ( q->next != NULL )
									 {
										 q = q->next ;
									 }
									 q->next = createnode ( OptValName, OptValDesc ) ;
								}
								
							}

						}
						
						cll_BAPI_CHARACT_CHANGE(start,OptfmlyName,OptfmlyDesc);
						my_free(start);

				   }
			}
	}

	ITK_CALL(POM_logout(false));
	return status;

	CLEANUP:

		 printf("\n CLEANUP"); fflush(stdout);
}
;

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

RFC_RC BAPI_CHARACT_CHANGE(
					RFC_HANDLE hRfc,
					BAPICHARACTKEY_CHARACTNAME *eBAPICHARACTKEY_CHARACTNAME,
					BAPICHARACTKEY_CHANGENUM *eBAPICHARACTKEY_CHANGENUM,
					BAPICHARACTKEY_KEYDATE *eBAPICHARACTKEY_KEYDATE,
					ITAB_H thBAPICHARACTDETAIL,
					ITAB_H thBAPICHARACTDESCR,
					ITAB_H thBAPICHARACTVALUESNUM,
					ITAB_H thBAPICHARACTVALUESCHAR,
					ITAB_H thBAPICHARACTVALUESCURR,
					ITAB_H thBAPICHARACTVALUESDESCR,
					ITAB_H thBAPICHARACTREFERENCES,
					ITAB_H thBAPICHARACTRESTRICTIONS,
					ITAB_H thBAPIRET2,
					char *xException )
{
	RFC_PARAMETER Exporting[4];
	RFC_PARAMETER Importing[1];
	RFC_TABLE Tables[10];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "CHARACTNAME";
	Exporting[0].nlen = 11;
	Exporting[0].type = handleOfBAPICHARACTKEY_CHARACTNAME;
	Exporting[0].leng = sizeof(BAPICHARACTKEY_CHARACTNAME);
	Exporting[0].addr = eBAPICHARACTKEY_CHARACTNAME;

	Exporting[1].name = "CHANGENUMBER";
	Exporting[1].nlen = 12;
	Exporting[1].type = handleOfBAPICHARACTKEY_CHANGENUM;
	Exporting[1].leng = sizeof(BAPICHARACTKEY_CHANGENUM);
	Exporting[1].addr = eBAPICHARACTKEY_CHANGENUM;

	Exporting[2].name = "KEYDATE";
	Exporting[2].nlen = 7;
	Exporting[2].type = handleOfBAPICHARACTKEY_KEYDATE;
	Exporting[2].leng = sizeof(BAPICHARACTKEY_KEYDATE);
	Exporting[2].addr = eBAPICHARACTKEY_KEYDATE;

	Exporting[3].name = NULL;

	Tables[0].name     = "CHARACTDETAILNEW";
	Tables[0].nlen     = 16;
	Tables[0].type     = handleOfBAPICHARACTDETAIL;
	Tables[0].ithandle = thBAPICHARACTDETAIL;

	Tables[1].name     = "CHARACTDESCRNEW";
	Tables[1].nlen     = 15;
	Tables[1].type     = handleOfBAPICHARACTDESCR;
	Tables[1].ithandle = thBAPICHARACTDESCR;

	Tables[2].name     = "CHARACTVALUESNUMNEW";
	Tables[2].nlen     = 19;
	Tables[2].type     = handleOfBAPICHARACTVALUESNUM;
	Tables[2].ithandle = thBAPICHARACTVALUESNUM;

	Tables[3].name     = "CHARACTVALUESCHARNEW";
	Tables[3].nlen     = 20;
	Tables[3].type     = handleOfBAPICHARACTVALUESCHAR;
	Tables[3].ithandle = thBAPICHARACTVALUESCHAR;

	Tables[4].name     = "CHARACTVALUESCURRNEW";
	Tables[4].nlen     = 20;
	Tables[4].type     = handleOfBAPICHARACTVALUESCURR;
	Tables[4].ithandle = thBAPICHARACTVALUESCURR;

	Tables[5].name     = "CHARACTVALUESDESCRNEW";
	Tables[5].nlen     = 21;
	Tables[5].type     = handleOfBAPICHARACTVALUESDESCR;
	Tables[5].ithandle = thBAPICHARACTVALUESDESCR;

	Tables[6].name     = "CHARACTREFERENCESNEW";
	Tables[6].nlen     = 20;
	Tables[6].type     = handleOfBAPICHARACTREFERENCES;
	Tables[6].ithandle = thBAPICHARACTREFERENCES;

	Tables[7].name     = "CHARACTRESTRICTIONSNEW";
	Tables[7].nlen     = 22;
	Tables[7].type     = handleOfBAPICHARACTRESTRICTIONS;
	Tables[7].ithandle = thBAPICHARACTRESTRICTIONS;

	Tables[8].name = "RETURN";
	Tables[8].nlen = 6;
	Tables[8].type = handleOfBAPIRET2;
	Tables[8].ithandle = thBAPIRET2;


	Tables[9].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_CHARACT_CHANGE",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\nImporting... RFC OK");

			Importing[0].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					printf("\nRFC_SYS_EXCEPTION:%s",xException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					printf("\nRFC_EXCEPTION:%s",xException);
					break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
			break;
	}
	return RfcRc;
}

RFC_RC BAPI_TRANSACTION_COMMIT(	RFC_HANDLE				    hRfc,
					BAPITA_WAIT*			    eBAPITA_WAIT,
					//BAPIRET2*				    eBapiret2,
					char*					    xException

				 )
{

	RFC_PARAMETER Exporting[2];
	RFC_PARAMETER Importing[1];
	RFC_TABLE Tables[1];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "WAIT";
	Exporting[0].nlen = 4;
	Exporting[0].type = handleOfBAPITA_WAIT;
	Exporting[0].leng = sizeof(BAPITA_WAIT);
	Exporting[0].addr = eBAPITA_WAIT;

	Exporting[1].name = NULL;

	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_TRANSACTION_COMMIT",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\nImporting... RFC OK");

		   /*Importing[0].name = "RETURN";
			Importing[0].nlen = 6;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = eBapiret2;*/
			Importing[0].name = NULL;


			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					printf("\nRFC_SYS_EXCEPTION:%s",xException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					printf("\nRFC_EXCEPTION:%s",xException);
					break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
			break;
	}
	return RfcRc;

}

void getTodayDateCal(char sTodaysDate[9])
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;

	time_t Tval = 0;
	Tval = time(0);
	Sys_T = localtime(&Tval);

	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;

	sprintf(sTodaysDate,"%04d%02d%02d",Year,Month,Day);

}

cll_BAPI_CHARACT_CHANGE(struct node *head,char *OptfmlyName,char *OptfmlyDesc)
{

	RFC_RC RfcRc;
	RFC_RC RfcRc1;
	RFC_HANDLE hRfc;
	char xException[256] = { 0 };
	char s[1024] = { 0 };
	char s1[1024] = { 0 };
	int crow=0;
	int crow1=0;
	int var=0;
	int var1=0;
	struct node *p=NULL;
	char value[100];
	char desc[100];
	char srno[5];
	char sTodaysDate[9] = { 0 };

	BAPICHARACTKEY_CHARACTNAME eBAPICHARACTKEY_CHARACTNAME;
	BAPICHARACTKEY_CHANGENUM eBAPICHARACTKEY_CHANGENUM;
	BAPICHARACTKEY_KEYDATE eBAPICHARACTKEY_KEYDATE;

	BAPITA_WAIT eBAPITA_WAIT;
	//BAPIRET2 eBapiret2;

	BAPICHARACTDETAIL* tBAPICHARACTDETAIL;

	BAPICHARACTDESCR* tBAPICHARACTDESCR;
	BAPICHARACTVALUESNUM* tBAPICHARACTVALUESNUM;
	BAPICHARACTVALUESCHAR* tBAPICHARACTVALUESCHAR;
	BAPICHARACTVALUESCURR* tBAPICHARACTVALUESCURR;
	BAPICHARACTVALUESDESCR* tBAPICHARACTVALUESDESCR;
	BAPICHARACTREFERENCES* tBAPICHARACTREFERENCES;
	BAPICHARACTRESTRICTIONS* tBAPICHARACTRESTRICTIONS;
	BAPIRET2* tBAPIRET2;

	ITAB_H thBAPICHARACTDETAIL = ITAB_NULL;
	ITAB_H thBAPICHARACTDESCR = ITAB_NULL;
	ITAB_H thBAPICHARACTVALUESNUM = ITAB_NULL;
	ITAB_H thBAPICHARACTVALUESCHAR = ITAB_NULL;
	ITAB_H thBAPICHARACTVALUESCURR = ITAB_NULL;
	ITAB_H thBAPICHARACTVALUESDESCR = ITAB_NULL;
	ITAB_H thBAPICHARACTREFERENCES = ITAB_NULL;
	//ITAB_H thBAPICHARACTREFERENCES = ITAB_NULL;
	ITAB_H thBAPICHARACTRESTRICTIONS = ITAB_NULL;
	ITAB_H thBAPIRET2 = ITAB_NULL;

    fsuccess = fopen("char_change.txt","a");


	getTodayDateCal(sTodaysDate);

	printf("\nsTodaysDate:%s",sTodaysDate);

	
	SETCHAR(eBAPICHARACTKEY_CHARACTNAME.CHARACTNAME,OptfmlyName);
	//SETCHAR(eBAPICHARACTKEY_CHARACTNAME.CHARACTNAME,"STEERING_OPERATION_1");
	SETCHAR(eBAPICHARACTKEY_CHANGENUM.CHANGENUM,"");
	//SETCHAR(eBAPICHARACTKEY_KEYDATE.KEYDATE,"20181008");//YYYYMMDD
	SETCHAR(eBAPICHARACTKEY_KEYDATE.KEYDATE,sTodaysDate);


	//tables create

	if (thBAPICHARACTDETAIL==ITAB_NULL)
	{
		thBAPICHARACTDETAIL = ItCreate("CHARACTDETAILNEW",sizeof(BAPICHARACTDETAIL),0,0);
		if (thBAPICHARACTDETAIL==ITAB_NULL)
		printf("ItCreate CHARACTDETAILNEW");
	}
	else
	{
			if (ItFree(thBAPICHARACTDETAIL) != 0)
			printf("ItFree CHARACTDETAILNEW");
	}

	if (thBAPICHARACTDESCR==ITAB_NULL)
	{
		thBAPICHARACTDESCR = ItCreate("CHARACTDESCRNEW",sizeof(BAPICHARACTDESCR),0,0);
		if (thBAPICHARACTDESCR==ITAB_NULL)
		printf("ItCreate CHARACTDESCRNEW");
	}
	else
	{
			if (ItFree(thBAPICHARACTDESCR) != 0)
			printf("ItFree CHARACTDESCRNEW");
	}

	if (thBAPICHARACTVALUESNUM==ITAB_NULL)
	{
		thBAPICHARACTVALUESNUM = ItCreate("CHARACTVALUESNUMNEW",sizeof(BAPICHARACTVALUESNUM),0,0);
		if (thBAPICHARACTVALUESNUM==ITAB_NULL)
			printf("ItCreate CHARACTVALUESNUMNEW");
	}
	else if (ItFree(thBAPICHARACTVALUESNUM)!= 0)
	{
		printf("ItFree CHARACTVALUESNUMNEW");
	}


	if (thBAPICHARACTVALUESCHAR==ITAB_NULL)
	{
		thBAPICHARACTVALUESCHAR = ItCreate("CHARACTVALUESCHARNEW",sizeof(BAPICHARACTVALUESCHAR),0,0);
		if (thBAPICHARACTVALUESCHAR==ITAB_NULL)
			printf("ItCreate CHARACTVALUESCHARNEW");
	}
	else if (ItFree(thBAPICHARACTVALUESCHAR)!= 0)
	{
		printf("ItFree CHARACTVALUESCHARNEW");
	}


	if (thBAPICHARACTVALUESCURR==ITAB_NULL)
	{
		thBAPICHARACTVALUESCURR = ItCreate("CHARACTVALUESCURRNEW",sizeof(BAPICHARACTVALUESCURR),0,0);
		if (thBAPICHARACTVALUESCURR==ITAB_NULL)
			printf("ItCreate CHARACTVALUESCURRNEW");
	}
	else if (ItFree(thBAPICHARACTVALUESCURR)!= 0)
	{
		printf("ItFree CHARACTVALUESCURRNEW");
	}

	if (thBAPICHARACTVALUESDESCR==ITAB_NULL)
	{
		thBAPICHARACTVALUESDESCR = ItCreate("CHARACTVALUESDESCRNEW",sizeof(BAPICHARACTVALUESDESCR),0,0);
		if (thBAPICHARACTVALUESDESCR==ITAB_NULL)
			printf("ItCreate CHARACTVALUESDESCRNEW");
	}
	else if (ItFree(thBAPICHARACTVALUESDESCR)!= 0)
	{
		printf("ItFree CHARACTVALUESDESCRNEW");
	}


	if (thBAPICHARACTREFERENCES==ITAB_NULL)
	{
		thBAPICHARACTREFERENCES = ItCreate("CHARACTREFERENCESNEW",sizeof(BAPICHARACTREFERENCES),0,0);
		if (thBAPICHARACTREFERENCES==ITAB_NULL)
			printf("ItCreate CHARACTREFERENCESNEW");
	}
	else if (ItFree(thBAPICHARACTREFERENCES)!= 0)
	{
		printf("ItFree CHARACTREFERENCESNEW");
	}

	if (thBAPICHARACTRESTRICTIONS==ITAB_NULL)
	{
		thBAPICHARACTRESTRICTIONS = ItCreate("CHARACTRESTRICTIONSNEW",sizeof(BAPICHARACTRESTRICTIONS),0,0);
		if (thBAPICHARACTRESTRICTIONS==ITAB_NULL)
			printf("ItCreate CHARACTRESTRICTIONSNEW");
	}
	else if (ItFree(thBAPICHARACTRESTRICTIONS)!= 0)
	{
		printf("ItFree CHARACTRESTRICTIONSNEW");
	}

	if (thBAPIRET2==ITAB_NULL)
	{
		thBAPIRET2 = ItCreate("RETURN",sizeof(BAPIRET2),0,0);
		if (thBAPIRET2==ITAB_NULL)
			printf("ItCreateRETURN");
	}
	else if (ItFree(thBAPIRET2)!= 0)
	{
		printf("ItFreeRETURN");
	}


	
	tBAPICHARACTDETAIL = ItAppLine (thBAPICHARACTDETAIL);
	SETCHAR(tBAPICHARACTDETAIL->CHARACT_NAME,OptfmlyName);
	//SETCHAR(tBAPICHARACTDETAIL->CHARACT_NAME,"STEERING_OPERATION_1");
	SETCHAR(tBAPICHARACTDETAIL->DATA_TYPE,"CHAR");
	SETNUM(tBAPICHARACTDETAIL->LENGTH,"30");
	SETNUM(tBAPICHARACTDETAIL->DECIMALS,"00");
	SETCHAR(tBAPICHARACTDETAIL->CASE_SENSITIV,"");
	SETNUM(tBAPICHARACTDETAIL->EXPONENT_TYPE,"0");
	SETINT2(&tBAPICHARACTDETAIL->EXPONENT,"0");
	SETCHAR(tBAPICHARACTDETAIL->TEMPLATE,"");
	SETCHAR(tBAPICHARACTDETAIL->WITH_SIGN,"");
	SETCHAR(tBAPICHARACTDETAIL->UNIT_OF_MEASUREMENT,"");
	SETCHAR(tBAPICHARACTDETAIL->UNIT_OF_MEASUREMENT_ISO,"");
	SETCHAR(tBAPICHARACTDETAIL->CURRENCY,"");
	SETCHAR(tBAPICHARACTDETAIL->CURRENCY_ISO,"");
	SETCHAR(tBAPICHARACTDETAIL->STATUS,"1");
	SETCHAR(tBAPICHARACTDETAIL->CHARACT_GROUP,"");
	SETCHAR(tBAPICHARACTDETAIL->VALUE_ASSIGNMENT,"M");//multi value selection radio button
	SETCHAR(tBAPICHARACTDETAIL->NO_ENTRY,"");
	SETCHAR(tBAPICHARACTDETAIL->NO_DISPLAY,"");
	SETCHAR(tBAPICHARACTDETAIL->ENTRY_REQUIRED,"");
	SETCHAR(tBAPICHARACTDETAIL->INTERVAL_ALLOWED,"");
	SETCHAR(tBAPICHARACTDETAIL->SHOW_TEMPLATE,"");
	SETCHAR(tBAPICHARACTDETAIL->DISPLAY_VALUES,"");
	SETCHAR(tBAPICHARACTDETAIL->ADDITIONAL_VALUES,"X");
	SETCHAR(tBAPICHARACTDETAIL->DOCUMENT_NO,"");
	SETCHAR(tBAPICHARACTDETAIL->DOCUMENT_TYPE,"");
	SETCHAR(tBAPICHARACTDETAIL->DOCUMENT_PART,"");
	SETCHAR(tBAPICHARACTDETAIL->DOCUMENT_VERSION,"");
	SETCHAR(tBAPICHARACTDETAIL->CHECK_TABLE,"");
	SETCHAR(tBAPICHARACTDETAIL->CHECK_FUNCTION,"");
	SETCHAR(tBAPICHARACTDETAIL->PLANT,"");
	SETCHAR(tBAPICHARACTDETAIL->SELECTED_SET,"");
	SETCHAR(tBAPICHARACTDETAIL->ADT_CLASS,"");
	SETCHAR(tBAPICHARACTDETAIL->ADT_CLASS_TYPE,"");
	SETCHAR(tBAPICHARACTDETAIL->AGGREGATING,"");
	SETCHAR(tBAPICHARACTDETAIL->BALANCING,"");
	SETCHAR(tBAPICHARACTDETAIL->INPUT_REQUESTED_CONF,"");
	SETCHAR(tBAPICHARACTDETAIL->AUTHORITY_GROUP,"");
	SETCHAR(tBAPICHARACTDETAIL->UNFORMATED,"");

	
    tBAPICHARACTDESCR = ItAppLine (thBAPICHARACTDESCR);
	SETCHAR(tBAPICHARACTDESCR->LANGUAGE_INT,"EN");
	SETCHAR(tBAPICHARACTDESCR->LANGUAGE_ISO,"");
	SETCHAR(tBAPICHARACTDESCR->DESCRIPTION,OptfmlyDesc);
	SETCHAR(tBAPICHARACTDESCR->HEADER1,"");
	SETCHAR(tBAPICHARACTDESCR->HEADER2,"");

	
	for(p = head; p != NULL; p = p -> next)
	{

		sprintf(value,"%s", p->value);
		sprintf(desc,"%s",p->desc);
		printf("\n\tAdding[%s]:[%s]",value,desc);fflush(stdout);


		tBAPICHARACTVALUESCHAR  = ItAppLine (thBAPICHARACTVALUESCHAR);
		if (tBAPICHARACTVALUESCHAR == NULL)
		printf("ItAppLineCHARACTVALUESCHAR");fflush(stdout);


		SETCHAR(tBAPICHARACTVALUESCHAR->VALUE_CHAR,value);
		SETCHAR(tBAPICHARACTVALUESCHAR->VALUE_CHAR_HIGH,"");
		SETCHAR(tBAPICHARACTVALUESCHAR->DEFAULT_VALUE,"");
		SETCHAR(tBAPICHARACTVALUESCHAR->DOCUMENT_NO,"");
		SETCHAR(tBAPICHARACTVALUESCHAR->DOCUMENT_TYPE,"");
		SETCHAR(tBAPICHARACTVALUESCHAR->DOCUMENT_PART,"");
		SETCHAR(tBAPICHARACTVALUESCHAR->DOCUMENT_VERSION,"");

		tBAPICHARACTVALUESDESCR  = ItAppLine (thBAPICHARACTVALUESDESCR);
		if (tBAPICHARACTVALUESDESCR == NULL)
		printf("ItAppLineCHARACTVALUESDESCR");fflush(stdout);

		SETCHAR(tBAPICHARACTVALUESDESCR->LANGUAGE_INT,"EN");
		SETCHAR(tBAPICHARACTVALUESDESCR->LANGUAGE_ISO,"");
		SETCHAR(tBAPICHARACTVALUESDESCR->VALUE_CHAR,value);
		SETCHAR(tBAPICHARACTVALUESDESCR->DESCRIPTION,desc);


	}

	tBAPICHARACTRESTRICTIONS = ItAppLine (thBAPICHARACTRESTRICTIONS);
	SETCHAR(tBAPICHARACTRESTRICTIONS->CLASS_TYPE,"300");
	printf("\ncalling BAPI_CHARACT_CHANGE"); fflush(stdout);

	hRfc = BapiLogon();

    RfcRc = BAPI_CHARACT_CHANGE(
				hRfc,
				&eBAPICHARACTKEY_CHARACTNAME,
				&eBAPICHARACTKEY_CHANGENUM,
				&eBAPICHARACTKEY_KEYDATE,
				thBAPICHARACTDETAIL,
				thBAPICHARACTDESCR,
				thBAPICHARACTVALUESNUM,
				thBAPICHARACTVALUESCHAR,
				thBAPICHARACTVALUESCURR,
				thBAPICHARACTVALUESDESCR,
				thBAPICHARACTREFERENCES,
				thBAPICHARACTRESTRICTIONS,
				thBAPIRET2,
				xException
		      );

	switch (RfcRc)
	{
		case RFC_OK:

            printf("\n*********BAPI_CHARACT_CHANGE************\n");fflush(stdout);

			printf("ItFill(thBAPICHARACTDESCR):%d\n",ItFill(thBAPICHARACTDESCR));

			for (crow = 1;crow <= ItFill(thBAPICHARACTDESCR); crow++)
			{
				tBAPICHARACTDESCR = ItGetLine(thBAPICHARACTDESCR,crow);
				if (tBAPICHARACTDESCR == NULL)
					printf("ItGetLineCHARACTDESCR");

				GETCHAR(tBAPICHARACTDESCR->LANGUAGE_INT,s);F_OUTK("LANGUAGE_INT",10,30,s);
				GETCHAR(tBAPICHARACTDESCR->LANGUAGE_ISO,s);F_OUTK("LANGUAGE_ISO",10,30,s);
				GETNUM(tBAPICHARACTDESCR->DESCRIPTION,s);F_OUTK("DESCRIPTION",10,30,s);
				GETCHAR(tBAPICHARACTDESCR->HEADER1,s);F_OUTK("HEADER1",10,30,s);
				GETCHAR(tBAPICHARACTDESCR->HEADER2,s);F_OUTK("HEADER2",10,30,s);
				//GETCHAR(tBAPIRET2->LOG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETNUM(tBAPIRET2->LOG_MSG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V1,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V2,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V3,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V4,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->PARAMETER,s);F_OUTK("RETURN",10,30,s);
				//GETINT(tBAPIRET2->ROW,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->FIELD,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->SYSTEM,s);F_OUTK("RETURN",10,30,s);

			}

			printf("ItFill(thBAPICHARACTVALUESDESCR):%d\n",ItFill(thBAPICHARACTVALUESDESCR));

		    for (crow = 1;crow <= ItFill(thBAPICHARACTVALUESDESCR); crow++)
			{
				tBAPICHARACTVALUESDESCR = ItGetLine(thBAPICHARACTVALUESDESCR,crow);
				if (tBAPICHARACTVALUESDESCR == NULL)
					printf("ItGetLineCHARACTVALUESDESCR");

				GETCHAR(tBAPICHARACTVALUESDESCR->LANGUAGE_INT,s);F_OUTK("LANGUAGE_INT",10,30,s);
				GETCHAR(tBAPICHARACTVALUESDESCR->LANGUAGE_ISO,s);F_OUTK("LANGUAGE_ISO",10,30,s);
				GETNUM(tBAPICHARACTVALUESDESCR->VALUE_CHAR,s);F_OUTK("VALUE_CHAR",10,30,s);
				GETCHAR(tBAPICHARACTVALUESDESCR->DESCRIPTION,s);F_OUTK("DESCRIPTION",10,30,s);
				//GETCHAR(tBAPIRET2->LOG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETNUM(tBAPIRET2->LOG_MSG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V1,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V2,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V3,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V4,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->PARAMETER,s);F_OUTK("RETURN",10,30,s);
				//GETINT(tBAPIRET2->ROW,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->FIELD,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->SYSTEM,s);F_OUTK("RETURN",10,30,s);

			}

			printf("ItFill(thBAPIRET2):%d\n",ItFill(thBAPIRET2));

			for (crow1 = 1;crow1 <= ItFill(thBAPIRET2); crow1++)
			{
				tBAPIRET2 = ItGetLine(thBAPIRET2,crow1);
				if (tBAPIRET2 == NULL)
					printf("ItGetLineRETURN");

				GETCHAR(tBAPIRET2->TYPE,s);F_OUTK("TYPE",10,30,s);
				GETCHAR(tBAPIRET2->ID,s);F_OUTK("ID",10,30,s);
				GETNUM(tBAPIRET2->NUMBER,s);F_OUTK("NUMBER",10,30,s);
				GETCHAR(tBAPIRET2->MESSAGE,s);F_OUTK("MESSAGE",10,30,s);

				printf("\nOptfmlyName:%s,OptfmlyDesc:%s,Message:%s",OptfmlyName,OptfmlyDesc,s);
				//GETCHAR(tBAPIRET2->LOG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETNUM(tBAPIRET2->LOG_MSG_NO,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V1,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V2,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V3,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->MESSAGE_V4,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->PARAMETER,s);F_OUTK("RETURN",10,30,s);
				//GETINT(tBAPIRET2->ROW,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->FIELD,s);F_OUTK("RETURN",10,30,s);
				//GETCHAR(tBAPIRET2->SYSTEM,s);F_OUTK("RETURN",10,30,s);
			}

			//SETCHAR(eBAPITA_WAIT.WAIT," ");
            //RfcRc1 = testcommit(hRfc,&eBAPITA_WAIT,xException);

		break;
		case RFC_EXCEPTION:
			printf("\nRFC EXCEPTION: %s",xException);
			rfc_error("RFC_EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			rfc_error("RFC_SYS_EXCEPTION");
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			rfc_error("RFC_FAILURE");
		break;
		default:
			printf("\nOther Failure!");
		break;
	}

	SETCHAR(eBAPITA_WAIT.WAIT," ");
    RfcRc1 = BAPI_TRANSACTION_COMMIT(hRfc,&eBAPITA_WAIT,xException);

	switch (RfcRc1)
	{
		case RFC_OK:
             printf("\n*********Commit************\n");fflush(stdout);
			 break;
		case RFC_EXCEPTION:
			printf("\ntestcommit..RFC EXCEPTION: %s",xException);
			rfc_error("RFC_EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION:
			printf("\ntestcommit..System Exception Raised!!!");
			rfc_error("RFC_SYS_EXCEPTION");
		break;
		case RFC_FAILURE:
			printf("\ntestcommit..Failure!!!");
			rfc_error("RFC_FAILURE");
		break;
		default:
			printf("\ntestcommit..Other Failure!");
		break;
    }

	if (ItDelete(thBAPICHARACTDESCR) != 0)
	printf("ItDelete thBAPICHARACTDESCR");

	if (ItDelete(thBAPICHARACTVALUESNUM) != 0)
	printf("ItDelete thBAPICHARACTVALUESNUM");

	if (ItDelete(thBAPICHARACTVALUESCHAR) != 0)
	printf("ItDelete thBAPICHARACTVALUESCHAR");

	if (ItDelete(thBAPICHARACTVALUESCURR) != 0)
	printf("ItDelete thBAPICHARACTVALUESCURR");

	if (ItDelete(thBAPICHARACTVALUESDESCR) != 0)
	printf("ItDelete thBAPICHARACTVALUESDESCR");

	if (ItDelete(thBAPICHARACTREFERENCES) != 0)
	printf("ItDelete thBAPICHARACTREFERENCES");

	if (ItDelete(thBAPICHARACTRESTRICTIONS) != 0)
	printf("ItDelete thBAPICHARACTRESTRICTIONS");

	if (ItDelete(thBAPIRET2) != 0)
	printf("ItDelete thBAPIRET2");

   fclose(fsuccess);
	RfcClose(hRfc);
/*
CLEANUP:
	printf("\nCleaning up memory"); fflush(stdout);

EXIT:
	printf("\nExiting from program\n"); fflush(stdout);*/
}



RFC_RC bapi_charact_getdetail(RFC_HANDLE hRfc3
/**********RFC Variable***********/
											,BAPICHARACTKEY_CHARACTNAME *eBAPICHARACTKEY_CHARACTNAME
											,BAPICHARACTKEY_KEYDATE *eBAPICHARACTKEY_KEYDATE
											,BAPIFIELDSCACL_BAPILANGUA *elanguage
											,BAPICHARACTDETAIL *icharactdetail
											,ITAB_H thcharactdescr
											,ITAB_H thcharactreferences
											,ITAB_H thcharactrestrictions
											,ITAB_H thcharactvalueschar
											,ITAB_H thcharactvaluescurr
											,ITAB_H thcharactvaluesdescr
											,ITAB_H thcharactvaluesnum
											,ITAB_H threturn
											,char *xException)

{

RFC_PARAMETER Exporting[4];
RFC_PARAMETER Importing[2];
RFC_TABLE Tables[9];
RFC_RC RfcRc3;
char *RfcException = NULL;


/**********Install Structure***********/
/*
if (handleOfBAPICHARACTDETAIL==0) {
							RfcRc3 = RfcInstallStructure("BAPICHARACTDETAIL",
							typeOfBAPICHARACTDETAIL,
							ENTRIES(typeOfBAPICHARACTDETAIL),
							&handleOfBAPICHARACTDETAIL);

 if (RfcRc3 != RFC_OK) rfc_error("RfcInstallStructure"); }

if (handleOfBAPICHARACTDESCR==0) {
							RfcRc3 = RfcInstallStructure("BAPICHARACTDESCR",
							typeOfBAPICHARACTDESCR,
							ENTRIES(typeOfBAPICHARACTDESCR),
							&handleOfBAPICHARACTDESCR);

 if (RfcRc3 != RFC_OK) rfc_error("RfcInstallStructure"); }

if (handleOfBAPICHARACTREFERENCES==0) {
							RfcRc3 = RfcInstallStructure("BAPICHARACTREFERENCES",
							typeOfBAPICHARACTREFERENCES,
							ENTRIES(typeOfBAPICHARACTREFERENCES),
							&handleOfBAPICHARACTREFERENCES);

 if (RfcRc3 != RFC_OK) rfc_error("RfcInstallStructure"); }

if (handleOfBAPICHARACTRESTRICTIONS==0) {
							RfcRc3 = RfcInstallStructure("BAPICHARACTRESTRICTIONS",
							typeOfBAPICHARACTRESTRICTIONS,
							ENTRIES(typeOfBAPICHARACTRESTRICTIONS),
							&handleOfBAPICHARACTRESTRICTIONS);

 if (RfcRc3 != RFC_OK) rfc_error("RfcInstallStructure"); }

if (handleOfBAPICHARACTVALUESCHAR==0) {
							RfcRc3 = RfcInstallStructure("BAPICHARACTVALUESCHAR",
							typeOfBAPICHARACTVALUESCHAR,
							ENTRIES(typeOfBAPICHARACTVALUESCHAR),
							&handleOfBAPICHARACTVALUESCHAR);

 if (RfcRc3 != RFC_OK) rfc_error("RfcInstallStructure"); }

if (handleOfBAPICHARACTVALUESCURR==0) {
							RfcRc3 = RfcInstallStructure("BAPICHARACTVALUESCURR",
							typeOfBAPICHARACTVALUESCURR,
							ENTRIES(typeOfBAPICHARACTVALUESCURR),
							&handleOfBAPICHARACTVALUESCURR);

 if (RfcRc3 != RFC_OK) rfc_error("RfcInstallStructure"); }

if (handleOfBAPICHARACTVALUESDESCR==0) {
							RfcRc3 = RfcInstallStructure("BAPICHARACTVALUESDESCR",
							typeOfBAPICHARACTVALUESDESCR,
							ENTRIES(typeOfBAPICHARACTVALUESDESCR),
							&handleOfBAPICHARACTVALUESDESCR);

 if (RfcRc3 != RFC_OK) rfc_error("RfcInstallStructure"); }

if (handleOfBAPICHARACTVALUESNUM==0) {
							RfcRc3 = RfcInstallStructure("BAPICHARACTVALUESNUM",
							typeOfBAPICHARACTVALUESNUM,
							ENTRIES(typeOfBAPICHARACTVALUESNUM),
							&handleOfBAPICHARACTVALUESNUM);

 if (RfcRc3 != RFC_OK) rfc_error("RfcInstallStructure"); }

if (handleOfBAPIRET2==0) {
							RfcRc3 = RfcInstallStructure("BAPIRET2",
							typeOfBAPIRET2,
							ENTRIES(typeOfBAPIRET2),
							&handleOfBAPIRET2);

 if (RfcRc3 != RFC_OK) rfc_error("RfcInstallStructure"); }*/

/* define export params */

/*Exporting[0].name="CHARACTNAME";
Exporting[0].nlen=11;
Exporting[0].type=TYPC;
Exporting[0].leng=sizeof(BAPICHARACTKEY_CHARACTNAME);
Exporting[0].addr=echaractname;

Exporting[1].name="KEYDATE";
Exporting[1].nlen=7;
Exporting[1].type=TYPDATE;
Exporting[1].leng=sizeof(BAPICHARACTKEY_KEYDATE);
Exporting[1].addr=ekeydate;*/

Exporting[0].name = "CHARACTNAME";
Exporting[0].nlen = 11;
Exporting[0].type = handleOfBAPICHARACTKEY_CHARACTNAME;
Exporting[0].leng = sizeof(BAPICHARACTKEY_CHARACTNAME);
Exporting[0].addr = eBAPICHARACTKEY_CHARACTNAME;


Exporting[1].name = "KEYDATE";
Exporting[1].nlen = 7;
Exporting[1].type = handleOfBAPICHARACTKEY_KEYDATE;
Exporting[1].leng = sizeof(BAPICHARACTKEY_KEYDATE);
Exporting[1].addr = eBAPICHARACTKEY_KEYDATE;


Exporting[2].name="LANGUAGE";
Exporting[2].nlen=8;
Exporting[2].type=TYPC;
Exporting[2].leng=sizeof(BAPIFIELDSCACL_BAPILANGUA);
Exporting[2].addr=elanguage;

Exporting[3].name=NULL;


/* define internal tables */

Tables[0].name="CHARACTDESCR";
Tables[0].nlen=12;
Tables[0].type=handleOfBAPICHARACTDESCR;
Tables[0].ithandle=thcharactdescr;

Tables[1].name="CHARACTREFERENCES";
Tables[1].nlen=17;
Tables[1].type=handleOfBAPICHARACTREFERENCES;
Tables[1].ithandle=thcharactreferences;

Tables[2].name="CHARACTRESTRICTIONS";
Tables[2].nlen=19;
Tables[2].type=handleOfBAPICHARACTRESTRICTIONS;
Tables[2].ithandle=thcharactrestrictions;

Tables[3].name="CHARACTVALUESCHAR";
Tables[3].nlen=17;
Tables[3].type=handleOfBAPICHARACTVALUESCHAR;
Tables[3].ithandle=thcharactvalueschar;

Tables[4].name="CHARACTVALUESCURR";
Tables[4].nlen=17;
Tables[4].type=handleOfBAPICHARACTVALUESCURR;
Tables[4].ithandle=thcharactvaluescurr;

Tables[5].name="CHARACTVALUESDESCR";
Tables[5].nlen=18;
Tables[5].type=handleOfBAPICHARACTVALUESDESCR;
Tables[5].ithandle=thcharactvaluesdescr;

Tables[6].name="CHARACTVALUESNUM";
Tables[6].nlen=16;
Tables[6].type=handleOfBAPICHARACTVALUESNUM;
Tables[6].ithandle=thcharactvaluesnum;

Tables[7].name="RETURN";
Tables[7].nlen=6;
Tables[7].type=handleOfBAPIRET2;
Tables[7].ithandle=threturn;

Tables[8].name=NULL;


/* call function module */

RfcRc3 = RfcCall(hRfc3,"BAPI_CHARACT_GETDETAIL",Exporting,Tables);

switch (RfcRc3) {

 case RFC_OK :

/* define import params */

Importing[0].name="CHARACTDETAIL";
Importing[0].nlen=13;
Importing[0].type=handleOfBAPICHARACTDETAIL;
Importing[0].leng=sizeof(BAPICHARACTDETAIL);
Importing[0].addr=icharactdetail;

Importing[1].name=NULL;


RfcRc3 = RfcReceive(hRfc3,Importing,Tables,&RfcException);

switch (RfcRc3) {
case RFC_SYS_EXCEPTION : strcpy(xException,RfcException);
case RFC_EXCEPTION : strcpy(xException,RfcException); }
}
return RfcRc3;
}

int cl_bapi_charact_getdetail ( char* OptfmlyName, char **SapCharVal, char **SapCharValDesc )
{
/* RFC variables */
 static RFC_RC RfcRc3;
 RFC_HANDLE hRfc3;
 char s[1024];
int iVal_Count = 0;
/* param variables */
	//BAPICHARACTKEY_KEYDATE KEYDATE
	//BAPICHARACTKEY_CHARACTNAME CHARACTNAME
											
	BAPICHARACTKEY_CHARACTNAME eBAPICHARACTKEY_CHARACTNAME;
	BAPICHARACTKEY_KEYDATE eBAPICHARACTKEY_KEYDATE;
	BAPIFIELDSCACL_BAPILANGUA elanguage;
	//BAPICHARACTDETAIL echaractdetail;
	BAPICHARACTDETAIL icharactdetail;
	ITAB_H thcharactdescr = ITAB_NULL;
	ITAB_H thcharactreferences = ITAB_NULL;
	ITAB_H thcharactrestrictions = ITAB_NULL;
	ITAB_H thcharactvalueschar = ITAB_NULL;
	ITAB_H thcharactvaluescurr = ITAB_NULL;
	ITAB_H thcharactvaluesdescr = ITAB_NULL;
	ITAB_H thcharactvaluesnum = ITAB_NULL;
	ITAB_H thBAPIRET2 = ITAB_NULL;
 char xException[256];
 char x[276];


/* table row variables */

	BAPICHARACTDESCR *tcharactdescr;
	BAPICHARACTREFERENCES *tcharactreferences;
	BAPICHARACTRESTRICTIONS *tcharactrestrictions;
	BAPICHARACTVALUESCHAR *tcharactvalueschar;
	BAPICHARACTVALUESCURR *tcharactvaluescurr;
	BAPICHARACTVALUESDESCR *tcharactvaluesdescr;
	BAPICHARACTVALUESNUM *tcharactvaluesnum;
	BAPIRET2 *tBAPIRET2;
 unsigned crow;
 char t;
	char sTodaysDate[9] = { 0 };
	fsuccess = fopen("test1.txt","a");
   getTodayDateCal(sTodaysDate);
   printf("\nsTodaysDate:%s",sTodaysDate);
/* init export parameters */


  SETCHAR(eBAPICHARACTKEY_CHARACTNAME.CHARACTNAME,OptfmlyName);
  SETDATE(eBAPICHARACTKEY_KEYDATE.KEYDATE,sTodaysDate);
  SETCHAR(elanguage,"EN");
 
/* init internal tables */

if (thcharactdescr==ITAB_NULL) {
thcharactdescr= ItCreate("CHARACTDESCR",sizeof( BAPICHARACTDESCR),0,0);
if (thcharactdescr==ITAB_NULL) rfc_error("ItCreate CHARACTDESCR");}
else {
if (ItFree(thcharactdescr)!=0); rfc_error("ItFree CHARACTDESCR");}

/*tcharactdescr = ItAppLine(thcharactdescr);

  SETCHAR(tcharactdescr->LANGUAGE_INT,"");
  SETCHAR(tcharactdescr->LANGUAGE_ISO,"");
  SETCHAR(tcharactdescr->DESCRIPTION,"");
  SETCHAR(tcharactdescr->HEADER1,"");
  SETCHAR(tcharactdescr->HEADER2,"");*/

if (thcharactreferences==ITAB_NULL) {
thcharactreferences= ItCreate("CHARACTREFERENCES",sizeof( BAPICHARACTREFERENCES),0,0);
if (thcharactreferences==ITAB_NULL) rfc_error("ItCreate CHARACTREFERENCES");}
else {
if (ItFree(thcharactreferences)!=0); rfc_error("ItFree CHARACTREFERENCES");}

/*tcharactreferences = ItAppLine(thcharactreferences);

  SETCHAR(tcharactreferences->REFERENCE_TABLE,"");
  SETCHAR(tcharactreferences->REFERENCE_FIELD,"");*/

if (thcharactrestrictions==ITAB_NULL) {
thcharactrestrictions= ItCreate("CHARACTRESTRICTIONS",sizeof( BAPICHARACTRESTRICTIONS),0,0);
if (thcharactrestrictions==ITAB_NULL) rfc_error("ItCreate CHARACTRESTRICTIONS");}
else {
if (ItFree(thcharactrestrictions)!=0); rfc_error("ItFree CHARACTRESTRICTIONS");}

/*tcharactrestrictions = ItAppLine(thcharactrestrictions);

  SETCHAR(tcharactrestrictions->CLASS_TYPE,"");*/

if (thcharactvalueschar==ITAB_NULL) {
thcharactvalueschar= ItCreate("CHARACTVALUESCHAR",sizeof( BAPICHARACTVALUESCHAR),0,0);
if (thcharactvalueschar==ITAB_NULL) rfc_error("ItCreate CHARACTVALUESCHAR");}
else {
if (ItFree(thcharactvalueschar)!=0); rfc_error("ItFree CHARACTVALUESCHAR");}

/*tcharactvalueschar = ItAppLine(thcharactvalueschar);

  SETCHAR(tcharactvalueschar->VALUE_CHAR,"");
  SETCHAR(tcharactvalueschar->VALUE_CHAR_HIGH,"");
  SETCHAR(tcharactvalueschar->DEFAULT_VALUE,"");
  SETCHAR(tcharactvalueschar->DOCUMENT_NO,"");
  SETCHAR(tcharactvalueschar->DOCUMENT_TYPE,"");
  SETCHAR(tcharactvalueschar->DOCUMENT_PART,"");
  SETCHAR(tcharactvalueschar->DOCUMENT_VERSION,"");*/

if (thcharactvaluescurr==ITAB_NULL) {
thcharactvaluescurr= ItCreate("CHARACTVALUESCURR",sizeof( BAPICHARACTVALUESCURR),0,0);
if (thcharactvaluescurr==ITAB_NULL) rfc_error("ItCreate CHARACTVALUESCURR");}
else {
if (ItFree(thcharactvaluescurr)!=0); rfc_error("ItFree CHARACTVALUESCURR");}

/*tcharactvaluescurr = ItAppLine(thcharactvaluescurr);

  SETFLOAT(tcharactvaluescurr->VALUE_FROM,"");
  SETFLOAT(tcharactvaluescurr->VALUE_TO,"");
  SETCHAR(tcharactvaluescurr->VALUE_RELATION,"");
  SETCHAR(tcharactvaluescurr->CURRENCY_FROM,"");
  SETCHAR(tcharactvaluescurr->CURRENCY_TO,"");
  SETCHAR(tcharactvaluescurr->CURRENCY_FROM_ISO,"");
  SETCHAR(tcharactvaluescurr->CURRENCY_TO_ISO,"");
  SETCHAR(tcharactvaluescurr->DEFAULT_VALUE,"");
  SETCHAR(tcharactvaluescurr->DOCUMENT_NO,"");
  SETCHAR(tcharactvaluescurr->DOCUMENT_TYPE,"");
  SETCHAR(tcharactvaluescurr->DOCUMENT_PART,"");
  SETCHAR(tcharactvaluescurr->DOCUMENT_VERSION,"");*/

if (thcharactvaluesdescr==ITAB_NULL) {
thcharactvaluesdescr= ItCreate("CHARACTVALUESDESCR",sizeof( BAPICHARACTVALUESDESCR),0,0);
if (thcharactvaluesdescr==ITAB_NULL) rfc_error("ItCreate CHARACTVALUESDESCR");}
else {
if (ItFree(thcharactvaluesdescr)!=0); rfc_error("ItFree CHARACTVALUESDESCR");}

/*tcharactvaluesdescr = ItAppLine(thcharactvaluesdescr);

  SETCHAR(tcharactvaluesdescr->LANGUAGE_INT,"");
  SETCHAR(tcharactvaluesdescr->LANGUAGE_ISO,"");
  SETCHAR(tcharactvaluesdescr->VALUE_CHAR,"");
  SETCHAR(tcharactvaluesdescr->DESCRIPTION,"");*/

if (thcharactvaluesnum==ITAB_NULL) {
thcharactvaluesnum= ItCreate("CHARACTVALUESNUM",sizeof( BAPICHARACTVALUESNUM),0,0);
if (thcharactvaluesnum==ITAB_NULL) rfc_error("ItCreate CHARACTVALUESNUM");}
else {
if (ItFree(thcharactvaluesnum)!=0); rfc_error("ItFree CHARACTVALUESNUM");}

/*tcharactvaluesnum = ItAppLine(thcharactvaluesnum);

  SETFLOAT(tcharactvaluesnum->VALUE_FROM,"");
  SETFLOAT(tcharactvaluesnum->VALUE_TO,"");
  SETCHAR(tcharactvaluesnum->VALUE_RELATION,"");
  SETCHAR(tcharactvaluesnum->UNIT_FROM,"");
  SETCHAR(tcharactvaluesnum->UNIT_TO,"");
  SETCHAR(tcharactvaluesnum->UNIT_FROM_ISO,"");
  SETCHAR(tcharactvaluesnum->UNIT_TO_ISO,"");
  SETCHAR(tcharactvaluesnum->DEFAULT_VALUE,"");
  SETCHAR(tcharactvaluesnum->DOCUMENT_NO,"");
  SETCHAR(tcharactvaluesnum->DOCUMENT_TYPE,"");
  SETCHAR(tcharactvaluesnum->DOCUMENT_PART,"");
  SETCHAR(tcharactvaluesnum->DOCUMENT_VERSION,"");*/

if (thBAPIRET2==ITAB_NULL) {
thBAPIRET2= ItCreate("RETURN",sizeof( BAPIRET2),0,0);
if (thBAPIRET2==ITAB_NULL) rfc_error("ItCreate RETURN");}
else {
if (ItFree(thBAPIRET2)!=0); rfc_error("ItFree RETURN");}

/*tBAPIRET2 = ItAppLine(thBAPIRET2);

  SETCHAR(tBAPIRET2->TYPE,"");
  SETCHAR(tBAPIRET2->ID,"");
  SETCHAR(tBAPIRET2->NUMBER,"");
  SETCHAR(tBAPIRET2->MESSAGE,"");
  SETCHAR(tBAPIRET2->LOG_NO,"");
  SETCHAR(tBAPIRET2->LOG_MSG_NO,"");
  SETCHAR(tBAPIRET2->MESSAGE_V1,"");
  SETCHAR(tBAPIRET2->MESSAGE_V2,"");
  SETCHAR(tBAPIRET2->MESSAGE_V3,"");
  SETCHAR(tBAPIRET2->MESSAGE_V4,"");
  SETCHAR(tBAPIRET2->PARAMETER,"");
  SETINT2(&tBAPIRET2->ROW,"");
  SETCHAR(tBAPIRET2->FIELD,"");
  SETCHAR(tBAPIRET2->SYSTEM,"");*/

/* call function module */

hRfc3 = BapiLogon();

	

RfcRc3 = bapi_charact_getdetail(hRfc3 	
								,&eBAPICHARACTKEY_CHARACTNAME
								,&eBAPICHARACTKEY_KEYDATE
								,&elanguage
								,&icharactdetail
								,thcharactdescr
								,thcharactreferences
								,thcharactrestrictions
								,thcharactvalueschar
								,thcharactvaluescurr
								,thcharactvaluesdescr
								,thcharactvaluesnum
								,thBAPIRET2
							,xException);
switch (RfcRc3) 
{

	case RFC_OK :

		/* define import params */

		GETCHAR(icharactdetail.CHARACT_NAME,s);	F_OUTK("CHARACT_NAME",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.DATA_TYPE,s); F_OUTK("DATA_TYPE",10,30,s);fflush(stdout);
		GETNUM(icharactdetail.LENGTH,s); F_OUTK("LENGTH",10,30,s);fflush(stdout);
		GETNUM(icharactdetail.DECIMALS,s);F_OUTK("DECIMALS",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.CASE_SENSITIV,s);F_OUTK("CASE_SENSITIV",10,30,s);fflush(stdout);
		GETNUM(icharactdetail.EXPONENT_TYPE,s);F_OUTK("EXPONENT_TYPE",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.EXPONENT,s);F_OUTK("EXPONENT",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.TEMPLATE,s);F_OUTK("TEMPLATE",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.WITH_SIGN,s);F_OUTK("WITH_SIGN",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.UNIT_OF_MEASUREMENT,s);F_OUTK("UNIT_OF_MEASUREMENT",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.UNIT_OF_MEASUREMENT_ISO,s);F_OUTK("UNIT_OF_MEASUREMENT_ISO",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.CURRENCY,s);F_OUTK("CURRENCY",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.CURRENCY_ISO,s);F_OUTK("CURRENCY_ISO",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.STATUS,s);F_OUTK("STATUS",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.CHARACT_GROUP,s);F_OUTK("CHARACT_GROUP",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.VALUE_ASSIGNMENT,s);F_OUTK("VALUE_ASSIGNMENT",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.NO_ENTRY,s);F_OUTK("NO_ENTRY",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.NO_DISPLAY,s);F_OUTK("NO_DISPLAY",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.ENTRY_REQUIRED,s);F_OUTK("ENTRY_REQUIRED",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.INTERVAL_ALLOWED,s);F_OUTK("INTERVAL_ALLOWED",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.SHOW_TEMPLATE,s);F_OUTK("SHOW_TEMPLATE",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.DISPLAY_VALUES,s);F_OUTK("DISPLAY_VALUES",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.ADDITIONAL_VALUES,s);F_OUTK("ADDITIONAL_VALUES",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.DOCUMENT_NO,s);F_OUTK("DOCUMENT_NO",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.DOCUMENT_TYPE,s);F_OUTK("DOCUMENT_TYPE",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.DOCUMENT_PART,s);F_OUTK("DOCUMENT_PART",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.DOCUMENT_VERSION,s);F_OUTK("DOCUMENT_VERSION",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.CHECK_TABLE,s);F_OUTK("CHECK_TABLE",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.CHECK_FUNCTION,s);F_OUTK("CHECK_FUNCTION",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.PLANT,s);F_OUTK("PLANT",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.SELECTED_SET,s);F_OUTK("SELECTED_SET",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.ADT_CLASS,s);F_OUTK("ADT_CLASS",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.ADT_CLASS_TYPE,s);F_OUTK("ADT_CLASS_TYPE",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.AGGREGATING,s);F_OUTK("AGGREGATING",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.BALANCING,s);F_OUTK("BALANCING",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.INPUT_REQUESTED_CONF,s);F_OUTK("INPUT_REQUESTED_CONF",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.AUTHORITY_GROUP,s);F_OUTK("AUTHORITY_GROUP",10,30,s);fflush(stdout);
		GETCHAR(icharactdetail.UNFORMATED,s);F_OUTK("UNFORMATED",10,30,s);fflush(stdout);

		printf("ItFill(thBAPICHARACTVALUESDESCR):%d\n",ItFill(thcharactvaluesdescr));

		iVal_Count = ItFill(thcharactvaluesdescr);

		for (crow = 1;crow <= ItFill(thcharactvaluesdescr); crow++)
		{
			tcharactvaluesdescr = ItGetLine(thcharactvaluesdescr,crow);
			if (tcharactvaluesdescr == NULL)
				printf("ItGetLineCHARACTVALUESDESCR");

			GETCHAR(tcharactvaluesdescr->LANGUAGE_INT,s);F_OUTK("LANGUAGE_INT",10,30,s);
			GETCHAR(tcharactvaluesdescr->LANGUAGE_ISO,s);F_OUTK("LANGUAGE_ISO",10,30,s);
			GETCHAR(tcharactvaluesdescr->VALUE_CHAR,s);F_OUTK("VALUE_CHAR",10,30,s);
			GETCHAR(tcharactvaluesdescr->DESCRIPTION,s);F_OUTK("DESCRIPTION",10,30,s);
			
			//val
			SapCharVal[crow - 1] = (char *) malloc ( 30 * sizeof ( char ) ) ;
			GETCHAR(tcharactvaluesdescr->VALUE_CHAR,SapCharVal[crow - 1]);
			SapCharVal[crow - 1] = stripBlanks(SapCharVal[crow - 1]);
			printf("\nSapCharVal[crow - 1]:%s",SapCharVal[crow - 1]);

			//val desc
			SapCharValDesc[crow - 1] = (char *) malloc ( 30 * sizeof ( char ) ) ;
			GETCHAR(tcharactvaluesdescr->DESCRIPTION,SapCharValDesc[crow - 1]);
			SapCharValDesc[crow - 1] = stripBlanks(SapCharValDesc[crow - 1]);
			printf("\nSapCharValDesc[crow - 1]:%s",SapCharValDesc[crow - 1]);



			

			//GETCHAR(tBAPIRET2->LOG_NO,s);F_OUTK("RETURN",10,30,s);
			//GETNUM(tBAPIRET2->LOG_MSG_NO,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->MESSAGE_V1,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->MESSAGE_V2,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->MESSAGE_V3,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->MESSAGE_V4,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->PARAMETER,s);F_OUTK("RETURN",10,30,s);
			//GETINT(tBAPIRET2->ROW,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->FIELD,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->SYSTEM,s);F_OUTK("RETURN",10,30,s);

		}

		printf("ItFill(thBAPIRET2):%d\n",ItFill(thBAPIRET2));

		for (crow = 1;crow <= ItFill(thBAPIRET2); crow++)
		{
			tBAPIRET2 = ItGetLine(thBAPIRET2,crow);
			if (tBAPIRET2 == NULL)
				printf("ItGetLineRETURN");

			GETCHAR(tBAPIRET2->TYPE,s);F_OUTK("TYPE",10,30,s);
			GETCHAR(tBAPIRET2->ID,s);F_OUTK("ID",10,30,s);
			GETNUM(tBAPIRET2->NUMBER,s);F_OUTK("NUMBER",10,30,s);
			GETCHAR(tBAPIRET2->MESSAGE,s);F_OUTK("MESSAGE",10,30,s);

			//printf("\nGetCHAR details OptfmlyName:%s,OptfmlyDesc:%s,Message:%s",OptfmlyName,OptfmlyDesc,s);
			//GETCHAR(tBAPIRET2->LOG_NO,s);F_OUTK("RETURN",10,30,s);
			//GETNUM(tBAPIRET2->LOG_MSG_NO,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->MESSAGE_V1,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->MESSAGE_V2,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->MESSAGE_V3,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->MESSAGE_V4,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->PARAMETER,s);F_OUTK("RETURN",10,30,s);
			//GETINT(tBAPIRET2->ROW,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->FIELD,s);F_OUTK("RETURN",10,30,s);
			//GETCHAR(tBAPIRET2->SYSTEM,s);F_OUTK("RETURN",10,30,s);
		}
	break;
	case RFC_EXCEPTION :   
		sprintf(x,"%s raised.",xException);
		printf("%s",x);
		rfc_error("RFC_EXCEPTION");
	case RFC_SYS_EXCEPTION : 
		rfc_error("RFC_SYS_EXCEPTION");

	case RFC_FAILURE : 
		rfc_error("failure");

	default : 
		rfc_error("other failure");
}
if (ItDelete(thcharactdescr)!=0)
rfc_error("ItDelete (BAPICHARACTDESCR)");
if (ItDelete(thcharactreferences)!=0)
rfc_error("ItDelete (BAPICHARACTREFERENCES)");
if (ItDelete(thcharactrestrictions)!=0)
rfc_error("ItDelete (BAPICHARACTRESTRICTIONS)");
if (ItDelete(thcharactvalueschar)!=0)
rfc_error("ItDelete (BAPICHARACTVALUESCHAR)");
if (ItDelete(thcharactvaluescurr)!=0)
rfc_error("ItDelete (BAPICHARACTVALUESCURR)");
if (ItDelete(thcharactvaluesdescr)!=0)
rfc_error("ItDelete (BAPICHARACTVALUESDESCR)");
if (ItDelete(thcharactvaluesnum)!=0)
rfc_error("ItDelete (BAPICHARACTVALUESNUM)");
if (ItDelete(thBAPIRET2)!=0)
rfc_error("ItDelete (BAPIRET2)");
fclose(fsuccess);
RfcClose(hRfc3);
printf("\nRfcClose bapi_charact_getdetail");
return iVal_Count;
}
