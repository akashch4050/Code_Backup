/*

*/
#define TE_MAXLINELEN  128

#define _CLMAIN_DEFNS

#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>
#include <user_exits/user_exits.h>
//#include <librfc.a>
//#include <ProdSap_functions.a>
//#include "VrCre.h"
#include "wmhelpe.h"
#include "ppe.h"
#include "bapi.h"
#include "time.h"
#include "BOMRule.h"
#include <pie/pie.h>

char *iSapServer = NULL;
static RFC_RC RfcRc;
struct node *start=NULL;
char *sr_no=NULL;
char *o1Context_VariantRule=NULL;
char *o2Context_VariantRule=NULL;
char *ostr=NULL;
char *ostr1=NULL;

//RFC_RC RfcRc;
static RFC_HANDLE hRfc;
char bomnum1[1024] = { 0 };
static char sap_proc_type[2] = {0};
static char sap_spproc_type[3] = {0};
static char SAPpstat[15] = {0};
static char MRPpstat[15] = {0};
static char pstat;
static char pstat_mrp;
static char pstat_acc;

char fsuccess_name[2000];

FILE * fsuccess;
void cll_ccap_ecn_create(char dmlno[13]);
RFC_HANDLE BapiLogon(void);
void my_free(struct node* start);
void rfc_error(char *operation);
#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))

char* subString(char* mainStringf ,int fromCharf ,int toCharf);
void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str);

struct node* createnode(char sr_no[5],char *part,float* qty,char uq[4],char *formula,char *Potx1);
void cll_CSAP_MAT_BOM_OPEN(struct node *head,char *assy_noDup , char *SapChangeNo,char *plantcode);
RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException);
int GetCSPstat(char cMaterial[50],char* plantcode);

void cll_CSAP_BOM_ITEM_MAINTAIN(struct node *head,char *assy_noDup,char* plantcode);
RFC_RC  cad_create_bom_with_sub_items(RFC_HANDLE hRfc, DRAW_LOEDK *eIAutoPosnr, CAD_BICSK *eIBomHeader, CAD_BICSK *iEBomHeader, MESSAGE_MSGTX *iEMessage, CAD_RETURN_MESSAGE_LEN *iEMessageLen, CAD_RETURN_VALUE *iEReturn, ITAB_H thBomItem, char *xException);

void cll_CSAP_MAT_BOM_CLOSE();

struct node
{
	char sr_no[5];
	char *part;
	float qty;
	char uq[4];
	char *formula;
	char* Potx1;
	struct node *next;
};

char * mod_trim(char * s) {
    int l = strlen(s);

    while(isspace(s[l - 1])) --l;
    while(* s && isspace(* s)) ++s, --l;

    return strndup(s, l);
}

void rfc_error(char *operation)
{
	#ifdef SAPonNT
	char s[16];
	#endif
	RFC_ERROR_INFO RfcErrorInfo;

	printf("\noperation/code:%s",operation);fflush(stdout);
	memset(&RfcErrorInfo,0,sizeof(RfcErrorInfo));
	RfcLastError(&RfcErrorInfo);
	printf("\nkey: %s",RfcErrorInfo.key);fflush(stdout);
	//OUTS("KEY",10,30,RfcErrorInfo.key);
	printf("\nstatus: %s",RfcErrorInfo.status);fflush(stdout);
	//OUTS("STATUS",10,30,RfcErrorInfo.status);
	printf("\nmessage: %s",RfcErrorInfo.message);fflush(stdout);
	//OUTS("MESSAGE",10,30,RfcErrorInfo.message);
	printf("\ninternal status: %s",RfcErrorInfo.intstat);fflush(stdout);
	//OUTS("INTSTAT",10,30,RfcErrorInfo.intstat);
	RfcClose (RFC_HANDLE_NULL);
	exit(1);
}

void my_free(struct node* start)
{
	struct node* prev;
	struct node* ptr;
	printf("\nErazing Linklist Started...\n");
	for(prev = start, ptr = start; ptr != NULL, prev = ptr; ptr = ptr->next)
	{
		printf("#");
		free(prev);
	}
	start = NULL;
	printf("\nErazing Linklist Completed.\n");
}
void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %s",len,text,str);fflush(stdout);
  //if (stdout!=NULL) fprintf(stdout,"=%s\n>%s\n",text,str);
  return;
}

void OUTI(const char *text,const unsigned pos,const unsigned len,int str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %d",len,text,str);fflush(stdout);
  //if (stdout!=NULL) fprintf(stdout,"=%s\n>%s\n",text,str);
  return;
}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

FILE* fp=NULL;
#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))

void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("%*.0s",pos,text);fflush(stdout); printf("%-*s : %s\n",len,text,str);fflush(stdout);
  return;
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    //fprintf( stderr, "Error(PrintErrorStack): \n");
    printf( "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
        printf( "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

char *replaceWord(const char *s, const char *oldW,
                                 const char *newW)
{
    char *result;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);

    // Counting the number of times old word
    // occur in the string
    for (i = 0; s[i] != '\0'; i++)
    {
        if (strstr(&s[i], oldW) == &s[i])
        {
            cnt++;

            // Jumping to index after the old word.
            i += oldWlen - 1;
        }
    }

    // Making new string of enough length
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;
    while (*s)
    {
        // compare the substring with the result
        if (strstr(s, oldW) == s)
        {
            strcpy(&result[i], newW);
            i += newWlen;
            s += oldWlen;
        }
        else
            result[i++] = *s++;
    }

    result[i] = '\0';
    return result;
}
static tag_t ask_item_revision_from_bom_line(tag_t bom_line)
{
    tag_t item_revision = NULLTAG;
    char *item_id = NULL, *rev_id = NULL;

    ITK_CALL(AOM_ask_value_string(bom_line, "bl_item_item_id", &item_id ));
    ITK_CALL(AOM_ask_value_string(bom_line, "bl_rev_item_revision_id", &rev_id));
    ITK_CALL(ITEM_find_rev(item_id, rev_id, &item_revision));

    if (item_id) MEM_free(item_id);
    if (rev_id) MEM_free(rev_id);
    return item_revision;
}
RFC_RC cad_display_bom_with_sub_items(RFC_HANDLE hRfc,RC29L_STLAL *eIBomAlternative,RC29L_STLAN *eIBomType,RC29L_AENNR *eIChangeNumber,DRAW_LOEDK *eIDisplayFlag,RC29L_MATNR *eIMaterial,RC29L_WERKS *eIPlant,RC29L_REVLV *eIRevisionLevel,BICSK_DATUV *eIValidFrom,CAD_BICSK *iEBomHeader,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_RETURN_VALUE *iEReturn,ITAB_H thBomItem,ITAB_H thBomSubItem,ITAB_H thDmsClassData,ITAB_H thSapFieldData,char *xException)
{


  RFC_PARAMETER Exporting[9];
  RFC_PARAMETER Importing[5];
  RFC_TABLE Tables[5];
  RFC_RC RfcRc;
  char *RfcException = NULL;

  Exporting[0].name = "I_BOM_ALTERNATIVE";
  Exporting[0].nlen = 17;
  Exporting[0].type = TYPC;
  Exporting[0].leng = sizeof(RC29L_STLAL);
  Exporting[0].addr = eIBomAlternative;

  Exporting[1].name = "I_BOM_TYPE";
  Exporting[1].nlen = 10;
  Exporting[1].type = TYPC;
  Exporting[1].leng = sizeof(RC29L_STLAN);
  Exporting[1].addr = eIBomType;

  Exporting[2].name = "I_CHANGE_NUMBER";
  Exporting[2].nlen = 15;
  Exporting[2].type = TYPC;
  Exporting[2].leng = sizeof(RC29L_AENNR);
  Exporting[2].addr = eIChangeNumber;

  Exporting[3].name = "I_DISPLAY_FLAG";
  Exporting[3].nlen = 14;
  Exporting[3].type = TYPC;
  Exporting[3].leng = sizeof(DRAW_LOEDK);
  Exporting[3].addr = eIDisplayFlag;

  Exporting[4].name = "I_MATERIAL";
  Exporting[4].nlen = 10;
  Exporting[4].type = TYPC;
  Exporting[4].leng = sizeof(RC29L_MATNR);
  Exporting[4].addr = eIMaterial;

  Exporting[5].name = "I_PLANT";
  Exporting[5].nlen = 7;
  Exporting[5].type = TYPC;
  Exporting[5].leng = sizeof(RC29L_WERKS);
  Exporting[5].addr = eIPlant;

  Exporting[6].name = "I_REVISION_LEVEL";
  Exporting[6].nlen = 16;
  Exporting[6].type = TYPC;
  Exporting[6].leng = sizeof(RC29L_REVLV);
  Exporting[6].addr = eIRevisionLevel;

  Exporting[7].name = "I_VALID_FROM";
  Exporting[7].nlen = 12;
  Exporting[7].type = TYPC;
  Exporting[7].leng = sizeof(BICSK_DATUV);
  Exporting[7].addr = eIValidFrom;

  Exporting[8].name = NULL;



  Tables[0].name     = "BOM_ITEM";
  Tables[0].nlen     = 8;
  Tables[0].type     = handleOfCAD_BOM_ITEM;
  Tables[0].ithandle = thBomItem;

  Tables[1].name     = "BOM_SUB_ITEM";
  Tables[1].nlen     = 12;
  Tables[1].type     = handleOfCSSUBITEM;
  Tables[1].ithandle = thBomSubItem;

  Tables[2].name     = "DMS_CLASS_DATA";
  Tables[2].nlen     = 14;
  Tables[2].type     = handleOfCLS_CHARAC;
  Tables[2].ithandle = thDmsClassData;

  Tables[3].name     = "SAP_FIELD_DATA";
  Tables[3].nlen     = 14;
  Tables[3].type     = handleOfRFCDMSDATA;
  Tables[3].ithandle = thSapFieldData;

  Tables[4].name = NULL;



  RfcRc = RfcCall(hRfc,"CAD_DISPLAY_BOM_WITH_SUB_ITEMS",Exporting,Tables);


  switch (RfcRc)
  {
    case RFC_OK :



      Importing[0].name = "E_BOM_HEADER";
      Importing[0].nlen = 12;
      Importing[0].type = handleOfCAD_BICSK;
      Importing[0].leng = sizeof(CAD_BICSK);
      Importing[0].addr = iEBomHeader;

      Importing[1].name = "E_MESSAGE";
      Importing[1].nlen = 9;
      Importing[1].type = TYPC;
      Importing[1].leng = sizeof(MESSAGE_MSGTX);
      Importing[1].addr = iEMessage;

      Importing[2].name = "E_MESSAGE_LEN";
      Importing[2].nlen = 13;
      Importing[2].type = TYPC;
      Importing[2].leng = sizeof(CAD_RETURN_MESSAGE_LEN);
      Importing[2].addr = iEMessageLen;

      Importing[3].name = "E_RETURN";

      Importing[3].nlen = 8;
      Importing[3].type = TYPC;
      Importing[3].leng = sizeof(CAD_RETURN_VALUE);
      Importing[3].addr = iEReturn;

      Importing[4].name = NULL;



      RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);


      switch (RfcRc)
      {
        case RFC_SYS_EXCEPTION :
				strcpy(xException,RfcException);
				break;
        case RFC_EXCEPTION :
				strcpy(xException,RfcException);
				break;
       }

		break;
	default :
		printf("Error occured");fflush(stdout);
  }

  return RfcRc;
}
char* Get_LatestSerial_No(char *assy_noDup,char *plantcode)
{
static RFC_RC RfcRc;
//RFC_HANDLE hRfc;
char s[1024];
/*char comp_part_sap[15];*/
char comp_part_sap[15];

char recstring_sap[25000];
char crecstring_sap[25000];


RC29L_STLAL eIBomAlternative;
RC29L_STLAN eIBomType;
RC29L_AENNR eIChangeNumber;
DRAW_LOEDK eIDisplayFlag;
RC29L_MATNR eIMaterial;
RC29L_WERKS eIPlant;
RC29L_REVLV eIRevisionLevel;
BICSK_DATUV eIValidFrom;
CAD_BICSK iEBomHeader;
MESSAGE_MSGTX iEMessage;
CAD_RETURN_MESSAGE_LEN iEMessageLen;
CAD_RETURN_VALUE iEReturn;
ITAB_H thBomItem = ITAB_NULL;
ITAB_H thBomSubItem = ITAB_NULL;
ITAB_H thDmsClassData = ITAB_NULL;
ITAB_H thSapFieldData = ITAB_NULL;
char xException[256];

int i_sap=0;
int j_sap=0;
int k_sap=0;
int m_sap=0;

/* table row variables */
CAD_BOM_ITEM *tBomItem;
unsigned crow;
char t;
/*char plant_code[5]={0};*/
struct node_mis *start_sap = NULL;
struct node_mis *p_sap = NULL;
struct node_mis *q_sap = NULL;

char sr_no[5] = { 0 };
//char ChildPart[19] = { 0 };
char *ChildPart = NULL;
char *ChildPartVal = NULL;
char *Quantity = NULL;
char *QuantityVal = NULL;
char *BomNo = NULL;
char *BomNoVal = NULL;
int iSap_item_no = 0;
int iSap_latest_item_no = 0;
char* sSap_Latest_item_no = NULL;
p_sap = NULL;
q_sap = NULL;


    //printf("\nBOM data received for :%s: ",plantcode);fflush(stdout);
	OUTS("BOM data received for",10,30,plantcode);

    SETCHAR(eIBomAlternative,"01");
    SETCHAR(eIBomType,"1");
    SETCHAR(eIChangeNumber,"");
    SETCHAR(eIDisplayFlag,"X");
    SETCHAR(eIMaterial,assy_noDup);
    SETCHAR(eIPlant,plantcode);
    SETCHAR(eIRevisionLevel,"");
    SETCHAR(eIValidFrom,"");


	hRfc = BapiLogon( );

    if (thBomItem==ITAB_NULL)
	{
      thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
      if (thBomItem==ITAB_NULL)
		  rfc_error("ItCreateBOM_ITEM");
	}
    else
	{
      if (ItFree(thBomItem) != 0)
		  rfc_error("ItFreeBOM_ITEM");
	}
    if (thBomSubItem==ITAB_NULL)
	{
      thBomSubItem = ItCreate("BOM_SUB_ITEM",sizeof(CSSUBITEM),0,0);
      if (thBomSubItem==ITAB_NULL)
		  rfc_error("ItCreateBOM_SUB_ITEM");
	}
    else
	{
      if (ItFree(thBomSubItem) != 0)
		  rfc_error("ItFreeBOM_SUB_ITEM");
	}
    if (thDmsClassData==ITAB_NULL)
	{
      thDmsClassData = ItCreate("DMS_CLASS_DATA",sizeof(CLS_CHARAC),0,0);
      if (thDmsClassData==ITAB_NULL)
		  rfc_error("ItCreateDMS_CLASS_DATA");
	}
    else
	{
      if (ItFree(thDmsClassData) != 0)
		  rfc_error("ItFreeDMS_CLASS_DATA");
	}
    if (thSapFieldData==ITAB_NULL)
	{
      thSapFieldData = ItCreate("SAP_FIELD_DATA",sizeof(RFCDMSDATA),0,0);
      if (thSapFieldData==ITAB_NULL)
		  rfc_error("ItCreateSAP_FIELD_DATA");
	}
    else
	{
      if (ItFree(thSapFieldData) != 0)
		  rfc_error("ItFreeSAP_FIELD_DATA");
	}



      /* call RFC function */
	RfcRc = cad_display_bom_with_sub_items(hRfc,&eIBomAlternative,&eIBomType,&eIChangeNumber,&eIDisplayFlag,&eIMaterial,&eIPlant,&eIRevisionLevel,&eIValidFrom,&iEBomHeader,&iEMessage,&iEMessageLen,&iEReturn,thBomItem,thBomSubItem,thDmsClassData,thSapFieldData,xException);
	switch (RfcRc)
	{

	case RFC_OK :
				sprintf(s,"%d lines",ItFill(thBomItem));
				//printf("\nNo of row fetched :%s:",s); fflush(stdout);
				OUTS("No of row fetched",10,30,s);

				for (crow = 1;crow <= ItFill(thBomItem); crow++)
				{
					tBomItem = ItGetLine(thBomItem,crow);
					if (tBomItem == NULL)
					rfc_error("ItGetLineBOM_ITEM");

					tc_strcpy(sr_no,"");

					/*ChildPart = (char *) MEM_alloc(19 * sizeof(char));
					ChildPartVal = (char *) MEM_alloc(19 * sizeof(char));
					tc_strcpy(ChildPart,"");
					tc_strcpy(ChildPartVal,"");

					Quantity = (char *) MEM_alloc(19 * sizeof(char));
					QuantityVal = (char *) MEM_alloc(19 * sizeof(char));
					tc_strcpy(Quantity,"");
					tc_strcpy(QuantityVal,"");

					BomNo = (char *) MEM_alloc(41 * sizeof(char));
					BomNoVal = (char *) MEM_alloc(41 * sizeof(char));

					tc_strcpy(BomNo,"");
					tc_strcpy(BomNoVal,"");*/

					GETCHAR(tBomItem->Posnr,sr_no);

					iSap_item_no = atoi(sr_no);

					//printf("\niSap_item_no:%d iSap_latest_item_no:[%d]",iSap_item_no,iSap_latest_item_no);

					if ( iSap_latest_item_no < iSap_item_no )
					{
						iSap_latest_item_no = iSap_item_no;
						//printf("\niSap_latest_item_no:%d",iSap_latest_item_no);
					}

					/*GETCHAR(tBomItem->Idnrk,ChildPart);
					ChildPartVal =  (char *)stripBlanks(ChildPart);
					printf("\nChildPartVal:[%s]",ChildPartVal);

					GETCHAR(tBomItem->Menge,Quantity);
					QuantityVal =  (char *)stripBlanks(Quantity);
					printf("\tQuantityVal:[%s]",QuantityVal);

					GETCHAR(tBomItem->Potx1,BomNo);
					BomNoVal =  (char *)stripBlanks(BomNo);
					printf("\tBomNoVal:[%s]",BomNoVal);



					if(p_sap == NULL)
					{
					p_sap = createnode_mis(sr_no,ChildPartVal,QuantityVal,BomNoVal);
					start_sap = p_sap;
					}
					else
					{
					q_sap = start_sap;
					while(q_sap->next != NULL)
					{
					q_sap = q_sap->next;
					}
					q_sap->next = createnode_mis(sr_no,ChildPartVal,QuantityVal,BomNoVal);

					}*/


				}
				sprintf(s,"\nchild parts fetched from sap : %d ",ItFill(thBomItem ));
		        break;
        case RFC_EXCEPTION :
				 rfc_error("RFC_EXCEPTION");
		         break;
        case RFC_SYS_EXCEPTION :
		         rfc_error("system exception raised");
       case RFC_FAILURE :
				 rfc_error("failure");
        default :
				 rfc_error("other failure");
      }
    /* delete tables */
	if (ItDelete(thBomItem) != 0)
      rfc_error("ItDelete BOM_ITEM");
    if (ItDelete(thBomSubItem) != 0)
      rfc_error("ItDelete BOM_SUB_ITEM");
    if (ItDelete(thDmsClassData) != 0)
      rfc_error("ItDelete DMS_CLASS_DATA");
    if (ItDelete(thSapFieldData) != 0)
      rfc_error("ItDelete SAP_FIELD_DATA");
	RfcClose (hRfc);
	if (iSap_latest_item_no == 9999)
	{
		//printf("\nReached max limit of item no in SAP bom");fflush(stdout);
		OUTS("Reached max limit of item no in SAP bom",10,30,"");
		exit(0);
	}
	if (iSap_latest_item_no == 0)	//if no bom then start adding from 1st line
	{
		iSap_latest_item_no = 1;
	}
	else	//add 1 to get latest item no from SAP
	{

		iSap_latest_item_no = iSap_latest_item_no + 1;
	}
	sSap_Latest_item_no = (char *) MEM_alloc( 5 * sizeof(char) );
	sprintf(sSap_Latest_item_no,"%04d",iSap_latest_item_no);
	//printf("\nsSap_Latest_item_no:%s................",sSap_Latest_item_no);fflush(stdout);
	OUTS("sSap_Latest_item_no",10,30,sSap_Latest_item_no);

	return sSap_Latest_item_no;
}


//char* Get_ModuleUidSerial(char *assy_noDup,char *plantcode)
char* Get_ModuleUidSerial(char *assy_noDup,char *ChildNo,char *uid,char *plantcode)
{
static RFC_RC RfcRc;
//RFC_HANDLE hRfc;
char s[1024];
/*char comp_part_sap[15];*/
char comp_part_sap[15];

char recstring_sap[25000];
char crecstring_sap[25000];


RC29L_STLAL eIBomAlternative;
RC29L_STLAN eIBomType;
RC29L_AENNR eIChangeNumber;
DRAW_LOEDK eIDisplayFlag;
RC29L_MATNR eIMaterial;
RC29L_WERKS eIPlant;
RC29L_REVLV eIRevisionLevel;
BICSK_DATUV eIValidFrom;
CAD_BICSK iEBomHeader;
MESSAGE_MSGTX iEMessage;
CAD_RETURN_MESSAGE_LEN iEMessageLen;
CAD_RETURN_VALUE iEReturn;
ITAB_H thBomItem = ITAB_NULL;
ITAB_H thBomSubItem = ITAB_NULL;
ITAB_H thDmsClassData = ITAB_NULL;
ITAB_H thSapFieldData = ITAB_NULL;
char xException[256];

int i_sap=0;
int j_sap=0;
int k_sap=0;
int m_sap=0;

/* table row variables */
CAD_BOM_ITEM *tBomItem;
unsigned crow;
char t;
/*char plant_code[5]={0};*/
struct node_mis *start_sap = NULL;
struct node_mis *p_sap = NULL;
struct node_mis *q_sap = NULL;

char sr_no[5] = { 0 };
char *SapChild = NULL;
//char SapChild[50] = { 0 };
char *SapChild1;
//char SapChild1[50] = { 0 };
//char Line1[50] = { 0 };
char* Line1 = NULL;
char* Line1_1 = NULL;
//char ChildPart[19] = { 0 };
char *ChildPart = NULL;
char *ChildPartVal = NULL;
char *Quantity = NULL;
char *QuantityVal = NULL;
char *BomNo = NULL;
char *BomNoVal = NULL;
int iSap_item_no = 0;
int iSap_latest_item_no = 0;
char* sSap_Latest_item_no = NULL;
p_sap = NULL;
q_sap = NULL;
int i_uid_Found = 0;


    //printf("\nBOM data received for :%s: ",plantcode);fflush(stdout);
	OUTS("Get_ModuleUidSerial BOM data received for",10,30,plantcode);

    SETCHAR(eIBomAlternative,"01");
    SETCHAR(eIBomType,"1");
    SETCHAR(eIChangeNumber,"");
    SETCHAR(eIDisplayFlag,"X");
    SETCHAR(eIMaterial,assy_noDup);
    SETCHAR(eIPlant,plantcode);
    SETCHAR(eIRevisionLevel,"");
    SETCHAR(eIValidFrom,"");


	hRfc = BapiLogon( );

    if (thBomItem==ITAB_NULL)
	{
      thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
      if (thBomItem==ITAB_NULL)
		  rfc_error("ItCreateBOM_ITEM");
	}
    else
	{
      if (ItFree(thBomItem) != 0)
		  rfc_error("ItFreeBOM_ITEM");
	}
    if (thBomSubItem==ITAB_NULL)
	{
      thBomSubItem = ItCreate("BOM_SUB_ITEM",sizeof(CSSUBITEM),0,0);
      if (thBomSubItem==ITAB_NULL)
		  rfc_error("ItCreateBOM_SUB_ITEM");
	}
    else
	{
      if (ItFree(thBomSubItem) != 0)
		  rfc_error("ItFreeBOM_SUB_ITEM");
	}
    if (thDmsClassData==ITAB_NULL)
	{
      thDmsClassData = ItCreate("DMS_CLASS_DATA",sizeof(CLS_CHARAC),0,0);
      if (thDmsClassData==ITAB_NULL)
		  rfc_error("ItCreateDMS_CLASS_DATA");
	}
    else
	{
      if (ItFree(thDmsClassData) != 0)
		  rfc_error("ItFreeDMS_CLASS_DATA");
	}
    if (thSapFieldData==ITAB_NULL)
	{
      thSapFieldData = ItCreate("SAP_FIELD_DATA",sizeof(RFCDMSDATA),0,0);
      if (thSapFieldData==ITAB_NULL)
		  rfc_error("ItCreateSAP_FIELD_DATA");
	}
    else
	{
      if (ItFree(thSapFieldData) != 0)
		  rfc_error("ItFreeSAP_FIELD_DATA");
	}



      /* call RFC function */
	RfcRc = cad_display_bom_with_sub_items(hRfc,&eIBomAlternative,&eIBomType,&eIChangeNumber,&eIDisplayFlag,&eIMaterial,&eIPlant,&eIRevisionLevel,&eIValidFrom,&iEBomHeader,&iEMessage,&iEMessageLen,&iEReturn,thBomItem,thBomSubItem,thDmsClassData,thSapFieldData,xException);
	switch (RfcRc)
	{

	case RFC_OK :
				  sprintf(s,"%d lines",ItFill(thBomItem));
				 // printf("\nNo of row fetched :%s:",s); fflush(stdout);
				 OUTS("No of row fetched",10,30,s);

				  for (crow = 1;crow <= ItFill(thBomItem); crow++)
				  {
					tBomItem = ItGetLine(thBomItem,crow);
					if (tBomItem == NULL)
						rfc_error("ItGetLineBOM_ITEM");

					tc_strcpy(sr_no,"");

					SapChild = (char *) MEM_alloc( 50 * sizeof ( char ) );
					SapChild1 = (char *) MEM_alloc( 50 * sizeof ( char ) );
					tc_strcpy(SapChild,"");
					tc_strcpy(SapChild1,"");


					GETCHAR(tBomItem->Idnrk,SapChild1);
					//SapChild = mod_trim(SapChild1);
					SapChild = stripBlanks(SapChild1);

					//printf("\nSapChild1:[%s] SapChild:[%s] tc_strlen(SapChild):%d ChildNo:[%s]",SapChild1,SapChild,tc_strlen(SapChild),ChildNo);
					//printf("\nSapChild:[%s] tc_strlen(SapChild):%d ChildNo:[%s]",SapChild,tc_strlen(SapChild),ChildNo);
					if ( tc_strcmp(SapChild,ChildNo)==0)
					{
						Line1 = (char *) MEM_alloc( 50 * sizeof ( char ) );
						Line1_1 = (char *) MEM_alloc( 50 * sizeof ( char ) );

						tc_strcpy(Line1,"");
						tc_strcpy(Line1_1,"");

						GETCHAR(tBomItem->Potx1,Line1_1);
						//Line1 = mod_trim(Line1_1);
						Line1 = stripBlanks(Line1_1);

						//printf("\nuid:[%s] Line1:[%s] Line1_1:[%s]",uid,Line1,Line1_1);
						if ( tc_strcmp(uid,Line1)==0)
						{
							GETCHAR(tBomItem->Posnr,sr_no);
							iSap_item_no = atoi(sr_no);
							i_uid_Found = 1;
							printf("\nfound uid:[%s] Line1:[%s] Line1_1:[%s]",uid,Line1,Line1_1);
						}
					}

				  }

				  sprintf(s,"\nchild parts fetched from sap : %d ",ItFill(thBomItem ));

		break;

        case RFC_EXCEPTION :
			         rfc_error("RFC_EXCEPTION");
		break;
        case RFC_SYS_EXCEPTION :
			         rfc_error("SYSTEM EXCEPTION RAISED");
		break;
        case RFC_FAILURE :
					 rfc_error("FAILURE");
		break;
        default :
					 rfc_error("OTHER FAILURE");
		break;
      }
    /* delete tables */
	if (ItDelete(thBomItem) != 0)
      rfc_error("ItDelete BOM_ITEM");
    if (ItDelete(thBomSubItem) != 0)
      rfc_error("ItDelete BOM_SUB_ITEM");
    if (ItDelete(thDmsClassData) != 0)
      rfc_error("ItDelete DMS_CLASS_DATA");
    if (ItDelete(thSapFieldData) != 0)
      rfc_error("ItDelete SAP_FIELD_DATA");
	RfcClose (hRfc);
	if (i_uid_Found == 0 ) //uid and module not found
	{
		if (iSap_latest_item_no == 9999)
		{
			//printf("\nReached max limit of item no in SAP bom");fflush(stdout);
			OUTS("Reached max limit of item no in SAP bom",10,30,"");
			exit(0);
		}
		if (iSap_latest_item_no == 0)	//if no bom then start adding from 1st line
		{
			iSap_latest_item_no = 1;
		}
		else	//add 1 to get latest item no from SAP
		{

			iSap_latest_item_no = iSap_latest_item_no + 1;
		}
		sSap_Latest_item_no = (char *) MEM_alloc( 5 * sizeof(char) );
		sprintf(sSap_Latest_item_no,"%04d",iSap_latest_item_no);
		//printf("\nsSap_Latest_item_no1:%s................",sSap_Latest_item_no);fflush(stdout);
		OUTS("sSap_Latest_item_no1",10,30,sSap_Latest_item_no);

	}
	else	//uid and module found
	{
		sSap_Latest_item_no = (char *) MEM_alloc( 5 * sizeof(char) );
		tc_strcpy(sSap_Latest_item_no,"-001");
		printf("\nsSap_Latest_item_no2:%s................",sSap_Latest_item_no);fflush(stdout);
	}

	return sSap_Latest_item_no;
}
extern int ITK_user_main ( int argc, char ** argv )
{
	int status = ITK_ok;
	char *inputDML = NULL;
	char *inputChldModule = NULL;
	tag_t queryTag = NULLTAG;
	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	int n_entries = 1;
	int n_tags_found = 0;
	int resultCount =0;
	tag_t *outTag = NULLTAG;
	tag_t ErcDmlTag = NULLTAG;
	tag_t StdTaskTag = NULLTAG;
    tag_t objTypeTag=NULLTAG;
	char  type_name[TCTYPE_name_size_c+1];
	char *DmlId = NULL;
	char *DmlIdDup = NULL;
	int DmlId_len = 0;
	char *DmlDesc=NULL;
	char *DmlRelType=NULL;
	char *DmlRelStat=NULL;
	char *dml_numER=NULL;
	date_t DmlRelDate;
	char *DmlRelDateStr=NULL;
	char *DMLDescription=NULL;
	char *erc_release_date=NULL;
	int tskcnt =0;
	tag_t *SetOfDmlTasksTag= NULLTAG;
	int t = 0;
	char *TaskId=NULL;
	int partCnt=0;
	tag_t *SetOfPartTags= NULLTAG;
	int p=0;
	tag_t PartTag= NULLTAG;
	tag_t PartMasterTag = NULLTAG;
	char *PartNum=NULL;
	char *PartNumDup=NULL;
	char *PartRev=NULL;
	char *PartRevDup=NULL;
	char *part_type=NULL;
	char *part_typeDup=NULL;
	char *desc=NULL;
	char *descDup=NULL;
	char *part_noDup=NULL;
	char *partClrInd = NULL;
	char *OwnerName=NULL;
	char *PartRelStat=NULL;
	const char *attrs[2];
	const char *values[2];
	tag_t	*DesignTags	= NULLTAG;
	char *unit=NULL;
	int *levels = 0;
	int n_parents=0;
	tag_t *parents = NULLTAG;
	tag_t parent = NULLTAG;
	char *ParentNum = NULL;
	char *ParentNumDup = NULL;
	char *ArchParentNum = NULL;
	char *ArchParentNumDup = NULL;

	int iParentCnt = 0;
	tag_t ParobjTypeTag=NULLTAG;
	char  Partype_name[TCTYPE_name_size_c+1];
	char* plantcode = NULL;
	char* SapChangeNo = NULL;


	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	inputDML = ITK_ask_cli_argument("-d=");
	inputChldModule = ITK_ask_cli_argument("-m=");
	iSapServer = ITK_ask_cli_argument("-s=");

	sprintf(fsuccess_name,"Task_mod_add_std_%s.log",inputDML);
	fsuccess = fopen(fsuccess_name,"a");


	//if(QRY_find("ERCDMLReleased", &queryTag));
	if(QRY_find("APLTaskRevisionQry", &queryTag));
	if (queryTag)
	{
		//printf("\nFound Query APLTaskRevisionQry  \n");fflush(stdout);
		OUTS("Found Query APLTaskRevisionQry",10,30,"");
	}
	else
	{
		//printf("\nNotFound Query APLTaskRevisionQry");fflush(stdout);
		OUTS("NotFound Query APLTaskRevisionQry",10,30,"");
		return status;
	}

	//printf("\ninputDML:%s", inputDML);fflush(stdout);
	OUTS("inputTask",10,30,inputDML);

	qry_values[0] = inputDML;

	if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));

	printf("\nresultCount :%d", resultCount);fflush(stdout);

	if(resultCount>0)
	{
		StdTaskTag = outTag[0];
		//printf("\nQuery Executed");fflush(stdout);
		OUTS("Query Executed",10,30,"");

		if (StdTaskTag != NULLTAG)
		{
			//printf("\nDML : %s Found With APLTaskRevisionQry Query",inputDML);fflush(stdout);
			OUTS("Task Found With APLTaskRevisionQry Query",10,30,inputDML);
			//fprintf(fsuccess,"\nDML : %s Found With APLTaskRevisionQry Query",inputDML);fflush(stdout);
			if(TCTYPE_ask_object_type(StdTaskTag,&objTypeTag));
			if(TCTYPE_ask_name(objTypeTag,type_name));
			//printf("\nErcDmlTag -> objTypeTag  %s\n", type_name);fflush(stdout);
			OUTS("StdTaskTag -> objTypeTag",10,30,type_name);
			//if(strcmp(type_name,"ChangeRequestRevision")==0)
			if(strcmp(type_name,"T5_APLTaskRevision")==0)
			{
				ITK_CALL(AOM_ask_value_string(StdTaskTag,"item_id",&DmlId));
				DmlId_len = tc_strlen ( DmlId );
				DmlIdDup = ( char * ) MEM_alloc ( DmlId_len * sizeof ( char ) ) ;
				tc_strcpy ( DmlIdDup, "" ) ;
				tc_strcpy ( DmlIdDup, DmlId ) ;
//				ITK_CALL(AOM_ask_value_string(ErcDmlTag,"current_name",&DmlDesc));
//				ITK_CALL(AOM_ask_value_string(ErcDmlTag,"t5_rlstype",&DmlRelType));
//				ITK_CALL(AOM_UIF_ask_value(ErcDmlTag,"release_status_list",&DmlRelStat));
//				ITK_CALL(AOM_ask_value_date(ErcDmlTag,"date_released",&DmlRelDate));
//				ITK_CALL(DATE_date_to_string(DmlRelDate,"%d/%m/%Y",&DmlRelDateStr));
//				printf("\nDmlId [%s]  DmlRelType [%s] LifeCycleState [%s] DmlDesc [%s]\n",DmlId,DmlRelType,DmlRelStat,DmlDesc);	fflush(stdout);
//
//				OUTS("DmlRelDateStr",10,30,DmlRelDateStr);
//				OUTS("DmlRelStat",10,30,DmlRelStat);
//
//				if(tc_strstr(DmlRelStat,"STDSIC Released")==NULL)
//				{
//					printf("\nDML [%s] $$ not STDSIC Released LifeCycleState [%s]\n",DmlId,DmlRelStat); fflush(stdout);
//					//goto CLEANUP;
//					return status;
//				}
//
//				ITK_CALL(AOM_ask_value_tags(ErcDmlTag,"T5_DMLTaskRelation",&tskcnt,&SetOfDmlTasksTag));
//				OUTI("DML Task Count",10,30,tskcnt);

//				if (tskcnt>0)
//				{
					
//					for( t = 0; t < tskcnt; t++ )
//					{
						ITK_CALL(AOM_ask_value_string(StdTaskTag,"item_id",&TaskId));
						OUTS("Starting for",10,30,TaskId);

						AOM_ask_value_tags(StdTaskTag,"CMHasSolutionItem",&partCnt,&SetOfPartTags);//solution item-->first time new module addition
						//AOM_ask_value_tags(StdTaskTag,"T5_ModuleVF_to_Change",&partCnt,&SetOfPartTags);//modules VF relation-->add new occurence
						//printf("\nNo of Design Rev:%d\n",partCnt);
						OUTI("No of Design Rev",10,30,partCnt);
						if ( partCnt > 0)
						{
							//displaying_objects();
							for( p = 0; p < partCnt; p++ )
							{
								PartTag = SetOfPartTags[p];

								if(TCTYPE_ask_object_type(PartTag,&objTypeTag));
								if(TCTYPE_ask_name(objTypeTag,type_name));

								//printf("\nPart Class [%s]",type_name); fflush(stdout);
								OUTS("Part Class",10,30,type_name);

								ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
								tc_strdup(PartNum,&part_noDup);
								OUTS("part_noDup",10,30,part_noDup);

								ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
								tc_strdup(PartRev,&PartRevDup);
								OUTS("PartRevDup",10,30,PartRevDup);

								ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
								tc_strdup(part_type,&part_typeDup);
								OUTS("part_typeDup",10,30,part_typeDup);

								ITK_CALL(AOM_UIF_ask_value(PartTag,"object_desc",&desc));
								tc_strdup(desc,&descDup);
								OUTS("descDup",10,30,descDup);

								ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&partClrInd));
								OUTS("partClrInd",10,30,partClrInd);

								ITK_CALL(AOM_UIF_ask_value(PartTag,"owning_user",&OwnerName));
								OUTS("OwnerName",10,30,OwnerName);

								ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&PartRelStat));
								OUTS("PartRelStat",10,30,PartRelStat);

								//ITK_CALL(ITEM_find_item(PartNum, &PartMasterTag));

								attrs[0] ="item_id";
								attrs[1] ="object_type";
								values[0]= PartNum;
								values[1] = "Design";
								ITK_CALL(ITEM_find_items_by_key_attributes(2,attrs,values,&n_tags_found,&DesignTags));
								//printf("\nITEM_find_items_by_key_attributes for Design output : %d",n_tags_found);
								OUTI("ITEM_find Design",10,30,n_tags_found);
								//printf("\n*.0%s %d",10,"ITEM_find_items_by_key_attributes for Design output :",n_tags_found);
								//fflush(stdout);

								//T5_EE_Part
								if(n_tags_found==0)
								{
									values[1] = "T5_EE_Part";
									ITK_CALL(ITEM_find_items_by_key_attributes(2,attrs,values,&n_tags_found,&DesignTags));
									//printf("\nITEM_find_items_by_key_attributes for T5_EE_Part output : %d",n_tags_found);
									//fflush(stdout);
									OUTI("ITEM_find T5_EE_Part",10,30,n_tags_found);

								}
								if(n_tags_found==0)//T5_ClrPartRevision
								{
									values[1] = "T5_ClrPart";
									ITK_CALL(ITEM_find_items_by_key_attributes(2,attrs,values,&n_tags_found,&DesignTags));
									//printf("\nITEM_find_items_by_key_attributes for T5_ClrPart output : %d",n_tags_found);
									//fflush(stdout);
									OUTI("ITEM_find T5_ClrPart",10,30,n_tags_found);
								}

								PartMasterTag = DesignTags[0];

								if (PartMasterTag != NULLTAG)
								{
									ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"uom_tag",&unit));
									OUTS("uom_tag value",10,30,unit);
								}

								//if(tc_strstr(PartRelStat,"ERC Released")==NULL)
								if(tc_strstr(PartRelStat,"STDSIC Released")==NULL)
								{
									printf("\nPart [%s] ^^ not STDSIC Released LifeCycleState [%s] Skipping...",PartNum,PartRelStat); fflush(stdout);
									continue;
								}

								if(	tc_strcmp(part_typeDup,"D")==0 ||
									tc_strcmp(part_typeDup,"DA")==0 ||
									tc_strcmp(part_typeDup,"DC")==0 ||
									tc_strcmp(part_typeDup,"IFD")==0 ||
									tc_strcmp(part_typeDup,"IM")==0 ||
									tc_strcmp(part_typeDup,"CP")==0)
								{
									printf("\nPart %s Has Type %s AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
									continue;
								}

								//printf("\nPart type:%s",part_typeDup);
								OUTS("part_typeDup",10,30,part_typeDup);

								if ( tc_strcmp(part_typeDup,"M") !=0 )
								{
									printf("\tskipping");
									fflush(stdout);
									continue;
								}
								//Getting where used.
								//printf("\nSkipping parts\n");
								OUTS("Skipping parts",10,30,"\n");
								fflush(stdout);
								//if ( tc_strcmp ( PartNum, "5442T2B0672001ZZ" ) != 0 )
								OUTS(PartNum,10,30,inputChldModule);
								if ( tc_strcmp ( PartNum, inputChldModule ) != 0 )
								{
									printf("#");
									fflush(stdout);
									continue;
								}
								printf("\n");
								fflush(stdout);

								ITK_CALL(PS_where_used_all(PartTag,2,&n_parents,&levels,&parents));
								//printf("\nn_parents:%d",n_parents);
								//printf("\nlevels found:%d",levels);

								OUTI("n_parents",10,30,n_parents);
								//printf("\nlevels found:%d",levels);
								OUTI("levels found",10,30,*levels);

								fflush(stdout);
								//for (n_parents;n_parents<0 ;n_parents++)
								printf("\n");
								for (iParentCnt = 0; iParentCnt < n_parents;iParentCnt++)
								{
									parent = parents[iParentCnt];

									if(TCTYPE_ask_object_type(parent,&ParobjTypeTag));
									if(TCTYPE_ask_name(ParobjTypeTag,Partype_name));
									//OUTS("Parent object type",10,30,Partype_name);

									if (
										( tc_strcmp(Partype_name,"T5_ClrPartRevision") == 0) || ( tc_strcmp(Partype_name,"Design Revision") == 0)
										)
									{
										printf("@");
										continue;
									}
									else if ( tc_strcmp(Partype_name,"T5_ArchModuleRevision") == 0)
									{
										ITK_CALL(AOM_ask_value_string(parent,"item_id",&ArchParentNum));
										tc_strdup(ArchParentNum,&ArchParentNumDup);
										//printf("\nParentNumDup:[%s]",ArchParentNumDup);
										OUTS("ArchParentNumDup\n",10,30,ArchParentNumDup);
										//fflush(stdout);

									}
									else if ( tc_strcmp(Partype_name,"T5_PlatformRevision") == 0)
									{
										ITK_CALL(AOM_ask_value_string(parent,"item_id",&ParentNum));
										tc_strdup(ParentNum,&ParentNumDup);
										//printf("\nParentNumDup:[%s]",ParentNumDup);
										OUTS("ParentNumDup",10,30,ParentNumDup);

										plantcode = (char *) MEM_alloc(5 * sizeof(char));
										tc_strcpy(plantcode ,"1100");

										SapChangeNo = (char *) MEM_alloc( 13 * sizeof ( char ) ) ;
										tc_strcpy ( SapChangeNo, "" ) ;
										tc_strncpy ( SapChangeNo, DmlIdDup, 10) ;
										//tc_strncpy ( SapChangeNo, inputDML, 10) ;
										//tc_strcat ( SapChangeNo, "MT" ) ;
										SapChangeNo[10]='M';
										//SapChangeNo[11]='T';
										SapChangeNo[11]='4';
										SapChangeNo[12]='\0';

										//tc_strcpy(SapChangeNo, "CORRCT0704MT" );

										printf("\nParentNumDup:[%s] ArchParentNumDup:[%s] part_noDup:[%s] plantcode:[%s] SapChangeNo:[%s]",ParentNumDup,ArchParentNumDup,part_noDup,plantcode,SapChangeNo);
										fflush(stdout);
										//printf("\ncall my function Add_Mod_to_PlatForm");
										OUTS("call my function Add_Mod_to_PlatForm",10,30,ParentNumDup);
										fflush(stdout);
										Add_Mod_to_PlatForm(ParentNumDup,ArchParentNumDup,part_noDup,plantcode,SapChangeNo );
										OUTS("after call my function Add_Mod_to_PlatForm",10,30,"");
									}
									else
									{
										OUTS("skipping\n",10,30,"");
										continue;
									}

								}

							}
						}
				//	}
				//}//task id loop
			}
		}
		else
		{
			OUTS("ERC DML %s not found in TCUA",10,30,inputDML);
			//printf("\nERC DML %s not found in TCUA\n",inputDML);
			return status;
		}
	}
	OUTS("transfer done",10,30,inputDML);
	OUTS("######################",10,30,"######################");
	ITK_CALL(POM_logout(false));
	return status;
}
//int test( tag_t platformrev, tag_t PartTag )
int Add_Mod_to_PlatForm( char* AssyNo, char* ArcNode, char* ChildNo,char* plantcode,char *SapChangeNo )
{
//	int status;
	int status = ITK_ok;
	struct usgProbnode *pUP = NULLTAG;
	tag_t ChildOPtr = NULLTAG;
	tag_t ChildOPtrCpy = NULLTAG;
	tag_t PartOPtr = NULLTAG;
	tag_t *partObjs = NULLTAG;
	//char *AssyNo = NULL;
	char *SapItemId = NULL;
	char *SapModExistItemId = NULL;
	//char *ArcNode = NULL;
	//char *ChildNo = NULL;
//	char *SapChangeNo = NULL;
	char *sRevision = NULL;
	char *sSequence = NULL;
	char *mat_prov_ind = NULL;
	char *meas_unit = NULL;
	char *tempcsrel = NULL;
	char *formula = NULL;
	char *aformula = NULL;
	int ci = 0;
	int ei = 0;
	int grind = 0;
	int iPartIndex;
	int ret;
	int failflag = 0;
	int i = 0;
	int noOfChilds = 0;
	int stat = 0;
	int taskCount = 0;
	static int sr_no1 = 0;
	char *AssyPrttype = NULL;
	char *AssyPrttypeDup = NULL;
	char *Revision = NULL;
	char *RevisionDup = NULL;
	char *assy_no = NULL;
	char *assy_noDup = NULL;
	char *date_updated = NULL;
	char *date_updatedDup = NULL;
	char *epaowner = NULL;
	char *epaownerDup = NULL;
	char *eparelzstate = NULL;
	char *eparelzstateDup = NULL;
	char *epataskId = NULL;
	char *epataskIdDup = NULL;
	char *make_buy_ind = NULL;
	char *make_buy_indDup = NULL;
	char *part_no = NULL;
	char *part_noDup = NULL;
	char *taskId = NULL;
	char *taskIdDup = NULL;
	char *unit = NULL;
	char *unitDup = NULL;
	char *DispName = NULL;
	char *DispNameDup = NULL;
	char *PrtCls = NULL;
	char *PrtClsDup = NULL;
	char *cPrtCls = NULL;
	char *owner = NULL;
	char *ownerDup = NULL;
	char *prjcode = NULL;
	char *prjcodeDup = NULL;
	char *prtType = NULL;
	char *prtTypeDup = NULL;
	char *qty = NULL;
	char *qtyDup = NULL;
	char *qty_req_info = NULL;
	char *qty_req_infoDup = NULL;
	char *relzstate = NULL;
	char *relzstateDup = NULL;
	struct node *p=NULL;
	struct node *q=NULL;
	float floatQty= 0.000;
	int mcSeriesRawPartflag = 1;
	char *iOrganizationID=NULL;
	char *StdDate=NULL;
	char *MonYear=NULL;
	char *inputDmlNumber=NULL;
	char *inputPlantCode=NULL;
	tag_t priobjTypeTag = NULLTAG;
	char *ChildPrtCls = NULL;
	int ic = 0 ;
	tag_t CtxtCntrlLocSet = NULLTAG;
	char *t5Userinfo1 = NULL;
	char *t5Userinfo1Dup = NULL;
	tag_t genContextObj = NULLTAG;
	tag_t CtxtObj = NULLTAG;
	char *viewName = NULLTAG;
	char *confg_class = NULL;
	tag_t MkeBuyControlObjs = NULLTAG;
	tag_t MkeBuyControlObjPtr = NULLTAG;
	char *pMkeBuyIndicator = NULL;
	char *pMkeBuyIndicatorDup = NULL;
	char *AssemblyRevision = NULL;
	char *AssemblyRevisionDup = NULL;
	char *SequenceRevision = NULL;
	char *SequenceRevisionDup = NULL;
	char *OrganizationID = NULL;
	char *epataskIdDup0 = NULL;
	char *epataskIdDup1 = NULL;
	char *epataskIdDup2 = NULL;
	char *taskIdDup0 = NULL;
	char *taskIdDup1 = NULL;
	char *taskIdDup2 = NULL;
	char *carcs = NULL;
	int noValidEpa = 1;
	int noValidDml = 1;
	char *myDate = NULL;
	char *curentname=NULL;
	char *priobj_name=NULL;
	tag_t ConfigCtx=NULLTAG;
	tag_t Optfmly_tag=NULLTAG;
	tag_t ConfigCtxObjTypeTag=NULLTAG;
	char Config_CtxType[TCTYPE_name_size_c+1];
	char *SmVCContext=NULL;
	char *SmCrIDContext=NULL;
	char *ContextobjName=NULL;
	tag_t *rev=NULLTAG;
	int resultCount = 0;
	int CntChildP = 0;
	int CntChildArch = 0;
	int ChildItemTag = 0;
	int Item_ID = 0;
	int Item_UoM = 0;
	int Item_Owner = 0;
	int Child_Item_RevSeq = 0;
	char *LatRevName = NULL;
	char *POwnerName = NULL;
	char *POwnerNameDup	= NULL;
	char *InpRevSeq = NULL;
	char *ChildRevName = NULL;
	char *Child_Item_RevSeq_str	= NULL;
	char *ChildOwnName = NULL;
	char *ChildPrtType = NULL;
	char *ChildPrtQty = NULL;
	char *ChildQtyDup = NULL;
	char *ChildPrtUoM = NULL;
	tag_t queryTag = NULLTAG;
	tag_t LatestPRev = NULLTAG;
	tag_t window = NULLTAG;
	tag_t window1 = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t rule1 = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t PerentLine = NULLTAG;
	tag_t PerentLine1 = NULLTAG;
	tag_t *ChildPartLine = NULLTAG;
	tag_t ChildItemRevTag = NULLTAG;
	tag_t ChildItemRev = NULLTAG;
	tag_t item_tag = NULLTAG;
	tag_t item_tag1 = NULLTAG;
	tag_t PlatLatestRev = NULLTAG;
	tag_t Arch_tag = NULLTAG;
	tag_t node_tag = NULLTAG;
	char* sPartType = NULL;
	char *Context_Str = NULL;
	char *Context_VariantRule = NULL;
	char *Context_VariantRuleTok1 = NULL;
	char **Options_array = NULL ;
	char *uContext_VariantRule = NULL;
	char *item_type = NULL;
	char *item_type1 = NULL;
	char *objectname = NULL;
	char *objectyp = NULL;
	char *OptValNameCopy = NULL;
	char *oDrwNum1 = NULL;
	tag_t *tags_found;
	tag_t *tags_found1;
	tag_t *ChildArchLine;
	tag_t view_relation = NULLTAG;
	tag_t relation_dep = NULLTAG;
	tag_t latestrev = NULLTAG;
	tag_t Archrev = NULLTAG;
	tag_t platformrev = NULLTAG;
	tag_t Anode_tag = NULLTAG;
	char *pltfrm_str = NULL;
	char *childid = NULL;
	int n_tags_found = 0;
	int n_tags_found1 = 0;
	int ai = 0;
	int viewcount = 0;
	int n_parents = 0;
	int countConfigCtx = 0;
	tag_t *ConfigCtxSecObject	= NULLTAG;
	int jd = 0;
	int *levels = 0;
	//char *Context_Str=NULL;
	char *Arch_str = NULL;
	tag_t *parents = NULL;
	tag_t *primary_ref_list=NULLTAG;
	const char **attrs = (const char **) MEM_alloc(1 * sizeof(char *));
	const char **attrs1 = (const char **) MEM_alloc(1 * sizeof(char *));
	const char **values = (const char **) MEM_alloc(1 * sizeof(char *));
	const char **values1 = (const char **) MEM_alloc(1 * sizeof(char *));
	//tag_t Optfmly_tag = NULLTAG;
	char *OptfmlyName_O = NULL;
	char *OptValName_O = NULL;
	int j = 0;
	char *qry_entriesOptFamVal[] = {"Thread ID","ID"};
	char **qry_valuesOptFamVal = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t OptfmlyVal_tag = NULLTAG;
	tag_t queryTagOptFamVal = NULLTAG;
	tag_t *revOptFamVal=NULL;
	int resultCountOptFamVal=0,n_entriesOptFamVal=2,iCnt=0;
	char* OptValName=NULL;
	char* OptfmlyName=NULL;
	char* OptfmlyDesc=NULL;
	char* VariantFormulaStr=NULL;
	char* VariantFormulaStrOptionVal=NULL;
	int vfrl=0;
	char *qry_entriesOptFam[] = {"ID"};
	tag_t queryTagOptFam = NULLTAG;
	tag_t *revOptFam=NULL;
	int resultCountOptFam=0;
	int n_entriesOptFam=1;
	int n_entries = 1;
	int k=0;
	int j1=0;
	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesOptFam = (char **) MEM_alloc(10 * sizeof(char *));
	char *svr_1 = NULL;
	char *svr_2 = NULL;
	/*char svr_1[500] = { 0 };
	char svr_2[500] = { 0 };*/
	char* option_token = NULL;
	char* equaltok = NULL;
	char **attrs_name = NULL;
	int ioc = 0;
	int joc = 0;
	int last_ioc = 0;
	char* tokstr = {"[" };
	int jCnt = 0;
	char *resultRule_1 = NULL;
	char *resultRule_2 = NULL;
	char *resultRule_3 = NULL;
	char *resultRule_4 = NULL;
	char* ClosureRule = NULL;
	PIE_scope_t scope;
	int n_closure_tags;
	tag_t* closure_tags;
	tag_t closure_tag;
	char* ClosureRule1 = NULL;
	PIE_scope_t scope1;
	int n_closure_tags1;
	tag_t* closure_tags1;
	tag_t closure_tag1;
	char *ChildPrtQty_req_info	= NULL;
	char* rev_release_statuses = NULL;
	//char* plantcode = NULL;

	char *uid = NULL;
	char *aPotx1 = NULL;
	int  bl_config = 0 ;
	logical bl_config_log ;
	int iArchModFoundFlag = 0;

	oDrwNum1 = ( char * ) malloc ( 500 * sizeof ( char ) ) ;
	OptValNameCopy = ( char * ) malloc ( 500 * sizeof (char ) ) ;
	formula = ( char * ) malloc ( 10000 * sizeof ( char ) ) ;
	aPotx1 = ( char * ) malloc ( 40 * sizeof ( char ) ) ;
//	aformula = ( char * ) malloc ( 10000 * sizeof ( char ) ) ;
	o1Context_VariantRule = ( char * ) malloc ( 10000 * sizeof ( char) ) ;
	o2Context_VariantRule = ( char * ) malloc ( 10000 * sizeof ( char ) ) ;

	meas_unit = ( char * ) malloc ( 5 * sizeof ( char ) );
	sr_no = ( char * ) malloc ( 5 * sizeof ( char ) );


	sprintf(fsuccess_name,"TCUA_SAP_MODULERBOM_add_module_%s.log",AssyNo);
	fsuccess = fopen(fsuccess_name,"a");
	if(fsuccess == NULL)
	OUTS("Unable To open Or Create Log  file",10,30,"");

	SapItemId = (char *) MEM_alloc(5 * sizeof(char));



	tc_strcpy(SapItemId,Get_LatestSerial_No(AssyNo,plantcode));


	//tc_strcpy(SapItemId,"1109");
	//printf("\nSapItemId:%s",SapItemId);
	OUTS("SapItemId",10,30,SapItemId);


	if ( SapChangeNo != NULL )
	{
		//cll_ccap_ecn_create(SapChangeNo);
	}
	else
	{
		exit(0);
	}

	ITK_CALL(ITEM_find_item( AssyNo, &node_tag ));

	if (node_tag != NULLTAG)
	{
		OUTS("PlatForm",10,30,AssyNo);
		ITK_CALL(ITEM_ask_type2 (node_tag, &item_type));
		OUTS("Main item_type",10,30,item_type);

	}
	else
	{
		OUTS("PlatForm not found in TCUA",10,30,AssyNo);
		goto CLEANUP;
	}

	if(tc_strcmp(item_type, "T5_Platform") == 0)	//Expanding Module BOM to TPL
	{
		attrs[0] = "item_id";
		values[0] = (char *)AssyNo;

		ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

		ITK_CALL(ITEM_ask_latest_rev(node_tag,&latestrev));

		if (latestrev!=NULLTAG)
		{
			ITK_CALL( AOM_ask_value_string(latestrev,"object_string",&curentname));
			OUTS("T5_Platform latest revision",10,30,curentname);
		}

		MEM_free(attrs);
		MEM_free(values);
		if (n_tags_found == 0)
		{
			OUTS("ITEM_find_items_by_key_attributes returns success,  but didn't find",10,30,AssyNo);
			exit(0);
		}
		else if (n_tags_found > 1)
		{
			MEM_free(tags_found);
			EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
			OUTS("More than one items matched with id",10,30,AssyNo);
			exit(0);
		}

		ITK_CALL(ITEM_ask_item_of_rev(latestrev, &platformrev));
		ITK_CALL(AOM_ask_value_string(platformrev,"item_id",&pltfrm_str));
		OUTS("pltfrm_str String Type",10,30,pltfrm_str);

		ITK_CALL(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
		if(relation_dep != NULLTAG)
		{
			OUTS("Variant ConfigContext relation found",10,30,"");
		}

		ITK_CALL(GRM_list_secondary_objects_only(platformrev,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
		//printf("Configuration Context count is : %d\n",countConfigCtx);
		OUTI("Configuration Context count",10,30,countConfigCtx);
		ConfigCtx=ConfigCtxSecObject[0];
		ITK_CALL(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
		ITK_CALL(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));
		OUTS("Config relation Config_CtxType",10,30,Config_CtxType);

		ITK_CALL(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
		OUTS("SmVCContext Object String Type",10,30,SmVCContext);

		ITK_CALL(AOM_ask_value_string(ConfigCtx,"item_id",&Context_Str));
		OUTS("Context_Str",10,30,Context_Str);



		if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTagOptFam));
		if (queryTagOptFam)
		{
			OUTS("Found Query",10,30,"");
		}
		else
		{
			OUTS("Not_Found_Query",10,30,"");
		}
		qry_valuesOptFam[0] = Context_Str;
		OUTS(qry_entriesOptFam[0],10,30,qry_valuesOptFam[0]);
		if(QRY_execute(queryTagOptFam, n_entriesOptFam, qry_entriesOptFam, qry_valuesOptFam, &resultCountOptFam, &revOptFam));
		printf("Cfg0OptionFamiliesFromIDs for %s resultCountOptFam:%d\n",Context_Str, resultCountOptFam); fflush(stdout);
		//context query dbk



		item_tag= tags_found[0];
		MEM_free(tags_found);

		ITK_CALL(ITEM_ask_latest_rev(item_tag,&PlatLatestRev));

		ITK_CALL(BOM_create_window (&window));
		//ITK_CALL(CFM_find( "Latest by Creation Date", &rule ));
		//ITK_CALL(CFM_find( "ERC release and above", &rule ));
		//ITK_CALL(CFM_find( "APLC Release and above", &rule ));
		ITK_CALL(CFM_find( "STDC Released and Above", &rule ));
		ITK_CALL(BOM_set_window_config_rule( window, rule ));
		ITK_CALL(BOM_set_window_pack_all (window, false));

		//-----------closure rule

		ClosureRule = (char *) MEM_alloc(100 * sizeof(char ));
		//tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLC");
		tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDC");
		//printf("\nClosureRule :[%s]",ClosureRule);
		OUTS("ClosureRule",10,30,ClosureRule);
		ITK_CALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &n_closure_tags, &closure_tags ));
		printf("\nn_closure_tags %s:%d ..............",ClosureRule,n_closure_tags);fflush(stdout);
		if(n_closure_tags > 0)
		{
			closure_tag=closure_tags[0];
			ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
		}
		//-----------closure rule

		ITK_CALL(BOM_set_window_top_line (window, null_tag, PlatLatestRev, null_tag, &PerentLine));
		ITK_CALL(BOM_line_ask_child_lines(PerentLine, &CntChildArch, &ChildArchLine));

		//printf("CntChildArch:%d\n",CntChildArch);
		OUTI("CntChildArch",10,30,CntChildArch);

		if(CntChildArch>0)
		{
			start = NULL;
			p = NULL;
			q = NULL;
			ret = 0;

			for(ai = 0;ai < CntChildArch; ai++)	//expand platform to architecture node
			{
				Arch_tag = NULLTAG;
				Arch_tag = ChildArchLine[ai];
				//printf("\nArchitecture node index ai:[%d]\n\t",ai);fflush(stdout);
				OUTI("Architecture node index ai",10,30,ai);
				if(ChildArchLine[ai])
				{
					if( AOM_ask_value_string(ChildArchLine[ai],"object_string",&objectname)==ITK_ok)
					OUTS("latest revision",10,30,objectname);
					if( AOM_ask_value_string(ChildArchLine[ai],"bl_child_id",&childid)==ITK_ok)
					OUTS("childid",10,30,childid);
					if( AOM_ask_value_string(ChildArchLine[ai],"bl_item_object_type",&objectyp)==ITK_ok)
					OUTS("objectype",10,30,objectyp);

				}
				else
				{
					OUTS("Tag does not having any value",10,30,"");
				}
				OUTS("objectname",10,30,objectname);

				attrs1[0] ="item_id";
				values1[0] = (char *)childid;


				ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs1, values1, &n_tags_found1, &tags_found1));
				item_tag1= tags_found1[0];
				MEM_free(tags_found1);

				ITK_CALL(ITEM_ask_latest_rev(item_tag1,&Archrev));

				//comment below if get fetal error at end
				//MEM_free(attrs1);
				//MEM_free(values1);


				ITK_CALL(AOM_ask_value_string(Archrev,"item_id",&Arch_str));
				OUTS("Archrev String Type",10,30,Arch_str);


				if(tc_strcmp(objectyp, "T5_ArchModule") == 0)	//Expanding Module BOM to TPL
				{
					/*if(tc_strcmp(Arch_str,ArcNode)!=0)
					{
						printf("\nSkipping architecture node as %s is not matching with input child %s",Arch_str,ArcNode);
						continue;
					}*/
					OUTS("Expanding Arch Module BOM",10,30,objectname);

					if ( tc_strcmp(Arch_str,ArcNode) == 0 )
					{
						printf("\nSkipping architecture node as %s is not matching with input child %s",Arch_str,ArcNode);
						iArchModFoundFlag = 1;
						break;
					}
					
					
				}//If Node
			}//for(ai = 0;ai < CntChildArch; ai++)

			if ( iArchModFoundFlag == 1 )
			{
					ITK_CALL(BOM_create_window (&window1));
					//ITK_CALL(CFM_find( "Latest by Creation Date", &rule ));
					//ITK_CALL(CFM_find( "APLC Release and above", &rule1 ));
					ITK_CALL(CFM_find( "STDC Released and Above", &rule1 ));
					ITK_CALL(BOM_set_window_config_rule( window1, rule1 ));

					//-----------closure rule

					ClosureRule1 = (char *) MEM_alloc(100 * sizeof(char ));
					//tc_strcpy(ClosureRule1,"BOMViewClosureRuleAPLC");
					tc_strcpy(ClosureRule1,"BOMViewClosureRuleSTDC");
					//printf("\nClosureRule :[%s]",ClosureRule1);
					OUTS("ClosureRule1",10,30,ClosureRule1);
					ITK_CALL(PIE_find_closure_rules( ClosureRule1,PIE_TEAMCENTER, &n_closure_tags1, &closure_tags1 ));
					printf("\nn_closure_tags %s:%d ..............",ClosureRule1,n_closure_tags1);fflush(stdout);
					if(n_closure_tags1 > 0)
					{
						closure_tag1=closure_tags1[0];
						ITK_CALL(BOM_window_set_closure_rule(window1,closure_tag1,0,NULL,NULL));
					}
					//-----------closure rule

					ITK_CALL(BOM_set_window_pack_all (window1, false));
					ITK_CALL(BOM_set_window_top_line (window1, null_tag, Archrev, null_tag, &PerentLine1));
					ITK_CALL(BOM_line_ask_child_lines(PerentLine1, &CntChildP, &ChildPartLine));

					//printf("CntChildP:%d\n\t",CntChildP);
					OUTI("CntChildP",10,30,CntChildP);


					if ( CntChildP > 0 )
					{
						for ( i = 0; i < CntChildP ; i++ )//expand architecture node to module
						{
							//printf("\nModule Index:[%d]",i);fflush(stdout);
							OUTI("Module Index",10,30,i);
							aformula = (char *)MEM_alloc(10000);  //dbk.07.04
							strcpy(formula,"");
							strcpy(aformula,"");
							strcpy(aPotx1,"");
							ChildOPtr=NULLTAG;
							ChildOPtr=ChildPartLine[i];

							ITK_CALL(AOM_ask_value_string(ChildOPtr,"bl_rev_release_statuses",&rev_release_statuses));

							BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID);
							BOM_line_ask_attribute_string(ChildOPtr, Item_ID, &ChildRevName);

							printf("\nrev_release_statuses:[%s]%s",rev_release_statuses,ChildRevName);fflush(stdout);

							OUTS("rev_release_statuses",10,30,rev_release_statuses);
							OUTS("ChildRevName",10,30,ChildRevName);

							if(tc_strcmp(ChildRevName,ChildNo)!=0)
							{
								printf("\nSkipping Module as %s is not matching with input child %s",ChildRevName,ChildNo);
								continue;
							}

							AOM_ask_value_string(ChildOPtr,"bl_occ_t5_uidsap",&uid);

							//printf("\tuid:[%s]",uid);
							OUTS("uid",10,30,uid);

							SapModExistItemId = (char *) MEM_alloc(5 * sizeof(char));
							tc_strcpy(SapModExistItemId,"");
							tc_strcpy(SapModExistItemId,Get_ModuleUidSerial(AssyNo,ChildNo,uid,plantcode));

							if ( tc_strcmp(SapModExistItemId,"-001") == 0 )
							{
								printf("\nModule found hence skipping for addition[%s][%s][%s][%s]\n",AssyNo,ChildNo,uid,plantcode);
								continue;
							}


							bl_config = 0;
							ITK_CALL( BOM_line_look_up_attribute ("bl_is_occ_configured",&bl_config));
							//printf("\nbl_config= [%d]\n", bl_config);
							OUTI("bl_config",10,30,bl_config);

							ITK_CALL(BOM_line_ask_attribute_logical(ChildOPtr, bl_config, &bl_config_log));
							printf("\nbl_config_log ChildRevName %s= [%d]",ChildRevName,bl_config_log);
							//if (bl_config_log == 0)
							if (bl_config_log == false)
							{
								printf("\tskipping unconfigured %s",ChildRevName);
								continue;
							}

							if(tc_strcmp(rev_release_statuses,"")==0)
							{
								OUTS("Part with /??? no revision found as per rule and closure rule applied skipping",10,30,ChildRevName);
								continue;
							}


							ITK_CALL( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Child_Item_RevSeq) );
							ITK_CALL( BOM_line_ask_attribute_string(ChildOPtr, Child_Item_RevSeq, &Child_Item_RevSeq_str) );

							OUTS("ChildRevSeq",10,30,Child_Item_RevSeq_str);


							BOM_line_look_up_attribute ("bl_item_uom_tag",&Item_UoM);
							BOM_line_ask_attribute_string(ChildOPtr,Item_UoM,&ChildPrtUoM);

							BOM_line_look_up_attribute ("awb0RevisionOwningUser",&Item_Owner);
							BOM_line_ask_attribute_string(ChildOPtr,Item_Owner,&ChildOwnName);

							AOM_ask_value_string(ChildOPtr,"bl_quantity",&ChildPrtQty);
							tc_strdup(ChildPrtQty,&ChildQtyDup);

							if(tc_strlen(ChildPrtUoM)>0)
							{
								tc_strdup(ChildPrtUoM,&unitDup);
								if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
								else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
								else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
								else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
								else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
								else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
								else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
								else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
								else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
								else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
								else
								{
									tc_strdup("EA",&unitDup);
									tc_strcpy(meas_unit,"EA");
								}
							}
							else tc_strcpy(meas_unit,"EA");

							printf("\nChildRevName:[%s]unitDup:[%s]meas_unit:[%s]",ChildRevName,unitDup,meas_unit);


							AOM_ask_value_string(ChildOPtr,"bl_occ_t5_Qri",&ChildPrtQty_req_info);

							if ( tc_strcmp ( ChildPrtQty, "0" ) == 0 )
							{
								continue;
							}
							if ( tc_strcmp ( ChildPrtQty, "" ) == 0 )
							{
								continue;
							}

							
							ChildItemRev = ask_item_revision_from_bom_line(ChildOPtr);

							ITK_CALL(AOM_ask_value_string(ChildItemRev,"t5_CarMakeBuyIndicator",&make_buy_indDup));

							if(tc_strlen(make_buy_indDup)>0)
							{
								if(tc_strcmp(make_buy_indDup,"F18") == 0)
								{
									tc_strdup("L",&mat_prov_ind);
									tc_strdup("1",&tempcsrel);
								}
								else
								{
									tc_strdup("",&mat_prov_ind);
									tc_strdup("X",&tempcsrel);
								}
							}

							ITK_CALL(AOM_ask_value_string(ChildItemRev,"t5_PartType",&sPartType));
							if(tc_strcmp(sPartType,"D")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							else if(tc_strcmp(sPartType,"DA")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							else if(tc_strcmp(sPartType,"DC")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							else if(tc_strcmp(sPartType,"IFD")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							else if(tc_strcmp(sPartType,"IM")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}
							else if(tc_strcmp(sPartType,"CP")==0)
							{
								printf("\nskip %s %s",ChildRevName,sPartType);
								continue;
							}


							printf("\nChild Part Number [%s] Part Qty [%s]	UoM [%s]	Owner [%s]",ChildRevName,ChildPrtQty,ChildPrtUoM,ChildOwnName);




							AOM_ask_value_string(ChildOPtr,"bl_formula",&Context_VariantRule);
							if (Context_VariantRule == NULL)
							{
								printf("\nModule variant formulae blank skipping for addition[%s][%s][%s][%s]Context_VariantRule[%s]\n",AssyNo,ChildNo,uid,plantcode,Context_VariantRule);
								continue;
							}
							//printf("formula before ::%s\n\t\t",Context_VariantRule);
							OUTS("formula before",10,30,Context_VariantRule);

							resultRule_1 = (char *)MEM_alloc(20000);
							resultRule_2 = (char *)MEM_alloc(10000);
							tc_strcpy(resultRule_2,Context_VariantRule);
							tc_strcpy(resultRule_1,Context_VariantRule);

//							if ( tc_strcmp(resultRule_2,"(((([Teamcenter]SCHEME-NO = CLRSCM-X4/19/0009 )  & [Teamcenter]'ROOF RAIL' = YES & [Teamcenter]COLOUR-BOM = Y  & [Teamcenter]'VEHICLE AGGREGATE' = BIW & [Teamcenter]'VEHICLE TYPE' = 'MINI SUV' & [Teamcenter]'VEHICLE DRIVE' = RHD & [Teamcenter]'MBOM INCLUSION' = YES & ([Teamcenter]'FUEL TYPE' = DIESEL | [Teamcenter]'FUEL TYPE' = PETROL) & [Teamcenter]'REAR WIPER' = YES)))") == 0)
//							{
//								tc_strcpy(resultRule_2, "(((([Teamcenter]SCHEME-NO = CLRSCM-X4/19/0009) & [Teamcenter]'ROOF RAIL' = YES & [Teamcenter]COLOUR-BOM = Y & [Teamcenter]'VEHICLE AGGREGATE' = BIW & [Teamcenter]'VEHICLE TYPE' = 'MINI SUV' & [Teamcenter]'VEHICLE DRIVE' = RHD & [Teamcenter]'MBOM INCLUSION' = YES & ([Teamcenter]'FUEL TYPE' = DIESEL | [Teamcenter]'FUEL TYPE' = PETROL) & [Teamcenter]'REAR WIPER' = YES)))");
//							}


							//test and comment below 8 line single quote around value 21-feb19
							resultRule_2 = replaceWord(resultRule_2, " = ", " = '");
							resultRule_2 = replaceWord(resultRule_2, ") & ", "') & ");
							resultRule_2 = replaceWord(resultRule_2, " & ", "' & ");
							resultRule_2 = replaceWord(resultRule_2, " | ", "' | ");
							resultRule_2 = replaceWord(resultRule_2, "))))", "'))))");
							resultRule_2 = replaceWord(resultRule_2, ")))", "')))");
							resultRule_2 = replaceWord(resultRule_2, "''", "'");
							resultRule_2 = replaceWord(resultRule_2, "''", "'");
							//test and comment below 8 line single quote around value 21-feb19


							resultRule_2 = replaceWord(resultRule_2, "& ([Teamcenter]", "AND$ ([Teamcenter]");
							resultRule_2 = replaceWord(resultRule_2, "& [Teamcenter]", "AND$ [Teamcenter]");
							resultRule_2 = replaceWord(resultRule_2, "| ([Teamcenter]", "OR$ ([Teamcenter]");
							resultRule_2 = replaceWord(resultRule_2, "| [Teamcenter]", "OR$ [Teamcenter]");
							resultRule_2 = replaceWord(resultRule_2, "[Teamcenter]", "");

							//test and comment below 2 line single quote around value 21-feb19
							resultRule_2 = replaceWord(resultRule_2, "' & ", " & ");
							resultRule_2 = replaceWord(resultRule_2, "')' AND$", "') AND$");
							//test and comment below 2 line single quote around value 21-feb19

							svr_1 = (char *)MEM_alloc(10000);
								attrs_name = (char **)MEM_alloc(1000 * sizeof(char *));
							tc_strcpy(svr_1,Context_VariantRule);
							ioc = 0;
							last_ioc = 0;
							option_token = strtok(svr_1,tokstr);	//tokenize char in string "[Teamcenter]" in rule
							while ( option_token != NULL )
							{

								attrs_name[ioc] = option_token;
								option_token = strtok ( NULL, tokstr );
								ioc = ioc + 1;
							}

							last_ioc = ioc;

							OUTS("formula after teamcenter replace",10,30,resultRule_2);

							printf("\nno of options found in rule last_ioc:[%d] [%s]",last_ioc,ChildRevName);
							for (joc = 0 ; joc < last_ioc ; joc++)
							{
								if(attrs_name[joc] != NULL)
								{
									printf("attrs_name[%d]:%s\n\t\t",joc,attrs_name[joc]);fflush(stdout);
									equaltok = strstr(attrs_name[joc],"=");
									if (equaltok != NULL )
									{
										*equaltok = '\0';
										resultRule_3 = replaceWord(attrs_name[joc], "Teamcenter]", "");
										resultRule_4 = replaceWord(resultRule_3, "'", "");
										resultRule_4[tc_strlen(resultRule_4)-1] = '\0';
										printf("Option Name in Rule:[%s]\n\t\t",resultRule_4);fflush(stdout);
										for ( jCnt = 0; jCnt< resultCountOptFam; jCnt++ )
										{
											Optfmly_tag = revOptFam[jCnt];
											OptfmlyDesc=NULL;
											OptfmlyName=NULL;
											ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyName));

											char* resultRule_44 = (char*) MEM_alloc( 100 );
											char* OptfmlyName_new = (char*) MEM_alloc( 100 );
											char* OptfmlyDesc_new = (char*) MEM_alloc( 100 );

											tc_strcpy(resultRule_44,"'");
											tc_strcat(resultRule_44,resultRule_4);
											tc_strcat(resultRule_44,"'");

											tc_strcpy(OptfmlyName_new,"'");
											tc_strcat(OptfmlyName_new,OptfmlyName);
											tc_strcat(OptfmlyName_new,"'");


											if(tc_strcmp(resultRule_44,OptfmlyName_new)==0)
											{
												OUTS(resultRule_44,10,30,OptfmlyName_new);
												ITK_CALL(AOM_ask_value_string(Optfmly_tag,"current_desc",&OptfmlyDesc));
												printf("\nNeed to replace with:[%s][%s]",resultRule_4,OptfmlyDesc);
												printf("\nbefore OptfmlyDesc:[%s]",OptfmlyDesc);
												tc_strcpy(OptfmlyDesc_new,"'");
												tc_strcat(OptfmlyDesc_new,OptfmlyDesc);
												tc_strcat(OptfmlyDesc_new,"'");

												printf("\nafter OptfmlyDesc_new:[%s]",OptfmlyDesc_new);

												resultRule_2 = replaceWord(resultRule_2, resultRule_44, OptfmlyDesc_new);
												if ( tc_strstr(resultRule_2,"COLOUR-BOM")!=NULL)
												{
													resultRule_2 = replaceWord(resultRule_2, "COLOUR-BOM", "COLOUR_BOM");
												}

												if ( tc_strstr(resultRule_2,"SCHEME-NO")!=NULL)
												{
													resultRule_2 = replaceWord(resultRule_2, "SCHEME-NO", "SCHEME_NO");
												}

												//printf("\nreplaced string:[%s]",resultRule_2);
												OUTS("replaced string",10,30,resultRule_2);
								
												break;
											}

										}
									}
								}
							}

							//-----------added below code for removing single code of option 14-feb-2019
							resultRule_2 = replaceWord(resultRule_2, "' =", " =");
							resultRule_2 = replaceWord(resultRule_2, "('", "(");
							resultRule_2 = replaceWord(resultRule_2, "AND$ '", "AND$ ");
							resultRule_2 = replaceWord(resultRule_2, "OR$ '", "OR$ ");
							//-----------added below code for removing single code of option 14-feb-2019

							tc_strcpy(aformula,"");
							tc_strcpy(aformula,resultRule_2);

							tc_strcpy(aPotx1,"");
							tc_strcpy(aPotx1,uid);

							OUTS("formula after",10,30,aformula);

							//added on 06-apr-2021 dbk

							printf("\nfirst char of formulae aformula:[%c]",aformula[0]);
							printf("\nlast char of formulae aformula:[%c]",aformula[tc_strlen(aformula)-1]);
							
							if ( aformula[0] == '\'' )//if first char is single quote of option in formulae
							{
								aformula[0] = ' ';
							}
							//X4 item_no 1637 case
							//exmaple option_name = 'YES) it should replace like option_name = 'YES')
							if ( ( aformula[tc_strlen(aformula)-1] == ')' )	//last char is ')'
									&&
								( isalpha(aformula[tc_strlen(aformula)-2]) > 0 )	//second last is alphabate
								)
							{
								aformula[tc_strlen(aformula)-1] = '\'';//added to add single quote if last char is alphabate
								aformula[tc_strlen(aformula)] = ')';//added to add single quote if last char is alphabate
							}

							if ( isalpha(aformula[tc_strlen(aformula)-1]) > 0 )
							{
								aformula[tc_strlen(aformula)] = '\'';//added to add single quote if last char is alphabate
							}

							printf("\nafter first char of formulae aformula:[%c]",aformula[0]);
							printf("\nsecond last char of formulae aformula:[%c]",aformula[tc_strlen(aformula)-1]);
							
							aformula = stripBlanks ( aformula );
							//added on 06-apr-2021 dbk

							printf("\nsvr_1:[%s]",svr_1);fflush(stdout);
							printf("\nContext_VariantRule:[%s]",Context_VariantRule);fflush(stdout);
							printf("\nresultRule_2:[%s]",resultRule_2);fflush(stdout);
							printf("\naformula:[%s]",aformula);fflush(stdout);
							

//							MEM_free(svr_1);
//							MEM_free(attrs_name);
//							MEM_free(Context_VariantRuleTok1);

							

							tc_strdup(ChildRevName,&part_noDup);
							floatQty = atof(ChildQtyDup);

							vfrl=tc_strlen(Context_VariantRule);
							printf("\nFinal Node String [%s][%7.3f][%s][%s][%s]\n\t\t",part_noDup,floatQty,meas_unit,aformula,aPotx1);fflush(stdout);
							fprintf(fsuccess,"\nFinal Node String [%s][%7.3f][%s][%s][%s]\n\t\t",part_noDup,floatQty,meas_unit,aformula,aPotx1);

							strcpy(sap_proc_type,"");
							strcpy(sap_spproc_type,"");
							strcpy(SAPpstat,"");
							strcpy(MRPpstat,"");

							GetCSPstat(part_noDup,plantcode);

							pstat='0';
							pstat_mrp='0';
							pstat_acc='0';

							pstat_basicFun();

							if(vfrl>0)
							{
								if(pstat_mrp=='D')
								{
									if(p==NULL)
									{
										sr_no1 = atoi(SapItemId);
										tc_strcpy(sr_no,SapItemId);
										//printf("\nsr_no 0:%s",sr_no);
										OUTS("sr_no 0",10,30,sr_no);
										p = createnode(sr_no,part_noDup,&floatQty,meas_unit,aformula,aPotx1);
										start = p;
									}
									else
									{

										q=start;
										while(q->next!=NULL)
										{
											q=q->next;
										}
										sr_no1 = sr_no1 + 1 ;
										sprintf(sr_no,"%04d",sr_no1);
										//printf("\nsr_no 1:%s",sr_no);
										OUTS("sr_no 1",10,30,sr_no);
										q->next=createnode(sr_no,part_noDup,&floatQty,meas_unit,aformula,aPotx1);

									}
								}
								else
								{
									//printf("\nchild skipped in bom transfer mat not exist:[%s]",part_noDup);
									OUTS("child skipped in bom transfer mat not exist",10,30,part_noDup);
									exit(0);
								}
							}

							//dbk.08.04
							if ( svr_1 != NULL )
							{
								MEM_free(svr_1);
							}
							svr_1 = NULL;

							if ( attrs_name != NULL )
							{
								MEM_free(attrs_name);
							}
							attrs_name = NULL;

							if ( Context_VariantRuleTok1 != NULL )
							{
								MEM_free(Context_VariantRuleTok1);
							}
							Context_VariantRuleTok1 = NULL;

							/*if ( aformula != NULL )
							{
								MEM_free(aformula);
							}
							aformula = NULL;*/
							//dbk.08.04
						}
					}
					else
					{
						 OUTS("NO Structure found for Node",10,30,AssyNo);

					}
			}

		}

		if(sr_no1 < 1)
		{
			OUTS("Do not have structure in PLM",10,30,AssyNo);

		}
		else
		{
			OUTS("Modular Bom SAP transfer started",10,30,AssyNo);

			BapiLogon();
			SapBomCreate(AssyNo,SapChangeNo,plantcode);
			cll_CSAP_MAT_BOM_OPEN(start,AssyNo,SapChangeNo,plantcode);
			cll_CSAP_MAT_BOM_CLOSE();
			RfcClose(hRfc);
			my_free(start);
			goto CLEANUP;

		}
	}//If platform

	CLEANUP:
		OUTS("CLEANUP...",10,30,AssyNo);

		//ITK_CALL(POM_logout(false));
		return status;

	EXIT:
		OUTS("Exiting...",10,30,assy_noDup);
		//ITK_CALL(POM_logout(false));
		return status;
}

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}


RFC_RC CSAP_MAT_BOM_OPEN (
                RFC_HANDLE				  hRfc,
				CSAP_MBOM_MATNR*		  eCSAP_MBOM_MATNR,
				CSAP_MBOM_WERKS*		  eCSAP_MBOM_WERKS,
				CSAP_MBOM_STLAN*	      eCSAP_MBOM_STLAN,
				CSAP_MBOM_STLAL*		  eCSAP_MBOM_STLAL,
				CSAP_MBOM_DATUV*	      eCSAP_MBOM_DATUV,
				CSAP_MBOM_AENNR*	      eCSAP_MBOM_AENNR,
				CSAP_MBOM_REVLV*		  eCSAP_MBOM_REVLV,
				CAPIFLAG_NO_CHG_DOC*	  eCAPIFLAG_NO_CHG_DOC,
				STKO_API02*                iSTKO_API02,
				CAPIFLAG_FLWARNING*        iCAPIFLAG_FLWARNING,
				ITAB_H					    thSTPO_API02,
				ITAB_H					    thCSDEP_DAT,
				ITAB_H					    thCSDEP_DESC,
				ITAB_H					    thCSDEP_ORD,
				ITAB_H					    thCSDEP_SORC,
				ITAB_H					    thCSDEP_DOC,
				char*					    xException
	       );



RFC_RC CSAP_BOM_ITEM_MAINTAIN (
                RFC_HANDLE				    hRfc,
				STPO_API02*		            eSTPO_API02,
				CSDATA_XFELD*		        eCSDATA_XFELD,
				STPO_API02*                 iSTPO_API02,
				CAPIFLAG_FLWARNING*         iCAPIFLAG_FLWARNING,
				ITAB_H					    thDEP_DATA,
				//ITAB_H					    thDEP_DESCR,
				//ITAB_H					    thDEP_ORDER,
				ITAB_H					    thDEP_SOURCE,
				//ITAB_H					    thDEP_DOC,
				char*					    xException
	       );


RFC_RC CSAP_MAT_BOM_CLOSE (
                 RFC_HANDLE				  hRfc,
				CAPIFLAG_COMM_WAIT*		eCAPIFLAG_COMM_WAIT,
				CAPIFLAG_FLWARNING*        iCAPIFLAG_FLWARNING,
				char*					    xException
	       );







void cll_CSAP_MAT_BOM_OPEN(struct node *head,char *assy_noDup, char* SapChangeNo, char* plantcode)
{
	//static RFC_RC RfcRc;
	//static RFC_HANDLE hRfc;
	struct node *p=NULL;
	char sap_qty[18];
	char childprt[18];
	char srno[5];
	char uom[5];

	char xException[256];
	char wrnmsg[1024] = { 0 };
	char bomnum[1024] = { 0 };

	int crow=1;


	CSAP_MBOM_MATNR eCSAP_MBOM_MATNR;
	CSAP_MBOM_WERKS eCSAP_MBOM_WERKS;
	CSAP_MBOM_STLAN eCSAP_MBOM_STLAN;
	CSAP_MBOM_STLAL eCSAP_MBOM_STLAL;
	CSAP_MBOM_DATUV eCSAP_MBOM_DATUV;
	CSAP_MBOM_AENNR eCSAP_MBOM_AENNR;
	CSAP_MBOM_REVLV eCSAP_MBOM_REVLV;
	CAPIFLAG_NO_CHG_DOC eCAPIFLAG_NO_CHG_DOC;
	STKO_API02 iSTKO_API02;
	CAPIFLAG_FLWARNING iCAPIFLAG_FLWARNING;

	ITAB_H thSTPO_API02 = ITAB_NULL;
	ITAB_H thCSDEP_DAT = ITAB_NULL;
	ITAB_H thCSDEP_DESC = ITAB_NULL;
	ITAB_H thCSDEP_ORD = ITAB_NULL;
	ITAB_H thCSDEP_SORC = ITAB_NULL;
	ITAB_H thCSDEP_DOC = ITAB_NULL;


	STPO_API02 *tSTPO_API02;
	CSDEP_DAT *tCSDEP_DAT;
	CSDEP_DESC *tCSDEP_DESC;
	CSDEP_ORD *tCSDEP_ORD;
	CSDEP_SORC *tCSDEP_SORC;
	CSDEP_DOC *tCSDEP_DOC;


    printf("\ncll_CSAP_MAT_BOM_OPEN function:[%s] [%s]\n",assy_noDup,plantcode); fflush(stdout);

	//Setting input argument for BAPI
	SETCHAR(eCSAP_MBOM_MATNR.MATNR,assy_noDup);
	//SETCHAR(eCSAP_MBOM_MATNR.MATNR,"X4_SUPERBOM_HD_3");
	SETCHAR(eCSAP_MBOM_WERKS.WERKS,plantcode);
	//SETCHAR(eCSAP_MBOM_WERKS.WERKS,"1100");
	SETCHAR(eCSAP_MBOM_STLAN.STLAN,"1");
	SETCHAR(eCSAP_MBOM_STLAL.STLAL,"01");
	SETCHAR(eCSAP_MBOM_DATUV.DATUV,"");
	//SETCHAR(eCSAP_MBOM_AENNR.AENNR,"CORRCT090219");
	SETCHAR(eCSAP_MBOM_AENNR.AENNR,SapChangeNo);
	SETCHAR(eCSAP_MBOM_REVLV.REVLV,"");
	SETCHAR(eCAPIFLAG_NO_CHG_DOC.NO_CHG_DOC,"");

	printf("\nassy_noDup:[%s] [%s] [%s]\n",assy_noDup,plantcode,SapChangeNo); fflush(stdout);



	if (thSTPO_API02==ITAB_NULL)
	{
		thSTPO_API02 = ItCreate("T_STPO",sizeof(STPO_API02),0,0);
		if (thSTPO_API02==ITAB_NULL)
		{
			printf("ItCreateT_STPO");
		}
	}
	else if (ItFree(thSTPO_API02)!= 0)
	{
		printf("ItFreeT_STPO");
	}



	for(p = head; p != NULL; p = p -> next)
	{
		sprintf(sap_qty,"%7.3f", p->qty);
		sprintf(childprt,"%s", p->part);
		sprintf(srno,"%s",p->sr_no);
		sprintf(uom,"%s",p -> uq);
		//printf("\n%s %-15s %7.3f %3s\n",p -> sr_no, p -> part, p -> qty,p -> uq, p->formula);
		printf("\n[%s] %-15s %7.3f %3s [%s]\n",p -> sr_no, p -> part, p -> qty,p -> uq,p->Potx1);
		//fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq);


		tSTPO_API02 = ItAppLine (thSTPO_API02);

		if (tSTPO_API02 == NULL) printf("ItAppLineT_STPO");


		//SETCHAR(tSTPO_API02->ITEM_CATEG,"L");
		SETCHAR(tSTPO_API02->ITEM_CATEG,"L");
		SETCHAR(tSTPO_API02->ITEM_NO,p->sr_no);
		//SETCHAR(tSTPO_API02->ITEM_NO,"0059");	//change comment of item id
		//SETCHAR(tSTPO_API02->ITEM_NO,"0001");
		//SETCHAR(tSTPO_API02->COMPONENT,"5436B1A0165001");
		SETCHAR(tSTPO_API02->COMPONENT,p->part);
		SETCHAR(tSTPO_API02->COMP_QTY,"1");
		SETCHAR(tSTPO_API02->COMP_UNIT,p->uq);
		SETCHAR(tSTPO_API02->FIXED_QTY,"");
		//SETCHAR(tSTPO_API02->ITEM_TEXT1,"");
		SETCHAR(tSTPO_API02->ITEM_TEXT1,p->Potx1);
		SETCHAR(tSTPO_API02->ITEM_TEXT2,"");
		SETCHAR(tSTPO_API02->SORTSTRING,"");
		SETCHAR(tSTPO_API02->REL_COST,"");
		SETCHAR(tSTPO_API02->REL_ENGIN,"");
		SETCHAR(tSTPO_API02->REL_PMAINT,"");
		SETCHAR(tSTPO_API02->REL_PROD,"");
		SETCHAR(tSTPO_API02->REL_SALES,"");
		SETCHAR(tSTPO_API02->SPARE_PART,"");
		SETCHAR(tSTPO_API02->MAT_PROVIS,"");
		SETCHAR(tSTPO_API02->BULK_MAT,"");
		SETCHAR(tSTPO_API02->REC_ALLOWD,"");
		SETCHAR(tSTPO_API02->COMP_SCRAP,"");
		SETCHAR(tSTPO_API02->OP_SCRAP,"");
		SETCHAR(tSTPO_API02->OP_NET_IND,"");
		SETCHAR(tSTPO_API02->DISTR_KEY,"");
		SETCHAR(tSTPO_API02->EXPL_TYPE,"");
		SETCHAR(tSTPO_API02->SPPROCTYPE,"");
		SETCHAR(tSTPO_API02->SUPPLYAREA,"");
		SETCHAR(tSTPO_API02->ISSUE_LOC,"");
		SETCHAR(tSTPO_API02->LEAD_TIME,"");
		SETCHAR(tSTPO_API02->OP_LEAD_TM,"");
		SETCHAR(tSTPO_API02->OP_LT_UNIT,"");
		SETCHAR(tSTPO_API02->CO_PRODUCT,"");
		SETCHAR(tSTPO_API02->DISCON_GRP,"");
		SETCHAR(tSTPO_API02->FOLLOW_GRP,"");
		SETCHAR(tSTPO_API02->AI_GROUP,"");
		SETCHAR(tSTPO_API02->AI_STRATEG,"");
		SETCHAR(tSTPO_API02->AI_PRIO,"");
		SETCHAR(tSTPO_API02->USAGE_PROB,"");
		SETCHAR(tSTPO_API02->REFPOINT,"");
		SETCHAR(tSTPO_API02->PM_ASSMBLY,"");
		SETCHAR(tSTPO_API02->COST_ELEM,"");
		SETCHAR(tSTPO_API02->DELIV_TIME,"");
		SETCHAR(tSTPO_API02->GRP_TIME,"");
		SETCHAR(tSTPO_API02->MAT_GROUP,"");
		SETCHAR(tSTPO_API02->PRICE,"");
		SETCHAR(tSTPO_API02->PRICE_UNIT,"");
		SETCHAR(tSTPO_API02->CURRENCY,"");
		SETCHAR(tSTPO_API02->PURCH_GRP,"");
		SETCHAR(tSTPO_API02->PURCH_ORG,"");
		SETCHAR(tSTPO_API02->VENDOR,"");
		SETCHAR(tSTPO_API02->VSI_NO,"");
		SETCHAR(tSTPO_API02->VSI_QTY,"");
		SETCHAR(tSTPO_API02->VSI_SIZE1,"");
		SETCHAR(tSTPO_API02->VSI_SIZE2,"");
		SETCHAR(tSTPO_API02->VSI_SIZE3,"");
		SETCHAR(tSTPO_API02->VSI_SZUNIT,"");
		SETCHAR(tSTPO_API02->VSI_FORMUL,"");
		SETCHAR(tSTPO_API02->DOCUMENT,"");
		SETCHAR(tSTPO_API02->DOC_TYPE,"");
		SETCHAR(tSTPO_API02->DOC_PART,"");
		SETCHAR(tSTPO_API02->DOC_VERS,"");
		SETCHAR(tSTPO_API02->aCLASS,"");
		SETCHAR(tSTPO_API02->CLASS_TYPE,"");
		SETCHAR(tSTPO_API02->RES_ITM_CT,"");
		SETCHAR(tSTPO_API02->SEL_COND,"");
		SETCHAR(tSTPO_API02->REQD_COMP,"");
		SETCHAR(tSTPO_API02->MULT_SELEC,"");
		SETCHAR(tSTPO_API02->REL_HLCONF,"");
		SETCHAR(tSTPO_API02->CAD_IND,"");
		SETCHAR(tSTPO_API02->ITM_IDENT,"");
		SETCHAR(tSTPO_API02->ITEM_GUID,"");
		SETCHAR(tSTPO_API02->VALID_FROM,"");
		SETCHAR(tSTPO_API02->CHANGE_NO,"");
		SETCHAR(tSTPO_API02->IDENTIFIER,"");
		SETCHAR(tSTPO_API02->SEGMENT_VALUE,"");
		SETNUM(tSTPO_API02->CUFACTOR,"");
		SETCHAR(tSTPO_API02->SAPMP_MET_LRCH,"");
		SETCHAR(tSTPO_API02->SAPMP_MAX_FERTL,"");
		SETCHAR(tSTPO_API02->SAPMP_FIX_AS_J,"");
		SETCHAR(tSTPO_API02->SAPMP_FIX_AS_E,"");
		SETCHAR(tSTPO_API02->SAPMP_FIX_AS_L,"");
		SETCHAR(tSTPO_API02->SAPMP_ABL_ZAHL,"");
		SETCHAR(tSTPO_API02->SAPMP_RUND_FAKT,"");
		SETCHAR(tSTPO_API02->BOM_NO,"");
		SETNUM(tSTPO_API02->ITEM_NODE,"");
		SETNUM(tSTPO_API02->ITEM_COUNT,"");
		SETCHAR(tSTPO_API02->RECURSIVE,"");
		SETNUM(tSTPO_API02->DEP_LINK,"");
		SETCHAR(tSTPO_API02->ALE_IND,"");
		SETCHAR(tSTPO_API02->VALID_TO,"");
		SETCHAR(tSTPO_API02->CHG_NO_TO,"");
		SETCHAR(tSTPO_API02->CREATED_ON,"");
		SETCHAR(tSTPO_API02->CREATED_BY,"");
		SETCHAR(tSTPO_API02->CHANGED_ON,"");
		SETCHAR(tSTPO_API02->CHANGED_BY,"");
		SETCHAR(tSTPO_API02->BOM_ALT,"");
		SETCHAR(tSTPO_API02->FLDELETE,"");
		SETCHAR(tSTPO_API02->SEGMENT_RELEVANT,"");


	}



	RfcRc = CSAP_MAT_BOM_OPEN(hRfc,&eCSAP_MBOM_MATNR,&eCSAP_MBOM_WERKS,&eCSAP_MBOM_STLAN,&eCSAP_MBOM_STLAL,&eCSAP_MBOM_DATUV,&eCSAP_MBOM_AENNR,&eCSAP_MBOM_REVLV,&eCAPIFLAG_NO_CHG_DOC,&iSTKO_API02,&iCAPIFLAG_FLWARNING,thSTPO_API02,thCSDEP_DAT,thCSDEP_DESC,thCSDEP_ORD,thCSDEP_SORC,thCSDEP_DOC,xException);




	switch (RfcRc)
	{
		case RFC_OK:
			GETCHAR(iSTKO_API02.BASE_QUAN,bomnum);
			OUTS("BASE_QUAN",10,30,bomnum);
		    //printf("STKO_API02.BASE_QUAN:%s\n",bomnum);fflush(stdout);
			GETCHAR(iSTKO_API02.BASE_UNIT,bomnum);
			//printf("BASE_UNIT:%s\n",bomnum);fflush(stdout);
			OUTS("BASE_UNIT",10,30,bomnum);
			GETCHAR(iSTKO_API02.BOM_STATUS,bomnum);
			//printf("BOM_STATUS:%s\n",bomnum);fflush(stdout);
			OUTS("BOM_STATUS",10,30,bomnum);
			GETCHAR(iSTKO_API02.ALT_TEXT,bomnum);
			//printf("ALT_TEXT:%s\n",bomnum);fflush(stdout);
			OUTS("ALT_TEXT",10,30,bomnum);
			GETCHAR(iSTKO_API02.LABORATORY,bomnum);
			//printf("LABORATORY:%s\n",bomnum);fflush(stdout);
			OUTS("LABORATORY",10,30,bomnum);
			GETCHAR(iSTKO_API02.DELETE_IND,bomnum);
			//printf("DELETE_IND:%s\n",bomnum);fflush(stdout);
			OUTS("DELETE_IND",10,30,bomnum);
			GETCHAR(iSTKO_API02.BOM_TEXT,bomnum);
			//printf("BOM_TEXT:%s\n",bomnum);fflush(stdout);
			OUTS("BOM_TEXT",10,30,bomnum);
			GETCHAR(iSTKO_API02.BOM_GROUP,bomnum);
			//printf("BOM_GROUP:%s\n",bomnum);fflush(stdout);
			OUTS("BOM_GROUP",10,30,bomnum);
			GETCHAR(iSTKO_API02.CAD_IND,bomnum);
			//printf("CAD_IND:%s\n",bomnum);fflush(stdout);
			OUTS("CAD_IND",10,30,bomnum);
			GETCHAR(iSTKO_API02.ID_GUID,bomnum);
			//printf("ID_GUID:%s\n",bomnum);fflush(stdout);
			OUTS("ID_GUID",10,30,bomnum);
			GETCHAR(iSTKO_API02.BOM_NO,bomnum1);
			//printf("BOM_NO:%s\n",bomnum);fflush(stdout);
			OUTS("BOM_NO",10,30,bomnum);
			GETCHAR(iSTKO_API02.ALE_IND,bomnum);
			//printf("ALE_IND:%s\n",bomnum);fflush(stdout);
			OUTS("ALE_IND",10,30,bomnum);
			GETCHAR(iSTKO_API02.VALID_TO,bomnum);
			//printf("VALID_TO:%s\n",bomnum);fflush(stdout);
			OUTS("VALID_TO",10,30,bomnum);
			GETCHAR(iSTKO_API02.CHG_NO_TO,bomnum);
			//printf("CHG_NO_TO:%s\n",bomnum);fflush(stdout);
			OUTS("CHG_NO_TO",10,30,bomnum);
			GETCHAR(iSTKO_API02.CREATED_ON,bomnum);
			//printf("CREATED_ON:%s\n",bomnum);fflush(stdout);
			OUTS("CREATED_ON",10,30,bomnum);
			GETCHAR(iSTKO_API02.CREATED_BY,bomnum);
			//printf("CREATED_BY:%s\n",bomnum);fflush(stdout);
			OUTS("CREATED_BY",10,30,bomnum);
			GETCHAR(iSTKO_API02.CHANGED_ON,bomnum);
			//printf("CHANGED_ON:%s\n",bomnum);fflush(stdout);
			OUTS("CHANGED_ON",10,30,bomnum);
			GETCHAR(iSTKO_API02.CHANGED_BY,bomnum);
			//printf("CHANGED_BY:%s\n",bomnum);fflush(stdout);
			OUTS("CHANGED_BY",10,30,bomnum);
			GETCHAR(iSTKO_API02.VALID_FROM,bomnum);
			//printf("VALID_FROM:%s\n",bomnum);fflush(stdout);
			OUTS("VALID_FROM",10,30,bomnum);
			GETCHAR(iSTKO_API02.CHG_NO,bomnum);
			//printf("CHG_NO:%s\n",bomnum);fflush(stdout);
			OUTS("CHG_NO",10,30,bomnum);


			GETCHAR(iCAPIFLAG_FLWARNING.FLWARNING,wrnmsg);

			//printf("\nwrnmsg:%s\n",wrnmsg);fflush(stdout);

			OUTS("wrnmsg",10,30,wrnmsg);


			for (crow = 1;crow <= ItFill(thSTPO_API02); crow++)
			{
				tSTPO_API02 = ItGetLine(thSTPO_API02,crow);
				if (tSTPO_API02 == NULL)
				{
					//printf("GetLineT_STPO\n");fflush(stdout);
					OUTS("GetLineT_STPO",10,30,"");
				}
				//printf("%04d %-.16s\n",crow,tSTPO_API02->COMPONENT);fflush(stdout);
				//GETCHAR(tSTPO_API02->COMPONENT,bomnum);
				//OUTS("COMPONENT",10,30,bomnum);

			}


			cll_CSAP_BOM_ITEM_MAINTAIN(start,assy_noDup,plantcode);





		break;
		case RFC_EXCEPTION:
			//printf("RFC EXCEPTION: %s\n",xException);
			rfc_error("RFC_EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION:
			//printf("System Exception Raised!!!\n");
			rfc_error("RFC_SYS_EXCEPTION");
		break;
		case RFC_FAILURE:
			//printf("Failure!!!\n");
			rfc_error("RFC_FAILURE");
		break;
		default:
			//printf("Other Failure!");
			rfc_error("Other Failure");
		break;
	}


}


void cll_CSAP_BOM_ITEM_MAINTAIN(struct node *head,char *assy_noDup,char* plantcode)
{
	//static RFC_RC RfcRc;
	//static RFC_HANDLE hRfc;
	char xException[256];
	char sr_no[10];
	char childprt[18];
	char compnum[1024] = { 0 };
	char Child[1024] = { 0 };
	char ObjectDep[1024] = { 0 };
	//char compnum1[1024] = { 0 };
	char compnum3[1024] = { 0 };
	char compnum4[1024] = { 0 };
	char compnum5[1024] = { 0 };
	char wrnmsg[1024] = { 0 };
	int crow=1;
	int compnum1=0;
	int i=0;
	struct node *p=NULL;
	//char sap_qty[18];
	char *tokSvr=NULL;
	char *vformula=NULL;
	char *oFormula=NULL;



	STPO_API02	eSTPO_API02;
	CSDATA_XFELD	eCSDATA_XFELD;
	STPO_API02               iSTPO_API02;
	CAPIFLAG_FLWARNING        iCAPIFLAG_FLWARNING;
	DEP_DATA *tDEP_DATA;
	//DEP_DESCR *tDEP_DESCR;
	DEP_DESCR *tDEP_DESCR;
	DEP_ORDER *tDEP_ORDER;
	DEP_SOURCE *tDEP_SOURCE;
	DEP_DOC *tDEP_DOC;

	ITAB_H					    thDEP_DATA= ITAB_NULL;
	//ITAB_H					    thDEP_DESCR= ITAB_NULL;
	//ITAB_H					    thDEP_ORDER= ITAB_NULL;
	ITAB_H					    thDEP_SOURCE= ITAB_NULL;
	//ITAB_H					    thDEP_DOC= ITAB_NULL;
	FILE *fpob = NULL;

	fpob = fopen("obdep_cld.txt","w");


    //printf("cll_CSAP_BOM_ITEM_MAINTAIN:%s\n",bomnum1); fflush(stdout);
    //printf("cll_CSAP_BOM_ITEM_MAINTAIN:%s\n",assy_noDup); fflush(stdout);

	OUTS("bomnum1",10,30,bomnum1);
	OUTS("assy_noDup",10,30,assy_noDup);

	tokSvr= (char *)malloc(1000 * sizeof(char));
	vformula= (char *)malloc(10000 * sizeof(char));
	oFormula= (char *)malloc(10000 * sizeof(char));





	for(p = head; p != NULL; p = p -> next)
	 {

		if(tc_strcmp(p -> formula,"")==0)
		{
			continue;		//skipping part if blank formulae	remove this if data is OK 13.10.2018 this is handle for testing purpose only by dbk
		}

		//sprintf(sap_qty,"%7.3f", p->qty);
		sprintf(childprt,"%s",p -> part);
		tc_strcpy(vformula,p -> formula);
		/*printf("sr_no:%s\t",p -> sr_no);
		printf("Formula:%s\t",p -> formula);
		printf("Qty:%7.3f\t",p -> qty);
		printf("Uq:%3s\n",p -> uq);*/
		printf("\n");
		OUTS("sr_no",10,30,p->sr_no);
		OUTS("part",10,30,p->part);
		OUTS("formula",10,30,p->formula);
		//OUTS("COMPONENT",10,30,p->qty);
		OUTS("uq",10,30,p->uq);
		OUTS("Potx1",10,30,p -> Potx1);


		SETCHAR(eSTPO_API02.ITEM_CATEG,"L");
		SETCHAR(eSTPO_API02.ITEM_NO,p -> sr_no);
		SETCHAR(eSTPO_API02.COMPONENT,p -> part);
		SETCHAR(eSTPO_API02.COMP_QTY,"1");
		SETCHAR(eSTPO_API02.COMP_UNIT,p -> uq);
		SETCHAR(eSTPO_API02.FIXED_QTY,"");
		//SETCHAR(eSTPO_API02.ITEM_TEXT1,"");
		SETCHAR(eSTPO_API02.ITEM_TEXT1,p -> Potx1);//5442B3I0772001--BOM::101645--BOM::101651
		SETCHAR(eSTPO_API02.ITEM_TEXT2,"");
		SETCHAR(eSTPO_API02.SORTSTRING,"");
		SETCHAR(eSTPO_API02.REL_COST,"");
		SETCHAR(eSTPO_API02.REL_ENGIN,"");
		SETCHAR(eSTPO_API02.REL_PMAINT,"");
		SETCHAR(eSTPO_API02.REL_PROD,"");
		SETCHAR(eSTPO_API02.REL_SALES,"");
		SETCHAR(eSTPO_API02.SPARE_PART,"");
		SETCHAR(eSTPO_API02.MAT_PROVIS,"");
		SETCHAR(eSTPO_API02.BULK_MAT,"");
		SETCHAR(eSTPO_API02.REC_ALLOWD,"");
		SETCHAR(eSTPO_API02.COMP_SCRAP,"");
		SETCHAR(eSTPO_API02.OP_SCRAP,"");
		SETCHAR(eSTPO_API02.OP_NET_IND,"");
		SETCHAR(eSTPO_API02.DISTR_KEY,"");
		SETCHAR(eSTPO_API02.EXPL_TYPE,"");
		SETCHAR(eSTPO_API02.SPPROCTYPE,"");
		SETCHAR(eSTPO_API02.SUPPLYAREA,"");
		SETCHAR(eSTPO_API02.ISSUE_LOC,"");
		SETCHAR(eSTPO_API02.LEAD_TIME,"");
		SETCHAR(eSTPO_API02.OP_LEAD_TM,"");
		SETCHAR(eSTPO_API02.OP_LT_UNIT,"");
		SETCHAR(eSTPO_API02.CO_PRODUCT,"");
		SETCHAR(eSTPO_API02.DISCON_GRP,"");
		SETCHAR(eSTPO_API02.FOLLOW_GRP,"");
		SETCHAR(eSTPO_API02.AI_GROUP,"");
		SETCHAR(eSTPO_API02.AI_STRATEG,"");
		SETCHAR(eSTPO_API02.AI_PRIO,"");
		SETCHAR(eSTPO_API02.USAGE_PROB,"");
		SETCHAR(eSTPO_API02.REFPOINT,"");
		SETCHAR(eSTPO_API02.PM_ASSMBLY,"");
		SETCHAR(eSTPO_API02.COST_ELEM,"");
		SETCHAR(eSTPO_API02.DELIV_TIME,"");
		SETCHAR(eSTPO_API02.GRP_TIME,"");
		SETCHAR(eSTPO_API02.MAT_GROUP,"");
		SETCHAR(eSTPO_API02.PRICE,"");
		SETCHAR(eSTPO_API02.PRICE_UNIT,"");
		SETCHAR(eSTPO_API02.CURRENCY,"");
		SETCHAR(eSTPO_API02.PURCH_GRP,"");
		SETCHAR(eSTPO_API02.PURCH_ORG,"");
		SETCHAR(eSTPO_API02.VENDOR,"");
		SETCHAR(eSTPO_API02.VSI_NO,"");
		SETCHAR(eSTPO_API02.VSI_QTY,"");
		SETCHAR(eSTPO_API02.VSI_SIZE1,"");
		SETCHAR(eSTPO_API02.VSI_SIZE2,"");
		SETCHAR(eSTPO_API02.VSI_SIZE3,"");
		SETCHAR(eSTPO_API02.VSI_SZUNIT,"");
		SETCHAR(eSTPO_API02.VSI_FORMUL,"");
		SETCHAR(eSTPO_API02.DOCUMENT,"");
		SETCHAR(eSTPO_API02.DOC_TYPE,"");
		SETCHAR(eSTPO_API02.DOC_PART,"");
		SETCHAR(eSTPO_API02.DOC_VERS,"");
		SETCHAR(eSTPO_API02.aCLASS,"");
		SETCHAR(eSTPO_API02.CLASS_TYPE,"");
		SETCHAR(eSTPO_API02.RES_ITM_CT,"");
		SETCHAR(eSTPO_API02.SEL_COND,"");
		SETCHAR(eSTPO_API02.REQD_COMP,"");
		SETCHAR(eSTPO_API02.MULT_SELEC,"");
		SETCHAR(eSTPO_API02.REL_HLCONF,"");
		SETCHAR(eSTPO_API02.CAD_IND,"");
		SETCHAR(eSTPO_API02.ITM_IDENT,"");
		SETCHAR(eSTPO_API02.ITEM_GUID,"");
		SETCHAR(eSTPO_API02.VALID_FROM,"");
		SETCHAR(eSTPO_API02.CHANGE_NO,"");
		SETCHAR(eSTPO_API02.IDENTIFIER,"");
		SETCHAR(eSTPO_API02.SEGMENT_VALUE,"");
		SETNUM(eSTPO_API02.CUFACTOR,"");
		SETCHAR(eSTPO_API02.SAPMP_MET_LRCH,"");
		SETCHAR(eSTPO_API02.SAPMP_MAX_FERTL,"");
		SETCHAR(eSTPO_API02.SAPMP_FIX_AS_J,"");
		SETCHAR(eSTPO_API02.SAPMP_FIX_AS_E,"");
		SETCHAR(eSTPO_API02.SAPMP_FIX_AS_L,"");
		SETCHAR(eSTPO_API02.SAPMP_ABL_ZAHL,"");
		SETCHAR(eSTPO_API02.SAPMP_RUND_FAKT,"");
		//SETCHAR(eSTPO_API02.BOM_NO,"00007308");
		SETCHAR(eSTPO_API02.BOM_NO,bomnum1);
		SETNUM(eSTPO_API02.ITEM_NODE,"");
		SETNUM(eSTPO_API02.ITEM_COUNT,"");
		SETCHAR(eSTPO_API02.RECURSIVE,"");
		SETNUM(eSTPO_API02.DEP_LINK,"");
		SETCHAR(eSTPO_API02.ALE_IND,"");
		SETCHAR(eSTPO_API02.VALID_TO,"");
		SETCHAR(eSTPO_API02.CHG_NO_TO,"");
		SETCHAR(eSTPO_API02.CREATED_ON,"");
		SETCHAR(eSTPO_API02.CREATED_BY,"");
		SETCHAR(eSTPO_API02.CHANGED_ON,"");
		SETCHAR(eSTPO_API02.CHANGED_BY,"");
		SETCHAR(eSTPO_API02.BOM_ALT,"");
		SETCHAR(eSTPO_API02.FLDELETE,"");
		SETCHAR(eSTPO_API02.SEGMENT_RELEVANT,"");

		SETCHAR(eCSDATA_XFELD.XFELD,"");

		//printf("\ncll_CSAP_BOM_ITEM_MAINTAIN...:%s\n",childprt); fflush(stdout);
		OUTS("cll_CSAP_BOM_ITEM_MAINTAIN childprt",10,30,childprt);

		if (thDEP_DATA==ITAB_NULL)
		{
			 thDEP_DATA = ItCreate("T_DEP_DATA",sizeof(DEP_DATA),0,0);
			if (thDEP_DATA==ITAB_NULL) printf("ItCreate T_DEP_DATA");
		}
		else if (ItFree(thDEP_DATA)!= 0) printf("ItFree T_DEP_DATA");

		tDEP_DATA = ItAppLine (thDEP_DATA);

		if (tDEP_DATA == NULL) printf("ItAppLine T_DEP_DATA");


		SETCHAR(tDEP_DATA->DEP_INTERN,"");
		SETCHAR(tDEP_DATA->DEP_EXTERN,"");
		SETCHAR(tDEP_DATA->DEP_TYPE,"5");//5
		SETCHAR(tDEP_DATA->DEP_TYPE2,"");
		SETCHAR(tDEP_DATA->SCE_FLAG,"");
		SETCHAR(tDEP_DATA->STATUS,"1");
		SETCHAR(tDEP_DATA->GROUP,"");
		SETCHAR(tDEP_DATA->WHR_TO_USE,"");
		SETCHAR(tDEP_DATA->FLDELETE,"");


		if (thDEP_SOURCE==ITAB_NULL)
		{
			 thDEP_SOURCE = ItCreate("T_DEP_SOURCE",sizeof(DEP_SOURCE),0,0);
			if (thDEP_SOURCE==ITAB_NULL) printf("ItCreate T_DEP_SOURCE");
		}
		else if (ItFree(thDEP_SOURCE)!= 0) printf("ItFree T_DEP_SOURCE");



				int vflen=0;
			vflen=tc_strlen(vformula);


			if(vflen>0)
			{
				oFormula=subString(vformula,0,(vflen-0));
				tokSvr=strtok(oFormula,"$");

			}
			else
			{
				strcat(tokSvr," ");
			}
			i = 10;	//object dependancy (variant rule ) start with 10
					//each line increment with line 10 count i = i + 10
			while (tokSvr != NULL)
			{
				sprintf(sr_no,"%04d",i);
				printf("\nsr_no:: %s\t",sr_no);
				printf("tokSvr:: %s",tokSvr);

				tDEP_SOURCE  = ItAppLine (thDEP_SOURCE);
				if (tDEP_SOURCE == NULL)
				{
					//printf("\nItAppLine T_DEP_SOURCE\n");fflush(stdout);
					OUTS("ItAppLine T_DEP_SOURCE",10,30,"");
				}

				SETCHAR(tDEP_SOURCE->DEP_INTERN,"");
				SETCHAR(tDEP_SOURCE->DEP_EXTERN,"");

				SETNUM(tDEP_SOURCE->LINE_NO,sr_no);
				SETCHAR(tDEP_SOURCE->LINE,tokSvr);

				i = i + 10;

				tokSvr=strtok(NULL,"$");
			 }






		RfcRc = CSAP_BOM_ITEM_MAINTAIN(hRfc,&eSTPO_API02,&eCSDATA_XFELD,&iSTPO_API02,&iCAPIFLAG_FLWARNING,thDEP_DATA,/*thDEP_DESCR,thDEP_ORDER,*/thDEP_SOURCE,/*thDEP_DOC,*/xException);


		switch (RfcRc)
		{
			case RFC_OK:

				GETCHAR(iSTPO_API02.ITEM_CATEG,compnum);
				//printf("ITEM_CATEG:%s\n",compnum);fflush(stdout);
				OUTS("ITEM_CATEG",10,30,compnum);
				GETCHAR(iSTPO_API02.ITEM_NO,compnum);
				//printf("ITEM_NO:%s\n",compnum);fflush(stdout);
				OUTS("ITEM_NO",10,30,compnum);
				GETCHAR(iSTPO_API02.COMPONENT,compnum);
				GETCHAR(iSTPO_API02.COMPONENT,Child);
				//printf("COMPONENT:%s\n",compnum);fflush(stdout);
				OUTS("COMPONENT",10,30,compnum);
				/*GETCHAR(iSTPO_API02.COMP_QTY,compnum);
				printf("COMP_QTY:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.COMP_UNIT,compnum);
				printf("COMP_UNIT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.FIXED_QTY,compnum);
				printf("FIXED_QTY:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.ITEM_TEXT1,compnum);
				printf("ITEM_TEXT1:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.ITEM_TEXT2,compnum);
				printf("ITEM_TEXT2:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SORTSTRING,compnum);
				printf("SORTSTRING:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.REL_COST,compnum);
				printf("REL_COST:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.REL_ENGIN,compnum);
				printf("REL_ENGIN:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.REL_PMAINT,compnum);
				printf("REL_PMAINT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.REL_PROD,compnum);
				printf("REL_PROD:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.REL_SALES,compnum);
				printf("REL_SALES:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SPARE_PART,compnum);
				printf("SPARE_PART:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.MAT_PROVIS,compnum);
				printf("MAT_PROVIS:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.BULK_MAT,compnum);
				printf("BULK_MAT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.REC_ALLOWD,compnum);
				printf("REC_ALLOWD:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.COMP_SCRAP,compnum);
				printf("COMP_SCRAP:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.OP_SCRAP,compnum);
				printf("OP_SCRAP:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.OP_NET_IND,compnum);
				printf("OP_NET_IND:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.DISTR_KEY,compnum);
				printf("DISTR_KEY:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.EXPL_TYPE,compnum);
				printf("EXPL_TYPE:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SPPROCTYPE,compnum);
				printf("SPPROCTYPE:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SUPPLYAREA,compnum);
				printf("SUPPLYAREA:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.ISSUE_LOC,compnum);
				printf("ISSUE_LOC:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.LEAD_TIME,compnum);
				printf("LEAD_TIME:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.OP_LEAD_TM,compnum);
				printf("OP_LEAD_TM:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.OP_LT_UNIT,compnum);
				printf("OP_LT_UNIT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CO_PRODUCT,compnum);
				printf("CO_PRODUCT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.DISCON_GRP,compnum);
				printf("DISCON_GRP:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.FOLLOW_GRP,compnum);
				printf("FOLLOW_GRP:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.AI_GROUP,compnum);
				printf("AI_GROUP:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.AI_STRATEG,compnum);
				printf("AI_STRATEG:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.AI_PRIO,compnum);
				printf("AI_PRIO:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.USAGE_PROB,compnum);
				printf("USAGE_PROB:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.REFPOINT,compnum);
				printf("REFPOINT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.PM_ASSMBLY,compnum);
				printf("PM_ASSMBLY:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.COST_ELEM,compnum);
				printf("COST_ELEM:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.DELIV_TIME,compnum);
				printf("DELIV_TIME:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.GRP_TIME,compnum);
				printf("GRP_TIME:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.MAT_GROUP,compnum);
				printf("MAT_GROUP:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.PRICE,compnum);
				printf("PRICE:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.PRICE_UNIT,compnum);
				printf("PRICE_UNIT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CURRENCY,compnum);
				printf("CURRENCY:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.PURCH_GRP,compnum);
				printf("PURCH_GRP:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.PURCH_ORG,compnum);
				printf("PURCH_ORG:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.VENDOR,compnum);
				printf("VENDOR:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.VSI_NO,compnum);
				printf("VSI_NO:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.VSI_QTY,compnum);
				printf("VSI_QTY:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.VSI_SIZE1,compnum);
				printf("VSI_SIZE1:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.VSI_SIZE2,compnum);
				printf("VSI_SIZE2:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.VSI_SIZE3,compnum);
				printf("VSI_SIZE3:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.VSI_SZUNIT,compnum);
				printf("VSI_SZUNIT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.VSI_FORMUL,compnum);
				printf("VSI_FORMUL:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.DOCUMENT,compnum);
				printf("DOCUMENT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.DOC_TYPE,compnum);
				printf("DOC_TYPE:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.DOC_PART,compnum);
				printf("DOC_PART:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.DOC_VERS,compnum);
				printf("DOC_VERS:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.aCLASS,compnum);
				printf("aCLASS:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CLASS_TYPE,compnum);
				printf("CLASS_TYPE:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.RES_ITM_CT,compnum);
				printf("RES_ITM_CT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SEL_COND,compnum);
				printf("SEL_COND:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.REQD_COMP,compnum);
				printf("REQD_COMP:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.MULT_SELEC,compnum);
				printf("MULT_SELEC:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.REL_HLCONF,compnum);
				printf("REL_HLCONF:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CAD_IND,compnum);
				printf("CAD_IND:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.ITM_IDENT,compnum);
				printf("ITM_IDENT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.ITEM_GUID,compnum);
				printf("ITEM_GUID:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.VALID_FROM,compnum);
				printf("VALID_FROM:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CHANGE_NO,compnum);
				printf("CHANGE_NO:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.IDENTIFIER,compnum);
				printf("IDENTIFIER:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SEGMENT_VALUE,compnum);
				printf("SEGMENT_VALUE:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CUFACTOR,compnum);
				printf("CUFACTOR:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SAPMP_MET_LRCH,compnum);
				printf("SAPMP_MET_LRCH:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SAPMP_MAX_FERTL,compnum);
				printf("SAPMP_MAX_FERTL:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SAPMP_FIX_AS_J,compnum);
				printf("SAPMP_FIX_AS_J:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SAPMP_FIX_AS_E,compnum);
				printf("SAPMP_FIX_AS_E:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SAPMP_FIX_AS_L,compnum);
				printf("SAPMP_FIX_AS_L:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SAPMP_ABL_ZAHL,compnum);
				printf("SAPMP_ABL_ZAHL:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SAPMP_RUND_FAKT,compnum);
				printf("SAPMP_RUND_FAKT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.BOM_NO,compnum);
				printf("BOM_NO:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.ITEM_NODE,compnum);
				printf("ITEM_NODE:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.ITEM_COUNT,compnum);
				printf("ITEM_COUNT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.RECURSIVE,compnum);
				printf("RECURSIVE:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.DEP_LINK,compnum);
				printf("DEP_LINK:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.ALE_IND,compnum);
				printf("ALE_IND:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.VALID_TO,compnum);
				printf("VALID_TO:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CHG_NO_TO,compnum);
				printf("CHG_NO_TO:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CREATED_ON,compnum);
				printf("CREATED_ON:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CREATED_BY,compnum);
				printf("CREATED_BY:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CHANGED_ON,compnum);
				printf("CHANGED_ON:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.CHANGED_BY,compnum);
				printf("CHANGED_BY:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.BOM_ALT,compnum);
				printf("BOM_ALT:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.FLDELETE,compnum);
				printf("FLDELETE:%s\n",compnum);fflush(stdout);
				GETCHAR(iSTPO_API02.SEGMENT_RELEVANT,compnum);
				printf("SEGMENT_RELEVANT:%s\n",compnum);fflush(stdout);*/


				GETCHAR(iCAPIFLAG_FLWARNING.FLWARNING,wrnmsg);

				//printf("wrnmsg:%s\n",wrnmsg);fflush(stdout);
				//printf("RFCOK:\n");fflush(stdout);

				//printf("\n*********CSAP_BOM_ITEM_MAINTAIN**********%d\n",ItFill(thDEP_DATA));fflush(stdout);
				OUTI("CSAP_BOM_ITEM_MAINTAIN ItFill(thDEP_DATA)",10,30,ItFill(thDEP_DATA));
				for (crow = 1;crow <= ItFill(thDEP_DATA); crow++)
				{
					tDEP_DATA = ItGetLine(thDEP_DATA,crow);
					if (tDEP_DATA == NULL)
					{
						//printf("\nItGetLineT_DEP_DATA\n");fflush(stdout);
						OUTS("ItGetLineT_DEP_DATA",10,30,"");
					}
					//printf("DEP_INTERN:%04d %-.16s\n",crow,tDEP_DATA->DEP_INTERN);fflush(stdout);
					//printf("DEP_EXTERN:%04d %-.16s\n",crow,tDEP_DATA->DEP_EXTERN);fflush(stdout);

				}

				//printf("\n*********CSAP_BOM_ITEM_MAINTAIN.....thDEP_SOURCE**********%d",ItFill(thDEP_SOURCE));fflush(stdout);
				OUTI("CSAP_BOM_ITEM_MAINTAIN ItFill(thDEP_SOURCE)",10,30,ItFill(thDEP_SOURCE));
				fprintf(fpob,"\n%s^",Child);

				for (crow = 1;crow <= ItFill(thDEP_SOURCE); crow++)
				{
					tDEP_SOURCE = ItGetLine(thDEP_SOURCE,crow);
					if (tDEP_SOURCE == NULL)
					{
						//printf("\nItGetLineT_DEP_SOURCE\n");fflush(stdout);
						OUTS("nItGetLineT_DEP_SOURCE",10,30,"");
					}
					//printf("LINE_NO:%04d %s\t",crow,tDEP_SOURCE->LINE_NO);fflush(stdout);
					//printf("LINE:%04d %s\n",crow,tDEP_SOURCE->LINE);fflush(stdout);
					GETCHAR(tDEP_SOURCE->LINE_NO,compnum);
					OUTS("LINE_NO",10,30,compnum);

					GETCHAR(tDEP_SOURCE->LINE,compnum);
					GETCHAR(tDEP_SOURCE->LINE,ObjectDep);
					OUTS("LINE",10,30,compnum);

					//Child,ObjectDep

					fprintf(fpob,"%s",ObjectDep);


				}

					//cll_CSAP_MAT_BOM_CLOSE();


			break;
			case RFC_EXCEPTION:
				//printf("\nRFC EXCEPTION: %s\n",xException);
				rfc_error("RFC_EXCEPTION");
			break;
			case RFC_SYS_EXCEPTION:
				//printf("\nSystem Exception Raised!!!\n");
				rfc_error("RFC_SYS_EXCEPTION");
			break;
			case RFC_FAILURE:
				//printf("\nFailure!!!\n");
				rfc_error("RFC_FAILURE");
			break;
			default:
				//printf("\nOther Failure!\n");
				rfc_error("Other Failure");
			break;
		}

	}
	if ( fpob )
	{
		fclose ( fpob );
	}
	//if (ItDelete(thBapiret2) != 0) printf("ItDelete thBapiret2");

	//RfcClose(hRfc);
}


void cll_CSAP_MAT_BOM_CLOSE()
{
	//static RFC_RC RfcRc;
	//static RFC_HANDLE hRfc;
	char s[1024] = {0};
	char s1[1024] = {0};

	int crow=1;
	int crow1=1;
	char xException[256];
	//char sap_msg[1024] = { 0 };
	char wrnmsg[1024] = { 0 };

	CAPIFLAG_COMM_WAIT eCAPIFLAG_COMM_WAIT;
	CAPIFLAG_FLWARNING iCAPIFLAG_FLWARNING;

	//printf("cll_CSAP_MAT_BOM_CLOSE\n"); fflush(stdout);

	//Setting input argument for BAPI
	SETCHAR(eCAPIFLAG_COMM_WAIT.COMM_WAIT,"X");

	 //printf("\ncll_CSAP_MAT_BOM_CLOSE"); fflush(stdout);
	 OUTS("cll_CSAP_MAT_BOM_CLOSE",10,30,"");

	RfcRc = CSAP_MAT_BOM_CLOSE(hRfc,&eCAPIFLAG_COMM_WAIT,&iCAPIFLAG_FLWARNING,xException);
	switch (RfcRc)
	{
		case RFC_OK:
			GETCHAR(iCAPIFLAG_FLWARNING.FLWARNING,wrnmsg);
			//printf("iCAPIFLAG_FLWARNING:%s:\n",wrnmsg);fflush(stdout);
			OUTS("FLWARNING",10,30,wrnmsg);



		break;
		case RFC_EXCEPTION:
			//printf("\nRFC EXCEPTION: %s",xException);
			rfc_error("RFC_EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION:
			//printf("\nSystem Exception Raised!!!");
			rfc_error("RFC_SYS_EXCEPTION");
		break;
		case RFC_FAILURE:
			//printf("\nFailure!!!");
			rfc_error("RFC_FAILURE");
		break;
		default:
			//printf("\nOther Failure!");
			rfc_error("Other Failure");
		break;
	}

	//if (ItDelete(thBapiret2) != 0) printf("ItDelete thBapiret2");

	//RfcClose(hRfc);
}




RFC_RC CSAP_MAT_BOM_OPEN (	RFC_HANDLE				  hRfc,
				CSAP_MBOM_MATNR*		eCSAP_MBOM_MATNR,
				CSAP_MBOM_WERKS*		eCSAP_MBOM_WERKS,
				CSAP_MBOM_STLAN*	     eCSAP_MBOM_STLAN,
				CSAP_MBOM_STLAL*		eCSAP_MBOM_STLAL,
				CSAP_MBOM_DATUV*	    eCSAP_MBOM_DATUV,
				CSAP_MBOM_AENNR*	    eCSAP_MBOM_AENNR,
				CSAP_MBOM_REVLV*		 eCSAP_MBOM_REVLV,
				CAPIFLAG_NO_CHG_DOC*	 eCAPIFLAG_NO_CHG_DOC,
				STKO_API02*               iSTKO_API02,
				CAPIFLAG_FLWARNING*        iCAPIFLAG_FLWARNING,
				ITAB_H					    thSTPO_API02,
				ITAB_H					    thCSDEP_DAT,
				ITAB_H					    thCSDEP_DESC,
				ITAB_H					    thCSDEP_ORD,
				ITAB_H					    thCSDEP_SORC,
				ITAB_H					    thCSDEP_DOC,
				char*					    xException
	       )

{
	RFC_PARAMETER Exporting[9];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[7];
	//RFC_TABLE Tables[2];
	//RFC_RC RfcRc;
	char *RfcException = NULL;


	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfCSAP_MBOM_MATNR;
	Exporting[0].leng = sizeof(CSAP_MBOM_MATNR);
	Exporting[0].addr = eCSAP_MBOM_MATNR;

	Exporting[1].name = "PLANT";
	Exporting[1].nlen = 5;
	Exporting[1].type = handleOfCSAP_MBOM_WERKS;
	Exporting[1].leng = sizeof(CSAP_MBOM_WERKS);
	Exporting[1].addr = eCSAP_MBOM_WERKS;

	Exporting[2].name = "BOM_USAGE";
	Exporting[2].nlen = 9;
	Exporting[2].type = handleOfCSAP_MBOM_STLAN;
	Exporting[2].leng = sizeof(CSAP_MBOM_STLAN);
	Exporting[2].addr = eCSAP_MBOM_STLAN;

    Exporting[3].name = "ALTERNATIVE";
	Exporting[3].nlen = 11;
	Exporting[3].type = handleOfCSAP_MBOM_STLAL;
	Exporting[3].leng = sizeof(CSAP_MBOM_STLAL);
	Exporting[3].addr = eCSAP_MBOM_STLAL;

	Exporting[4].name = "VALID_FROM";
	Exporting[4].nlen = 10;
	Exporting[4].type = handleOfCSAP_MBOM_DATUV;
	Exporting[4].leng = sizeof(CSAP_MBOM_DATUV);
	Exporting[4].addr = eCSAP_MBOM_DATUV;

	Exporting[5].name = "CHANGE_NO";
	Exporting[5].nlen = 9;
	Exporting[5].type = handleOfCSAP_MBOM_AENNR;
	Exporting[5].leng = sizeof(CSAP_MBOM_AENNR);
	Exporting[5].addr = eCSAP_MBOM_AENNR;

	Exporting[6].name = "REVISION_LEVEL";
	Exporting[6].nlen = 14;
	Exporting[6].type = handleOfCSAP_MBOM_REVLV;
	Exporting[6].leng = sizeof(CSAP_MBOM_REVLV);
	Exporting[6].addr = eCSAP_MBOM_REVLV;


	Exporting[7].name = "FL_NO_CHANGE_DOC";
	Exporting[7].nlen = 16;
	Exporting[7].type = handleOfCAPIFLAG_NO_CHG_DOC;
	Exporting[7].leng = sizeof(CAPIFLAG_NO_CHG_DOC);
	Exporting[7].addr = eCAPIFLAG_NO_CHG_DOC;


    Exporting[8].name = NULL;


	Tables[0].name     = "T_STPO";
	Tables[0].nlen     = 6;
	Tables[0].type     = handleOfSTPO_API02;
	Tables[0].ithandle = thSTPO_API02;

	Tables[1].name     = "T_DEP_DATA";
	Tables[1].nlen     = 10;
	Tables[1].type     = handleOfCSDEP_DAT;
	Tables[1].ithandle = thCSDEP_DAT;

	Tables[2].name     = "T_DEP_DESCR";
	Tables[2].nlen     = 11;
	Tables[2].type     = handleOfCSDEP_DESC;
	Tables[2].ithandle = thCSDEP_DESC;

	Tables[3].name     = "T_DEP_ORDER";
	Tables[3].nlen     = 11;
	Tables[3].type     = handleOfCSDEP_ORD;
	Tables[3].ithandle = thCSDEP_ORD;

	Tables[4].name     = "T_DEP_SOURCE";
	Tables[4].nlen     = 12;
	Tables[4].type     = handleOfCSDEP_SORC;
	Tables[4].ithandle = thCSDEP_SORC;

	Tables[5].name     = "T_DEP_DOC";
	Tables[5].nlen     = 9;
	Tables[5].type     = handleOfCSDEP_DOC;
	Tables[5].ithandle = thCSDEP_DOC;

	Tables[6].name = NULL;


	RfcRc = RfcCall(hRfc,"CSAP_MAT_BOM_OPEN",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			Importing[0].name = "O_STKO";
			Importing[0].nlen = 6;
			Importing[0].type = handleOfSTKO_API02;
			Importing[0].leng = sizeof(STKO_API02);
			Importing[0].addr = iSTKO_API02;

            Importing[1].name = "FL_WARNING";
			Importing[1].nlen = 10;
			Importing[1].type = handleOfCAPIFLAG_FLWARNING;
			Importing[1].leng = sizeof(CAPIFLAG_FLWARNING);
			Importing[1].addr = iCAPIFLAG_FLWARNING;

			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
			break;
		default:
			//printf("\nNOT RFC OK\n");
			OUTS("Default",10,30,"");
			break;
	}
	return RfcRc;
}






RFC_RC CSAP_BOM_ITEM_MAINTAIN (	RFC_HANDLE				  hRfc,
				STPO_API02*		eSTPO_API02,
				CSDATA_XFELD*		eCSDATA_XFELD,
				STPO_API02*               iSTPO_API02,
				CAPIFLAG_FLWARNING*        iCAPIFLAG_FLWARNING,
				ITAB_H					    thDEP_DATA,
				//ITAB_H					    thDEP_DESCR,
				//ITAB_H					    thDEP_ORDER,
				ITAB_H					    thDEP_SOURCE,
				//ITAB_H					    thDEP_DOC,
				char*					    xException
	       )

{
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[3];
	//RFC_TABLE Tables[2];
	//RFC_RC RfcRc;
	char *RfcException = NULLTAG;


	Exporting[0].name = "I_STPO";
	Exporting[0].nlen = 6;
	Exporting[0].type = handleOfSTPO_API02;
	Exporting[0].leng = sizeof(STPO_API02);
	Exporting[0].addr = eSTPO_API02;

	Exporting[1].name = "FL_DEP_ALE_CONFORM";
	Exporting[1].nlen = 18;
	Exporting[1].type = handleOfCSDATA_XFELD;
	Exporting[1].leng = sizeof(CSDATA_XFELD);
	Exporting[1].addr = eCSDATA_XFELD;

    Exporting[2].name = NULLTAG;

	Tables[0].name     = "T_DEP_DATA";
	Tables[0].nlen     = 10;
	Tables[0].type     = handleOfDEP_DATA;
	Tables[0].ithandle = thDEP_DATA;

	/*Tables[1].name     = "T_DEP_DESCR";
	Tables[1].nlen     = 11;
	Tables[1].type     = handleOfDEP_DESCR;
	Tables[1].ithandle = thDEP_DESCR;

	Tables[2].name     = "T_DEP_ORDER";
	Tables[2].nlen     = 11;
	Tables[2].type     = handleOfDEP_ORDER;
	Tables[2].ithandle = thDEP_ORDER;*/

	Tables[1].name     = "T_DEP_SOURCE";
	Tables[1].nlen     = 12;
	Tables[1].type     = handleOfDEP_SOURCE;
	Tables[1].ithandle = thDEP_SOURCE;

	/*Tables[4].name     = "T_DEP_DOC";
	Tables[4].nlen     = 9;
	Tables[4].type     = handleOfDEP_DOC;
	Tables[4].ithandle = thDEP_DOC;*/

	Tables[2].name = NULLTAG;

	RfcRc = RfcCall(hRfc,"CSAP_BOM_ITEM_MAINTAIN",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			Importing[0].name = "O_STPO";
			Importing[0].nlen = 6;
			Importing[0].type = handleOfSTPO_API02;
			Importing[0].leng = sizeof(STPO_API02);
			Importing[0].addr = iSTPO_API02;

            Importing[1].name = "FL_WARNING";
			Importing[1].nlen = 10;
			Importing[1].type = handleOfCAPIFLAG_FLWARNING;
			Importing[1].leng = sizeof(CAPIFLAG_FLWARNING);
			Importing[1].addr = iCAPIFLAG_FLWARNING;

			Importing[2].name = NULLTAG;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
			break;
		default:
			//printf("\nNOT RFC OK\n");
			OUTS("Default1",10,30,"");
			break;
	}
	return RfcRc;
}


RFC_RC CSAP_MAT_BOM_CLOSE (	RFC_HANDLE				  hRfc,
				CAPIFLAG_COMM_WAIT*		eCAPIFLAG_COMM_WAIT,
				CAPIFLAG_FLWARNING*        iCAPIFLAG_FLWARNING,
				char*					    xException
	       )
{
	RFC_PARAMETER Exporting[2];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[1];
	//RFC_TABLE Tables[2];
	//RFC_RC RfcRc;
	char *RfcException = NULLTAG;


	Exporting[0].name = "FL_COMMIT_AND_WAIT";
	Exporting[0].nlen = 18;
	Exporting[0].type = handleOfCAPIFLAG_COMM_WAIT;
	Exporting[0].leng = sizeof(CAPIFLAG_COMM_WAIT);
	Exporting[0].addr = eCAPIFLAG_COMM_WAIT;

    Exporting[1].name = NULLTAG;


	Tables[0].name = NULLTAG;

	RfcRc = RfcCall(hRfc,"CSAP_MAT_BOM_CLOSE",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:

            Importing[0].name = "FL_WARNING";
			Importing[0].nlen = 10;
			Importing[0].type = handleOfCAPIFLAG_FLWARNING;
			Importing[0].leng = sizeof(CAPIFLAG_FLWARNING);
			Importing[0].addr = iCAPIFLAG_FLWARNING;

			Importing[1].name = NULLTAG;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
			break;
		default:
			//printf("\nNOT RFC OK\n");
			OUTS("Default2",10,30,"");
			break;
	}
	return RfcRc;
}

struct node* createnode(char sr_no[5],char *part,float* qty,char uq[4],char *formula,char *Potx1)

{
	struct node* p = NULL;

	p = (struct node*)malloc(sizeof(struct node));
	//strcpy(p->part,part);
	p->part = part;
	//p->part = tc_strdup(part);
	strcpy(p->sr_no,sr_no);
	strcpy(p->uq,uq);
	//strcpy(p->mat_prov_ind,mat_prov_ind);
	//strcpy(p->tempcsrel,tempcsrel);
	//p->make_buy_indDup=make_buy_indDup;
	p->qty = *qty;

	p->formula = (char*) malloc(10000 * sizeof(char));
	tc_strcpy(p->formula,formula);

	p->Potx1 = (char*) malloc(40 * sizeof(char));
	tc_strcpy(p->Potx1,Potx1);

	//p->usgProb = 0.000f;
	p->next = NULL;
	return p;
}

int search(struct node* start,char *part,float* qty)
{
	struct node* p;
	int found = 1 ;

	p = start;
	/*while(p->next!=NULL)*/
	while ( p != NULL )
	{
			if ( strcmp ( p->part, part ) == 0 )
			{
					//found;
					p->qty = p->qty + *qty;
					found = 0;
					break;
			}
			else
			{
				p = p->next;
				found = 1 ;
			}

		}
	return found;
}

char* subString(char* mainStringf ,int fromCharf ,	int toCharf)
{
    int i;
    char *retStringf;
    retStringf = (char*) malloc(toCharf+1);
    for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
    *(retStringf+i) = '\0';
    return retStringf;
}

SapBomCreate(char *assy_noDup, char *SapChangeNo,char* plantcode)
{
	//struct node *p=NULL;
	char sap_qty[18];


	char xException[256];
	//static RFC_HANDLE hRfc;
	//static RFC_RC RfcRc;

	CAD_BICSK eIBomHeader;
	DRAW_LOEDK eIAutoPosnr;
	CAD_BICSK iEBomHeader;
	MESSAGE_MSGTX iEMessage;
	CAD_RETURN_MESSAGE_LEN iEMessageLen;
	CAD_RETURN_VALUE iEReturn;
	ITAB_H thBomItem = ITAB_NULL;
	CAD_BOM_ITEM *tBomItem;



	//hRfc = BapiLogon();
	thBomItem = ITAB_NULL;
	if (thBomItem==ITAB_NULL)
	{
		thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
		if (thBomItem==ITAB_NULL)
				printf("\nItCreateBOM_ITEM");
	}
	else
	{
		if (ItFree(thBomItem) != 0)
			printf("\nItFreeBOM_ITEM");
	}

	printf("\nAssembly:[%s][%s]\n",assy_noDup,plantcode);



	SETCHAR(eIAutoPosnr,"");
	SETCHAR(eIBomHeader.Matnr,assy_noDup);
	//SETCHAR(eIBomHeader.Matnr,"X4_SUPERBOM_HD_3");
	SETCHAR(eIBomHeader.Werks,plantcode);
	//SETCHAR(eIBomHeader.Werks,"1100");
	SETCHAR(eIBomHeader.Stlan,"1");
	SETCHAR(eIBomHeader.Stlal,"01");
	//SETCHAR(eIBomHeader.Aennr,"CORRCT0704MT");
	SETCHAR(eIBomHeader.Aennr,SapChangeNo);
	//SETCHAR(eIBomHeader.Datuv,"16042019");
	SETCHAR(eIBomHeader.Datuv,"");//date required
	SETCHAR(eIBomHeader.Stype,"");
	SETCHAR(eIBomHeader.Tcode,"CS01");
	SETCHAR(eIBomHeader.Bmein,"");
	SETCHAR(eIBomHeader.Bmeng,"");
	SETCHAR(eIBomHeader.Cadkz,"");
	SETCHAR(eIBomHeader.Datub,"");
	SETCHAR(eIBomHeader.Emeng,"");
	SETCHAR(eIBomHeader.Equnr,"");
	SETCHAR(eIBomHeader.Exstl,"");
	SETCHAR(eIBomHeader.Labor,"");
	SETCHAR(eIBomHeader.Loekz,"");
	SETCHAR(eIBomHeader.Losbs,"");
	SETCHAR(eIBomHeader.Losvn,"");
	SETCHAR(eIBomHeader.Selal,"");
	SETCHAR(eIBomHeader.Serge,"");
	SETCHAR(eIBomHeader.Stktx,"");
	SETCHAR(eIBomHeader.Stlbe,"");
	SETCHAR(eIBomHeader.Stlst,"");
	SETCHAR(eIBomHeader.Vmtnr,"");
	SETCHAR(eIBomHeader.Ztext,"");
	SETCHAR(eIBomHeader.Revlv,"");
	SETCHAR(eIBomHeader.Tplnr,"");
	SETCHAR(eIBomHeader.Dokar,"");
	SETCHAR(eIBomHeader.Doknr,"");
	SETCHAR(eIBomHeader.Doktl,"");
	SETCHAR(eIBomHeader.Dokvr,"");
	SETCHAR(eIBomHeader.Vbeln,"");
	SETNUM(eIBomHeader.Vbpos,"000000");
	SETCHAR(eIBomHeader.Stobj,"");
	SETCHAR(eIBomHeader.Vdknr,"");
	SETCHAR(eIBomHeader.Vdkar,"");
	SETCHAR(eIBomHeader.Vdktl,"");
	SETCHAR(eIBomHeader.Vdkvr,"");
	SETCHAR(eIBomHeader.Veqnr,"");
	SETCHAR(eIBomHeader.Vtpnr,"");
	SETCHAR(eIBomHeader.Pspnr,"");
	SETCHAR(eIBomHeader.Oitxt,"");
	SETCHAR(eIBomHeader.MatnrLong,"");




	RfcRc = cad_create_bom_with_sub_items(hRfc,&eIAutoPosnr,&eIBomHeader,&iEBomHeader,&iEMessage,&iEMessageLen,&iEReturn,thBomItem,xException);
	 switch (RfcRc)
	  {
	     case RFC_OK :
							/*for (crow = 1;crow <= ItFill(thBomItem); crow++)
							{
							    tBomItem = ItGetLine(thBomItem,crow);
							    if (tBomItem == NULL)
									printf("ItGetLineBOM_ITEM");
								strcpy(comp_sap,"");
							    strncpy(comp_sap,tBomItem->Idnrk,15);
							    printf("\nBomItem:%04d %15s",crow,comp_sap);
							    fprintf(fgen,"\nBomItem:%04d %15s",crow,comp_sap);
							}*/
							printf("\n\nMESSAGE FOR BOM %s CREATE:%s\n\n",assy_noDup,iEMessage);

							break;
	     case RFC_EXCEPTION :
							//printf("\nexception\n");
							rfc_error("RFC_EXCEPTION");
							break;
	     case RFC_SYS_EXCEPTION :
							//printf("\nsystem exception raised\n");
							rfc_error("RFC_SYS_EXCEPTION");
							break;
	     case RFC_FAILURE :
							//printf("\nfailure\n");
							rfc_error("RFC_FAILURE");
							break;
	     default :
							//printf("\nother failure\n");
							rfc_error("other failure");
							break;
	   }
	 if (ItDelete(thBomItem) != 0)
	   //printf("\nItDelete BOM_ITEM");
	 OUTS("ItDelete BOM_ITEM",10,30,"");

}

RFC_RC  cad_create_bom_with_sub_items(RFC_HANDLE hRfc, DRAW_LOEDK *eIAutoPosnr, CAD_BICSK *eIBomHeader, CAD_BICSK *iEBomHeader, MESSAGE_MSGTX *iEMessage, CAD_RETURN_MESSAGE_LEN *iEMessageLen, CAD_RETURN_VALUE *iEReturn, ITAB_H thBomItem, char *xException)
{
  /* RFC variables */
  RFC_PARAMETER Exporting[3];
  //RFC_PARAMETER Importing[5];
  RFC_PARAMETER Importing[2];
  //RFC_TABLE Tables[2];
  RFC_TABLE Tables[1];
//  RFC_RC RfcRc;
  char *RfcException = NULL;
  /* define export params */
  Exporting[0].name = "I_AUTO_POSNR";
  Exporting[0].nlen = 12;
  Exporting[0].type = TYPC;
  Exporting[0].leng = sizeof(DRAW_LOEDK);
  Exporting[0].addr = eIAutoPosnr;

  Exporting[1].name = "I_BOM_HEADER";
  Exporting[1].nlen = 12;
  Exporting[1].type = handleOfCAD_BICSK;
  Exporting[1].leng = sizeof(CAD_BICSK);
  Exporting[1].addr = eIBomHeader;

  Exporting[2].name = NULL;



  /*Tables[0].name     = "BOM_ITEM";
  Tables[0].nlen     = 8;
  Tables[0].type     = handleOfCAD_BOM_ITEM;
  Tables[0].ithandle = thBomItem;

  Tables[1].name = NULL;*/

	Tables[0].name = NULL;


  RfcRc = RfcCall(hRfc,"CAD_CREATE_BOM_WITH_SUB_ITEMS",Exporting,Tables);
  switch (RfcRc)
  {
    case RFC_OK :

		  /*Importing[0].name = "E_BOM_HEADER";
		  Importing[0].nlen = 12;
		  Importing[0].type = handleOfCAD_BICSK;
		  Importing[0].leng = sizeof(CAD_BICSK);
		  Importing[0].addr = iEBomHeader;

		  Importing[1].name = "E_MESSAGE";
		  Importing[1].nlen = 9;
		  Importing[1].type = TYPC;
		  Importing[1].leng = sizeof(MESSAGE_MSGTX);
		  Importing[1].addr = iEMessage;

		  Importing[2].name = "E_MESSAGE_LEN";
		  Importing[2].nlen = 13;
		  Importing[2].type = TYPC;
		  Importing[2].leng = sizeof(CAD_RETURN_MESSAGE_LEN);
		  Importing[2].addr = iEMessageLen;

		  Importing[3].name = "E_RETURN";
		  Importing[3].nlen = 8;
		  Importing[3].type = TYPC;
		  Importing[3].leng = sizeof(CAD_RETURN_VALUE);
		  Importing[3].addr = iEReturn;

		  Importing[4].name = NULL;*/

		  Importing[0].name = "E_MESSAGE";
		  Importing[0].nlen = 9;
		  Importing[0].type = TYPC;
		  Importing[0].leng = sizeof(MESSAGE_MSGTX);
		  Importing[0].addr = iEMessage;

		  Importing[1].name = NULL;


		  RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
		  /* printf("\nMessage Received:%s",RfcException);*/

	switch (RfcRc)
	{
			case RFC_SYS_EXCEPTION :

				printf("\nRFC_SYS_EXCEPTION: %s\n",xException);
				break;
			case RFC_EXCEPTION :

				printf("\nRFC_EXCEPTION: %s\n",xException);
				break;
	}
	break;
	default:
			printf("Not ok\n");

  }
  return RfcRc;
}


RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException)
{
	//RFC_RC RfcRc;
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[1];
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfMATNR;
	Exporting[0].leng = sizeof(MATNR);
	Exporting[0].addr = eMatnr;

	Exporting[1].name = "PLANT";
	Exporting[1].nlen = 5;
	Exporting[1].type = handleOfWERKS_D;
	Exporting[1].leng = sizeof(WERKS_D);
	Exporting[1].addr = eWerks;

	Exporting[2].name = NULL;


	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_MATERIAL_GETALL",Exporting,Tables);

	switch (RfcRc)
	{
	  	case RFC_OK :

			Importing[0].name = "CLIENTDATA";
			Importing[0].nlen = 10;
			Importing[0].type = handleOfCLIENTDATA;
			Importing[0].leng = sizeof(CLIENTDATA);
			Importing[0].addr = iView;

			Importing[1].name = "PLANTDATA";
			Importing[1].nlen = 9;
			Importing[1].type = handleOfPLANTDATA;
			Importing[1].leng = sizeof(PLANTDATA);
			Importing[1].addr = iMrpView;

			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
	  			case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
		default: ;
	}
	return RfcRc;
}


int GetCSPstat(char cMaterial[50],char* plantcode)
{
char xException[256];
//RFC_HANDLE hRfc;
//RFC_RC RfcRc;
MATNR eMatnr;
WERKS_D eWerks;
PLANTDATA iMrpView;
CLIENTDATA iView;

//printf("Processing GetCSPstat:[%s]\n\t\t",cMaterial);

hRfc = BapiLogon();

//strcpy(sap_proc_type,"");
//strcpy(sap_spproc_type,"");
strcpy(SAPpstat,"");
strcpy(MRPpstat,"");

SETCHAR(eMatnr.Matnr,cMaterial);
//SETCHAR(eMatnr.Matnr,part_noDup);
SETCHAR(eWerks.WerksD,plantcode);
//SETCHAR(eWerks.WerksD,"1100");

//printf("\nhRfc:%d",hRfc);
RfcRc = export_CSpastat(hRfc,&eMatnr,&eWerks,&iMrpView,&iView,xException);

switch (RfcRc)
{
	case RFC_OK:
		//printf("\n In RFC_OK case...\n");	fflush(stdout);
		//GETCHAR(iMrpView.PROC_TYPE, proc_type1);		OUTS("PROC_TYPE",10,30,proc_type1);
		//GETCHAR(iMrpView.SPPROCTYPE, spproc_type);		OUTS("SPPROCTYPE",10,30,spproc_type);

		GETCHAR(iMrpView.PROC_TYPE, sap_proc_type);		//OUTS("PROC_TYPE",10,30,sap_proc_type);
		GETCHAR(iMrpView.SPPROCTYPE, sap_spproc_type);	//OUTS("SPPROCTYPE",10,30,sap_spproc_type);

		GETCHAR(iView.MAINT_STAT, SAPpstat);
		SAPpstat[14] = '\0';
		//OUTS("SAPpstat",10,30,SAPpstat);

		GETCHAR(iMrpView.MAINT_STAT, MRPpstat);
		MRPpstat[14] = '\0';
		//OUTS("MRPpstat",10,30,MRPpstat);

		//printf("\n...SAPpstat:[%s]\n\n",SAPpstat);
		//printf("\n...Material[%s]; proc_type1:[%s]; spproc_type:[%s]; SAPpstat:[%s]\n\n",cMaterial,proc_type1,spproc_type,SAPpstat);

	break;
	case RFC_EXCEPTION:
		//printf("\nRFC Exception : %s\n",xException);
		rfc_error("RFC_EXCEPTION");
	break;
	case RFC_SYS_EXCEPTION:
		//printf("\nSystem Exception Raised!!!\n");
		rfc_error("RFC_SYS_EXCEPTION");
	break;
	case RFC_FAILURE:
		//printf("\nFailure!!!\n");
		rfc_error("RFC_FAILURE");
	break;
	default:
		printf("\nOther Failure!\n");
		exit(0);
}

RfcClose(hRfc);
return 0;
}

int pstat_basicFun(void)
{
	if(tc_strstr(SAPpstat,"K"))
	{
		pstat = 'K';
	}
	else
	{
		pstat = '0';
	}

	if(tc_strstr(MRPpstat,"D"))
	{
		pstat_mrp = 'D';
	}
	else
	{
		pstat_mrp = '0';
	}

	if(tc_strstr(MRPpstat,"B"))
	{
		pstat_acc = 'B';
	}
	else
	{
		pstat_acc = '0';
	}
	return 0;
}

RFC_RC ccap_ecn_create(RFC_HANDLE hRfc,AENR_API01 *eChangeHeader,CSDATA_XFELD *eFlAle,CSDATA_XFELD *eFlCommitAndWait,CSDATA_XFELD *eFlNoCommitWork,AENV_API01 *eObjectBom,AENV_API01 *eObjectBomCus,AENV_API01 *eObjectBomDoc,AENV_API01 *eObjectBomEqui,AENV_API01 *eObjectBomLoc,AENV_API01 *eObjectBomMat,AENV_API01 *eObjectBomPsp,AENV_API01 *eObjectBomStd,AENV_API01 *eObjectChar,AENV_API01 *eObjectCls,AENV_API01 *eObjectClsMaint,AENV_API01 *eObjectConfProf,AENV_API01 *eObjectDep,AENV_API01 *eObjectDoc,AENV_API01 *eObjectHazmat,AENV_API01 *eObjectMat,AENV_API01 *eObjectPhrase,AENV_API01 *eObjectPvs,AENV_API01 *eObjectPvsAlt,AENV_API01 *eObjectPvsRel,AENV_API01 *eObjectPvsVar,AENV_API01 *eObjectSubstance,AENV_API01 *eObjectTlist,AENV_API01 *eObjectTlist2,AENV_API01 *eObjectTlistA,AENV_API01 *eObjectTlistE,AENV_API01 *eObjectTlistM,AENV_API01 *eObjectTlistN,AENV_API01 *eObjectTlistQ,AENV_API01 *eObjectTlistR,AENV_API01 *eObjectTlistS,AENV_API01 *eObjectTlistT,AENV_API01 *eObjectValidMatvers,AENV_API01 *eObjectVarTab,AEEF_API01 *eValueAssign,AENRB_AENNR *iChangeNo,ITAB_H thAltDates,ITAB_H thEffectivity,ITAB_H thObjmgrec,ITAB_H thTextheader,ITAB_H thTextlines,char *xException)
{
	RFC_PARAMETER Exporting[40];
	RFC_PARAMETER Importing[2];
	/*RFC_TABLE Tables[6];*/
	RFC_TABLE Tables[1];
	RFC_RC RfcRc;
	char *RfcException = NULL;
	Exporting[0].name = "CHANGE_HEADER";
	Exporting[0].nlen = 13;
	Exporting[0].type = handleOfAENR_API01;
	Exporting[0].leng = sizeof(AENR_API01);
	Exporting[0].addr = eChangeHeader;

	Exporting[1].name = "FL_ALE";
	Exporting[1].nlen = 6;
	Exporting[1].type = TYPC;
	Exporting[1].leng = sizeof(CSDATA_XFELD);
	Exporting[1].addr = eFlAle;

	Exporting[2].name = "FL_COMMIT_AND_WAIT";
	Exporting[2].nlen = 18;
	Exporting[2].type = TYPC;
	Exporting[2].leng = sizeof(CSDATA_XFELD);
	Exporting[2].addr = eFlCommitAndWait;

	Exporting[3].name = "FL_NO_COMMIT_WORK";
	Exporting[3].nlen = 17;
	Exporting[3].type = TYPC;
	Exporting[3].leng = sizeof(CSDATA_XFELD);
	Exporting[3].addr = eFlNoCommitWork;

	Exporting[4].name = "OBJECT_BOM";
	Exporting[4].nlen = 10;
	Exporting[4].type = handleOfAENV_API01;
	Exporting[4].leng = sizeof(AENV_API01);
	Exporting[4].addr = eObjectBom;

	Exporting[5].name = "OBJECT_BOM_CUS";
	Exporting[5].nlen = 14;
	Exporting[5].type = handleOfAENV_API01;
	Exporting[5].leng = sizeof(AENV_API01);
	Exporting[5].addr = eObjectBomCus;

	Exporting[6].name = "OBJECT_BOM_DOC";
	Exporting[6].nlen = 14;
	Exporting[6].type = handleOfAENV_API01;
	Exporting[6].leng = sizeof(AENV_API01);
	Exporting[6].addr = eObjectBomDoc;

	Exporting[7].name = "OBJECT_BOM_EQUI";
	Exporting[7].nlen = 15;
	Exporting[7].type = handleOfAENV_API01;
	Exporting[7].leng = sizeof(AENV_API01);
	Exporting[7].addr = eObjectBomEqui;

	Exporting[8].name = "OBJECT_BOM_LOC";
	Exporting[8].nlen = 14;
	Exporting[8].type = handleOfAENV_API01;
	Exporting[8].leng = sizeof(AENV_API01);
	Exporting[8].addr = eObjectBomLoc;

	Exporting[9].name = "OBJECT_BOM_MAT";
	Exporting[9].nlen = 14;
	Exporting[9].type = handleOfAENV_API01;
	Exporting[9].leng = sizeof(AENV_API01);
	Exporting[9].addr = eObjectBomMat;

	Exporting[10].name = "OBJECT_BOM_PSP";
	Exporting[10].nlen = 14;
	Exporting[10].type = handleOfAENV_API01;
	Exporting[10].leng = sizeof(AENV_API01);
	Exporting[10].addr = eObjectBomPsp;

	Exporting[11].name = "OBJECT_BOM_STD";
	Exporting[11].nlen = 14;
	Exporting[11].type = handleOfAENV_API01;
	Exporting[11].leng = sizeof(AENV_API01);
	Exporting[11].addr = eObjectBomStd;

	Exporting[12].name = "OBJECT_CHAR";
	Exporting[12].nlen = 11;
	Exporting[12].type = handleOfAENV_API01;
	Exporting[12].leng = sizeof(AENV_API01);
	Exporting[12].addr = eObjectChar;

	Exporting[13].name = "OBJECT_CLS";
	Exporting[13].nlen = 10;
	Exporting[13].type = handleOfAENV_API01;
	Exporting[13].leng = sizeof(AENV_API01);
	Exporting[13].addr = eObjectCls;

	Exporting[14].name = "OBJECT_CLS_MAINT";
	Exporting[14].nlen = 16;
	Exporting[14].type = handleOfAENV_API01;
	Exporting[14].leng = sizeof(AENV_API01);
	Exporting[14].addr = eObjectClsMaint;

	Exporting[15].name = "OBJECT_CONF_PROF";
	Exporting[15].nlen = 16;
	Exporting[15].type = handleOfAENV_API01;
	Exporting[15].leng = sizeof(AENV_API01);
	Exporting[15].addr = eObjectConfProf;

	Exporting[16].name = "OBJECT_DEP";
	Exporting[16].nlen = 10;
	Exporting[16].type = handleOfAENV_API01;
	Exporting[16].leng = sizeof(AENV_API01);
	Exporting[16].addr = eObjectDep;

	Exporting[17].name = "OBJECT_DOC";
	Exporting[17].nlen = 10;
	Exporting[17].type = handleOfAENV_API01;
	Exporting[17].leng = sizeof(AENV_API01);
	Exporting[17].addr = eObjectDoc;

	Exporting[18].name = "OBJECT_HAZMAT";
	Exporting[18].nlen = 13;
	Exporting[18].type = handleOfAENV_API01;
	Exporting[18].leng = sizeof(AENV_API01);
	Exporting[18].addr = eObjectHazmat;

	Exporting[19].name = "OBJECT_MAT";
	Exporting[19].nlen = 10;
	Exporting[19].type = handleOfAENV_API01;
	Exporting[19].leng = sizeof(AENV_API01);
	Exporting[19].addr = eObjectMat;

	Exporting[20].name = "OBJECT_PHRASE";
	Exporting[20].nlen = 13;
	Exporting[20].type = handleOfAENV_API01;
	Exporting[20].leng = sizeof(AENV_API01);
	Exporting[20].addr = eObjectPhrase;

	Exporting[21].name = "OBJECT_PVS";
	Exporting[21].nlen = 10;
	Exporting[21].type = handleOfAENV_API01;
	Exporting[21].leng = sizeof(AENV_API01);
	Exporting[21].addr = eObjectPvs;

	Exporting[22].name = "OBJECT_PVS_ALT";
	Exporting[22].nlen = 14;
	Exporting[22].type = handleOfAENV_API01;
	Exporting[22].leng = sizeof(AENV_API01);
	Exporting[22].addr = eObjectPvsAlt;

	Exporting[23].name = "OBJECT_PVS_REL";
	Exporting[23].nlen = 14;
	Exporting[23].type = handleOfAENV_API01;
	Exporting[23].leng = sizeof(AENV_API01);
	Exporting[23].addr = eObjectPvsRel;

	Exporting[24].name = "OBJECT_PVS_VAR";
	Exporting[24].nlen = 14;
	Exporting[24].type = handleOfAENV_API01;
	Exporting[24].leng = sizeof(AENV_API01);
	Exporting[24].addr = eObjectPvsVar;

	Exporting[25].name = "OBJECT_SUBSTANCE";
	Exporting[25].nlen = 16;
	Exporting[25].type = handleOfAENV_API01;
	Exporting[25].leng = sizeof(AENV_API01);
	Exporting[25].addr = eObjectSubstance;

	Exporting[26].name = "OBJECT_TLIST";
	Exporting[26].nlen = 12;
	Exporting[26].type = handleOfAENV_API01;
	Exporting[26].leng = sizeof(AENV_API01);
	Exporting[26].addr = eObjectTlist;

	Exporting[27].name = "OBJECT_TLIST_2";
	Exporting[27].nlen = 14;
	Exporting[27].type = handleOfAENV_API01;
	Exporting[27].leng = sizeof(AENV_API01);
	Exporting[27].addr = eObjectTlist2;

	Exporting[28].name = "OBJECT_TLIST_A";
	Exporting[28].nlen = 14;
	Exporting[28].type = handleOfAENV_API01;
	Exporting[28].leng = sizeof(AENV_API01);
	Exporting[28].addr = eObjectTlistA;

	Exporting[29].name = "OBJECT_TLIST_E";
	Exporting[29].nlen = 14;
	Exporting[29].type = handleOfAENV_API01;
	Exporting[29].leng = sizeof(AENV_API01);
	Exporting[29].addr = eObjectTlistE;

	Exporting[30].name = "OBJECT_TLIST_M";
	Exporting[30].nlen = 14;
	Exporting[30].type = handleOfAENV_API01;
	Exporting[30].leng = sizeof(AENV_API01);
	Exporting[30].addr = eObjectTlistM;

	Exporting[31].name = "OBJECT_TLIST_N";
	Exporting[31].nlen = 14;
	Exporting[31].type = handleOfAENV_API01;
	Exporting[31].leng = sizeof(AENV_API01);
	Exporting[31].addr = eObjectTlistN;

	Exporting[32].name = "OBJECT_TLIST_Q";
	Exporting[32].nlen = 14;
	Exporting[32].type = handleOfAENV_API01;
	Exporting[32].leng = sizeof(AENV_API01);
	Exporting[32].addr = eObjectTlistQ;

	Exporting[33].name = "OBJECT_TLIST_R";
	Exporting[33].nlen = 14;
	Exporting[33].type = handleOfAENV_API01;
	Exporting[33].leng = sizeof(AENV_API01);
	Exporting[33].addr = eObjectTlistR;

	Exporting[34].name = "OBJECT_TLIST_S";
	Exporting[34].nlen = 14;
	Exporting[34].type = handleOfAENV_API01;
	Exporting[34].leng = sizeof(AENV_API01);
	Exporting[34].addr = eObjectTlistS;

	Exporting[35].name = "OBJECT_TLIST_T";
	Exporting[35].nlen = 14;
	Exporting[35].type = handleOfAENV_API01;
	Exporting[35].leng = sizeof(AENV_API01);
	Exporting[35].addr = eObjectTlistT;

	Exporting[36].name = "OBJECT_VALID_MATVERS";
	Exporting[36].nlen = 20;
	Exporting[36].type = handleOfAENV_API01;
	Exporting[36].leng = sizeof(AENV_API01);
	Exporting[36].addr = eObjectValidMatvers;

	Exporting[37].name = "OBJECT_VAR_TAB";
	Exporting[37].nlen = 14;
	Exporting[37].type = handleOfAENV_API01;
	Exporting[37].leng = sizeof(AENV_API01);
	Exporting[37].addr = eObjectVarTab;

	Exporting[38].name = "VALUE_ASSIGN";
	Exporting[38].nlen = 12;
	Exporting[38].type = handleOfAEEF_API01;
	Exporting[38].leng = sizeof(AEEF_API01);
	Exporting[38].addr = eValueAssign;

	Exporting[39].name = NULL;

	/*Tables[0].name     = "ALT_DATES";
	Tables[0].nlen     = 9;
	Tables[0].type     = handleOfAEDT_API01;
	Tables[0].ithandle = thAltDates;

	Tables[1].name     = "EFFECTIVITY";
	Tables[1].nlen     = 11;
	Tables[1].type     = handleOfAEEF_API01;
	Tables[1].ithandle = thEffectivity;

	Tables[2].name     = "OBJMGREC";
	Tables[2].nlen     = 8;
	Tables[2].type     = handleOfAEOI_API01;
	Tables[2].ithandle = thObjmgrec;

	Tables[3].name     = "TEXTHEADER";
	Tables[3].nlen     = 10;
	Tables[3].type     = handleOfCCTHEAD;
	Tables[3].ithandle = thTextheader;

	Tables[4].name     = "TEXTLINES";
	Tables[4].nlen     = 9;
	Tables[4].type     = handleOfCCTLINE;
	Tables[4].ithandle = thTextlines;

	Tables[5].name = NULL;*/

	Tables[0].name = NULL;


	RfcRc = RfcCall(hRfc,"CCAP_ECN_CREATE",Exporting,Tables);
	//RfcRc = RfcCall(hRfc,"CCAP_ECN_MAINTAIN",Exporting,Tables);



	switch (RfcRc)
	{
		case RFC_OK:
			Importing[0].name = "CHANGE_NO";
			Importing[0].nlen = 9;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(AENRB_AENNR);
			Importing[0].addr = iChangeNo;

			Importing[1].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;

				case RFC_EXCEPTION:
				    strcpy(xException,RfcException);
					break;
				default:;
			}
		default:
			//printf("\nYou are in Default case %d",RfcRc);
			OUTI("You are in Default case",10,30,RfcRc);
	}
	return RfcRc;
}
void getTodayDate(char StdDate[11])
{
    struct tm *Sys_T = NULL;
    int Month;
    int Day;
    int Year;
    time_t Tval = 0;
    Tval = time(NULL);
    Sys_T = localtime(&Tval);
    Day=Sys_T->tm_mday;
    Month=Sys_T->tm_mon+1;
    Year=1900 + Sys_T->tm_year;
    sprintf(StdDate,"%02d.%02d.%04d",Day,Month,Year);
}
void cll_ccap_ecn_create(char* dmlno)
{
		//static RFC_HANDLE hRfc;
		static RFC_RC RfcRc;

		//int noOfParts;
		char StdDate[11] = { 0 };

		AENR_API01 eChangeHeader;
		CSDATA_XFELD eFlAle;
		CSDATA_XFELD eFlCommitAndWait;
		CSDATA_XFELD eFlNoCommitWork;
		AENV_API01 eObjectBom;
		AENV_API01 eObjectBomCus;
		AENV_API01 eObjectBomDoc;
		AENV_API01 eObjectBomEqui;
		AENV_API01 eObjectBomLoc;
		AENV_API01 eObjectBomMat;
		AENV_API01 eObjectBomPsp;
		AENV_API01 eObjectBomStd;
		AENV_API01 eObjectChar;
		AENV_API01 eObjectCls;
		AENV_API01 eObjectClsMaint;
		AENV_API01 eObjectConfProf;
		AENV_API01 eObjectDep;
		AENV_API01 eObjectDoc;
		AENV_API01 eObjectHazmat;
		AENV_API01 eObjectMat;
		AENV_API01 eObjectPhrase;
		AENV_API01 eObjectPvs;
		AENV_API01 eObjectPvsAlt;
		AENV_API01 eObjectPvsRel;
		AENV_API01 eObjectPvsVar;
		AENV_API01 eObjectSubstance;
		AENV_API01 eObjectTlist;
		AENV_API01 eObjectTlist2;
		AENV_API01 eObjectTlistA;
		AENV_API01 eObjectTlistE;
		AENV_API01 eObjectTlistM;
		AENV_API01 eObjectTlistN;
		AENV_API01 eObjectTlistQ;
		AENV_API01 eObjectTlistR;
		AENV_API01 eObjectTlistS;
		AENV_API01 eObjectTlistT;
		AENV_API01 eObjectValidMatvers;
		AENV_API01 eObjectVarTab;
		AEEF_API01 eValueAssign;
		AENRB_AENNR iChangeNo;
		ITAB_H thAltDates = ITAB_NULL;
		ITAB_H thEffectivity = ITAB_NULL;
		ITAB_H thObjmgrec = ITAB_NULL;
		ITAB_H thTextheader = ITAB_NULL;
		ITAB_H thTextlines = ITAB_NULL;
		char xException[256];
		AEOI_API01 *tObjmgrec;

		hRfc = BapiLogon();
		getTodayDate(StdDate);
		printf("\nChangeno:[%s]Date:[%s]",dmlno,StdDate);
		SETCHAR(eChangeHeader.ChangeNo,dmlno);/*dml_no*/
		//SETCHAR(eChangeHeader.ChangeNo,"13SM000108ST");/*dml_no*/
		SETNUM(eChangeHeader.Status,"01");
		SETCHAR(eChangeHeader.AuthGroup,"");
		//SETCHAR(eChangeHeader.ValidFrom,StdDate);/*StdDate*/
		SETCHAR(eChangeHeader.ValidFrom,StdDate);/*StdDate*/
		//SETCHAR(eChangeHeader.ValidFrom,"07.04.2017");/*StdDate*/
		SETCHAR(eChangeHeader.Descript,"partwise rev xfr change no");/*tempstr*/
		//SETCHAR(eChangeHeader.Descript,"FOR Latest IPL updation by 14th Aug13");/*tempstr*/
		SETCHAR(eChangeHeader.ReasonChg,"");
		SETCHAR(eChangeHeader.DeletionMark,"");
		SETCHAR(eChangeHeader.IndateRule,"");
		SETCHAR(eChangeHeader.OutdateRule,"");
		SETCHAR(eChangeHeader.ChangeLeader,"");
		SETCHAR(eChangeHeader.EffectivityType,"");
		SETCHAR(eChangeHeader.OverridingMark,"");
		SETNUM(eChangeHeader.Rank,"");

		/*for without release key*/
		SETCHAR(eChangeHeader.Function,"");			//for any material dml or PE MATERIAL
		SETNUM(eChangeHeader.ReleaseKey,"");

		/*for with release key*/
		//SETCHAR(eChangeHeader.Function,"1");		//for PE BOM
		//SETNUM(eChangeHeader.ReleaseKey,"00");

		SETCHAR(eChangeHeader.StatusProfile,"");
		SETCHAR(eChangeHeader.TechRel,"");
		SETCHAR(eChangeHeader.BasicChange,"");
		SETCHAR(eFlAle.XFELD,"");
		SETCHAR(eFlCommitAndWait.XFELD,"X");
		SETCHAR(eFlNoCommitWork.XFELD,"");
		SETCHAR(eObjectBom.Active,"");
		SETCHAR(eObjectBom.Locked,"");
		SETCHAR(eObjectBom.ObjRequ,"");
		SETCHAR(eObjectBom.MgtrecGen,"");
		SETCHAR(eObjectBom.GenNew,"");
		SETCHAR(eObjectBom.GenDialog,"");
		SETCHAR(eObjectBomCus.Active,"");
		SETCHAR(eObjectBomCus.Locked,"");
		SETCHAR(eObjectBomCus.ObjRequ,"");
		SETCHAR(eObjectBomCus.MgtrecGen,"");
		SETCHAR(eObjectBomCus.GenNew,"");
		SETCHAR(eObjectBomCus.GenDialog,"");
		SETCHAR(eObjectBomDoc.Active,"");
		SETCHAR(eObjectBomDoc.Locked,"");
		SETCHAR(eObjectBomDoc.ObjRequ,"");
		SETCHAR(eObjectBomDoc.MgtrecGen,"");
		SETCHAR(eObjectBomDoc.GenNew,"");
		SETCHAR(eObjectBomDoc.GenDialog,"");
		SETCHAR(eObjectBomEqui.Active,"");
		SETCHAR(eObjectBomEqui.Locked,"");
		SETCHAR(eObjectBomEqui.ObjRequ,"");
		SETCHAR(eObjectBomEqui.MgtrecGen,"");
		SETCHAR(eObjectBomEqui.GenNew,"");
		SETCHAR(eObjectBomEqui.GenDialog,"");
		SETCHAR(eObjectBomLoc.Active,"");
		SETCHAR(eObjectBomLoc.Locked,"");
		SETCHAR(eObjectBomLoc.ObjRequ,"");
		SETCHAR(eObjectBomLoc.MgtrecGen,"");
		SETCHAR(eObjectBomLoc.GenNew,"");
		SETCHAR(eObjectBomLoc.GenDialog,"");
		SETCHAR(eObjectBomMat.Active,"X");
		SETCHAR(eObjectBomMat.Locked,"");
		SETCHAR(eObjectBomMat.ObjRequ,"X");
		SETCHAR(eObjectBomMat.MgtrecGen,"X");
		SETCHAR(eObjectBomMat.GenNew,"");
		SETCHAR(eObjectBomMat.GenDialog,"");
		SETCHAR(eObjectBomPsp.Active,"");
		SETCHAR(eObjectBomPsp.Locked,"");
		SETCHAR(eObjectBomPsp.ObjRequ,"");
		SETCHAR(eObjectBomPsp.MgtrecGen,"");
		SETCHAR(eObjectBomPsp.GenNew,"");
		SETCHAR(eObjectBomPsp.GenDialog,"");
		SETCHAR(eObjectBomStd.Active,"");
		SETCHAR(eObjectBomStd.Locked,"");
		SETCHAR(eObjectBomStd.ObjRequ,"");
		SETCHAR(eObjectBomStd.MgtrecGen,"");
		SETCHAR(eObjectBomStd.GenNew,"");
		SETCHAR(eObjectBomStd.GenDialog,"");
		SETCHAR(eObjectChar.Active,"");
		SETCHAR(eObjectChar.Locked,"");
		SETCHAR(eObjectChar.ObjRequ,"");
		SETCHAR(eObjectChar.MgtrecGen,"");
		SETCHAR(eObjectChar.GenNew,"");
		SETCHAR(eObjectChar.GenDialog,"");
		SETCHAR(eObjectCls.Active,"");
		SETCHAR(eObjectCls.Locked,"");
		SETCHAR(eObjectCls.ObjRequ,"");
		SETCHAR(eObjectCls.MgtrecGen,"");
		SETCHAR(eObjectCls.GenNew,"");
		SETCHAR(eObjectCls.GenDialog,"");
		SETCHAR(eObjectClsMaint.Active,"");
		SETCHAR(eObjectClsMaint.Locked,"");
		SETCHAR(eObjectClsMaint.ObjRequ,"");
		SETCHAR(eObjectClsMaint.MgtrecGen,"");
		SETCHAR(eObjectClsMaint.GenNew,"");
		SETCHAR(eObjectClsMaint.GenDialog,"");
		SETCHAR(eObjectConfProf.Active,"");
		SETCHAR(eObjectConfProf.Locked,"");
		SETCHAR(eObjectConfProf.ObjRequ,"");
		SETCHAR(eObjectConfProf.MgtrecGen,"");
		SETCHAR(eObjectConfProf.GenNew,"");
		SETCHAR(eObjectConfProf.GenDialog,"");
		SETCHAR(eObjectDep.Active,"");
		SETCHAR(eObjectDep.Locked,"");
		SETCHAR(eObjectDep.ObjRequ,"");
		SETCHAR(eObjectDep.MgtrecGen,"");
		SETCHAR(eObjectDep.GenNew,"");
		SETCHAR(eObjectDep.GenDialog,"");
		SETCHAR(eObjectDoc.Active,"X");
		SETCHAR(eObjectDoc.Locked,"");
		SETCHAR(eObjectDoc.ObjRequ,"X");
		SETCHAR(eObjectDoc.MgtrecGen,"X");
		SETCHAR(eObjectDoc.GenNew,"");
		SETCHAR(eObjectDoc.GenDialog,"");
		SETCHAR(eObjectHazmat.Active,"");
		SETCHAR(eObjectHazmat.Locked,"");
		SETCHAR(eObjectHazmat.ObjRequ,"");
		SETCHAR(eObjectHazmat.MgtrecGen,"");
		SETCHAR(eObjectHazmat.GenNew,"");
		SETCHAR(eObjectHazmat.GenDialog,"");
		SETCHAR(eObjectMat.Active,"X");
		SETCHAR(eObjectMat.Locked,"");
		SETCHAR(eObjectMat.ObjRequ,"X");
		SETCHAR(eObjectMat.MgtrecGen,"X");
		SETCHAR(eObjectMat.GenNew,"");
		SETCHAR(eObjectMat.GenDialog,"");
		SETCHAR(eObjectPhrase.Active,"");
		SETCHAR(eObjectPhrase.Locked,"");
		SETCHAR(eObjectPhrase.ObjRequ,"");
		SETCHAR(eObjectPhrase.MgtrecGen,"");
		SETCHAR(eObjectPhrase.GenNew,"");
		SETCHAR(eObjectPhrase.GenDialog,"");
		SETCHAR(eObjectPvs.Active,"");
		SETCHAR(eObjectPvs.Locked,"");
		SETCHAR(eObjectPvs.ObjRequ,"");
		SETCHAR(eObjectPvs.MgtrecGen,"");
		SETCHAR(eObjectPvs.GenNew,"");
		SETCHAR(eObjectPvs.GenDialog,"");
		SETCHAR(eObjectPvsAlt.Active,"");
		SETCHAR(eObjectPvsAlt.Locked,"");
		SETCHAR(eObjectPvsAlt.ObjRequ,"");
		SETCHAR(eObjectPvsAlt.MgtrecGen,"");
		SETCHAR(eObjectPvsAlt.GenNew,"");
		SETCHAR(eObjectPvsAlt.GenDialog,"");
		SETCHAR(eObjectPvsRel.Active,"");
		SETCHAR(eObjectPvsRel.Locked,"");
		SETCHAR(eObjectPvsRel.ObjRequ,"");
		SETCHAR(eObjectPvsRel.MgtrecGen,"");
		SETCHAR(eObjectPvsRel.GenNew,"");
		SETCHAR(eObjectPvsRel.GenDialog,"");
		SETCHAR(eObjectPvsVar.Active,"X");
		SETCHAR(eObjectPvsVar.Locked,"");
		SETCHAR(eObjectPvsVar.ObjRequ,"X");
		SETCHAR(eObjectPvsVar.MgtrecGen,"X");
		SETCHAR(eObjectPvsVar.GenNew,"");
		SETCHAR(eObjectPvsVar.GenDialog,"");
		SETCHAR(eObjectSubstance.Active,"");
		SETCHAR(eObjectSubstance.Locked,"");
		SETCHAR(eObjectSubstance.ObjRequ,"");
		SETCHAR(eObjectSubstance.MgtrecGen,"");
		SETCHAR(eObjectSubstance.GenNew,"");
		SETCHAR(eObjectSubstance.GenDialog,"");
		SETCHAR(eObjectTlist.Active,"");
		SETCHAR(eObjectTlist.Locked,"");
		SETCHAR(eObjectTlist.ObjRequ,"");
		SETCHAR(eObjectTlist.MgtrecGen,"");
		SETCHAR(eObjectTlist.GenNew,"");
		SETCHAR(eObjectTlist.GenDialog,"");
		SETCHAR(eObjectTlist2.Active,"");
		SETCHAR(eObjectTlist2.Locked,"");
		SETCHAR(eObjectTlist2.ObjRequ,"");
		SETCHAR(eObjectTlist2.MgtrecGen,"");
		SETCHAR(eObjectTlist2.GenNew,"");
		SETCHAR(eObjectTlist2.GenDialog,"");
		SETCHAR(eObjectTlistA.Active,"");
		SETCHAR(eObjectTlistA.Locked,"");
		SETCHAR(eObjectTlistA.ObjRequ,"");
		SETCHAR(eObjectTlistA.MgtrecGen,"");
		SETCHAR(eObjectTlistA.GenNew,"");
		SETCHAR(eObjectTlistA.GenDialog,"");
		SETCHAR(eObjectTlistE.Active,"");
		SETCHAR(eObjectTlistE.Locked,"");
		SETCHAR(eObjectTlistE.ObjRequ,"");
		SETCHAR(eObjectTlistE.MgtrecGen,"");
		SETCHAR(eObjectTlistE.GenNew,"");
		SETCHAR(eObjectTlistE.GenDialog,"");
		SETCHAR(eObjectTlistM.Active,"");
		SETCHAR(eObjectTlistM.Locked,"");
		SETCHAR(eObjectTlistM.ObjRequ,"");
		SETCHAR(eObjectTlistM.MgtrecGen,"");
		SETCHAR(eObjectTlistM.GenNew,"");
		SETCHAR(eObjectTlistM.GenDialog,"");
		SETCHAR(eObjectTlistN.Active,"");
		SETCHAR(eObjectTlistN.Locked,"");
		SETCHAR(eObjectTlistN.ObjRequ,"");
		SETCHAR(eObjectTlistN.MgtrecGen,"");
		SETCHAR(eObjectTlistN.GenNew,"");
		SETCHAR(eObjectTlistN.GenDialog,"");
		SETCHAR(eObjectTlistQ.Active,"");
		SETCHAR(eObjectTlistQ.Locked,"");
		SETCHAR(eObjectTlistQ.ObjRequ,"");
		SETCHAR(eObjectTlistQ.MgtrecGen,"");
		SETCHAR(eObjectTlistQ.GenNew,"");
		SETCHAR(eObjectTlistQ.GenDialog,"");
		SETCHAR(eObjectTlistR.Active,"");
		SETCHAR(eObjectTlistR.Locked,"");
		SETCHAR(eObjectTlistR.ObjRequ,"");
		SETCHAR(eObjectTlistR.MgtrecGen,"");
		SETCHAR(eObjectTlistR.GenNew,"");
		SETCHAR(eObjectTlistR.GenDialog,"");
		SETCHAR(eObjectTlistS.Active,"");
		SETCHAR(eObjectTlistS.Locked,"");
		SETCHAR(eObjectTlistS.ObjRequ,"");
		SETCHAR(eObjectTlistS.MgtrecGen,"");
		SETCHAR(eObjectTlistS.GenNew,"");
		SETCHAR(eObjectTlistS.GenDialog,"");
		SETCHAR(eObjectTlistT.Active,"");
		SETCHAR(eObjectTlistT.Locked,"");
		SETCHAR(eObjectTlistT.ObjRequ,"");
		SETCHAR(eObjectTlistT.MgtrecGen,"");
		SETCHAR(eObjectTlistT.GenNew,"");
		SETCHAR(eObjectTlistT.GenDialog,"");
		SETCHAR(eObjectValidMatvers.Active,"");
		SETCHAR(eObjectValidMatvers.Locked,"");
		SETCHAR(eObjectValidMatvers.ObjRequ,"");
		SETCHAR(eObjectValidMatvers.MgtrecGen,"");
		SETCHAR(eObjectValidMatvers.GenNew,"");
		SETCHAR(eObjectValidMatvers.GenDialog,"");
		SETCHAR(eObjectVarTab.Active,"");
		SETCHAR(eObjectVarTab.Locked,"");
		SETCHAR(eObjectVarTab.ObjRequ,"");
		SETCHAR(eObjectVarTab.MgtrecGen,"");
		SETCHAR(eObjectVarTab.GenNew,"");
		SETCHAR(eObjectVarTab.GenDialog,"");
		SETCHAR(eValueAssign.ValidFrom,"");
		SETCHAR(eValueAssign.ValidTo,"");
		SETCHAR(eValueAssign.DateMark,"");
		SETCHAR(eValueAssign.Material,"");
		SETCHAR(eValueAssign.SerialnrLow,"");
		SETCHAR(eValueAssign.SerialnrHigh,"");
		SETCHAR(eValueAssign.Class,"");
		SETCHAR(eValueAssign.Classty,"");
		SETCHAR(eValueAssign.Startup,"");
		SETCHAR(eValueAssign.Plant,"");
		SETCHAR(eValueAssign.SernrOi,"");
		SETCHAR(eValueAssign.FlDelete,"");

		if (thObjmgrec==ITAB_NULL)
		{
			thObjmgrec = ItCreate("OBJMGREC", sizeof(AEOI_API01), 0, 0);
			if (thObjmgrec==ITAB_NULL)
				printf("\nItCreate OBJMGREC");
		}
		else if (ItFree(thObjmgrec) != 0)
			printf("\nItFree OBJMGREC");


			tObjmgrec = ItAppLine(thObjmgrec);
			if (tObjmgrec == NULL)
				printf("\nItAppLine OBJMGREC");

	SETCHAR(tObjmgrec->AltDate,"");
	SETNUM(tObjmgrec->ChgObjtyp,"");
	SETNUM(tObjmgrec->ChgObjtyp,"4");
	SETCHAR(tObjmgrec->BomCat,"");
	SETCHAR(tObjmgrec->BomStdObject,"");
	SETCHAR(tObjmgrec->BomUsage,"");
	SETNUM(tObjmgrec->Chgtypeobj,"");
	SETCHAR(tObjmgrec->DescrObj,"");
	SETCHAR(tObjmgrec->DocType,"");
	SETCHAR(tObjmgrec->DocNumber,"");
	SETCHAR(tObjmgrec->DocVers,"");
	SETCHAR(tObjmgrec->DocPart,"");
	SETCHAR(tObjmgrec->Equipment,"");
	SETCHAR(tObjmgrec->FuncLoc,"");
	SETCHAR(tObjmgrec->Material,"2834342054RZZ");
	SETCHAR(tObjmgrec->Plant,"");
	SETCHAR(tObjmgrec->PspElement,"");
	SETCHAR(tObjmgrec->PvsType,"");
	SETCHAR(tObjmgrec->PvsNode,"");
	SETCHAR(tObjmgrec->PvsClassNumber,"");
	SETCHAR(tObjmgrec->PvsClassType,"");
	SETCHAR(tObjmgrec->PvsVariant,"");
	SETCHAR(tObjmgrec->SdOrder,"");
	SETNUM(tObjmgrec->SdOrderI,"");
	SETNUM(tObjmgrec->Textkey,"");
	SETCHAR(tObjmgrec->TlistType,"");
	SETCHAR(tObjmgrec->TlistGrp,"");
	SETCHAR(tObjmgrec->ObjChglock,"");
	SETCHAR(tObjmgrec->StatusProfObj,"");
	SETCHAR(tObjmgrec->FlDelete,"");


	/*tObjmgrec = ItAppLine(thObjmgrec);
	if (tObjmgrec == NULL)
		printf("\nItAppLine OBJMGREC");

	SETCHAR(tObjmgrec->AltDate,"");
	SETNUM(tObjmgrec->ChgObjtyp,"");
	SETNUM(tObjmgrec->ChgObjtyp,"4");
	SETCHAR(tObjmgrec->BomCat,"");
	SETCHAR(tObjmgrec->BomStdObject,"");
	SETCHAR(tObjmgrec->BomUsage,"");
	SETNUM(tObjmgrec->Chgtypeobj,"");
	SETCHAR(tObjmgrec->DescrObj,"");
	SETCHAR(tObjmgrec->DocType,"");
	SETCHAR(tObjmgrec->DocNumber,"");
	SETCHAR(tObjmgrec->DocVers,"");
	SETCHAR(tObjmgrec->DocPart,"");
	SETCHAR(tObjmgrec->Equipment,"");
	SETCHAR(tObjmgrec->FuncLoc,"");
	SETCHAR(tObjmgrec->Material,"2834342054R");
	SETCHAR(tObjmgrec->Plant,"");
	SETCHAR(tObjmgrec->PspElement,"");
	SETCHAR(tObjmgrec->PvsType,"");
	SETCHAR(tObjmgrec->PvsNode,"");
	SETCHAR(tObjmgrec->PvsClassNumber,"");
	SETCHAR(tObjmgrec->PvsClassType,"");
	SETCHAR(tObjmgrec->PvsVariant,"");
	SETCHAR(tObjmgrec->SdOrder,"");
	SETNUM(tObjmgrec->SdOrderI,"");
	SETNUM(tObjmgrec->Textkey,"");
	SETCHAR(tObjmgrec->TlistType,"");
	SETCHAR(tObjmgrec->TlistGrp,"");
	SETCHAR(tObjmgrec->ObjChglock,"");
	SETCHAR(tObjmgrec->StatusProfObj,"");
	SETCHAR(tObjmgrec->FlDelete,"");*/

	RfcRc = ccap_ecn_create(hRfc,&eChangeHeader,&eFlAle,&eFlCommitAndWait,&eFlNoCommitWork,&eObjectBom,&eObjectBomCus,&eObjectBomDoc,&eObjectBomEqui,&eObjectBomLoc,&eObjectBomMat,&eObjectBomPsp,&eObjectBomStd,&eObjectChar,&eObjectCls,&eObjectClsMaint,&eObjectConfProf,&eObjectDep,&eObjectDoc,&eObjectHazmat,&eObjectMat,&eObjectPhrase,&eObjectPvs,&eObjectPvsAlt,&eObjectPvsRel,&eObjectPvsVar,&eObjectSubstance,&eObjectTlist,&eObjectTlist2,&eObjectTlistA,&eObjectTlistE,&eObjectTlistM,&eObjectTlistN,&eObjectTlistQ,&eObjectTlistR,&eObjectTlistS,&eObjectTlistT,&eObjectValidMatvers,&eObjectVarTab,&eValueAssign,&iChangeNo,thAltDates,thEffectivity,thObjmgrec,thTextheader,thTextlines,xException);
	switch (RfcRc)
	{
		case RFC_OK:
			printf("\necn create: %u\n",RFC_OK);
		break;
		case RFC_EXCEPTION:
			rfc_error("RFC_EXCEPTION");
			//printf("\nRFC Exception: %s\n",xException);
		break;
		case RFC_SYS_EXCEPTION:
			//printf("\nSystem Exception Raised!!!\n");
			rfc_error("RFC_SYS_EXCEPTION");
		break;
		case RFC_FAILURE:
			//printf("\nFailure!!!\n");
			rfc_error("RFC_FAILURE");
		break;
		default:;
	}

EXIT:
	;
	RfcClose(hRfc);
}
