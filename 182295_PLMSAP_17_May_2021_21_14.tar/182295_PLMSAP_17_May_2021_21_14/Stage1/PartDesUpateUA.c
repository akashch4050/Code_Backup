#define TE_MAXLINELEN  128
#define _CLMAIN_DEFNS
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>
#include <user_exits/user_exits.h>

#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"

void descChange(char *Part_Num,char *DescStr,char *dml_numER);
RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,char *xException);


char fsuccess_name[200];
FILE * fsuccess;
char *iSapServer=NULL;


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}


BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;

	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3])
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;
	AENNR eAennr;
	CCMATNR eMatnr;
	CC_REVLV eRevlv;
	BAPIRET2 iMessg;
	SYST_SUBRC iRetval;
	char xException[256];
	char s[1024] = { 0 } ;

	hRfc = BapiLogon();

	printf("\nRevision Creation DmlNo.:[%s]\t PartNo.:[%s]\tRevSheetstatus:[%s]",sap_dml_no,sap_part_no,sap_rev_sheet_status);
	fprintf(fsuccess,"\nRevision Creation DmlNo.:[%s]\t PartNo.:[%s]\tRevSheetstatus:[%s]",sap_dml_no,sap_part_no,sap_rev_sheet_status);

	SETCHAR(eAennr.Aennr,sap_dml_no);
	SETCHAR(eMatnr.Ccmatnr,sap_part_no);
	SETCHAR(eRevlv.CcRevlv,sap_rev_sheet_status);

	RfcRc = zpprfc_revisionnum_change(hRfc,&eAennr,&eMatnr,&eRevlv,&iMessg,&iRetval,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\n[%s]Revision Creation Message	:%s",sap_part_no,iMessg.Message);
			fprintf(fsuccess,"\n[%s]Revision Creation Message	:%s",sap_part_no,iMessg.Message);fflush(stdout);
			/*GETCHAR(iMessg.Type,s);
			F_OUTK("TYPE",10,30,s);
			GETCHAR(iMessg.Id,s);
			F_OUTK("ID",10,30,s);
			GETNUM(iMessg.Number,s);
			F_OUTK("NUMBER",10,30,s);
			GETCHAR(iMessg.Message,s);
			F_OUTK("MESSAGE",10,30,s);
			GETCHAR(iMessg.Log_No,s);
			F_OUTK("LOG_NO",10,30,s);
			GETNUM(iMessg.Log_Msg_No,s);
			F_OUTK("LOG_MSG_NO",10,30,s);
			GETCHAR(iMessg.Message_V1,s);
			F_OUTK("MESSAGE_V1",10,30,s);
			GETCHAR(iMessg.Message_V2,s);
			F_OUTK("MESSAGE_V2",10,30,s);
			GETCHAR(iMessg.Message_V3,s);
			F_OUTK("MESSAGE_V3",10,30,s);
			GETCHAR(iMessg.Message_V4,s);
			F_OUTK("MESSAGE_V4",10,30,s);
			GETCHAR(iMessg.Parameter,s);
			F_OUTK("PARAMETER",10,30,s);
			GETINT(iMessg.Row,s);
			F_OUTK("ROW",10,30,s);
			GETCHAR(iMessg.Field,s);
			F_OUTK("FIELD",10,30,s);
			GETCHAR(iMessg.System,s);
			F_OUTK("SYSTEM",10,30,s);*/
			NL;
		break;
		case RFC_EXCEPTION:
			printf("\nRFC_EXCEPTION raised");
			fprintf(fsuccess,"\nRFC_EXCEPTION raised");
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nsystem exception raised");
			fprintf(fsuccess,"\nsystem exception raised");
		break;
		case RFC_FAILURE:
			printf("\nfailure");
		break;
		default:
			printf("\nother failure");
	}
	RfcClose(hRfc);

	return 0;
}

RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,char *xException)
{
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[2];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "HEADDATA";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfBAPIMATHEAD;
	Exporting[0].leng = sizeof(BAPIMATHEAD);
	Exporting[0].addr = eBapiMatHead;

	Exporting[1].name = "CHANGE_NUMBER";
	Exporting[1].nlen = 13;
	Exporting[1].type = handleOfRMMG1_AENNR;
	Exporting[1].leng = sizeof(RMMG1_AENNR);
	Exporting[1].addr = eRmmg1_Aennr;

	Exporting[2].name = NULL;

	Tables[0].name     = "MATERIALDESCRIPTION";
	Tables[0].nlen     = 19;
	Tables[0].type     = handleOfBAPI_MAKT;
	Tables[0].ithandle = thBapi_Makt;


	Tables[1].name = NULL;

	RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			Importing[0].name = "RETURN";
			Importing[0].nlen = 6;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = eBapiret2;

			Importing[1].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
			break;
	}
	return RfcRc;
}

void descChange(char *Part_Num,char *DescStr,char *dml_numER)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256];
	char sap_msg[60];
	BAPIMATHEAD eBapiMatHead;
	RMMG1_AENNR eRmmg1_Aennr;
	BAPIRET2 eBapiret2;
	
	ITAB_H thBapi_Makt = ITAB_NULL;
	BAPI_MAKT *tBapi_Makt;

	printf("\nPart Number : [%s] Description : [%s] ChangeNo : [%s]",Part_Num,DescStr,dml_numER);
	fprintf(fsuccess,"\nPart Number : [%s] Description : [%s] ChangeNo : [%s]",Part_Num,DescStr,dml_numER);
	hRfc = BapiLogon();
	SETCHAR(eBapiMatHead.Material,Part_Num);
	SETCHAR(eBapiMatHead.Ind_Sector,"");
	SETCHAR(eBapiMatHead.Matl_Type,"");
	SETCHAR(eBapiMatHead.Basic_View,"");
	SETCHAR(eBapiMatHead.Sales_View,"");
	SETCHAR(eBapiMatHead.Purchase_View,"");
	SETCHAR(eBapiMatHead.Mrp_View,"");
	SETCHAR(eBapiMatHead.Forecast_View,"");
	SETCHAR(eBapiMatHead.Work_Sched_View,"");
	SETCHAR(eBapiMatHead.Prt_View,"");
	SETCHAR(eBapiMatHead.Storage_View,"");
	SETCHAR(eBapiMatHead.Warehouse_View,"");
	SETCHAR(eBapiMatHead.Quality_View,"");
	SETCHAR(eBapiMatHead.Account_View,"");
	SETCHAR(eBapiMatHead.Cost_View,"");
	SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
	SETCHAR(eBapiMatHead.Material_External,"");
	SETCHAR(eBapiMatHead.MateriaL_Guid,"");
	SETCHAR(eBapiMatHead.Material_Version,"");

	SETCHAR(eRmmg1_Aennr.Aennr,dml_numER);

	thBapi_Makt = ITAB_NULL;
	if (thBapi_Makt==ITAB_NULL)
	{
		thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
		if (thBapi_Makt==ITAB_NULL)
		rfc_error("ItCreate MATERIALDESCRIPTION");
	}
	else if (ItFree(thBapi_Makt) != 0)
	{
		rfc_error("ItFree MATERIALDESCRIPTION");
	}

	tBapi_Makt = ItAppLine (thBapi_Makt) ;
	if (tBapi_Makt == NULL)
	{
		rfc_error("ItAppLine BAPI_MAKT");
	}

	SETCHAR(tBapi_Makt->Langu,"EN");
	SETCHAR(tBapi_Makt->Langu_Iso,"");
	SETCHAR(tBapi_Makt->Matl_Desc,DescStr);
	SETCHAR(tBapi_Makt->Del_Flag,"");

	RfcRc = zbapi_material_savedata_mrp(hRfc,&eBapiMatHead,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			sprintf(sap_msg,"%.*s:",sizeof(sap_msg),eBapiret2.Message);
			printf("\n\nDesc Change Message: %s\n",sap_msg);
			fprintf(fsuccess,"\nDesc Change Message:%s",sap_msg);
			break;
		case RFC_EXCEPTION:
			printf("\nRFC EXCEPTION: %s",xException);
			break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			break;
		default:
			printf("\nOther Failure!");
		break;
	}
	if (ItDelete(thBapi_Makt) != 0)
	{
		rfc_error("ItDelete thBapi_Makt");
	}

	RfcClose(hRfc);
}

extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	int kk=0;
	int is=0;
	int sflag=0;
	int i=0;
	int doccount=0;
	int len=0;
	int Refcount=0;
	int resultCount =0;
	int n_entries = 2; //no. of query input arg
	int n_tags_found = 1;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};

	tag_t queryTag = NULLTAG;
	tag_t docOPtr = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t resultOutputTag = NULLTAG;
	tag_t LatestRev=NULLTAG;
    tag_t docRelObjs=NULLTAG;
    tag_t *docObjs=NULLTAG;
    tag_t *refdocObjs=NULLTAG;
    tag_t doctag=NULLTAG;
    tag_t docRelObj=NULLTAG;
    tag_t refdocRelObj=NULLTAG;
	tag_t		*DesignTags			= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;

	char* sUserName	= NULL;
	char* sPassword = NULL;
	char *LatRevName=NULL;
	char *part_type=NULL;
	char *unit=NULL;
	char *part_typeDup=NULL;
	char *unitDup=NULL;
	char *doc_no=NULL;
	char *PrtRev=NULL;
	char* PartRelStatus = NULL;
	char *Lcs = NULL;
	char	*AllColRevSet	= NULL;

	static RFC_RC RfcRc;
	const char *attrs[2];
	const char *values[2];

	char *inputPart=NULL;
	char *dml_no_arg = NULL;
	char *PrtRevDup = NULL;
	char *part_noDup = NULL;
	char *desc = NULL;
	char *descDup = NULL;
	char *partClrIndDup = NULL;
	char *partClrInd = NULL;

	int ColCount = 0, cl = 0;
	tag_t *AllColPartTags = NULLTAG;
	tag_t ColPartTag = NULLTAG;
	char *ColPartRev = NULL;
	int PStrCount = 0, j=0;
	char **ColPartList =NULL;
	char *RelRevNumber =NULL;
	tag_t *ColPTags = NULLTAG;
	tag_t ColPTag = NULLTAG;

	//char *qry_entries[1] = {"Name"};
	char *qry_entries[] = {"Item ID","Release Status"};

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	inputPart = ITK_ask_cli_argument("-i=");
	dml_no_arg = ITK_ask_cli_argument("-c=");
	iSapServer = ITK_ask_cli_argument("-s=");

	if(tc_strcmp(sUserName,"")==0 || tc_strcmp(sPassword,"")==0 || tc_strcmp(inputPart,"")==0 || tc_strcmp(dml_no_arg,"")==0)
	{
		printf("\nPartDesUpateUA -u=userid -p=password -i=inputPart -c=change_no\n");fflush(stdout);
		goto CLEANUP;
	}

	sprintf(fsuccess_name,"/user/plmsap/PLMSAP/ONE_TIME_LOG/PART_DESC_UPDATE_ONETIME_%s.log",inputPart);
	//sprintf(fsuccess_name,"PART_DESC_UPDATE_ONETIME_%s.log",inputPart);
	fsuccess = fopen(fsuccess_name,"a");

	//if(QRY_find("QueryDesignRev", &queryTag));
	if(QRY_find("Driver VC Query", &queryTag));
	
	if (queryTag)
	{
		printf("\nFound Query QueryDesignRev\n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query QueryDesignRev");fflush(stdout);
		goto CLEANUP;
	}
    
    printf("\nQueryig input Part %s\n ", inputPart);fflush(stdout);

	Lcs = (char *) MEM_alloc(1000);
	//tc_strcpy(Lcs,"T5_LcsAplRlzd");
	tc_strcpy(Lcs,"T5_LcsErcRlzd");

    qry_values[0] = inputPart;
    qry_values[1] = Lcs;

	//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));
	//1-Ascending 2- Descending
	ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &outTag));

    printf("\nPart Found Count %d", resultCount);fflush(stdout);

	if(resultCount>0)
	{
		LatestRev=outTag[0];
	}
	else
	{
		printf("\nPart %s Not found ERC Released and above in TCUA\n", inputPart);fflush(stdout);
		goto CLEANUP;
	}

	ITK_CALL(AOM_ask_value_string(LatestRev,"object_string",&LatRevName));
	printf("\nLatRevName:%s \n",LatRevName);fflush(stdout);
	fprintf(fsuccess,"\nLatRevName:%s \n",LatRevName);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&part_noDup));

	ITK_CALL(AOM_ask_value_string(LatestRev,"item_revision_id",&PrtRev));
	
	printf("\nPart [%s] Part Revision [%s]\n",part_noDup,PrtRev);fflush(stdout);
	fprintf(fsuccess,"\nPart [%s] Part Revision [%s]\n",part_noDup,PrtRev);fflush(stdout);

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));

	if(	
		tc_strstr(PartRelStatus,"STDSIC Released")!=NULL ||
		tc_strstr(PartRelStatus,"APLC Released")!=NULL ||
		tc_strstr(PartRelStatus,"ERC Released")!=NULL ||
		tc_strstr(PartRelStatus,"STDSIC Restructured")!=NULL
		)
	{
		printf("\nPartRelStatus: %s\n",PartRelStatus);
		fprintf(fsuccess,"\nPartRelStatus: %s\n",PartRelStatus);
		
	}
	else
	{
		printf("\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
		fprintf(fsuccess,"\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
		goto CLEANUP;
	}
		
	
	ITK_CALL(AOM_ask_value_string(LatestRev,"t5_PartType",&part_type));
	tc_strdup(part_type,&part_typeDup);

	printf("\nPart Type: %s\n", part_typeDup);
	printf("\npart_noDup: %s\n", part_noDup);

	if(	tc_strcmp(part_typeDup,"D")==0 ||
		tc_strcmp(part_typeDup,"DA")==0 ||
		tc_strcmp(part_typeDup,"DC")==0 ||
		tc_strcmp(part_typeDup,"IFD")==0 ||
		tc_strcmp(part_typeDup,"IM")==0 ||
		tc_strcmp(part_typeDup,"CP")==0)
	{
		printf("\nPart %s Has Type %s ! AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
		fprintf(fsuccess,"\nPart %s Has Type %s ! AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
		goto CLEANUP;
	}


	ITK_CALL(AOM_ask_value_string(LatestRev,"object_desc",&desc));

	if(tc_strlen(desc)>0)
	{
		tc_strdup(desc,&descDup);
		printf("\nDescription: %s", descDup);
		descChange(part_noDup,descDup,dml_no_arg);

	}
	else
	{
		printf("\nDescription is NULL!");
		goto CLEANUP;
	}


	ITK_CALL(AOM_ask_value_string(LatestRev,"t5_ColourInd",&partClrInd));
	tc_strdup(partClrInd,&partClrIndDup);

	if (tc_strcmp(partClrIndDup,"Y")==0)
	{
		AllColRevSet     =  (char *) MEM_alloc(100000 * sizeof(char));
		tc_strcpy (AllColRevSet,"" );

		printf("\nNon-Colour Part : %s", part_noDup);

		ITK_CALL(AOM_ask_value_tags(LatestRev,"representation_for",&ColCount,&AllColPartTags));
		for (cl=0 ; cl<ColCount ; cl++)
		{
			ColPartTag = AllColPartTags[cl];
			ITK_CALL(AOM_ask_value_string(ColPartTag,"item_id",&ColPartRev));
			//printf("\nColor Part : %s", ColPartRev);

			if(tc_strcmp(AllColRevSet,"")==0)
			{
				tc_strcpy (AllColRevSet,"" );
				tc_strcpy (AllColRevSet,ColPartRev);
				printf("\n1 Part added to AllColRevSet: %s",ColPartRev);	fflush(stdout);

			}
			else
			{
				if(tc_strstr(AllColRevSet,ColPartRev)==NULL)
				{
					tc_strcat (AllColRevSet,"," );
					tc_strcat (AllColRevSet,ColPartRev);
					printf("\n2 Part added to AllColRevSet: %s",ColPartRev);	fflush(stdout);
				}
			}
		}
					
		tc_strcpy(Lcs,"T5_LcsErcRlzd");
		//tc_strcpy(Lcs,"T5_LcsStdRlzd");

		ITK_CALL(EPM__parse_string(AllColRevSet,",",&PStrCount,&ColPartList));
		
		for ( i=0;i<PStrCount ;i++ )
		{
			printf("\nChecking Part : %s",ColPartList[i]);	fflush(stdout);

			qry_values[0] = ColPartList[i];
			qry_values[1] = Lcs;

			//1-Ascending 2- Descending
			ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &ColPTags));
			
			for (j=0;j< resultCount;j++ )
			{
				ColPTag=ColPTags[j];
				
				//ITK_CALL(AOM_ask_value_string(ColPTag,"item_revision_id",&RelRevNumber));

				ITK_CALL(AOM_UIF_ask_value(ColPTag,"release_status_list",&PartRelStatus));
				if(	
					tc_strstr(PartRelStatus,"STDSIC Released")!=NULL ||
					tc_strstr(PartRelStatus,"APLC Released")!=NULL ||
					tc_strstr(PartRelStatus,"ERC Released")!=NULL ||
					tc_strstr(PartRelStatus,"STDSIC Restructured")!=NULL
					)
				{
					ITK_CALL(AOM_ask_value_string(ColPTag,"object_string",&RelRevNumber));
					ITK_CALL(AOM_ask_value_string(ColPTag,"item_id",&part_noDup));
					printf("\nLatest Colour Revision : %s\n",RelRevNumber);
					
					ITK_CALL(AOM_ask_value_string(ColPTag,"object_desc",&desc));
					if(tc_strlen(desc)>0)
					{
						tc_strdup(desc,&descDup);
						printf("\nDescription: %s", descDup);
						descChange(part_noDup,descDup,dml_no_arg);

					}
					else printf("\nDescription is NULL!");

					break;
				}
				else
				{
					continue;
				}
			}
		}
	}
	else
	{
		printf("\nNot Colorable Part : %s", part_noDup);
		goto CLEANUP;
	}

	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);
}