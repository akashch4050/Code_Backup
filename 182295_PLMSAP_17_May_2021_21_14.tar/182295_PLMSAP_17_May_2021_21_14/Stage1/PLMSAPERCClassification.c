/********************************************************************************************************************************
* Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : PLMSAPERCClassification.c
* Created By                   : Poonam K Sah
* Created On                   : 
* Project                      : Tata Motors PLM-CAD BOM
* Methods Defined              :
* Description                  : Creates Basic View in SAP From UA
* Specific Notes               :
*
* Modification History :
* S.No		Date			CR No       Modified By		Modification Notes
************************************************************************************************************************************/
#define TE_MAXLINELEN  128
#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"
#include "bapi.h"
//#include "t11.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <ict/ict_userservice.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <pie/pie.h>

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
struct DzSim
{
	char *aVcClass;
	char *cSeatingCapacity; //car
	char *cVehicleLength;
	char *cVehicleType;
	char *cEngineDisplacement;
	char *cGrossVehicleWeight;
	char *cChassis;
	char *cVehAppl;
	char *cMajorModel;
	char *cMascot;
};

struct VCAttrDetails
{
	char VCAttrID[500];
	char VCAttrName[500]; //car
	char VCAttrNameValue[500];
};
struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;
FILE * fsuccess;
FILE* fp=NULL;
char fsuccess_name[200];

FILE * fUASAPMapping;
char fUASAPMapping_name[200];


WERKS_D eWerks;
static MATNR eMatnr;


char group;
FILE *fsuccess,*ferror1;
//FILE *flog;
char cComma[14]={",,,,,,,,,,,,"};
char SiamFile[100]={0};
char ferror_name[200] = {0};
int	cmvrFlag	= 0;
//static char sap_attrname[255] = {0};

char *ColorIDPart = NULL;
char *ColorIDPartDup = NULL;
char *UrnCode = NULL;

char *st5Pollutant_CM1 = NULL;
char *CMUnit = NULL;
char *st5Pollutant_HC1 = NULL;
char *HCUnit = NULL;
char *st5Pollutant_NH1 = NULL;
char *NMHCUnit = NULL;
char *st5Pollutant_RHC1 = NULL;
char *RHCUnit = NULL;
char *st5Pollutant_NO1 = NULL;
char *NOUnit = NULL;
char *st5Pollutant_HCNO1 = NULL;
char *HCNOUnit = NULL;
char *st5Pollutant_PM1 = NULL;
char *PMUnit = NULL;
char *st5Pollutant_HO1 = NULL;
char *st5BystanderPos = NULL;

char *st5Pollutant_CM1Dup = NULL;
char *CMUnitDup = NULL;
char *st5Pollutant_HC1Dup = NULL;
char *HCUnitDup = NULL;
char *st5Pollutant_NH1Dup = NULL;
char *NMHCUnitDup = NULL;
char *st5Pollutant_RHC1Dup = NULL;
char *RHCUnitDup = NULL;
char *st5Pollutant_NO1Dup = NULL;
char *NOUnitDup = NULL;
char *st5Pollutant_HCNO1Dup = NULL;
char *HCNOUnitDup = NULL;
char *st5Pollutant_PM1Dup = NULL;
char *PMUnitDup = NULL;
char *st5Pollutant_HO1Dup = NULL;
char *st5BystanderPosDup = NULL;

char *st5Pollutant_CM1Dup1 = NULL;
char *st5Pollutant_HC1Dup1 = NULL;
char *st5Pollutant_NH1Dup1 = NULL;
char *st5Pollutant_RHC1Dup1 = NULL;
char *st5Pollutant_NO1Dup1 = NULL;
char *st5Pollutant_HCNO1Dup1 = NULL;
char *st5Pollutant_PM1Dup1 = NULL;

char *BBBACNUM			= NULL;
char *BBBACNUMDup		= NULL;
char *BBBACISDT		= NULL;
char *BBBACISDTDup		= NULL;
char *BBBACVLDT		= NULL;
char *BBBACVLDTDup		= NULL;
char *VBCAPRCNUM		= NULL;
char *VBCAPRCNUMDup	= NULL;
char *VBCAPRDT			= NULL;
char *VBCAPRDTDup		= NULL;



//drwnum = (char *)malloc(500 * sizeof(char));


#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)




void myDzSiamCode(struct DzSim* SiamAttr,char* siamCode1);
void myDzSiamCode2(struct DzSim* SiamAttr,char* siamCode2);
void rfc_error(char *);
void UpWtBasicView(char* VCNumDup, char* GrosWeight,char* NetWeight);
RFC_RC zpprfc_char_update(RFC_HANDLE hRfc,KLASSE_D *Class, SY_SUBRC *Sy_subrc, BAPIRET2	*iRETURN, ITAB_H thAusparch,char *xException);
RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA	*,BAPI_MARAX	*,BAPIRET2	*,ITAB_H       ,ITAB_H       ,ITAB_H       ,char *);

void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

void Multi_Get_Part_BOM_Lvl(tag_t inputPart,int reqLevel,int level,tag_t revRule,struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);


	if( level >= reqLevel )
	{
		goto CLEANUP;
	}


	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));
	//ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITKCALL(BOM_set_window_pack_all (window, true));
	
		BOM_set_window_top_line(window, null_tag,inputPart ,null_tag, &top_line);
		ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n; k++)
		{
			BOM_line_unpack (children[k]);
			BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
			if(t_ChildItemRev!=NULLTAG)
			{
				AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);
				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; 
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;

				Multi_Get_Part_BOM_Lvl(t_ChildItemRev,reqLevel,level,revRule,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}
int Get_Part_BOM_Lvl(tag_t VehicleObj,int reqLevel,char*  revRuleName,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1=0;
	int n=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	int level 				= 0;
	tag_t	window 				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	objChild			= NULLTAG;
	tag_t	objChild_bvr			= NULLTAG;
	int child_lvl=0;
	char	*c_Qty						=	NULL;
	tag_t  *children1=NULLTAG;
	int iChildItemTag=0;
	int assbvr=0;
	int bvrfound=0;
	int flagRevRule=0;
	int flagClosureRule=0;
	char *view_name=NULL;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;

	printf("\nInside Get_Part_BOM_Lvl ....\n");

	if(VehicleObj == NULLTAG)
	{
		printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	ITKCALL(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	//printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);


		ITKCALL(CFM_find(revRuleName, &revRule));
		if (revRule != NULLTAG)
		{
			printf("\nFind revRule\n");fflush(stdout);
			flagRevRule=1;
		}

		scope=PIE_TEAMCENTER;
		//ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		//printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
		//if(n_closure_tags==1)
		//{
			//closure_tag=closure_tags[0];
			//flagClosureRule=1;
		//}
		printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
		printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
		//if((flagClosureRule==1) && (flagRevRule==1))
		if(flagRevRule==1)
		{

			Multi_Get_Part_BOM_Lvl(VehicleObj,reqLevel,level,revRule,BomChldStrut,StructChldCnt);
		}
		else
		{
			printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
		}


	printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);

	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		child_lvl       =0;

		printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;

		AOM_ask_value_string(objChild,"item_id",&ItemName);
		printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		printf("\nQty==>%s\n",c_Qty);fflush(stdout);

	}
	return ifail;
}
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}
static tag_t ask_item_revision_from_bom_line_SnapShot(tag_t bom_line)
{
    tag_t item_revision = NULLTAG;
    char *item_id = NULL, *rev_id = NULL;
    
    ITKCALL(AOM_ask_value_string(bom_line, "bl_item_item_id", &item_id ));
    ITKCALL(AOM_ask_value_string(bom_line, "bl_rev_item_revision_id", &rev_id));
    ITKCALL(ITEM_find_rev(item_id, rev_id, &item_revision));
    
    if (item_id) MEM_free(item_id);
    if (rev_id) MEM_free(rev_id);
    return item_revision;
}

void GetAllChild_SnapShot(tag_t* top_line,int depth,char ***SetModulePart,int *icount)
{
	int n = 0;
	tag_t* children = NULLTAG;
	int k = 0;
	int Item_ID = 0;
	int Item_RevSeq = 0;
	char *Item_ID_str = NULL;
	char *Item_RevSeq_str = NULL;
	tag_t ChildItemRev = NULLTAG;
	char	*ModPartType=	NULL;
	int			modadd			= 0;
	char	*ModPartAct	=	NULL;
	char *mod_addr = NULL;

	
	depth++;
	printf("\nInside GetAllChild_SnapShot********");fflush(stdout);
	ITKCALL( BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	ITKCALL( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_RevSeq));
	ITKCALL(BOM_line_ask_attribute_string(*top_line, Item_ID, &Item_ID_str));
	ITKCALL(BOM_line_ask_attribute_string(*top_line, Item_RevSeq, &Item_RevSeq_str));
	printf("\n%d]Item_ID_str: [%s] [%s]",depth,Item_ID_str,Item_RevSeq_str);fflush(stdout);
	ChildItemRev = ask_item_revision_from_bom_line_SnapShot(*top_line);
	tag_t ChildTagLatestRev	 = NULLTAG;

	if(ITEM_ask_latest_rev(ChildItemRev,&ChildTagLatestRev));
	
	if (ChildItemRev==NULLTAG)
	{
		printf("\nNULLTAG FOUND FOR BOM LINE ITEM : %s",Item_ID_str);fflush(stdout);
	}
	else
	{
		if(ModPartType) ModPartType=NULL;
		

		ITKCALL(AOM_ask_value_string(*top_line, "bl_Design_t5_RevPartType", &ModPartType ));
		printf("\n Part type Modules Under Architechtures --> : %s\n",ModPartType); fflush(stdout);
		
		if(BOM_line_look_up_attribute("bl_Design Revision_t5_ModuleAddress",&modadd))PrintErrorStack();
		if(BOM_line_ask_attribute_string(*top_line, modadd, &mod_addr))PrintErrorStack();
		printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);
	
		if((tc_strcmp(ModPartType,"M")==0) || (tc_strcmp(ModPartType,"CM")==0))
		{
			/*X4MC1D01
			X4MC2A01
			X4MC3Z01vi 
			X4MP1A01
			X4MP1N01
			X4MP3A01
			X4MC1D02*/
			//this module is not menstioned in excel shee added as per mail MP1L01
			if((tc_strcmp(mod_addr,"MC1D01")==0) || (tc_strcmp(mod_addr,"MC2A01")==0)|| (tc_strcmp(mod_addr,"MC3Z01")==0)|| (tc_strcmp(mod_addr,"MP1A01")==0)|| (tc_strcmp(mod_addr,"MP1N01")==0)|| (tc_strcmp(mod_addr,"MP3A01")==0)|| (tc_strcmp(mod_addr,"MC1D02")==0)|| (tc_strcmp(mod_addr,"MP1L01")==0))
			{
			printf("\nFor Adding Item_ID_str: [%s] [%s]",Item_ID_str,Item_RevSeq_str);fflush(stdout);
			printf("\n adding Modules adderess --> : %s\n",mod_addr); fflush(stdout);
			//To add in set
			ModPartAct	=	(char	*)MEM_alloc(300);
			tc_strcpy(ModPartAct,Item_ID_str);
			tc_strcat(ModPartAct,"/");
			tc_strcat(ModPartAct,Item_RevSeq_str);

			printf("\n ModPartAct --> : %s",ModPartAct); fflush(stdout);
			setAddStr(icount,SetModulePart,ModPartAct);
			}
		}
		ITKCALL(BOM_line_ask_child_lines (*top_line, &n, &children));

		printf("\nAssembly:%s no of child found:%d",Item_ID_str,n);fflush(stdout);
		for (k = 0; k < n; k++)
		{
			GetAllChild_SnapShot(&children[k],depth,SetModulePart,icount);
		}
	}
}

int tm_ebom_mbom_rpt(tag_t VObjTag,char ***SetModulePart,int *icount)
{
	int		ifail 				=   ITK_ok;
	char	*tasknumber			=	NULL;
	char	*type_name			=	NULL;
	char	*type_nameP			=	NULL;
	char	*type_name2			=	NULL;
	char	*tsk_object_name	=	NULL;
	char	*ClrSVROnly			=	NULL;
	char	*tmpSVR				=	NULL;
	char	*nonClrSvr			=	NULL;
	char	*clrSlr				=	NULL;
	char	*qry_entries3[1]	= {"Name"};
	char	*qry_entries10[1]	= {"ID"};
	char	*itemid;
	char	*svrName			=	NULL;
	char	*t5_SchmPlant		=	NULL;
	char	*t5_ClSrl			=	NULL;
	char	*arch_item_id		=	NULL;
	char	*arch_item_idrev		=	NULL;
	char	*Archtype_name		=	NULL;
	char	**rulename			=	NULL;
	char	**rulevalue			=	NULL;
	char	*item_Rev_Seq		=	NULL;
	char	*StagePartNo		=	NULL;
	char	*Stage_item_Rev_Seq	=	NULL;
	char	*StagePartType		=	NULL;
	char	*ModPartNo			=	NULL;
	char	*ModPartType		=	NULL;
	char	*ModPartLine		=	NULL;
	char	*ModItem_Rev		=	NULL;
	char	*ModItem_Seq		=	NULL;
	char	*ChildColInd		=	NULL;
	char	*Item_ID_str		=	NULL;
	char	*ModPartAct			=	NULL;

	char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
	char	**valuesPlatfrom = (char **) MEM_alloc(1 * sizeof(char *));

	date_t  eff_date;

	tag_t	objTypeTag			=	NULLTAG;
	tag_t	ItemTypeTag			=	NULLTAG;
	tag_t	*PartTags			=	NULLTAG;
	tag_t	t_svr				=	NULLTAG;
	tag_t	ClrVariqueryTag		=	NULLTAG;
	tag_t	*ColVRule_tags		=	NULLTAG;
	tag_t	*t5_clrscm			=	NULLTAG;
	tag_t	PlatformTag			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;
	tag_t	item_tag			=	NULLTAG;
	tag_t	PlatformTypeTag		=	NULLTAG;
	tag_t	PlatformRevTag		=	NULLTAG;
	tag_t	PlatformRevTypeTag	=	NULLTAG;
	tag_t   e_block				=	NULLTAG;
	tag_t	*lines2				=	NULLTAG;
	tag_t	*lines3				=	NULLTAG;
	tag_t	PartChildobj		=	NULLTAG;
	tag_t	StageChildobj		=	NULLTAG;
	tag_t   t_ChildItemRev		=	NULLTAG;


	int		PartCnt			=	0;
	int		n_entriesV		=	1;
	int		n_entriesP		=	1;
	int		n_tags_found	=	0;
	int		n_count			=	0;
	int		ClrCnt = 0;
	int		iSVR = 0;
	int		count_clrscm	=	0;
	int		rulefound		=	0;
	int		count			=	0;
	int		ichld			=	0;
	int		n_lines2		=	0;
	int		n_lines3		=	0;
	int		iMod			=	0;
	int		iMod1			=	0;
	int		NonClrPartlevel =	0;
	int		iChildItemTag	=   0;
	int		Revformula;
	const char *qry_entries[1];
	const char *qry_values[1];
	struct	BomChldStrut	ChldStrutBdySh[5000];
	
	tag_t	*itemclass			=	NULLTAG;
	tag_t	item				=	NULLTAG;
	tag_t	tsk_HSI_rel_type	=	NULLTAG;
	tag_t	t5_appl_SVR			=	NULLTAG;
	tag_t	item_rev_tag		=	NULLTAG;
	tag_t	bom_wnd				=	NULLTAG;
	tag_t	rule				=	NULLTAG;
	tag_t	*closurerule		=	NULLTAG;
	tag_t	close_tag			=	NULLTAG;
	tag_t   bom_variant_rule	=	NULLTAG;
	tag_t  	objTypeTag1			=	NULLTAG;
	tag_t	top_lne				=	NULLTAG;
	tag_t	*ArchNodeLines		=	NULLTAG;
	tag_t	VarientRuletag		=	NULLTAG;
	tag_t	*ColIndChilds		=	NULLTAG;
	tag_t	Childobject			=	NULLTAG;
	char   *taskowning_groupVal =	NULL;
	
	

	printf("\nInSide tm_ebom_mbom_rpt");fflush(stdout);
	
	char *VPrtNum=NULL;
	char *VPrtType=NULL;
	
	ITK_CALL(AOM_ask_value_string(VObjTag,"item_id",&VPrtNum));
	ITK_CALL(AOM_ask_value_string(VObjTag,"item_revision_id",&VPrtType));
	
	printf("\n Platform name------> %s\n",VPrtNum);fflush(stdout);
	printf("\n Platform name------> %s\n",VPrtType);fflush(stdout);
	if(VObjTag!=NULLTAG)
	{		
			
				ITKCALL(BOM_create_window(&bom_wnd ));
				ITKCALL(CFM_find("ERC release and above", &rule));
				//ITKCALL(BOM_set_window_config_rule(bom_wnd, rule));
				//ITKCALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
				printf ("\nrule count %d \n",rulefound);fflush(stdout);
				//if (rulefound > 0)
				//{
					//close_tag = closurerule[0];
					//printf ("closure rule found \n"); fflush(stdout);
				//}
				//ITKCALL(BOM_window_set_closure_rule( bom_wnd,close_tag, 0, rulename,rulevalue ));
		
				ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE));
				ITKCALL(BOM_set_window_top_line( bom_wnd, NULLTAG, VObjTag, NULLTAG, &top_lne ));

				if(top_lne!=NULLTAG)
				{
					ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
					printf("\n n_count --------> : %d\n", n_count);
					ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
					printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node
							
					if (count >0)
					{
						for (ichld=0;ichld<count ;ichld++ )
						{
							if(Childobject) Childobject=NULLTAG;
							Childobject=ColIndChilds[ichld];

							ITKCALL(AOM_ask_value_string(Childobject, "bl_item_item_id", &arch_item_id ));
							printf("\n arch_item_id ..:%s\n",arch_item_id); fflush(stdout);
							ITKCALL(AOM_ask_value_string(Childobject, "bl_rev_item_revision_id", &arch_item_idrev ));
							printf("\n arch_item_idrev ..:%s\n",arch_item_idrev); fflush(stdout);
							char*	 arch_item_ModAdd    			= NULL;	
							ITKCALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_ModuleAddress",&arch_item_ModAdd));
							printf("\n arch_item_idrev ..:%s\n",arch_item_ModAdd); fflush(stdout);
							
							if((tc_strcmp(arch_item_ModAdd,"MC1D01")==0) || (tc_strcmp(arch_item_ModAdd,"MC2A01")==0)|| (tc_strcmp(arch_item_ModAdd,"MC3Z01")==0)|| (tc_strcmp(arch_item_ModAdd,"MP1A01")==0)|| (tc_strcmp(arch_item_ModAdd,"MP1N01")==0)|| (tc_strcmp(arch_item_ModAdd,"MP3A01")==0)|| (tc_strcmp(arch_item_ModAdd,"MC1D02")==0)|| (tc_strcmp(arch_item_ModAdd,"MP1L01")==0))
							{
								ModPartAct	=	(char	*)MEM_alloc(300);
								tc_strcpy(ModPartAct,arch_item_id);
								tc_strcat(ModPartAct,"/");
								tc_strcat(ModPartAct,arch_item_idrev);

								printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
								setAddStr(icount,SetModulePart,ModPartAct);
							}
								//Find the ERC and explode and find PB part.
								if(lines2) lines2=NULL;

								ITKCALL(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));
								printf("\n Child parts count--> %d\n",n_lines2);fflush(stdout);

								if(n_lines2 > 0)
								{
									for (iMod=0;iMod<n_lines2 ;iMod++ )
									{
										if(PartChildobj) PartChildobj=NULLTAG;
										if(ModPartNo) ModPartNo=NULL;
										if(item_Rev_Seq) item_Rev_Seq=NULL;
										if(ModPartType) ModPartType=NULL;
										if(ModPartLine) ModPartLine=NULL;
										if(taskowning_groupVal) taskowning_groupVal=NULL;
										PartChildobj=lines2[iMod];

										ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
										printf("\n No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);

										ITKCALL(AOM_ask_value_string(PartChildobj, "bl_line_name", &ModPartLine ));
										printf("\n ModPartLine --> : %s\n",ModPartLine); fflush(stdout);
										
										ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
										printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);
										
										ITKCALL(AOM_ask_value_string(PartChildobj, "bl_Design_t5_RevPartType", &ModPartType ));
										printf("\n Part type Modules Under Architechtures --> : %s\n",ModPartType); fflush(stdout);
										
										char*	 ModPart_ModAdd    			= NULL;	
										ITKCALL(AOM_ask_value_string(PartChildobj,"bl_Design Revision_t5_ModuleAddress",&ModPart_ModAdd));

										//if(tc_strcmp(ModPartType,"M")==0)//To add Module and CP Modules
										//if((tc_strcmp(ModPartType,"M")==0) || (tc_strcmp(ModPartType,"CM")==0))
										//{
											if((tc_strcmp(ModPart_ModAdd,"MC1D01")==0) || (tc_strcmp(ModPart_ModAdd,"MC2A01")==0)|| (tc_strcmp(ModPart_ModAdd,"MC3Z01")==0)|| (tc_strcmp(ModPart_ModAdd,"MP1A01")==0)|| (tc_strcmp(ModPart_ModAdd,"MP1N01")==0)|| (tc_strcmp(ModPart_ModAdd,"MP3A01")==0)|| (tc_strcmp(ModPart_ModAdd,"MC1D02")==0)|| (tc_strcmp(ModPart_ModAdd,"MP1L01")==0))
											{
											ModPartAct	=	(char	*)MEM_alloc(300);
											tc_strcpy(ModPartAct,ModPartNo);
											tc_strcat(ModPartAct,"/");
											tc_strcat(ModPartAct,item_Rev_Seq);
											printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);

											setAddStr(icount,SetModulePart,ModPartAct);
											}

												iChildItemTag=0;
												t_ChildItemRev=NULLTAG;
												BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
												BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);
												if(t_ChildItemRev!=NULLTAG)
												{
													
													n_lines3=0;
													
													ITKCALL(Get_Part_BOM_Lvl(t_ChildItemRev,1,"ERC release and above",ChldStrutBdySh,&n_lines3));
													printf("\n\t\t n_lines3:%d",n_lines3);fflush(stdout);
													
													printf("\n Stage Assembly count--> %d\n",n_lines3);fflush(stdout);

													if(n_lines3 > 0)
													{
														for (iMod1=1;iMod1<=n_lines3 ;iMod1++ )
														{
															if(StageChildobj) StageChildobj=NULLTAG;	
															if(StagePartNo) StagePartNo=NULL;
															if(Stage_item_Rev_Seq) Stage_item_Rev_Seq=NULL;
															if(StagePartType) StagePartType=NULL;
															
															char*	 StagePartNo_ModAdd    			= NULL;
															
															StageChildobj=ChldStrutBdySh[iMod1].child_objs_bvr;

															ITKCALL(AOM_ask_value_string(StageChildobj, "bl_item_item_id", &StagePartNo ));
															printf("\n StagePartNo --> : %s\n",StagePartNo); fflush(stdout);
															
															ITKCALL(AOM_ask_value_string(StageChildobj, "bl_rev_item_revision_id", &Stage_item_Rev_Seq));
															printf("\n Stage_item_Rev_Seq --> : %s\n",Stage_item_Rev_Seq); fflush(stdout);
															
															ITKCALL(AOM_ask_value_string(StageChildobj, "bl_Design_t5_RevPartType", &StagePartType ));
															printf("\n StagePartType --> : %s\n",StagePartType); fflush(stdout);
															
															ITKCALL(AOM_ask_value_string(StageChildobj,"bl_Design Revision_t5_ModuleAddress",&StagePartNo_ModAdd));
															printf("\n stage Part type Modules Under StagePartNo_ModAdd for child parts --> : %s\n",StagePartNo_ModAdd); fflush(stdout);

															if((tc_strcmp(StagePartNo_ModAdd,"MC1D01")==0) || (tc_strcmp(StagePartNo_ModAdd,"MC2A01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MC3Z01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP1A01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP1N01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP3A01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MC1D02")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP1L01")==0))
															{
																//To add in set
																ModPartAct	=	(char	*)MEM_alloc(300);
																tc_strcpy(ModPartAct,StagePartNo);
																tc_strcat(ModPartAct,"/");
																tc_strcat(ModPartAct,Stage_item_Rev_Seq);

																printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
																setAddStr(icount,SetModulePart,ModPartAct);
															}
														}
													}
												}
										//}

									}//for loop
								}//if(n_lines2 > 0)
						}
					}
				}

	}
	else 
	{
		printf ("\n  Object is null\n"); fflush(stdout);	
	}
	
	return ifail;
}

int tm_ebom_snapshot(char *snapshot,char ***SetModulePart,int *icount)
{
	int	ifail 	=   ITK_ok;

	WSO_search_criteria_t SSCriteria;

	tag_t* SSobjTag		= NULLTAG;

	int SScount			= 0;
	int Item_ID			= 0;

	tag_t Snapshot_tag	= NULLTAG;
	tag_t window		= NULLTAG;
	tag_t item_rev_tags	= NULLTAG;
	tag_t top_line		= NULLTAG;

	char* SSTopLineRev	= NULL;
	char *Item_ID_str	= NULL;

	PIE_scope_t scope;
	scope=PIE_TEAMCENTER;

	printf("\nInSide tm_ebom_snapshot functionssssssss");fflush(stdout);
	
	printf("\nsnapshot ...%s\n", snapshot);fflush(stdout);
	
	ITKCALL(WSOM_clear_search_criteria(&SSCriteria));
	tc_strcpy(SSCriteria.class_name,"Snapshot");
	tc_strcpy(SSCriteria.name,snapshot);
	ITKCALL(WSOM_search(SSCriteria,&SScount,&SSobjTag));
	printf("\nSnapShot found :%d",SScount);fflush(stdout);
	
	int		rulefound		=	0;
	tag_t	*closurerule		=	NULLTAG;
	tag_t	close_tag			=	NULLTAG;
	char	**rulename			=	NULL;
		
	char	**rulevalue			=	NULL;

	if (SScount > 0)
	{		
		Snapshot_tag = SSobjTag[0];

		ITKCALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
		printf("\nSnapshot Top Line : %s",SSTopLineRev);fflush(stdout);

		ITKCALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));

		ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));
		
		ITKCALL(PIE_find_closure_rules("BOMLineskipforunconfigured",scope, &rulefound, &closurerule ));
		printf ("\nrule count %d \n",rulefound);fflush(stdout);
		if (rulefound > 0)
		{
			close_tag = closurerule[0];
			printf ("closure rule found \n"); fflush(stdout);
		}
		ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
		printf ("closure rule found applied \n"); fflush(stdout);
		ITKCALL(BOM_set_window_pack_all (window, FALSE));
		ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
		ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));

		ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
		ITKCALL(BOM_line_ask_attribute_string(top_line, Item_ID, &Item_ID_str));
		printf("\nItem_ID_str#:%s",Item_ID_str);fflush(stdout);


		GetAllChild_SnapShot(&top_line,2,SetModulePart,icount);

	}
	else 
	{
		printf ("\n  SnapShot not found [%s]\n", snapshot); fflush(stdout);	
	}
	
	
	return ifail;
}

void getMoRTHAttributes(tag_t PartObj)
{
	cmvrFlag=0;
	st5Pollutant_CM1Dup= NULL;
	st5Pollutant_HC1Dup= NULL;
	st5Pollutant_NH1Dup= NULL;
	st5Pollutant_RHC1Dup= NULL;
	st5Pollutant_NO1Dup= NULL;
	st5Pollutant_HCNO1Dup= NULL;
	st5Pollutant_PM1Dup= NULL;
	st5Pollutant_HO1Dup= NULL;
	st5BystanderPosDup= NULL;
	BBBACNUMDup= NULL;
	BBBACISDTDup= NULL;
	BBBACVLDTDup= NULL;
	VBCAPRCNUMDup= NULL;
	int ifail = ITK_ok;
	
	char* 	VehNo 					= NULL;
	
	tag_t relType = NULLTAG;
	tag_t* CMVRObjs = NULL;
	int CMVRObjsCount=0;
	tag_t CMVRObjTag = NULLTAG;
	
	ITK_CALL(AOM_ask_value_string(PartObj,"item_id",&VehNo));
	printf("\n  vehicleNumber1 : %s \n",VehNo); fflush(stdout);
	
	ITK_CALL(GRM_find_relation_type("T5_CmvrVeh", &relType));
	printf("\n CMVRObj=%u relType=%u\n",PartObj,relType);fflush(stdout);
	
	if( relType != NULLTAG )
	{
		ITK_CALL(GRM_list_primary_objects_only(PartObj,relType,&CMVRObjsCount,&CMVRObjs));
		printf("\n CMVRObjsCount=%d \n",CMVRObjsCount);fflush(stdout);
		if(CMVRObjsCount > 0)
		{

		CMVRObjTag = CMVRObjs[0];
		}

	}
	
		if(CMVRObjsCount == 0)
			{
				tag_t	*rev_list				= NULL;
				int Item_count      =  0;
				tag_t cPartOPtr = NULLTAG;
				tag_t			All_item_tag		= NULLTAG;
				ITK_CALL(ITEM_find_item (VehNo, &All_item_tag));
				ITK_CALL(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list));
				printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
				int ii = 0;
				if(Item_count > 0)
				{
					for(ii=Item_count-1;ii>=0;ii--)
					{
						cPartOPtr=rev_list[ii];
						char 	*rev_idd				= NULL;
						ITK_CALL(GRM_list_primary_objects_only(cPartOPtr,relType,&CMVRObjsCount,&CMVRObjs));
						
						ITK_CALL(AOM_UIF_ask_value (cPartOPtr, "item_revision_id", &rev_idd));
						printf("\n Eff: Latest released rev is:%s.", rev_idd);fflush(stdout);

						if(CMVRObjsCount > 0)
							break;
						else
							continue;
					}
				}

			}

			if(CMVRObjsCount > 0)
			{
				cmvrFlag=1;

				CMVRObjTag = CMVRObjs[0];
				char *CmvrIntentNum 	   = NULL;
				char *CmvrIntentNumDup 	   = NULL;
				char* status_rel = NULL;
				
				AOM_ask_value_string( CMVRObjTag, "t5_IntentNumber", &CmvrIntentNum);
				printf( "CmvrIntentNum:%s\n", CmvrIntentNum);fflush(stdout);
				if(CmvrIntentNum)
				{
					 tc_strdup(CmvrIntentNum,&CmvrIntentNumDup);	
					printf( "CmvrIntentNumDup:%s\n", CmvrIntentNumDup);fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(CMVRObjTag,"release_status_list",&status_rel));
				
				//if((tc_strstr(status_rel,"ERC Released") != NULL))
				if(tc_strstr(status_rel,"ERC Released") == NULL)
				{
				st5Pollutant_CM1Dup=MEM_alloc(50);
				st5Pollutant_HC1Dup = MEM_alloc(50);
				st5Pollutant_NH1Dup = MEM_alloc(50);
				st5Pollutant_RHC1Dup = MEM_alloc(50);
				st5Pollutant_NO1Dup = MEM_alloc(50);
				st5Pollutant_HCNO1Dup = MEM_alloc(50);
				st5Pollutant_PM1Dup = MEM_alloc(50);

				AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_CM", &st5Pollutant_CM1);
				printf( "st5Pollutant_CM1:%s\n", st5Pollutant_CM1);fflush(stdout);
				if(st5Pollutant_CM1)
				{
				//tc_strdup(st5Pollutant_CM1Dup1,&st5Pollutant_CM1);
				tc_strdup(st5Pollutant_CM1,&st5Pollutant_CM1Dup1);
				}
				printf( "st5Pollutant_CM1Dup1:%s\n", st5Pollutant_CM1Dup1);fflush(stdout);

				if(tc_strcmp(st5Pollutant_CM1Dup1,"NA") != 0)
				{
					
					AOM_ask_value_string( CMVRObjTag, "t5_CMUoM ", &CMUnit);
					printf( "CMUnit:%s\n", CMUnit);fflush(stdout);
					if(CMUnit)
					{
					tc_strdup(CMUnit,&CMUnitDup);
					}
					
					tc_strcpy(st5Pollutant_CM1Dup,st5Pollutant_CM1Dup1);
					tc_strcat(st5Pollutant_CM1Dup," ");
					tc_strcat(st5Pollutant_CM1Dup,CMUnitDup);
				}
				else
				{	tc_strcpy(st5Pollutant_CM1Dup,st5Pollutant_CM1Dup1); }

				printf( "st5Pollutant_CM1Dup:%s\n", st5Pollutant_CM1Dup);fflush(stdout);
				
				AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_HC", &st5Pollutant_HC1);
				
				printf( "st5Pollutant_HC1:%s\n", st5Pollutant_HC1);fflush(stdout);
				
				if(st5Pollutant_HC1)
				{
				tc_strdup(st5Pollutant_HC1,&st5Pollutant_HC1Dup1);
				}
				
				if(tc_strcmp(st5Pollutant_HC1Dup1,"NA") != 0)
				{
					AOM_ask_value_string( CMVRObjTag, "t5_HCUoM", &HCUnit);
					printf( "HCUnit:%s\n", HCUnit);fflush(stdout);
					
					if(HCUnit)
					{
					tc_strdup(HCUnit,&HCUnitDup);
					}
					tc_strcpy(st5Pollutant_HC1Dup,st5Pollutant_HC1Dup1);
					tc_strcat(st5Pollutant_HC1Dup," ");
					tc_strcat(st5Pollutant_HC1Dup,HCUnitDup);
				}
				else
				{	
				tc_strcpy(st5Pollutant_HC1Dup,st5Pollutant_HC1Dup1);
				}
				printf( "st5Pollutant_HC1Dup:%s\n", st5Pollutant_HC1Dup);fflush(stdout);
				
				AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_NH", &st5Pollutant_NH1);
				
				printf( "st5Pollutant_NH1:%s\n", st5Pollutant_NH1);fflush(stdout);
				
				if(st5Pollutant_NH1)
				{
				tc_strdup(st5Pollutant_NH1,&st5Pollutant_NH1Dup1);
				}
				if(tc_strcmp(st5Pollutant_NH1Dup1,"NA") != 0)
				{
					AOM_ask_value_string( CMVRObjTag, "t5_NMHCUoM", &NMHCUnit);
					printf( "NMHCUnit:%s\n", NMHCUnit);fflush(stdout);
					if(NMHCUnit)
					{
					tc_strdup(NMHCUnit,&NMHCUnitDup);
					}
					tc_strcpy(st5Pollutant_NH1Dup,st5Pollutant_NH1Dup1);
					tc_strcat(st5Pollutant_NH1Dup," ");
					tc_strcat(st5Pollutant_NH1Dup,NMHCUnitDup);
				}
				else
				{	tc_strcpy(st5Pollutant_NH1Dup,st5Pollutant_NH1Dup1); }
			
				printf( "st5Pollutant_NH1Dup:%s\n", st5Pollutant_NH1Dup);fflush(stdout);

				AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_RHC", &st5Pollutant_RHC1);
				
				printf( "st5Pollutant_RHC1:%s\n", st5Pollutant_RHC1);fflush(stdout);
				if(st5Pollutant_RHC1)
				{
				tc_strdup(st5Pollutant_RHC1,&st5Pollutant_RHC1Dup1);
				}
				if(tc_strcmp(st5Pollutant_RHC1Dup1,"NA") != 0)
				{
					AOM_ask_value_string( CMVRObjTag, "t5_RHCUoM", &RHCUnit);
					printf( "RHCUnit:%s\n", RHCUnit);fflush(stdout);
					if(RHCUnit)
					{
					tc_strdup(RHCUnit,&RHCUnitDup);
					}
					tc_strcpy(st5Pollutant_RHC1Dup,st5Pollutant_RHC1Dup1);
					tc_strcat(st5Pollutant_RHC1Dup," ");
					tc_strcat(st5Pollutant_RHC1Dup,RHCUnitDup);
				}
				else
				{	tc_strcpy(st5Pollutant_RHC1Dup,st5Pollutant_RHC1Dup1);}
			
				printf( "st5Pollutant_RHC1Dup:%s\n", st5Pollutant_RHC1Dup);fflush(stdout);
				
				AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_NO", &st5Pollutant_NO1);
				printf( "st5Pollutant_NO1:%s\n", st5Pollutant_NO1);fflush(stdout);
				
				if(st5Pollutant_NO1)
				{
				tc_strdup(st5Pollutant_NO1,&st5Pollutant_NO1Dup1);
				}
				if(tc_strcmp(st5Pollutant_NO1Dup1,"NA") != 0)
				{
					AOM_ask_value_string( CMVRObjTag, "t5_NOUoM", &NOUnit);
					printf( "NOUnit:%s\n", NOUnit);fflush(stdout);
					if(NOUnit)
					{
					tc_strdup(NOUnit,&NOUnitDup);
					}
					tc_strcpy(st5Pollutant_NO1Dup,st5Pollutant_NO1Dup1);
					tc_strcat(st5Pollutant_NO1Dup," ");
					tc_strcat(st5Pollutant_NO1Dup,NOUnitDup);
				}
				else
				{	tc_strcpy(st5Pollutant_NO1Dup,st5Pollutant_NO1Dup1);}
			
				printf( "st5Pollutant_NO1Dup:%s\n", st5Pollutant_NO1Dup);fflush(stdout);

				AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_HCNO", &st5Pollutant_HCNO1);
				
				printf( "st5Pollutant_HCNO1:%s\n", st5Pollutant_HCNO1);fflush(stdout);
				
				if(st5Pollutant_HCNO1)
				{
				tc_strdup(st5Pollutant_HCNO1,&st5Pollutant_HCNO1Dup1);
				}
				if(tc_strcmp(st5Pollutant_HCNO1Dup1,"NA") != 0)
				{
					AOM_ask_value_string( CMVRObjTag, "t5_HCNOUoM", &HCNOUnit);
					
					printf( "HCNOUnit:%s\n", HCNOUnit);fflush(stdout);
					
					if(HCNOUnit)
					{
					tc_strdup(HCNOUnit,&HCNOUnitDup);
					}
					tc_strcpy(st5Pollutant_HCNO1Dup,st5Pollutant_HCNO1Dup1);
					tc_strcat(st5Pollutant_HCNO1Dup," ");
					tc_strcat(st5Pollutant_HCNO1Dup,HCNOUnitDup);
				}
				else
				{	tc_strcpy(st5Pollutant_HCNO1Dup,st5Pollutant_HCNO1Dup1);	}
			
				printf( "st5Pollutant_HCNO1Dup:%s\n", st5Pollutant_HCNO1Dup);fflush(stdout);

				AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_PM", &st5Pollutant_PM1);
				
				printf( "st5Pollutant_PM1:%s\n", st5Pollutant_PM1);fflush(stdout);
				
				if(st5Pollutant_PM1)
				{
				tc_strdup(st5Pollutant_PM1,&st5Pollutant_PM1Dup1);
				}
				if(tc_strcmp(st5Pollutant_PM1Dup1,"NA") != 0)
				{
					AOM_ask_value_string( CMVRObjTag, "t5_PMUoM", &PMUnit);
					
					printf( "PMUnit:%s\n", PMUnit);fflush(stdout);
					
					if(PMUnit)
					{
					tc_strdup(PMUnit,&PMUnitDup);
					}
					tc_strcpy(st5Pollutant_PM1Dup,st5Pollutant_PM1Dup1);
					tc_strcat(st5Pollutant_PM1Dup," ");
					tc_strcat(st5Pollutant_PM1Dup,PMUnitDup);
				}
				else
				{	tc_strcpy(st5Pollutant_PM1Dup,st5Pollutant_PM1Dup1);	}


				printf( "st5Pollutant_PM1Dup:%s\n", st5Pollutant_PM1Dup);fflush(stdout);
				
				AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_HO", &st5Pollutant_HO1);
				
				printf( "st5Pollutant_HO1:%s\n", st5Pollutant_HO1);fflush(stdout);
				
				if(st5Pollutant_HO1)
				{
				tc_strdup(st5Pollutant_HO1,&st5Pollutant_HO1Dup);
				}
				
				printf( "st5Pollutant_HO1Dup:%s\n", st5Pollutant_HO1Dup);fflush(stdout);
				
				AOM_ask_value_string( CMVRObjTag, "t5_BystanderPos", &st5BystanderPos);
				
				printf( "st5BystanderPos:%s\n", st5BystanderPos);fflush(stdout);
				if(st5BystanderPos)
				{
				tc_strdup(st5BystanderPos,&st5BystanderPosDup);
				}
				printf( "st5BystanderPosDup:%s\n", st5BystanderPosDup);fflush(stdout);
				AOM_ask_value_string( CMVRObjTag, "t5_BBBACNum", &BBBACNUM);
				printf( "BBBACNUM:%s\n", BBBACNUM);fflush(stdout);
				if(BBBACNUM)
				{
				tc_strdup(BBBACNUM,&BBBACNUMDup);
				}
				printf( "st5BystanderPos:%s\n", st5BystanderPos);fflush(stdout);
				AOM_ask_value_string( CMVRObjTag, "t5_BBBACIsDt", &BBBACISDT);
				printf( "BBBACISDT:%s\n", BBBACISDT);fflush(stdout);
				if(BBBACISDT)
				{
				tc_strdup(BBBACISDT,&BBBACISDTDup);
				}
				printf( "st5BystanderPos:%s\n", BBBACISDTDup);fflush(stdout);
				AOM_ask_value_string( CMVRObjTag, "t5_BBBACVlDt", &BBBACVLDT);
				printf( "BBBACVLDT:%s\n", BBBACVLDT);fflush(stdout);
				if(BBBACVLDT)
				{
				tc_strdup(BBBACVLDT,&BBBACVLDTDup);
				}
				AOM_ask_value_string( CMVRObjTag, "t5_VBCAprCNum", &VBCAPRCNUM);
				printf( "VBCAPRCNUM:%s\n", VBCAPRCNUM);fflush(stdout);
				if(VBCAPRCNUM)
				{
				tc_strdup(VBCAPRCNUM,&VBCAPRCNUMDup);
				}
				AOM_ask_value_string( CMVRObjTag, "t5_VBCAprDt", &VBCAPRDT);
				printf( "VBCAPRDT:%s\n", VBCAPRDT);fflush(stdout);
				if(VBCAPRDT)
				{
				tc_strdup(VBCAPRDT,&VBCAPRDTDup);
				}

				printf("\nst5Pollutant_CM1Dup:%s",st5Pollutant_CM1Dup);fflush(stdout);
				printf("\nst5Pollutant_HC1Dup:%s",st5Pollutant_HC1Dup);fflush(stdout);
				printf("\nst5Pollutant_NH1Dup:%s",st5Pollutant_NH1Dup);fflush(stdout);
				printf("\nst5Pollutant_RHC1Dup:%s",st5Pollutant_RHC1Dup);fflush(stdout);
				printf("\nst5Pollutant_NO1Dup:%s",st5Pollutant_NO1Dup);fflush(stdout);
				printf("\nst5Pollutant_HCNO1Dup:%s",st5Pollutant_HCNO1Dup);fflush(stdout);
				printf("\nst5Pollutant_PM1Dup:%s",st5Pollutant_PM1Dup);fflush(stdout);
				printf("\nst5Pollutant_HO1Dup:%s",st5Pollutant_HO1Dup);fflush(stdout);
				printf("\nst5BystanderPosDup:%s",st5BystanderPosDup);fflush(stdout);
				printf("\nBBBACNUMDup:%s",BBBACNUMDup);fflush(stdout);
				printf("\nBBBACISDTDup:%s",BBBACISDTDup);fflush(stdout);
				printf("\nBBBACVLDTDup:%s",BBBACVLDTDup);fflush(stdout);
				printf("\nVBCAPRCNUMDup:%s",VBCAPRCNUMDup);fflush(stdout);
				printf("\nVBCAPRDTDup:%s",VBCAPRDTDup);fflush(stdout);
				
				fprintf(fsuccess,"\nst5Pollutant_CM1Dup:%s",st5Pollutant_CM1Dup);fflush(stdout);
				fprintf(fsuccess,"\nst5Pollutant_HC1Dup:%s",st5Pollutant_HC1Dup);fflush(stdout);
				fprintf(fsuccess,"\nst5Pollutant_NH1Dup:%s",st5Pollutant_NH1Dup);fflush(stdout);
				fprintf(fsuccess,"\nst5Pollutant_RHC1Dup:%s",st5Pollutant_RHC1Dup);fflush(stdout);
				fprintf(fsuccess,"\nst5Pollutant_NO1Dup:%s",st5Pollutant_NO1Dup);fflush(stdout);
				fprintf(fsuccess,"\nst5Pollutant_HCNO1Dup:%s",st5Pollutant_HCNO1Dup);fflush(stdout);
				fprintf(fsuccess,"\nst5Pollutant_PM1Dup:%s",st5Pollutant_PM1Dup);fflush(stdout);
				fprintf(fsuccess,"\nst5Pollutant_HO1Dup:%s",st5Pollutant_HO1Dup);fflush(stdout);
				fprintf(fsuccess,"\nst5BystanderPosDup:%s",st5BystanderPosDup);fflush(stdout);
				fprintf(fsuccess,"\nBBBACNUMDup:%s",BBBACNUMDup);fflush(stdout);
				fprintf(fsuccess,"\nBBBACISDTDup:%s",BBBACISDTDup);fflush(stdout);
				fprintf(fsuccess,"\nBBBACVLDTDup:%s",BBBACVLDTDup);fflush(stdout);
				fprintf(fsuccess,"\nVBCAPRCNUMDup:%s",VBCAPRCNUMDup);fflush(stdout);
				fprintf(fsuccess,"\nVBCAPRDTDup:%s",VBCAPRDTDup);fflush(stdout);
			}

			}
			else
			{
				printf("\ncmvrFlag : %d CMVRObjs not Found for Vehicle : %s",cmvrFlag,VehNo);fflush(stdout);
				fprintf(fsuccess,"\ncmvrFlag : %d CMVRObjs not Found for Vehicle : %s",cmvrFlag,VehNo);fflush(stdout);
				//goto CLEANUP;
			}
}
void myDzSiamCode2(struct DzSim* SiamAttr,char *siamCode2)
{
	int iGrossVehicleWeight = 0;
	int iVehicleLength = 0;
	int iSeatingCapacity = 0;
	int iVehicleOverAllLength = 0;
	int iEngineDisplacement = 0;
	char cHash[2]={"@"};
	//*siamCode1 = nlsStrAlloc(10);
	//siamCode2=(char *) MEM_alloc(40 * sizeof(char));

	printf("\n in function myDzSiamCode2");fflush(stdout);
	printf("\n\n\nVcClass:[%s]",SiamAttr->aVcClass);fflush(stdout);

		printf("\nString SeatingCapacity:[%s]",SiamAttr->cSeatingCapacity);
		printf("\nString VehicleLength:[%s]",SiamAttr->cVehicleLength);fflush(stdout);
		printf("\nVehicleType:[%s]",SiamAttr->cVehicleType);fflush(stdout);
		//printf("\nString EngineDisplacement:[%s]",SiamAttr->cEngineDisplacement);fflush(stdout);
		
		iVehicleOverAllLength = atoi(SiamAttr->cVehicleLength);
		
		printf("\nInteger VehicleOverAllLength:[%d]",iVehicleOverAllLength);fflush(stdout);
		
	if(tc_strcmp(SiamAttr->aVcClass,"CAR")==0)
	{
		if(tc_strcmp(SiamAttr->cVehicleLength,"NA")==0)
		{
			printf("\nOverall length is null for CAR");fflush(stdout);
			exit(1);
		}
		else
		{
			
			if(iVehicleOverAllLength <=3400)
			{
				printf("\n 22");fflush(stdout);
				tc_strcpy(siamCode2,"M1A1");
				printf("\nInteger VehicleOverAllLength22:[%s]",siamCode2);fflush(stdout);
			}
			else if ((iVehicleOverAllLength >= 3401) && (iVehicleOverAllLength <= 4000))
			{
				printf("\n 33");fflush(stdout);
				tc_strcpy(siamCode2,"M1A2");
				printf("\nInteger VehicleOverAllLength33:[%s]",siamCode2);fflush(stdout);
			}
			else if ((iVehicleOverAllLength >= 4001) && (iVehicleOverAllLength <= 4500))
			{
				tc_strcpy(siamCode2,"M1A3");
				printf("\nInteger VehicleOverAllLength44:[%s]",siamCode2);fflush(stdout);
			}
			else if ((iVehicleOverAllLength >= 4501) && (iVehicleOverAllLength <= 4700))
			{
				tc_strcpy(siamCode2,"M1A4");
				printf("\nInteger VehicleOverAllLength55:[%s]",siamCode2);fflush(stdout);
			}
			else if ((iVehicleOverAllLength >= 4701) && (iVehicleOverAllLength <= 5000))
			{
				tc_strcpy(siamCode2,"M1A5");
				printf("\nInteger VehicleOverAllLength66:[%s]",siamCode2);fflush(stdout);
			}
			else if (iVehicleOverAllLength >= 5001)
			{
				tc_strcpy(siamCode2,"M1A6");
				printf("\nInteger VehicleOverAllLength77:[%s]",siamCode2);fflush(stdout);
			}
		}
	}
}
void myDzSiamCode(struct DzSim* SiamAttr,char *siamCode1)
{
	int iGrossVehicleWeight = 0;
	int iVehicleLength = 0;
	int iSeatingCapacity = 0;
	int iVehicleOverAllLength = 0;
	int iEngineDisplacement = 0;
	char cHash[2]={"@"};
	//*siamCode1 = nlsStrAlloc(10);
	//siamCode1=(char *) MEM_alloc(40 * sizeof(char));
	tc_strcpy(siamCode1,"");
	printf("\n in function myDzSiamCode");fflush(stdout);
	printf("\n\n\nVcClass:[%s]",SiamAttr->aVcClass);fflush(stdout);

	//F_OUTK("SiamAttr->aVcClass",10,50,SiamAttr->aVcClass);

	/*fprintf(flog,"%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,SiamAttr->cVehicleLength,SiamAttr->cVehicleType,SiamAttr->cEngineDisplacement,SiamAttr->cGrossVehicleWeight,SiamAttr->cChassis);*/

	if(tc_strcmp(SiamAttr->aVcClass,"CAR")==0)
	{
		printf("\n in function car");fflush(stdout);

		/*printf("\nString SeatingCapacity:[%s]",SiamAttr->cSeatingCapacity);
		printf("\nString VehicleLength:[%s]",SiamAttr->cVehicleLength);fflush(stdout);
		printf("\nVehicleType:[%s]",SiamAttr->cVehicleType);fflush(stdout);
		printf("\nString EngineDisplacement:[%s]",SiamAttr->cEngineDisplacement);fflush(stdout);*/

		//F_OUTK("CSEATINGCAPACITY",10,50,SiamAttr->cSeatingCapacity);
		//F_OUTK("CVEHICLELENGTH",10,50,SiamAttr->cVehicleLength);
		//F_OUTK("CVEHICLETYPE",10,50,SiamAttr->cVehicleType);
		//F_OUTK("CENGINEDISPLACEMENT",10,50,SiamAttr->cEngineDisplacement);


		iSeatingCapacity = atoi(SiamAttr->cSeatingCapacity);
		iVehicleOverAllLength = atoi(SiamAttr->cVehicleLength);
		iEngineDisplacement = atoi(SiamAttr->cEngineDisplacement);
		
		fprintf(fUASAPMapping,"\n SiamCode Calculated based on following attribute:"); fflush(fUASAPMapping);
		fprintf(fUASAPMapping,"\n SeatingCapacity:%d",iSeatingCapacity); fflush(fUASAPMapping);
		fprintf(fUASAPMapping,"\n VehicleOverAllLength:%d",iVehicleOverAllLength); fflush(fUASAPMapping);
		fprintf(fUASAPMapping,"\n EngineDisplacement:%d",iEngineDisplacement); fflush(fUASAPMapping);
		fprintf(fUASAPMapping,"\n VehicleType:%s \n",SiamAttr->cVehicleType); fflush(fUASAPMapping);
		//if((tc_strcmp(SiamAttr->cEngineDisplacement,"NA")==0)||tc_strcmp(SiamAttr->cEngineDisplacement,"")==0)
		//{
			//iEngineDisplacement=0;
		//}
		//else
		//{
		//iEngineDisplacement = atoi(SiamAttr->cEngineDisplacement);
		//}
		//iEngineDisplacement=1198;

		printf("\nInteger SeatingCapacity:[%d]",iSeatingCapacity);fflush(stdout);
		printf("\nInteger VehicleOverAllLength:[%d]",iVehicleOverAllLength);fflush(stdout);
		printf("\nInteger EngineDisplacement:[%d]",iEngineDisplacement);fflush(stdout);
		printf("\nInteger VehicleType:[%s]",SiamAttr->cVehicleType);fflush(stdout);

		/*F_OUTK("ISEATINGCAPACITY",10,50,iSeatingCapacity);
		F_OUTK("IVEHICLEOVERALLLENGTH",10,50,iVehicleOverAllLength);
		F_OUTK("IENGINEDISPLACEMENT",10,50,iEngineDisplacement);
		F_OUTK("IVEHICLETYPE",10,50,SiamAttr->cVehicleType);*/
printf("\n in function car11");fflush(stdout);

		//fprintf(flog,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,SiamAttr->cVehicleLength,SiamAttr->cVehicleType,SiamAttr->cEngineDisplacement,cHash,cHash,cHash,cHash,cHash);
		printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,SiamAttr->cVehicleLength,SiamAttr->cVehicleType,SiamAttr->cEngineDisplacement,cHash,cHash,cHash,cHash,cHash);fflush(stdout);
printf("\n in function car22");fflush(stdout);

		if((tc_strcmp(SiamAttr->cVehicleLength,"NA")==0)||tc_strcmp(SiamAttr->cVehicleLength,"")==0)
		{
			printf("\nOverall length is null for CAR");fflush(stdout);
			exit(0);
		}

		printf("\n%d,%d,%s,%d",iSeatingCapacity,iVehicleOverAllLength,SiamAttr->cVehicleType,iEngineDisplacement);fflush(stdout);
		if((iSeatingCapacity <= 4)&&(iVehicleOverAllLength < 3200)&&(tc_strcmp(SiamAttr->cVehicleType,"HATCHBACK")==0)&&(iEngineDisplacement <= 800))
		{
			tc_strcpy(siamCode1,"M1A0");
		}
		else if((iSeatingCapacity <= 5)&&(iVehicleOverAllLength < 3600)&&(tc_strcmp(SiamAttr->cVehicleType,"HATCHBACK")==0)&&(iEngineDisplacement <= 1000))
		{
			tc_strcpy(siamCode1,"M1A1");
		}
		/*else if((iSeatingCapacity <= 5)&&((iVehicleOverAllLength > 3600)&&(iVehicleOverAllLength < 3988))&&(strcmp(SiamAttr->cVehicleType,"HATCHBACK")==0)&&(iEngineDisplacement <= 1405))*/ /*Requested by Vivek pande*/
		/*else if((iSeatingCapacity <= 5)&&((iVehicleOverAllLength > 3600)&&(iVehicleOverAllLength < 4000))&&(strcmp(SiamAttr->cVehicleType,"HATCHBACK")==0)&&(iEngineDisplacement <= 1400))*/
		else if((iSeatingCapacity <= 5)&&((iVehicleOverAllLength > 3600)&&(iVehicleOverAllLength < 4000))&&(
															(tc_strcmp(SiamAttr->cVehicleType,"SEDAN")==0)
															||(tc_strcmp(SiamAttr->cVehicleType,"ESTATE")==0)
															||(tc_strcmp(SiamAttr->cVehicleType,"NOTCHBACK")==0)
															||(tc_strcmp(SiamAttr->cVehicleType,"HATCHBACK")==0)
															||(tc_strcmp(SiamAttr->cVehicleType,"STATION WAGON")==0))&&(iEngineDisplacement <= 1405))/*again Requested by Vivek pande on 15.mar2012*/
															/*SEDAN ,ESTATE, NOTCHBACK, STATION WAGON added on request of Mr vivek pande on 16.05.2012 */
		{
			tc_strcpy(siamCode1,"M1A2");
		}
		/*else if((iSeatingCapacity <= 5)&&((iVehicleOverAllLength >= 3988)&&(iVehicleOverAllLength <= 4250))&&*//*Requested by Vivek pande*/
		else if((iSeatingCapacity <= 5)&&((iVehicleOverAllLength >= 4000)&&(iVehicleOverAllLength <= 4250))&&
				(
					(tc_strcmp(SiamAttr->cVehicleType,"SEDAN")==0)||
					(tc_strcmp(SiamAttr->cVehicleType,"ESTATE")==0)||
					(tc_strcmp(SiamAttr->cVehicleType,"NOTCHBACK")==0)||
					(tc_strcmp(SiamAttr->cVehicleType,"HATCHBACK")==0)||
					(strcmp(SiamAttr->cVehicleType,"STATION WAGON")==0)
				/*)&&(iEngineDisplacement <= 1405)*/ /*Requested by Vivek pande*/
				)&&(iEngineDisplacement <= 1600)
				)
		{
			tc_strcpy(siamCode1,"M1A3");
		}
		else if((iSeatingCapacity <= 5)&&((iVehicleOverAllLength > 4250)&&(iVehicleOverAllLength <= 4500))&&
				(
					(tc_strcmp(SiamAttr->cVehicleType,"SEDAN")==0)||
					(tc_strcmp(SiamAttr->cVehicleType,"ESTATE")==0)||
					(tc_strcmp(SiamAttr->cVehicleType,"NOTCHBACK")==0)||
					(tc_strcmp(SiamAttr->cVehicleType,"HATCHBACK")==0)
				)&&(iEngineDisplacement <= 1600))
		{
			tc_strcpy(siamCode1,"M1A4");
		}
		else if((iSeatingCapacity <= 5)&&((iVehicleOverAllLength > 4500)&&(iVehicleOverAllLength <= 4700))&&
				(
					(tc_strcmp(SiamAttr->cVehicleType,"SEDAN")==0)||
					(tc_strcmp(SiamAttr->cVehicleType,"ESTATE")==0)||
					(tc_strcmp(SiamAttr->cVehicleType,"NOTCHBACK")==0)
				)&&(iEngineDisplacement <= 2000))
		{
			tc_strcpy(siamCode1,"M1A5");
		}
		else if((iSeatingCapacity <= 5)&&((iVehicleOverAllLength > 4700)&&(iVehicleOverAllLength <= 5000))&&
				(
					(tc_strcmp(SiamAttr->cVehicleType,"SEDAN")==0)||
					(tc_strcmp(SiamAttr->cVehicleType,"ESTATE")==0)
				)&&(iEngineDisplacement <= 3000))
		{
			tc_strcpy(siamCode1,"M1A6");
		}
		else if((iSeatingCapacity <= 5)&&((iVehicleOverAllLength > 4700)&&(iVehicleOverAllLength <= 5000))&&
				(
					(tc_strcmp(SiamAttr->cVehicleType,"SEDAN")==0)||
					(tc_strcmp(SiamAttr->cVehicleType,"ESTATE")==0)
				)&&(iEngineDisplacement <= 5000))
		{
			tc_strcpy(siamCode1,"M1A7");
		}
	}
	
	printf("\nvalue of siamCode1 in function myDzSiamCode%s ",siamCode1);fflush(stdout);
	if(tc_strcmp(SiamAttr->aVcClass,"MUV")==0)
	{
		/*printf("\nString SeatingCapacity:[%s]",SiamAttr->cSeatingCapacity);fflush(stdout);
		printf("\nString VehicleLength:[%s]",SiamAttr->cVehicleLength);fflush(stdout);
		printf("\nString GrossVehicleWeight:[%s]",SiamAttr->cGrossVehicleWeight);fflush(stdout);*/

		//F_OUTK("CSEATINGCAPACITY",10,50,SiamAttr->cSeatingCapacity);
		//F_OUTK("CVEHICLELENGTH",10,50,SiamAttr->cVehicleLength);
		//F_OUTK("CGROSSVEHICLEWEIGHT",10,50,SiamAttr->cGrossVehicleWeight);


		iGrossVehicleWeight = atoi(SiamAttr->cGrossVehicleWeight);
		iVehicleLength = atoi(SiamAttr->cVehicleLength);
		iSeatingCapacity = atoi(SiamAttr->cSeatingCapacity);

		/*printf("\nIntGrossVehicleWeight:[%d]",iGrossVehicleWeight);fflush(stdout);
		printf("\nIntVehicleLength:[%d]",iVehicleLength);fflush(stdout);
		printf("\nIntSeatingCapacity:[%d]",iSeatingCapacity);fflush(stdout);

		F_OUTK("IGROSSVEHICLEWEIGHT",10,50,iGrossVehicleWeight);
		F_OUTK("IVEHICLELENGTH",10,50,iVehicleLength);
		F_OUTK("ISEATINGCAPACITY",10,50,iSeatingCapacity);*/


		//fprintf(flog,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,SiamAttr->cVehicleLength,cHash,cHash,SiamAttr->cGrossVehicleWeight,SiamAttr->cVehAppl,cHash,cHash,cHash);
		printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,SiamAttr->cVehicleLength,cHash,cHash,SiamAttr->cGrossVehicleWeight,SiamAttr->cVehAppl,cHash,cHash,cHash);fflush(stdout);

		if((tc_strcmp(SiamAttr->cSeatingCapacity,"NA") == 0)||(tc_strcmp(SiamAttr->cSeatingCapacity,"") == 0))
		{
			printf("\nSeatingCapacity is NULL");fflush(stdout);
			exit(0);
		}
		if(tc_strcmp(SiamAttr->cVehAppl,"ARMY")==0)
		{
			if(iSeatingCapacity <5 )
			{
				if((tc_strcmp(SiamAttr->cVehicleLength,"NA") == 0)||(tc_strcmp(SiamAttr->cVehicleLength,"") == 0))
				{
					printf("\nVehicleLength is NULL");fflush(stdout);
					exit(0);
				}
				if(iVehicleLength < 4400)
				{
					tc_strcpy(siamCode1,"M1BUV1");
				}
				else if((iVehicleLength >= 4400)&&(iVehicleLength <= 4700))
				{
					tc_strcpy(siamCode1,"M1BUV2");
				}
				else if(iVehicleLength > 4700)
				{
					tc_strcpy(siamCode1,"M1BUV3");
				}
			}
		}
		if(tc_strcmp(SiamAttr->cVehAppl,"AMBULANCE")!=0)
		{
			if((iSeatingCapacity >= 5)&&(iSeatingCapacity < 10))
			{
				if((tc_strcmp(SiamAttr->cVehicleLength,"NA") == 0)||(tc_strcmp(SiamAttr->cVehicleLength,"") == 0))
				{
					printf("\nVehicleLength is NULL");fflush(stdout);
					exit(0);
				}
				if(iVehicleLength < 4400)
				{
					tc_strcpy(siamCode1,"M1BUV1");
				}
				else if((iVehicleLength >= 4400)&&(iVehicleLength <= 4700))
				{
					tc_strcpy(siamCode1,"M1BUV2");
				}
				else if(iVehicleLength > 4700)
				{
					tc_strcpy(siamCode1,"M1BUV3");
				}
			}
			else if(iSeatingCapacity >= 10)
			{
				if((tc_strcmp(SiamAttr->cGrossVehicleWeight,"NA") == 0)||(tc_strcmp(SiamAttr->cGrossVehicleWeight,"") == 0))
				{
					printf("\nGrossVehicleWeight is NULL");fflush(stdout);
					exit(0);
				}
				if((iGrossVehicleWeight < 5000))
				{
					printf("\nGrossVehicle Weight is NULL");fflush(stdout);
					if(iSeatingCapacity <= 13)
					{
						tc_strcpy(siamCode1,"M2A1");
					}
					else if(iSeatingCapacity > 13)
					{
						tc_strcpy(siamCode1,"M2A2");
					}
				}
				else
				{
					if((iGrossVehicleWeight >= 5000)&&(iGrossVehicleWeight < 7500))
					{
						if((iSeatingCapacity >= 9)&&(iSeatingCapacity < 13))
						{
							tc_strcpy(siamCode1,"M3A1");
						}
						if(iSeatingCapacity > 13)
						{
							tc_strcpy(siamCode1,"M3A2");
						}
					}
					else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 12000))
					{
						if((iSeatingCapacity >= 9)&&(iSeatingCapacity < 13))
						{
							tc_strcpy(siamCode1,"M3B1");
						}
						if(iSeatingCapacity > 13)
						{
							tc_strcpy(siamCode1,"M3B2");
						}
					}
					else if((iGrossVehicleWeight >= 12000)&&(iGrossVehicleWeight <= 16200))
					{
						if((iSeatingCapacity >= 9)&&(iSeatingCapacity < 13))
						{
							tc_strcpy(siamCode1,"M3C1");
						}
						if(iSeatingCapacity > 13)
						{
							tc_strcpy(siamCode1,"M3C2");
						}
					}
					else if(iGrossVehicleWeight > 16200)
					{
						if(iSeatingCapacity > 13)
						{
							tc_strcpy(siamCode1,"M3D");
						}
					}
				}
			}
		}
		else if(tc_strcmp(SiamAttr->cVehAppl,"AMBULANCE")==0)
		{
			if((iVehicleLength > 0)&&(iVehicleLength <= 4400))
			{
				tc_strcpy(siamCode1,"M1BUV1");
			}
			else if((iVehicleLength > 4400)&&(iVehicleLength <= 4700))
			{
				tc_strcpy(siamCode1,"M1BUV2");
			}
			else if(iVehicleLength > 4700)
			{
				tc_strcpy(siamCode1,"M1BUV3");
			}
		}
	}
	else if(tc_strcmp(SiamAttr->aVcClass,"LMV")==0)
	{
		/*printf("\nString SeatingCapacity:[%s]",SiamAttr->cSeatingCapacity);fflush(stdout);
		printf("\nString VehicleLength:[%s]",SiamAttr->cVehicleLength);fflush(stdout);
		printf("\nString GrossVehicleWeight:[%s]",SiamAttr->cGrossVehicleWeight);fflush(stdout);
		printf("\nString MajorModel:[%s]",SiamAttr->cMajorModel);fflush(stdout);
		printf("\nString Mascot:[%s]",SiamAttr->cMascot);fflush(stdout);*/

		//F_OUTK("SEATINGCAPACITY",10,50,SiamAttr->cSeatingCapacity);
		//F_OUTK("VEHICLELENGTH",10,50,SiamAttr->cVehicleLength);
		//F_OUTK("GROSSVEHICLEWEIGHT",10,50,SiamAttr->cGrossVehicleWeight);
		//F_OUTK("MAJORMODEL",10,50,SiamAttr->cMajorModel);
		//F_OUTK("MASCOT",10,50,SiamAttr->cMascot);


		iGrossVehicleWeight = atoi(SiamAttr->cGrossVehicleWeight);
		iVehicleLength = atoi(SiamAttr->cVehicleLength);
		iSeatingCapacity = atoi(SiamAttr->cSeatingCapacity);

		/*printf("\nIntGrossVehicleWeight:[%d]",iGrossVehicleWeight);fflush(stdout);
		printf("\nIntVehicleLength:[%d]",iVehicleLength);fflush(stdout);
		printf("\nIntSeatingCapacity:[%d]",iSeatingCapacity);fflush(stdout);

		F_OUTK("IGROSSVEHICLEWEIGHT",10,50,iGrossVehicleWeight);
		F_OUTK("IVEHICLELENGTH",10,50,iVehicleLength);
		F_OUTK("ISEATINGCAPACITY",10,50,iSeatingCapacity);*/


		//fprintf(flog,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,SiamAttr->cVehicleLength,cHash,cHash,SiamAttr->cGrossVehicleWeight,cHash,cHash,SiamAttr->cMajorModel,SiamAttr->cMascot);
		printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,SiamAttr->cVehicleLength,cHash,cHash,SiamAttr->cGrossVehicleWeight,cHash,cHash,SiamAttr->cMajorModel,SiamAttr->cMascot);fflush(stdout);

		/*if(
		((tc_strcmp(SiamAttr->cMajorModel,"TATA VENTURE")==0)||(tc_strcmp(SiamAttr->cMajorModel,"TATA ACE")==0)||(tc_strcmp(SiamAttr->cMajorModel,"MAGIC IRIS")==0))
		&&
			((tc_strcmp(SiamAttr->cMascot,"MAGIC_CNG_HT")==0)
			||(tc_strcmp(SiamAttr->cMascot,"MAGIC_IRIS")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA_ACE_MAGIC_CNG")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA_ACE_MAGIC_HT")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA_ACE_MAGIC")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA_ACE_MICROBUS")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA_PENGUIN")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA_VENTURE_CX")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA_VENTURE_EX")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA_VENTURE_GX")==0)
			||(tc_strcmp(SiamAttr->cMascot,"MAGIC CNG HT")==0)
			||(tc_strcmp(SiamAttr->cMascot,"MAGIC IRIS")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA ACE MAGIC CNG")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA ACE MAGIC HT")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA ACE MAGIC")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA ACE MICROBUS")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA PENGUIN")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA VENTURE CX")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA VENTURE EX")==0)
			||(tc_strcmp(SiamAttr->cMascot,"TATA VENTURE GX")==0)
			)
		)
		{
				tc_strcpy(siamCode1,"M1CV2");
		}*/ /*new logic on 16.05.2012 Mr Vivek pande*/
		/*New Logic as per CR-FY19-0088 on 01.10.2018*/
		if(
				(tc_strcmp(SiamAttr->cMajorModel,"TATA VENTURE")==0 ||
				tc_strcmp(SiamAttr->cMajorModel,"MAGIC EXPRESS")==0 || 
				tc_strcmp(SiamAttr->cMajorModel,"TATA MAGIC EXPRESS")==0 ||
				tc_strcmp(SiamAttr->cMajorModel,"TATA MICROBUS")==0 ||
				tc_strcmp(SiamAttr->cMajorModel,"TATA_ACE_MICROBUS")==0
				)
				&&
				(tc_strcmp(SiamAttr->cMascot,"MAGIC_CNG_HT")==0 ||
				tc_strcmp(SiamAttr->cMascot,"MAGIC EXPRESS")==0 ||
				tc_strcmp(SiamAttr->cMascot,"TATA VENTURE CX")==0 ||
				tc_strcmp(SiamAttr->cMascot,"TATA VENTURE EX")==0 ||
				tc_strcmp(SiamAttr->cMascot,"TATA VENTURE GX")==0 ||
				tc_strcmp(SiamAttr->cMascot,"TATA VENTURE LX")==0 ||
				tc_strcmp(SiamAttr->cMascot,"TATA_VENTURE_CX")==0 ||
				tc_strcmp(SiamAttr->cMascot,"TATA_VENTURE_EX")==0 ||
				tc_strcmp(SiamAttr->cMascot,"TATA_VENTURE_GX")==0 ||
				tc_strcmp(SiamAttr->cMascot,"TATA_VENTURE_LX")==0 ||
				tc_strcmp(SiamAttr->cMascot,"VENTURE")==0)
			)
		{
			tc_strcpy(siamCode1,"M1CV1");
		}
		else if(((tc_strcmp(SiamAttr->cMajorModel,"TATA ACE")==0)||
				(tc_strcmp(SiamAttr->cMajorModel,"MAGIC IRIS")==0)||
				(tc_strcmp(SiamAttr->cMajorModel,"TATA ACE ZIP")==0) ||
				(tc_strcmp(SiamAttr->cMajorModel,"MAGIC CNG")==0) ||
				(tc_strcmp(SiamAttr->cMajorModel,"MAGIC HT")==0) ||
				(tc_strcmp(SiamAttr->cMajorModel,"MAGIC IRIS CNG")==0) ||
				(tc_strcmp(SiamAttr->cMajorModel,"MAGIC MANTRA")==0)
				)
				&&
				((tc_strcmp(SiamAttr->cMascot,"MAGIC_CNG_HT")==0)
				||(tc_strcmp(SiamAttr->cMascot,"MAGIC_IRIS")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA_ACE_MAGIC_CNG")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA_ACE_MAGIC_HT")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA_ACE_MAGIC")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA_MAGIC_CNG")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA_MAGIC_HT")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA_MAGIC")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA_ACE_MICROBUS")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA_PENGUIN")==0)
				||(tc_strcmp(SiamAttr->cMascot,"MAGIC IRIS")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA ACE MAGIC CNG")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA ACE MAGIC HT")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA ACE MAGIC")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA MAGIC CNG")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA MAGIC HT")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA MAGIC")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA ACE MICROBUS")==0)
				||(tc_strcmp(SiamAttr->cMascot,"TATA PENGUIN")==0)
				||(tc_strcmp(SiamAttr->cMascot,"MAGIC_IRIS_CNG")==0)
				||(tc_strcmp(SiamAttr->cMascot,"MAGIC_MANTRA")==0)
				)
		)
		{
			tc_strcpy(siamCode1,"M1CV2");
		}
		else if((iSeatingCapacity >= 5)&&(iSeatingCapacity < 10))
		{
			if((tc_strcmp(SiamAttr->cVehicleLength,"NA")==0)||(tc_strcmp(SiamAttr->cVehicleLength,"")==0))
			{
				printf("\nVehicleLength NULL");fflush(stdout);
				exit(0);
			}
			if(iVehicleLength < 4400)
			{
				tc_strcpy(siamCode1,"M1BUV1");
			}
			else if((iVehicleLength >= 4400)&&(iVehicleLength <= 4700))
			{
				tc_strcpy(siamCode1,"M1BUV2");
			}
			else if(iVehicleLength > 4700)
			{
				tc_strcpy(siamCode1,"M1BUV3");
			}
		}
		else if(iSeatingCapacity >= 10)
		{
			if((tc_strcmp(SiamAttr->cGrossVehicleWeight,"NA")==0)||(tc_strcmp(SiamAttr->cGrossVehicleWeight,"")==0))
			{
				printf("\nGrossVehicleWeight NULL");fflush(stdout);
				exit(0);
			}
			if((iGrossVehicleWeight < 5000))
			{
				printf("\nGrossVehicle Weight is NULL");fflush(stdout);
				if(iSeatingCapacity <= 13)
				{
					tc_strcpy(siamCode1,"M2A1");
				}
				else if(iSeatingCapacity > 13)
				{
					tc_strcpy(siamCode1,"M2A2");
				}
			}
			else
			{
				if((iGrossVehicleWeight >= 5000)&&(iGrossVehicleWeight < 7500))
				{
					if((iSeatingCapacity >= 9)&&(iSeatingCapacity < 13))
					{
						tc_strcpy(siamCode1,"M3A1");
					}
					if(iSeatingCapacity > 13)
					{
						tc_strcpy(siamCode1,"M3A2");
					}
				}
				else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 12000))
				{
					if((iSeatingCapacity >= 9)&&(iSeatingCapacity < 13))
					{
						tc_strcpy(siamCode1,"M3B1");
					}
					if(iSeatingCapacity > 13)
					{
						tc_strcpy(siamCode1,"M3B2");
					}
				}
				else if((iGrossVehicleWeight >= 12000)&&(iGrossVehicleWeight <= 16200))
				{
					if((iSeatingCapacity >= 9)&&(iSeatingCapacity < 13))
					{
						tc_strcpy(siamCode1,"M3C1");
					}
					if(iSeatingCapacity > 13)
					{
						tc_strcpy(siamCode1,"M3C2");
					}
				}
				else if(iGrossVehicleWeight > 16200)
				{
					if(iSeatingCapacity > 13)
					{
						tc_strcpy(siamCode1,"M3D");
					}
				}
				if(iGrossVehicleWeight <= 3500)
				{
					if(iGrossVehicleWeight < 2000)
					{
						tc_strcpy(siamCode1,"N1A1");
					}
					if((iGrossVehicleWeight >= 2000)&&(iGrossVehicleWeight < 3500))
					{
						tc_strcpy(siamCode1,"N1A2");
					}
				}
			}
		}
		/*else if(tc_strcmp(SiamAttr->cSeatingCapacity,"1")==0)*/
		else if((iSeatingCapacity >= 1)&&(iSeatingCapacity <= 4))/*requested by Mr vivek pande on 13.02.2011*/
		{
			if((tc_strcmp(SiamAttr->cGrossVehicleWeight,"NA")==0)||(tc_strcmp(SiamAttr->cGrossVehicleWeight,"")==0))
			{
				printf("\nGrossVehicleWeight NULL");fflush(stdout);
				exit(0);
			}
			if((iGrossVehicleWeight > 0 )&&(iGrossVehicleWeight < 2000))
			{
				tc_strcpy(siamCode1,"N1A1");
			}
			else if((iGrossVehicleWeight >= 2000)&&(iGrossVehicleWeight < 3500))
			{
				tc_strcpy(siamCode1,"N1A2");
			}else if((iGrossVehicleWeight >= 3500)&&(iGrossVehicleWeight < 6000))
			{
				tc_strcpy(siamCode1,"N2A1");
			}
			else if((iGrossVehicleWeight >= 6000)&&(iGrossVehicleWeight < 7500))
			{
				tc_strcpy(siamCode1,"N2A2");
			}
			else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 10000))
			{
				tc_strcpy(siamCode1,"N2A3");
			}
			else if((iGrossVehicleWeight >= 10000)&&(iGrossVehicleWeight < 12000))
			{
				tc_strcpy(siamCode1,"N2A4");
			}
		}
	}
	else if(tc_strcmp(SiamAttr->aVcClass,"LCV")==0)
	{

		//printf("\nString GrossVehicleWeight:[%s]",SiamAttr->cGrossVehicleWeight);fflush(stdout);

		//F_OUTK("CGROSSVEHICLEWEIGHT",10,50,SiamAttr->cGrossVehicleWeight);


		iGrossVehicleWeight = atoi(SiamAttr->cGrossVehicleWeight);
		iSeatingCapacity = atoi(SiamAttr->cSeatingCapacity);
		/*
		printf("\nIntSeatingCapacity:[%d]",iSeatingCapacity);fflush(stdout);
		printf("\nIntGrossVehicleWeight:[%d]",iGrossVehicleWeight);fflush(stdout);

		F_OUTK("ISEATINGCAPACITY",10,50,iSeatingCapacity);
		F_OUTK("IGROSSVEHICLEWEIGHT",10,50,iGrossVehicleWeight);*/

		//fprintf(flog,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,cHash,cHash,cHash,SiamAttr->cGrossVehicleWeight,SiamAttr->cVehAppl,cHash,cHash,cHash);
		printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,cHash,cHash,cHash,SiamAttr->cGrossVehicleWeight,SiamAttr->cVehAppl,cHash,cHash,cHash);fflush(stdout);

		if((tc_strcmp(SiamAttr->cGrossVehicleWeight,"NA")==0)||(tc_strcmp(SiamAttr->cGrossVehicleWeight,"")==0))
		{
			printf("\nGrossVehicleWeight NULL");fflush(stdout);
			exit(0);
		}
		if(tc_strcmp(SiamAttr->cVehAppl,"BUS")!=0)
		{
			if(iGrossVehicleWeight <= 3500)
			{
				if(iGrossVehicleWeight < 2000)
				{
					tc_strcpy(siamCode1,"N1A1");
				}
				if((iGrossVehicleWeight >= 2000)&&(iGrossVehicleWeight < 3500))
				{
					tc_strcpy(siamCode1,"N1A2");
				}
			}
			else if((iGrossVehicleWeight >= 3500)&&(iGrossVehicleWeight < 6000))
			{
				tc_strcpy(siamCode1,"N2A1");
			}
			else if((iGrossVehicleWeight >= 6000)&&(iGrossVehicleWeight < 7500))
			{
				tc_strcpy(siamCode1,"N2A2");
			}
			else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 10000))
			{
				tc_strcpy(siamCode1,"N2A3");
			}
			else if((iGrossVehicleWeight >= 10000)&&(iGrossVehicleWeight < 12000))
			{
				tc_strcpy(siamCode1,"N2A4");
			}
		}
		else if(tc_strcmp(SiamAttr->cVehAppl,"BUS")==0)
		{
			if((iGrossVehicleWeight >= 1)&&(iGrossVehicleWeight < 5000))
			{
				if(strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M2A2");
				}
				else
				{
					tc_strcpy(siamCode1,"M2A1");
				}
			}else if((iGrossVehicleWeight >= 5000)&&(iGrossVehicleWeight < 7500))
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
				{
						tc_strcpy(siamCode1,"N2A2");
				}
				else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3A2");
				}
				else
				{
					tc_strcpy(siamCode1,"M3A1");
				}
			}
			else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 12000))
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
				{
						tc_strcpy(siamCode1,"N2A3");
				}
				else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3B2");
				}
				else
				{
					tc_strcpy(siamCode1,"M3B1");
				}
			}
			else if((iGrossVehicleWeight >= 12000)&&(iGrossVehicleWeight <= 16200))
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
				{
						tc_strcpy(siamCode1,"N3A1");
				}
				else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3C2");
				}
				else
				{
					tc_strcpy(siamCode1,"M3C1");
				}
			}
			else if(iGrossVehicleWeight > 16200)
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3D");
				}
			}
		}
	}
	else if(tc_strcmp(SiamAttr->aVcClass,"HCV")==0)
	{

		/*printf("\nString GrossVehicleWeight:[%s]",SiamAttr->cGrossVehicleWeight);fflush(stdout);
		printf("\nString Chassis:[%s]",SiamAttr->cChassis);fflush(stdout);*/

		//F_OUTK("CGROSSVEHICLEWEIGHT",10,50,SiamAttr->cGrossVehicleWeight);
		//F_OUTK("CCHASSIS",10,50,SiamAttr->cChassis);


		iGrossVehicleWeight = atoi(SiamAttr->cGrossVehicleWeight);


		//printf("\nIntGrossVehicleWeight:[%d]",iGrossVehicleWeight);fflush(stdout);
		//F_OUTK("IGROSSVEHICLEWEIGHT",10,50,iGrossVehicleWeight);


		//fprintf(flog,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,cHash,cHash,cHash,SiamAttr->cGrossVehicleWeight,SiamAttr->cVehAppl,SiamAttr->cChassis,cHash,cHash);
		printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,cHash,cHash,cHash,SiamAttr->cGrossVehicleWeight,SiamAttr->cVehAppl,SiamAttr->cChassis,cHash,cHash);fflush(stdout);

		if((tc_strcmp(SiamAttr->cGrossVehicleWeight,"NA")==0)||(tc_strcmp(SiamAttr->cGrossVehicleWeight,"")==0))
		{
			printf("\nGrossVehicleWeight NULL");fflush(stdout);
			exit(0);
		}
		if(tc_strcmp(SiamAttr->cChassis,"LPS")!=0)
		{
			if(tc_strcmp(SiamAttr->cVehAppl,"BUS")!=0)
			{
				if((iGrossVehicleWeight >= 3500)&&(iGrossVehicleWeight < 6000))
				{
					tc_strcpy(siamCode1,"N2A1");
				}
				else if((iGrossVehicleWeight >= 6000)&&(iGrossVehicleWeight < 7500))
				{
					tc_strcpy(siamCode1,"N2A2");
				}
				else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 10000))
				{
					tc_strcpy(siamCode1,"N2A3");
				}
				else if((iGrossVehicleWeight >= 10000)&&(iGrossVehicleWeight < 12000))
				{
					tc_strcpy(siamCode1,"N2A4");
				}
				else if((iGrossVehicleWeight >= 12000)&&(iGrossVehicleWeight <= 16200))
				{
					tc_strcpy(siamCode1,"N3A1");
				}
				else if((iGrossVehicleWeight > 16200)&&(iGrossVehicleWeight <= 25000))
				{
					tc_strcpy(siamCode1,"N3B1(a)");
				}
				else if(iGrossVehicleWeight > 25000)
				{
					tc_strcpy(siamCode1,"N3B1(b)");
				}
			}
			else if(tc_strcmp(SiamAttr->cVehAppl,"BUS")==0)
			{
				if((iGrossVehicleWeight >= 5000)&&(iGrossVehicleWeight < 7500))
				{
					if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
					{
						tc_strcpy(siamCode1,"N2A2");
					}
					else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
					{
						tc_strcpy(siamCode1,"M3A2");
					}
					else
					{
						tc_strcpy(siamCode1,"M3A1");
					}/*Pande sir requested for logic of IPC=NA*/
				}
				else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 12000))
				{
					if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
					{
						tc_strcpy(siamCode1,"N2A3");
					}
					else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
					{
						tc_strcpy(siamCode1,"M3B2");
					}
					else
					{
						tc_strcpy(siamCode1,"M3B1");
					}/*Pande sir requested for logic of IPC=NA*/
				}
				else if((iGrossVehicleWeight >= 12000)&&(iGrossVehicleWeight <= 16200))
				{

					if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
					{
						tc_strcpy(siamCode1,"N3A1");
					}
					else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
					{
						tc_strcpy(siamCode1,"M3C2");
					}
					else
					{
						tc_strcpy(siamCode1,"M3C1");
					}/*Pande sir requested for logic of IPC=NA*/
				}
				else if(iGrossVehicleWeight > 16200)
				{
					if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
					{
						tc_strcpy(siamCode1,"M3D");
					}
				}
			}

		}
		else if(tc_strcmp(SiamAttr->cChassis,"LPS")==0)
		{
			if((iGrossVehicleWeight >= 16200)&&(iGrossVehicleWeight < 26400))
			{
				tc_strcpy(siamCode1,"N3B2(a)");
			}
			else if((iGrossVehicleWeight >= 26400)&&(iGrossVehicleWeight < 35200))
			{
				tc_strcpy(siamCode1,"N3B2(b)");
			}
			else if((iGrossVehicleWeight >= 35200)&&(iGrossVehicleWeight < 40200))	//Chnaged by Amol as per request
			{
				tc_strcpy(siamCode1,"N3B2(c)");
			}
			else if((iGrossVehicleWeight >= 40200)&&(iGrossVehicleWeight < 44000))
			{
				tc_strcpy(siamCode1,"N3B2(d)");
			}
			else if((iGrossVehicleWeight >= 44000)&&(iGrossVehicleWeight < 49000))
			{
				tc_strcpy(siamCode1,"N3B2(e)");
			}
			else if((iGrossVehicleWeight >= 49000))
			{
				tc_strcpy(siamCode1,"N3B2(f)");
			}
		}
	}
	else if(tc_strcmp(SiamAttr->aVcClass,"MCV")==0)
	{
		/*printf("\nGrossVehicleWeight:[%s]",SiamAttr->cGrossVehicleWeight);fflush(stdout);
		printf("\nSeatingCapacity:[%s]",SiamAttr->cSeatingCapacity);fflush(stdout);
		printf("\nString Chassis:[%s]",SiamAttr->cChassis);fflush(stdout);fflush(stdout);
		*/
		//F_OUTK("CGROSSVEHICLEWEIGHT",10,50,SiamAttr->cGrossVehicleWeight);
		//F_OUTK("CSEATINGCAPACITY",10,50,SiamAttr->cSeatingCapacity);
		//F_OUTK("CHASSIS",10,50,SiamAttr->cChassis);



		iGrossVehicleWeight = atoi(SiamAttr->cGrossVehicleWeight);

		//F_OUTK("IGROSSVEHICLEWEIGHT",10,50,iGrossVehicleWeight);

		//printf("\nIntGrossVehicleWeight:[%d]",iGrossVehicleWeight);fflush(stdout);
		//fprintf(flog,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,cHash,cHash,cHash,SiamAttr->cGrossVehicleWeight,SiamAttr->cVehAppl,SiamAttr->cChassis,cHash,cHash,cHash,cHash);
		printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,cHash,cHash,cHash,SiamAttr->cGrossVehicleWeight,SiamAttr->cVehAppl,SiamAttr->cChassis,cHash,cHash,cHash,cHash);fflush(stdout);

		if((tc_strcmp(SiamAttr->cGrossVehicleWeight,"NA")==0)||(tc_strcmp(SiamAttr->cGrossVehicleWeight,"")==0))
		{
			printf("\nGrossVehicleWeight null");fflush(stdout);
			exit(0);
		}
		if(tc_strcmp(SiamAttr->cChassis,"LPS")!=0)
		{
			if(tc_strcmp(SiamAttr->cVehAppl,"BUS")!=0)
			{
				if((iGrossVehicleWeight >= 3500)&&(iGrossVehicleWeight < 6000))
				{
					tc_strcpy(siamCode1,"N2A1");
				}
				else if((iGrossVehicleWeight >= 6000)&&(iGrossVehicleWeight < 7500))
				{
					tc_strcpy(siamCode1,"N2A2");
				}
				else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 10000))
				{
					tc_strcpy(siamCode1,"N2A3");
				}
				else if((iGrossVehicleWeight >= 10000)&&(iGrossVehicleWeight < 12000))
				{
					tc_strcpy(siamCode1,"N2A4");
				}
				else if((iGrossVehicleWeight >= 12000)&&(iGrossVehicleWeight <= 16200))
				{
					tc_strcpy(siamCode1,"N3A1");
				}
				else if((iGrossVehicleWeight > 16200)&&(iGrossVehicleWeight <= 25000))
				{
					tc_strcpy(siamCode1,"N3B1(a)");
				}
				else if(iGrossVehicleWeight > 25000)
				{
					tc_strcpy(siamCode1,"N3B1(b)");
				}
			}else if(tc_strcmp(SiamAttr->cVehAppl,"BUS")==0)
			{
				if((iGrossVehicleWeight >= 5000)&&(iGrossVehicleWeight < 7500))
				{
					if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
					{
							tc_strcpy(siamCode1,"N2A2");
					}
					else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
					{
						tc_strcpy(siamCode1,"M3A2");
					}
					else
					{
						tc_strcpy(siamCode1,"M3A1");
					}
				}
				else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 12000))
				{
					if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
					{
							tc_strcpy(siamCode1,"N2A3");
					}
					else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
					{
						tc_strcpy(siamCode1,"M3B2");
					}
					else
					{
						tc_strcpy(siamCode1,"M3B1");
					}
				}
				else if((iGrossVehicleWeight >= 12000)&&(iGrossVehicleWeight <= 16200))
				{
					if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
					{
							tc_strcpy(siamCode1,"N3A1");
					}
					else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
					{
						tc_strcpy(siamCode1,"M3C2");
					}
					else
					{
						tc_strcpy(siamCode1,"M3C1");
					}
				}
				else if(iGrossVehicleWeight > 16200)
				{
					if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
					{
						tc_strcpy(siamCode1,"M3D");
					}
				}
			}


		}
		else if(tc_strcmp(SiamAttr->cChassis,"LPS")==0)
		{
			if((iGrossVehicleWeight >= 16200)&&(iGrossVehicleWeight < 26400))
			{
				tc_strcpy(siamCode1,"N3B2(a)");
			}
			else if((iGrossVehicleWeight >= 26400)&&(iGrossVehicleWeight < 35200))
			{
				tc_strcpy(siamCode1,"N3B2(b)");
			}
			else if((iGrossVehicleWeight >= 35200)&&(iGrossVehicleWeight < 40200))
			{
				tc_strcpy(siamCode1,"N3B2(c)");
			}
			else if((iGrossVehicleWeight >= 40200)&&(iGrossVehicleWeight < 44000))
			{
				tc_strcpy(siamCode1,"N3B2(d)");
			}
			else if((iGrossVehicleWeight >= 44000)&&(iGrossVehicleWeight < 49000))
			{
				tc_strcpy(siamCode1,"N3B2(e)");
			}
			else if((iGrossVehicleWeight >= 49000))
			{
				tc_strcpy(siamCode1,"N3B2(f)");
			}
		}
		if(tc_strcmp(SiamAttr->cVehAppl,"ARMY")==0)
		{
			if((iGrossVehicleWeight >= 5000)&&(iGrossVehicleWeight < 7500))
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
				{
						tc_strcpy(siamCode1,"N2A2");
				}
				else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3A2");
				}
				else
				{
					tc_strcpy(siamCode1,"M3A1");
				}
			}
			else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 12000))
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
				{
						tc_strcpy(siamCode1,"N2A3");
				}
				else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3B2");
				}
				else
				{
					tc_strcpy(siamCode1,"M3B1");
				}
			}
			else if((iGrossVehicleWeight >= 12000)&&(iGrossVehicleWeight <= 16200))
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)
				{
						tc_strcpy(siamCode1,"N3A1");
				}
				else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3C2");
				}
				else
				{
					tc_strcpy(siamCode1,"M3C1");
				}
			}
			else if(iGrossVehicleWeight > 16200)
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3D");
				}
			}
		}
	}
	else if(tc_strcmp(SiamAttr->aVcClass,"UV_VAN")==0)
	{
		/*printf("\nString SeatingCapacity:[%s]",SiamAttr->cSeatingCapacity);fflush(stdout);
		printf("\nString GrossVehicleWeight:[%s]",SiamAttr->cGrossVehicleWeight);fflush(stdout);
		printf("\nString VehicleLength:[%s]",SiamAttr->cVehicleLength);fflush(stdout);
		*/
		//F_OUTK("CSEATINGCAPACITY",10,50,SiamAttr->cSeatingCapacity);
		//F_OUTK("CGROSSVEHICLEWEIGHT",10,50,SiamAttr->cGrossVehicleWeight);
		//F_OUTK("CVEHICLELENGTH",10,50,SiamAttr->cVehicleLength);


		iGrossVehicleWeight = atoi(SiamAttr->cGrossVehicleWeight);
		iSeatingCapacity = atoi(SiamAttr->cSeatingCapacity);
		iVehicleLength = atoi(SiamAttr->cVehicleLength);

		/*printf("\nIntGrossVehicleWeight:[%d]",iGrossVehicleWeight);fflush(stdout);
		printf("\nIntSeatingCapacity:[%d]",iSeatingCapacity);fflush(stdout);
		printf("\nIntVehicleLength:[%d]",iVehicleLength);fflush(stdout);

		F_OUTK("IGROSSVEHICLEWEIGHT",10,50,iGrossVehicleWeight);
		F_OUTK("ISEATINGCAPACITY",10,50,iSeatingCapacity);
		F_OUTK("IVEHICLELENGTH",10,50,iVehicleLength);*/


		//fprintf(flog,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,SiamAttr->cVehicleLength,cHash,cHash,SiamAttr->cGrossVehicleWeight,SiamAttr->cVehAppl,cHash,cHash,cHash,cHash,cHash);
		printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,SiamAttr->cVehicleLength,cHash,cHash,SiamAttr->cGrossVehicleWeight,SiamAttr->cVehAppl,cHash,cHash,cHash,cHash,cHash);fflush(stdout);

		if((tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)||(tc_strcmp(SiamAttr->cSeatingCapacity,"")==0))
		{
			printf("\nSeatingCapacity NULL");fflush(stdout);
			exit(0);
		}
		if(tc_strcmp(SiamAttr->cVehAppl,"AMBULANCE")!=0)
		{
			if(iSeatingCapacity < 10)
			{
				tc_strcpy(siamCode1,"M2A1");
			}
			else if(iSeatingCapacity >= 10)
			{
				if((iGrossVehicleWeight < 5000))
				{
					printf("\nGrossVehicle Weight is NULL");fflush(stdout);
					if(iSeatingCapacity <= 13)
					{
						tc_strcpy(siamCode1,"M2A1");
					}
					else if(iSeatingCapacity > 13)
					{
						tc_strcpy(siamCode1,"M2A2");
					}
				}
			}
		}
		else if(tc_strcmp(SiamAttr->cVehAppl,"AMBULANCE")==0)
		{
			if((iGrossVehicleWeight < 5000))/*on 16.05.2012 */
			{
				printf("\nGrossVehicle Weight is NULL");fflush(stdout);
				if(iSeatingCapacity <= 13)
				{
					tc_strcpy(siamCode1,"M2A1");
				}
				else if(iSeatingCapacity > 13)
				{
					tc_strcpy(siamCode1,"M2A2");
				}
			}
		}
	}
	else if(tc_strcmp(SiamAttr->aVcClass,"BUS")==0)
	{
		tc_strcpy(SiamAttr->cSeatingCapacity,"ABOVE 13");

		iGrossVehicleWeight = atoi(SiamAttr->cGrossVehicleWeight);
		iSeatingCapacity = atoi(SiamAttr->cSeatingCapacity);

		printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",SiamAttr->aVcClass,SiamAttr->cSeatingCapacity,cHash,cHash,cHash,SiamAttr->cGrossVehicleWeight,cHash,cHash,cHash,cHash);fflush(stdout);

		if((tc_strcmp(SiamAttr->cSeatingCapacity,"NA")==0)||(tc_strcmp(SiamAttr->cSeatingCapacity,"")==0))
		{
			printf("\nSeatingCapacity NULL");fflush(stdout);
			exit(0);
		}

			if((tc_strcmp(SiamAttr->cGrossVehicleWeight,"NA")==0)||(tc_strcmp(SiamAttr->cGrossVehicleWeight,"")==0))
			{
				printf("\nGrossVehicleWeight null");fflush(stdout);
				exit(0);
			}
			if((iGrossVehicleWeight < 5000))
			{
				printf("\nGrossVehicle Weight is NULL");fflush(stdout);
				/*if(iSeatingCapacity <= 13)*/
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"FROM 10 TO 13")==0)
				{
					tc_strcpy(siamCode1,"M2A1");
				}
				else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M2A2");
				}
			}
			if((iGrossVehicleWeight >= 5000)&&(iGrossVehicleWeight < 7500))
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"FROM 10 TO 13")==0)
				{
					tc_strcpy(siamCode1,"M3A1");
				}
				else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3A2");
				}
			}
			else if((iGrossVehicleWeight >= 7500)&&(iGrossVehicleWeight < 12000))
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"FROM 10 TO 13")==0)
				{
					tc_strcpy(siamCode1,"M3B1");
				}
				else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3B2");
				}
			}
			else if((iGrossVehicleWeight >= 12000)&&(iGrossVehicleWeight <= 16200))
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"FROM 10 TO 13")==0)
				{
					tc_strcpy(siamCode1,"M3C1");
				}
				else if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3C2");
				}
			}
			else if(iGrossVehicleWeight > 16200)
			{
				if(tc_strcmp(SiamAttr->cSeatingCapacity,"ABOVE 13")==0)
				{
					tc_strcpy(siamCode1,"M3D");
				}
			}
		/*}*/
	}
	printf("\n\nSiamCodeGenerated: %s",siamCode1);fflush(stdout);
}

void UpWtBasicView(char* VCNumDup, char* GrosWeight,char* NetWeight)
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;

	BAPIMATHEAD eBapiMatHead;
	BAPI_MARA	eBasicView;
	BAPI_MARAX	eBasicViewx;
	BAPIRET2	eBapiret2;
	ITAB_H thBapi_Makt = ITAB_NULL;
	ITAB_H thBapi_Marm = ITAB_NULL;
	ITAB_H thBapi_Marmx = ITAB_NULL;

	char xException[256];
	
	char sUq[4]={0};
	char mat_type[5]={0};
	
	char *myzeroDup = NULL;
	char *myzeroDup1 = NULL;

	BAPI_MAKT		*tBapi_Makt;
	BAPI_MARM		*tBapi_Marm;
	BAPI_MARMX		*tBapi_Marmx;

	//myzeroDup=nlsStrAlloc(7);
	//myzeroDup1=nlsStrAlloc(2);
	myzeroDup = (char *)malloc(7 * sizeof(char));
	myzeroDup1 = (char *)malloc(2 * sizeof(char));

	tc_strcpy(sUq,"EA");
	tc_strcpy(mat_type,"FERT");
	
	tc_strcpy(myzeroDup,"0.000");
	tc_strcpy(myzeroDup1,myzeroDup1);

	hRfc = BapiLogon();

	if (thBapi_Makt==ITAB_NULL)
	{thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
	if (thBapi_Makt==ITAB_NULL) printf("ItCreate MATERIALDESCRIPTION");fflush(stdout);}
	else {if (ItFree(thBapi_Makt) != 0) printf("ItFree MATERIALDESCRIPTION");fflush(stdout);  }
	if (thBapi_Marm==ITAB_NULL)
	{ thBapi_Marm = ItCreate("UNITSOFMEASURE",sizeof(BAPI_MARM),0,0);
	 if (thBapi_Marm==ITAB_NULL) printf("ItCreate UNITSOFMEASURE");	fflush(stdout);}
	else
	{if (ItFree(thBapi_Marm)!= 0) printf("ItFree UNITSOFMEASURE");fflush(stdout);}
	if (thBapi_Marmx==ITAB_NULL)
	{ thBapi_Marmx = ItCreate("UNITSOFMEASUREX",sizeof(BAPI_MARMX),0,0);
		if (thBapi_Marmx==ITAB_NULL) printf("ItCreate UNITSOFMEASUREX");fflush(stdout);}
	else
	{if (ItFree(thBapi_Marmx)!= 0) printf("ItFree UNITSOFMEASUREX");fflush(stdout);}

	tBapi_Makt = ItAppLine (thBapi_Makt) ;
	tBapi_Marm  = ItAppLine (thBapi_Marm) ;
	tBapi_Marmx = ItAppLine (thBapi_Marmx) ;

	if (tBapi_Makt == NULL)
	printf("ItAppLine BAPI_MAKT");fflush(stdout);
	if (tBapi_Marm == NULL)
	printf("ItAppLine BAPI_MARM second table");fflush(stdout);
	if (tBapi_Marmx == NULL)
	printf("ItAppLine BAPI_MARMX");fflush(stdout);

	printf("\nInside Basic Weight Update for Basic View\n");fflush(stdout);
	printf("\nVC Number : [%s] Gross Weight : [%s] Net Weight : [%s]\n",VCNumDup,GrosWeight,NetWeight);
	//fprintf(fsuccess,"\nVC Number : [%s] Gross Weight : [%s] Net Weight : [%s]\n",*VCNumDup,*GrosWeight,*NetWeight);

	fflush(stdout);
	SETCHAR(eBapiMatHead.Material,VCNumDup);
	SETCHAR(eBapiMatHead.Matl_Type,mat_type);
	SETCHAR(eBapiMatHead.Ind_Sector,"M");
	SETCHAR(eBapiMatHead.Basic_View,"X");		/*basic view*/

	SETBCD(tBapi_Marm->Numerator,"1",0);
	SETBCD(tBapi_Marm->Denominatr,"1",0);
	SETCHAR(tBapi_Marmx->Numerator,"X");
	SETCHAR(tBapi_Marmx->Denominatr,"X");

	SETCHAR(eBasicView.Base_Uom,sUq);
	SETCHAR(eBasicViewx.Base_Uom,"X");

	SETCHAR(tBapi_Marm->Alt_Unit,sUq);
	SETCHAR(tBapi_Marmx->Alt_Unit,sUq);
	SETCHAR(tBapi_Marm->Alt_Unit_Iso,sUq);
	SETCHAR(tBapi_Marmx->Alt_Unit_Iso,sUq);


	SETCHAR(eBasicView.Division,"");
	SETCHAR(eBasicViewx.Division,"");
	SETCHAR(eBasicView.Matl_Group,"");
	SETCHAR(eBasicViewx.Matl_Group,"");

	//if(nlsIsStrNull(*NetWeight))/*do not send*/
	if(tc_strcmp(NetWeight,NULL)!=0 || tc_strcmp(NetWeight,"")!=0 )
	{
		SETBCD(eBasicView.Net_Weight,myzeroDup,3);
		SETCHAR(eBasicViewx.Net_Weight,"");
	}
	else
	{
		SETBCD(eBasicView.Net_Weight,NetWeight,3);
		SETCHAR(eBasicViewx.Net_Weight,"X");
	}

	//if(nlsIsStrNull(GrosWeight))/*do not send*/
	if(tc_strcmp(GrosWeight,NULL)!=0 || tc_strcmp(GrosWeight,"")!=0 )
	{
		SETBCD(tBapi_Marm->Gross_Wt,myzeroDup,3);
		SETCHAR(tBapi_Marmx->Gross_Wt,"");
	}
	else
	{
		SETBCD(tBapi_Marm->Gross_Wt,GrosWeight,3);
		SETCHAR(tBapi_Marmx->Gross_Wt,"X");
	}


	SETCHAR(eBasicView.Unit_Of_Wt,"");
	SETCHAR(eBasicViewx.Unit_Of_Wt,"");
	SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
	SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");

	SETCHAR(tBapi_Marm->Unit_Of_Wt,"");
	SETCHAR(tBapi_Marmx->Unit_Of_Wt,"");
	SETCHAR(tBapi_Marm->Unit_Of_Wt_Iso,"");
	SETCHAR(tBapi_Marmx->Unit_Of_Wt_Iso,"");

	SETBCD(tBapi_Marm->Volume,myzeroDup,3);
	SETCHAR(tBapi_Marmx->Volume,"");
	SETCHAR(tBapi_Marm->VolumeUnit,"");
	SETCHAR(tBapi_Marmx->VolumeUnit,"");
	SETCHAR(tBapi_Marm->VolumeUnit_Iso,"");
	SETCHAR(tBapi_Marmx->VolumeUnit_Iso,"");

	SETCHAR(eBapiMatHead.Account_View,"");
	SETCHAR(eBapiMatHead.Cost_View,"");
	SETCHAR(eBapiMatHead.Forecast_View,"");
	SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
	SETCHAR(eBapiMatHead.MateriaL_Guid,"");
	SETCHAR(eBapiMatHead.Material_External,"");
	SETCHAR(eBapiMatHead.Material_Version,"");
	SETCHAR(eBapiMatHead.Prt_View,"");
	SETCHAR(eBapiMatHead.Purchase_View,"");
	SETCHAR(eBapiMatHead.Quality_View,"");	/*quality view*/
	SETCHAR(eBapiMatHead.Sales_View,"");
	SETCHAR(eBapiMatHead.Warehouse_View,"");
	SETCHAR(eBapiMatHead.Work_Sched_View,"");

	SETBCD(eBasicView.Allowed_Wt,myzeroDup,3);
	SETBCD(eBasicView.Allwd_Vol,myzeroDup,3);
	SETBCD(eBasicView.Fill_Level,"0",0);
	SETBCD(eBasicView.Minremlife,"0",0);

	SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup,3);
	SETBCD(eBasicView.Shelf_Life,"0",0);
	SETBCD(eBasicView.Stor_Pct,"0",0);
	SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
	SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
	SETCHAR(eBasicView.Appd_B_Rec,"");
	SETCHAR(eBasicView.Authoritygroup,"");

	SETCHAR(eBasicView.Base_Uom_Iso,"");
	SETCHAR(eBasicView.Basic_Matl,"");
	SETCHAR(eBasicView.Batch_Mgmt,"");
	SETCHAR(eBasicView.Cad_Id,"");
	SETCHAR(eBasicView.Catprofile,"");
	SETCHAR(eBasicView.Closed_Box,"");
	SETCHAR(eBasicView.Cm_Relevance_Flag,"");
	SETCHAR(eBasicView.Competitor,"");
	SETCHAR(eBasicView.Container,"");
	SETCHAR(eBasicView.Del_Flag,"");

	SETCHAR(eBasicView.Doc_Chg_No,"");
	SETCHAR(eBasicView.Doc_Format,"");
	SETCHAR(eBasicView.Doc_Type,"");
	SETCHAR(eBasicView.Doc_Vers,"");
	SETCHAR(eBasicView.Document,"");
	SETCHAR(eBasicView.Dsn_Office,"");
	SETCHAR(eBasicView.Envt_Rlvt,"");
	SETCHAR(eBasicView.Extmatlgrp,"");
	SETCHAR(eBasicView.Gtin_Variant,"");
	SETCHAR(eBasicView.Haz_Mat_No,"");
	SETCHAR(eBasicView.Haz_Mat_No_External,"");
	SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
	SETCHAR(eBasicView.Haz_Mat_No_Version,"");
	SETCHAR(eBasicView.Hazmatprof,"");
	SETCHAR(eBasicView.High_Visc,"");
	SETCHAR(eBasicView.Inv_Mat_No,"");
	SETCHAR(eBasicView.Inv_Mat_No_External,"");
	SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
	SETCHAR(eBasicView.Inv_Mat_No_Version,"");
	SETCHAR(eBasicView.Item_Cat,"");
	SETCHAR(eBasicView.Label_Form,"");
	SETCHAR(eBasicView.Label_Type,"");
	SETCHAR(eBasicView.Looseorliq,"");
	SETCHAR(eBasicView.Manu_Mat,"");
	SETCHAR(eBasicView.Manuf_Prof,"");
	SETCHAR(eBasicView.Mat_Grp_Sm,"");
	SETCHAR(eBasicView.Material_Fixed,"");

	SETCHAR(eBasicView.Mfr_No,"");
	SETCHAR(eBasicView.Old_Mat_No,"");
	SETCHAR(eBasicView.Pack_Vo_Un,"");
	SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
	SETCHAR(eBasicView.Pack_Wt_Un,"");
	SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
	SETCHAR(eBasicView.Page_No,"");
	SETCHAR(eBasicView.Pageformat,"");
	SETCHAR(eBasicView.Par_Eff,"");
	SETCHAR(eBasicView.Period_Ind_Expiration_Date,"");
	SETCHAR(eBasicView.Pl_Ref_Mat,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");
	SETCHAR(eBasicView.Po_Unit,"");
	SETCHAR(eBasicView.Po_Unit_Iso,"");
	SETCHAR(eBasicView.Proc_Rule,"");
	SETCHAR(eBasicView.Prod_Alloc,"");
	SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
	SETCHAR(eBasicView.Prod_Hier,"");
	SETCHAR(eBasicView.Prod_Memo,"");
	SETCHAR(eBasicView.Pur_Status,"");
	SETCHAR(eBasicView.Pur_Valkey,"");
	SETCHAR(eBasicView.Qm_Procmnt,"");
	SETCHAR(eBasicView.Qual_Dik,"");
	SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
	SETCHAR(eBasicView.Sal_Status,"");
	SETCHAR(eBasicView.Season,"");
	SETCHAR(eBasicView.Serialization_Level,"");
	SETCHAR(eBasicView.Sh_Mat_Typ,"");
	SETCHAR(eBasicView.Size_Dim,"");
	SETCHAR(eBasicView.Sled_Bbd,"");
	SETCHAR(eBasicView.Std_Descr,"");
	SETCHAR(eBasicView.Stor_Conds,"");
	SETCHAR(eBasicView.Sup_Source,"");
	SETCHAR(eBasicView.Temp_Conds,"");
	SETCHAR(eBasicView.Trans_Grp,"");
	SETCHAR(eBasicView.Uomusage,"");
	SETCHAR(eBasicView.Var_Ord_Un,"");
	SETDATE(eBasicView.Pvalidfrom,"");
	SETDATE(eBasicView.Svalidfrom,"");
	SETINT2(&eBasicView.Stack_Fact,"0");
	SETNUM(eBasicView.Matcmpllvl,"00");
	SETNUM(eBasicView.No_Sheets,"");

	SETCHAR(eBasicViewx.Allowed_Wt,"");
	SETCHAR(eBasicViewx.Allwd_Vol,"");
	SETCHAR(eBasicViewx.Appd_B_Rec,"");
	SETCHAR(eBasicViewx.Authoritygroup,"");

	SETCHAR(eBasicViewx.Base_Uom_Iso,"");
	SETCHAR(eBasicViewx.Basic_Matl,"");
	SETCHAR(eBasicViewx.Batch_Mgmt,"");
	SETCHAR(eBasicViewx.Cad_Id,"");
	SETCHAR(eBasicViewx.Catprofile,"");
	SETCHAR(eBasicViewx.Closed_Box,"");
	SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
	SETCHAR(eBasicViewx.Competitor,"");
	SETCHAR(eBasicViewx.Container,"");
	SETCHAR(eBasicViewx.Del_Flag,"");

	SETCHAR(eBasicViewx.Doc_Chg_No,"");
	SETCHAR(eBasicViewx.Doc_Format,"");
	SETCHAR(eBasicViewx.Doc_Type,"");
	SETCHAR(eBasicViewx.Doc_Vers,"");
	SETCHAR(eBasicViewx.Document,"");
	SETCHAR(eBasicViewx.Dsn_Office,"");
	SETCHAR(eBasicViewx.Envt_Rlvt,"");
	SETCHAR(eBasicViewx.Extmatlgrp,"");
	SETCHAR(eBasicViewx.Fill_Level,"");
	SETCHAR(eBasicViewx.Gtin_Variant,"");
	SETCHAR(eBasicViewx.Haz_Mat_No,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
	SETCHAR(eBasicViewx.Hazmatprof,"");
	SETCHAR(eBasicViewx.High_Visc,"");
	SETCHAR(eBasicViewx.Inv_Mat_No,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
	SETCHAR(eBasicViewx.Item_Cat,"");
	SETCHAR(eBasicViewx.Label_Form,"");
	SETCHAR(eBasicViewx.Label_Type,"");
	SETCHAR(eBasicViewx.Looseorliq,"");
	SETCHAR(eBasicViewx.Manu_Mat,"");
	SETCHAR(eBasicViewx.Manuf_Prof,"");
	SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
	SETCHAR(eBasicViewx.Matcmpllvl,"");
	SETCHAR(eBasicViewx.Material_Fixed,"");

	SETCHAR(eBasicViewx.Mfr_No,"");
	SETCHAR(eBasicViewx.Minremlife,"");

	SETCHAR(eBasicViewx.No_Sheets,"");
	SETCHAR(eBasicViewx.Old_Mat_No,"");
	SETCHAR(eBasicViewx.Pack_Vo_Un,"");
	SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
	SETCHAR(eBasicViewx.Pack_Wt_Un,"");
	SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
	SETCHAR(eBasicViewx.Page_No,"");
	SETCHAR(eBasicViewx.Pageformat,"");
	SETCHAR(eBasicViewx.Par_Eff,"");
	SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");
	SETCHAR(eBasicViewx.Po_Unit,"");
	SETCHAR(eBasicViewx.Po_Unit_Iso,"");
	SETCHAR(eBasicViewx.Proc_Rule,"");
	SETCHAR(eBasicViewx.Prod_Alloc,"");
	SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
	SETCHAR(eBasicViewx.Prod_Hier,"");
	SETCHAR(eBasicViewx.Prod_Memo,"");
	SETCHAR(eBasicViewx.Pur_Status,"");
	SETCHAR(eBasicViewx.Pur_Valkey,"");
	SETCHAR(eBasicViewx.Pvalidfrom,"");
	SETCHAR(eBasicViewx.Qm_Procmnt,"");
	SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
	SETCHAR(eBasicViewx.Qual_Dik,"");
	SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
	SETCHAR(eBasicViewx.Sal_Status,"");
	SETCHAR(eBasicViewx.Season,"");
	SETCHAR(eBasicViewx.Serialization_Level,"");
	SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
	SETCHAR(eBasicViewx.Shelf_Life,"");
	SETCHAR(eBasicViewx.Size_Dim,"");
	SETCHAR(eBasicViewx.Sled_Bbd,"");
	SETCHAR(eBasicViewx.Stack_Fact,"");
	SETCHAR(eBasicViewx.Std_Descr,"");
	SETCHAR(eBasicViewx.Stor_Conds,"");
	SETCHAR(eBasicViewx.Stor_Pct,"");
	SETCHAR(eBasicViewx.Sup_Source,"");
	SETCHAR(eBasicViewx.Svalidfrom,"");
	SETCHAR(eBasicViewx.Temp_Conds,"");
	SETCHAR(eBasicViewx.Trans_Grp,"");
	SETCHAR(eBasicViewx.Uomusage,"");
	SETCHAR(eBasicViewx.Var_Ord_Un,"");
	SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
	SETCHAR(eBasicViewx.Wt_Tol_Lt,"");

	SETCHAR(tBapi_Makt->Matl_Desc,"");

	SETCHAR(tBapi_Makt->Langu,"EN");
	SETCHAR(tBapi_Makt->Langu_Iso,"EN");
	SETCHAR(tBapi_Makt->Del_Flag,"");

	SETCHAR(tBapi_Marm->Ean_Upc,"");
	SETCHAR(tBapi_Marm->Ean_Cat,"");
	SETCHAR(tBapi_Marm->Length,"");
	SETCHAR(tBapi_Marm->Width,"");
	SETCHAR(tBapi_Marm->Height,"");
	SETCHAR(tBapi_Marm->Unit_Dim,"");
	SETCHAR(tBapi_Marm->Unit_Dim_Iso,"");
	SETCHAR(tBapi_Marm->Del_Flag,"");
	SETCHAR(tBapi_Marm->Sub_Uom,"");
	SETCHAR(tBapi_Marm->Sub_Uom_Iso,"");
	SETCHAR(tBapi_Marm->Gtin_Variant,"");


	SETCHAR(tBapi_Marmx->Ean_Upc,"");
	SETCHAR(tBapi_Marmx->Ean_Cat,"");
	SETCHAR(tBapi_Marmx->Length,"");
	SETCHAR(tBapi_Marmx->Width,"");
	SETCHAR(tBapi_Marmx->Height,"");
	SETCHAR(tBapi_Marmx->Unit_Dim,"");
	SETCHAR(tBapi_Marmx->Unit_Dim_Iso,"");

	SETCHAR(tBapi_Marmx->Sub_Uom,"");
	SETCHAR(tBapi_Marmx->Sub_Uom_Iso,"");
	SETCHAR(tBapi_Marmx->Gtin_Variant,"");



	RfcRc = zbapi_material_savedata_mrp(hRfc
			,&eBapiMatHead
			,&eBasicView
			,&eBasicViewx
			,&eBapiret2
			,thBapi_Makt
			,thBapi_Marm
			,thBapi_Marmx
		    ,xException);

	switch (RfcRc)
	{
		case RFC_OK :
				printf("\nMESSAGE:-%s",eBapiret2.Message);fflush(stdout);
				break;
		case RFC_EXCEPTION :
				printf("\nRFC EXCEPTION:-%s",xException);fflush(stdout);
				break;
		case RFC_SYS_EXCEPTION :
				printf("\nsystem exception raised");fflush(stdout);
		case RFC_FAILURE :
				printf("\nfailure");fflush(stdout);
				break;
		default :
				printf("\nother failure");fflush(stdout);
				break;
	}

	if (ItDelete(thBapi_Makt) != 0)
		printf("ItDelete thBapi_Makt");fflush(stdout);
	if (ItDelete(thBapi_Marm) != 0)
		printf("ItDelete tBapi_Marm");fflush(stdout);
	if (ItDelete(thBapi_Marmx) != 0)
		printf("ItDelete thBapi_Marmx");fflush(stdout);
	RfcClose(hRfc);

//CLEANUP:
	printf("\nCleanup...UpWtBasicView");fflush(stdout);
//EXIT:
	printf("\nExiting...UpWtBasicView");fflush(stdout);
}
char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}
	void rfc_error(char *operation)
	{
		#ifdef SAPonNT
		char s[16];
		#endif
		RFC_ERROR_INFO RfcErrorInfo;

		//fprintf(fgen,"\n\n\n operation/code:%d",operation);fflush(fgen);
		memset(&RfcErrorInfo,0,sizeof(RfcErrorInfo));
		RfcLastError(&RfcErrorInfo);
		//fprintf(fgen,"\n\n key: %d",RfcErrorInfo.key);fflush(fgen);
		//fprintf(fgen,"\n\n status: %d",RfcErrorInfo.status);fflush(fgen);
		//fprintf(fgen,"\n\n message: %s",RfcErrorInfo.message);fflush(fgen);
		//fprintf(fgen,"\n\n internal status: %d",RfcErrorInfo.intstat);fflush(fgen);
		RfcClose (RFC_HANDLE_NULL);
		exit(1);
	}
RFC_RC zpprfc_char_update(RFC_HANDLE hRfc,
						KLASSE_D	*Class,
						SY_SUBRC	*Sy_subrc,
						BAPIRET2	*iRETURN,
						ITAB_H		thAusparch,
						char *xException)
{
 RFC_PARAMETER Exporting[2];
 RFC_PARAMETER Importing[3];
 RFC_TABLE Tables[2];
 RFC_RC RfcRc;
 char *RfcException = NULL;

		 Exporting[0].name = "CLASS";
		 Exporting[0].nlen = 5;
		 Exporting[0].type = TYPC;
		 Exporting[0].leng = sizeof(KLASSE_D);
		 Exporting[0].addr = Class;

		 Exporting[1].name = NULL;

		Tables[0].name     = "CHAR_DATA";
		Tables[0].nlen     = 9;
		Tables[0].type     = handleOfAUSPARCH;
		Tables[0].ithandle = thAusparch;

		Tables[1].name = NULL;

		RfcRc = RfcCall(hRfc,"ZPPRFC_CHAR_UPDATE",Exporting,Tables);
		switch (RfcRc)
		{
			case RFC_OK :
				Importing[0].name = "RETVAL";
				Importing[0].nlen = 6;
				Importing[0].type = TYPC;
				Importing[0].leng = sizeof(SY_SUBRC);
				Importing[0].addr = Sy_subrc;

				/*Importing[1].name = "MESSG";
				Importing[1].nlen = 5;
				Importing[1].type = handleOfMESSAGEINF;
				Importing[1].leng = sizeof(MESSAGEINF);
				Importing[1].addr = Messageinf;*/

				Importing[1].name = "MESSG";
				Importing[1].nlen = 5;
				Importing[1].type = handleOfBAPIRET2;
				Importing[1].leng = sizeof(BAPIRET2);
				Importing[1].addr = iRETURN;

				Importing[2].name = NULL;

				RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

				switch (RfcRc)
				{
					case RFC_SYS_EXCEPTION :
						tc_strcpy(xException,RfcException);
						printf("\n in function zpprfc_char_update NOT RFC OK 111 %s",xException);
					break;
					case RFC_EXCEPTION :
						tc_strcpy(xException,RfcException);
						printf("\n in function zpprfc_char_update NOT RFC OK 222 %s",xException);
					break;
					default:;
				}
			break;
			default :
				printf("\nNOT RFC OK");
		}
  return RfcRc;
}

RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,
						BAPIMATHEAD *eBapiMatHead,
						BAPI_MARA	*eBasicView,
						BAPI_MARAX	*eBasicViewx,
						BAPIRET2	*eBapiret2,
						ITAB_H       thBapi_Makt,
						ITAB_H       thBapi_Marm,
						ITAB_H       thBapi_Marmx,
						char *xException)
{
 RFC_PARAMETER Exporting[4];
 RFC_PARAMETER Importing[2];
 RFC_TABLE Tables[4];
 RFC_RC RfcRc;
 char *RfcException = NULL;


		 Exporting[0].name = "HEADDATA";
		 Exporting[0].nlen = 8;
		 Exporting[0].type = handleOfBAPIMATHEAD;
		 Exporting[0].leng = sizeof(BAPIMATHEAD);
		 Exporting[0].addr = eBapiMatHead;

		 Exporting[1].name = "CLIENTDATA";
		 Exporting[1].nlen = 10;
		 Exporting[1].type = handleOfBAPI_MARA;
		 Exporting[1].leng = sizeof(BAPI_MARA);
		 Exporting[1].addr = eBasicView;

		 Exporting[2].name = "CLIENTDATAX";
		 Exporting[2].nlen = 11;
		 Exporting[2].type = handleOfBAPI_MARAX;
		 Exporting[2].leng = sizeof(BAPI_MARAX);
		 Exporting[2].addr = eBasicViewx;

		 Exporting[3].name = NULL;



		Tables[0].name     = "MATERIALDESCRIPTION";
		Tables[0].nlen     = 19;
		Tables[0].type     = handleOfBAPI_MAKT;
		Tables[0].ithandle = thBapi_Makt;

		Tables[1].name     = "UNITSOFMEASURE";
		Tables[1].nlen     = 14;
		Tables[1].type     = handleOfBAPI_MARM;
		Tables[1].ithandle = thBapi_Marm;

		Tables[2].name     = "UNITSOFMEASUREX";
		Tables[2].nlen     = 15;
		Tables[2].type     = handleOfBAPI_MARMX;
		Tables[2].ithandle = thBapi_Marmx;

		Tables[3].name = NULL;



		RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

		switch (RfcRc)
		{

		case RFC_OK :
			printf("\nHERE IN IMPORTING RFC_OK CASE");fflush(stdout);
			Importing[0].name = "RETURN";
			Importing[0].nlen = 6;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = eBapiret2;

			Importing[1].name = NULL;
			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION :
					tc_strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION :
					tc_strcpy(xException,RfcException);
				break;
				default :
				printf("\nNOT RFC OK");fflush(stdout);
			}
		break;
		default :
			printf("\nNOT RFC OK");fflush(stdout);
		}
  return RfcRc;
}
BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	// RfcOptions.destination ="PP8";
	// RfcOptions.client = "500";
	// RfcOptions.user = "DENIS";
	// RfcOptions.language = "EN";
	// RfcOptions.password = "CARINIT1";
	// RfcOptions.trace = 0;
	// RfcConnoptR3only.hostname="p690";
	// RfcConnoptR3only.gateway_host="p690";
	// RfcConnoptR3only.gateway_service="sapgw00";
	// RfcOptions.connopt = &RfcConnoptR3only;
	
	//*************************************
    //***** SAP QA *****
    //**************************************
   /* RfcOptions.destination           ="172.24.29.12";
    RfcOptions.client                = "500";
    RfcOptions.user                  = "DENIS";
	RfcOptions.language              = "E";
    RfcOptions.password              = "CARINIT1";
	RfcOptions.trace                 = 1;
    RfcConnoptR3only.hostname        ="172.24.29.12";
    RfcConnoptR3only.gateway_host    ="172.24.29.12";
    RfcConnoptR3only.gateway_service ="sapgw00";
    RfcOptions.connopt               = &RfcConnoptR3only;*/
	
	
	RfcOptions.destination ="172.31.9.75";
	RfcOptions.client = "500";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "E";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 1; 
	RfcConnoptR3only.hostname="172.31.9.75";
	RfcConnoptR3only.gateway_host="172.31.9.75";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt				= &RfcConnoptR3only;
	
	// RfcOptions.destination ="PP8";
	// RfcOptions.client = "500";
	// RfcOptions.user = "DENIS";
	// RfcOptions.language = "EN";
	// RfcOptions.password = "CARINIT1";
	// RfcOptions.trace = 0;
	// RfcConnoptR3only.hostname="p690";
	// RfcConnoptR3only.gateway_host="p690";
	// RfcConnoptR3only.gateway_service="sapgw00";
	// RfcOptions.connopt = &RfcConnoptR3only;
 
	//SAP DEV
	/*RfcOptions.destination ="PD8";
	RfcOptions.client = "250";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 1;
	RfcConnoptR3only.hostname="6m252";
	RfcConnoptR3only.gateway_host="6m252";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;*/

	/*RfcOptions.destination ="PQ8";
	RfcOptions.client = "500";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 0;
	RfcConnoptR3only.hostname="tmleccqa";
	RfcConnoptR3only.gateway_host="tmleccqa";	//tmleccqa
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;*/

		
	printf("\nDESTINATION    :%-50s",RfcOptions.destination);fflush(stdout);
	printf("\nCLIENT         :%-50s",RfcOptions.client);fflush(stdout);
	printf("\nUSER           :%-50s",RfcOptions.user);fflush(stdout);
	printf("\nPASSWORD       :%-50s",RfcOptions.password);fflush(stdout);
	printf("\nLAGUAGE        :%-50s",RfcOptions.language);fflush(stdout);
	printf("\nTRACE          :%-50d",RfcOptions.trace);fflush(stdout);
	printf("\nHOST NAME      :%-50s",RfcConnoptR3only.hostname);fflush(stdout);
	printf("\nGATEWAY HOST   :%-50s",RfcConnoptR3only.gateway_host);fflush(stdout);
	printf("\nGATEWAY SERVICE:%-50s",RfcConnoptR3only.gateway_service);fflush(stdout);
	printf("\nCONNOPT        :%-50u",RfcOptions.connopt);fflush(stdout);

	printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);fflush(stdout);
	hRfc = RfcOpen(&RfcOptions);
	if (hRfc == RFC_HANDLE_NULL)
	{
		printf("\nERROR RECEIVED CPIC-ERROR");fflush(stdout);
		exit(0);
	}
	else
	{
		printf("\nGot the connection!!!");fflush(stdout);
		RfcEnvironment(&RfcEnv);
		printf("\n connected!!!");fflush(stdout);
	}
	return hRfc;
}


//query-->product structure classes-->colour Module queries-->Color Master-->taking attribute Colour Tat No
char* getTatNumber(char* ColorID)
{
	printf("\nInside Tat Function\n");fflush(stdout);
//	MODNAME ("VcAttribute");

	tag_t queryTag = NULLTAG;
	tag_t ColorIDObj = NULLTAG;
	tag_t *ColorIDObjs=NULLTAG;
	char*	 ColVCTatNo			= NULL;
	int resultCount =0;
	int n_entries = 1; //no. of query input arg
	
	if(QRY_find("ClrMaster", &queryTag));
	printf("\nAfter Part query : QRY_find \n");fflush(stdout);
	if (queryTag)
	{
		printf("\nFound Query Part  \n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query Part");fflush(stdout);
	}

	 
    
	  //char *qry_entries[1] = {"Color Serial"};
	  char *qry_entries[1] = {"Colour ID"};
	  char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	  //qry_values[0] = "IJ";
	  qry_values[0] = ColorID;
	 // ITK_CALL(QRY_find("Item Revision...", &queryTag));	
	  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &ColorIDObjs));
	
	if(resultCount>0)
	{
		ColorIDObj=ColorIDObjs[0];
		
		 if(AOM_ask_value_string(ColorIDObj,"t5_ClTatNo",&ColVCTatNo));
		 printf("\n\t t5_ClTatNo  is=>>>>>>> :%s",ColVCTatNo); fflush(stdout);
	}

	printf("\nVC ColorID : %s TAT Number : %s\n",ColorID,ColVCTatNo);
	//fprintf(fsuccess,"\nVC ColorID : %s TAT Number : %s\n",ColorID,ColVCTatNo);
	return ColVCTatNo;
}

void ClassificationView1(tag_t PartObj,char* part_noDup,char* VCPartNumDup,tag_t* TechSPecObj,int vcattrcount,struct VCAttrDetails* VCAttrDetailsList)
{
	
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;

	KLASSE_D Class;
	SY_SUBRC Sy_subrc;
	BAPIRET2 Messageinf;

	static AUSPARCH *tAusparch;
	static ITAB_H thAusparch = ITAB_NULL;

	static int no_of_values;
	int car_dml = 1;
	int ai = 0;
	int i = 0;
	int val_len = 0;
	int	Index	= 0;
	char xException[256]={0};
	char chk[5]={0};
	char s[1074] = { 0 };
	char *attributeName = NULL;
	char *attributeValue = NULL;
	char *headerName = NULL;
	char *headerNameDup = NULL;
	char *hRevision = NULL;
	char *hRevisionDup = NULL;
	char *hSeq = NULL;
	char *hSeqDup = NULL;
	struct DzSim SiamAttr;
	struct DzSim* ptrSiamAttr;
	char *sGrossVehicleWeight = NULL;
	char *sGrossCombWeight = NULL;
	char *TechSpecDispName = NULL;
	char *TechSpecDispNameDup = NULL;
	char *TatNoDup = NULL;
	char *VModName = NULL;
	char *VModName1 = NULL;
	char *VModName2 = NULL;
	char *VModName3 = NULL;
	char *CIAgName = NULL;
	char *VehCat = NULL;
	char *CmvrNo = NULL;
	char *ExtCertNo = NULL;
	char *NetWeight = NULL;
	char *NetWeightDup = NULL;
	char *GrosWeight = NULL;
	char *GrosWeightDup = NULL;
	static char *sap_attrname = NULL;
	char *sap_attrnameDup = NULL;
	static char attName[255][200]={"0"};
	static char attValue[255][200]={"0"};
	static int noOfAttribute = 0;
	char *Wbsnumber=NULL;
	
	ptrSiamAttr = &SiamAttr;

	/*if((strcmp(chk,"2678") == 0)
		||(strcmp(chk,"2690") == 0)
		||(strcmp(chk,"2695") == 0)
		||(strcmp(chk,"2702") == 0)
		||(strcmp(chk,"2775") == 0)
		||(strcmp(chk,"2779") == 0)
		||(strcmp(chk,"2790") == 0)
		||(strcmp(chk,"2791") == 0)
		||(strcmp(chk,"2792") == 0)
		||(strcmp(chk,"2797") == 0)
		||(strcmp(chk,"2798") == 0)
		||(strcmp(chk,"2802") == 0)
		||(strcmp(chk,"2810") == 0)
		||(strcmp(chk,"2820") == 0)
		||(strcmp(chk,"2828") == 0)
		||(strcmp(chk,"2834") == 0)
		||(strcmp(chk,"2842") == 0)
		||(strcmp(chk,"2843") == 0)
		||(strcmp(chk,"2844") == 0)
		||(strcmp(chk,"2853") == 0)
		||(strcmp(chk,"2856") == 0)
		||(strcmp(chk,"2857") == 0)
		||(strcmp(chk,"2861") == 0)
		||(strcmp(chk,"2862") == 0)
		||(strcmp(chk,"2868") == 0)
		||(strcmp(chk,"2869") == 0)
		||(strcmp(chk,"2871") == 0)
		||(strcmp(chk,"2872") == 0)
		||(strcmp(chk,"2873") == 0)
		||(strcmp(chk,"2874") == 0)
		||(strcmp(chk,"2889") == 0)
		||(strcmp(chk,"5401") == 0)
		||(strcmp(chk,"5402") == 0)
		||(strcmp(chk,"5406") == 0)
		||(strcmp(chk,"5409") == 0)
		||(strcmp(chk,"5410") == 0)
		||(strcmp(chk,"5414") == 0)
		||(strcmp(chk,"5415") == 0)
		||(strcmp(chk,"5419") == 0)
		||(strcmp(chk,"5421") == 0)
		||(strcmp(chk,"5422") == 0)
		||(strcmp(chk,"5424") == 0)
		||(strcmp(chk,"5425") == 0)
		||(strcmp(chk,"5427") == 0)
		||(strcmp(chk,"5429") == 0)
		||(strcmp(chk,"5432") == 0)
		||(strcmp(chk,"5433") == 0)
		||(strcmp(chk,"5438") == 0)
		||(strcmp(chk,"5443") == 0)
		||(strcmp(chk,"5702") == 0)
		||(strcmp(chk,"5703") == 0)
		||(strcmp(chk,"5704") == 0)
		||(strcmp(chk,"5705") == 0)
		||(strcmp(chk,"5707") == 0)
		||(strcmp(chk,"5710") == 0)
		||(strcmp(chk,"5711") == 0)
		||(strcmp(chk,"5712") == 0)
		||(strcmp(chk,"5715") == 0)
		||(strcmp(chk,"5718") == 0)
		||(strcmp(chk,"5724") == 0)
		||(strcmp(chk,"5726") == 0)
		||(strcmp(chk,"5801") == 0)
		||(strcmp(chk,"5806") == 0)
		||(strcmp(chk,"5807") == 0)
		||(strcmp(chk,"5810") == 0)
		||(strcmp(chk,"5814") == 0)
		||(strcmp(chk,"5825") == 0)
		||(strcmp(chk,"5901") == 0)
		)
	{
		car_dml = 1;
		//printf("car_dml set to: %d ",car_dml);fflush(stdout);
		////F_OUTK("CAR_DML",10,50,car_dml);
	}*/
	/*tc_strcpy(VCPartNumDup,"MRACEL20MORL");*/ /*CKD VC*/
	
	char*			BussObj				= NULL;
	char*			teckSpecObjName				= NULL;
	char*			teckSpecrev				= NULL;
	char*			teckSpecSeq				= NULL;
	
	int 			nAttributes				= 0;
	int 			naAttributes				= 0;
	char 			**attributeNames;
	char 			**theAttributeNames;
	char 			***aattributeNames;
	char 			**attributeValues;
	tag_t			classificationObject = NULLTAG;
	tag_t			*view;
	tag_t			cObject					= NULLTAG;		
	

	char* 	vehicleNumber1 					= NULL;
	char* 	PDRStat 					= NULL;
	
	ITK_CALL(AOM_ask_value_string(PartObj,"item_id",&vehicleNumber1));
	printf("\n  vehicleNumber1 : %s \n",vehicleNumber1); fflush(stdout);
	ITK_CALL(AOM_ask_value_string(PartObj,"t5_PartStatus",&PDRStat));
	printf("\n  PDRStat : %s \n",PDRStat); fflush(stdout);
	ITK_CALL(AOM_ask_value_string(*TechSPecObj,"object_name",&teckSpecObjName));
	printf("\n  teckSpecObjName : %s \n",teckSpecObjName); fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(*TechSPecObj,"item_revision_id",&teckSpecrev));
	printf("\n  teckSpecrev : %s \n",teckSpecrev); fflush(stdout);

	ITK_CALL(AOM_ask_value_string(*TechSPecObj,"t5_VCClassName",&BussObj));
	printf("\n  BussObj : %s \n",BussObj); fflush(stdout);
	
	fprintf(fUASAPMapping,"\n Number of Attribute: %d\n",vcattrcount); fflush(fUASAPMapping);
	int j=0;
	for(j=0 ;j<vcattrcount;j++ )
	{
	char 	*attributeNameDup 			= NULL;
	char 	*attributeValueDup 			= NULL;
	
	printf("\n value of J:[%d] ",j);fflush(stdout);fflush(stdout);
	printf("\n attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
	attributeNameDup=VCAttrDetailsList[j].VCAttrName;
	printf("\n attribute name :[%s]",attributeNameDup);fflush(stdout);
	attributeValueDup=VCAttrDetailsList[j].VCAttrNameValue;
	printf("\n attribute value :[%s]",attributeValueDup);fflush(stdout);

	fprintf(fUASAPMapping,"\n Attribute At: %d \t\t Attibute Name: %s \t\t\t Attibute Value: %s",j,attributeNameDup,attributeValueDup); fflush(fUASAPMapping);	
	}
	
	
	GrosWeightDup = (char *) MEM_alloc( 50 * sizeof(char) );
	NetWeightDup = (char *) MEM_alloc( 50 * sizeof(char) );
	j=0;
	for(j=0;j<vcattrcount;j++)
		{
			
			printf("\n value net weight Gross weight");fflush(stdout);fflush(stdout);
			printf("\n value of J:[%d] ",j);fflush(stdout);fflush(stdout);
			printf("\n attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
			
			if(tc_strcmp(VCAttrDetailsList[j].VCAttrID,"8165")==0)
			{	
			tc_strcpy(GrosWeightDup,VCAttrDetailsList[j].VCAttrNameValue);
			printf("\n GrosWeightDup:[%s]",GrosWeightDup);fflush(stdout);
			}
			if(tc_strcmp(VCAttrDetailsList[j].VCAttrID,"8193")==0)
			{	
			tc_strcpy(NetWeightDup,VCAttrDetailsList[j].VCAttrNameValue);
			printf("\n NetWeightDup:[%s]",NetWeightDup);fflush(stdout);
			}
		}
	printf("\n value of NetWeightDup:[%s]  GrosWeightDup:[%s]",NetWeightDup,GrosWeightDup);fflush(stdout);
	//sending basic view by NetWeight and GrosWeight
	UpWtBasicView(VCPartNumDup,GrosWeightDup,NetWeightDup);	//Seting Weight on Basic View
	
	SiamAttr.aVcClass = (char *)malloc(500 * sizeof(char));
	tc_strcpy(SiamAttr.aVcClass,"");
	tc_strcpy(SiamAttr.aVcClass,BussObj);
									
if(vcattrcount>0)
	{
		thAusparch = ITAB_NULL;

		SETCHAR(Class.KLASSE_D,"DENIS_VC_ATTR");
		if (thAusparch==ITAB_NULL)
		{
			thAusparch = ItCreate("CHAR_DATA",sizeof(AUSPARCH),0,0);
			if (thAusparch==ITAB_NULL)
			printf("ItCreate AUSPARCH");fflush(stdout);
		}
		else
		{
			if (ItFree(thAusparch) != 0)
			printf("ItFree AUSPARCH");fflush(stdout);
		}
		printf("\nsetSize(vcattrcount):[%d]",vcattrcount);fflush(stdout);

		for(i=0;i<vcattrcount;i++)
		{
			char 	*attributeNameDup 			= NULL;
			char 	*attributeValueDup 			= NULL;
			printf("\n value of I:[%d] ",i);fflush(stdout);fflush(stdout);
			printf("\n attribute id :[%s]",VCAttrDetailsList[i].VCAttrID);fflush(stdout);
			attributeNameDup=VCAttrDetailsList[i].VCAttrName;
			printf("\n attribute name :[%s]",attributeNameDup);fflush(stdout);
			attributeValueDup=VCAttrDetailsList[i].VCAttrNameValue;
			printf("\n attribute value :[%s]",attributeValueDup);fflush(stdout);
			
			fprintf(fUASAPMapping,"\n Attribute Loop: %d Attribute Name:%s Attribute Value:%s\n",i,attributeNameDup,attributeValueDup); fflush(fUASAPMapping);
			
			if(tc_strcmp(SiamAttr.aVcClass,"CAR")==0)
			{
			
				printf("\n I am in Car");fflush(stdout);
				
				if(tc_strcmp(attributeNameDup,"[VC]Seating Capacity(SEATING_CAP)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cSeatingCapacity);
					printf("\n I am in Car Seating Capacity %s",attributeValueDup);fflush(stdout);
				}
				if(tc_strcmp(attributeNameDup,"[VC]VEH_OVERALL_LENGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehicleLength);
					printf("\n I am in Car VEH_OVERALL_LENGHT %s",attributeValueDup);fflush(stdout);
				}
				if(tc_strcmp(attributeNameDup,"[VC]VEHICLE_TYPE(VEHICLE_TYPE)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehicleType);
					printf("\n I am in Car VEHICLE_TYPE(VEHICLE_TYPE) %s",attributeValueDup);fflush(stdout);
				}
				if(tc_strcmp(attributeNameDup,"CUBIC_CAPACITY")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cEngineDisplacement);
					printf("\n I am in Car CUBIC_CAPACITY %s",attributeValueDup);fflush(stdout);
				}
			}
		else if(tc_strcmp(SiamAttr.aVcClass,"MUV")==0)
			{
				if(tc_strcmp(attributeNameDup,"[VC]SEATING CAPACITY(SEATING_CAP)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cSeatingCapacity);
				}
				if(tc_strcmp(attributeNameDup,"[VC]VEH_OVERALL_LENGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehicleLength);
				}
				if(tc_strcmp(attributeNameDup,"[VC]GROSS VEHICLE WEIGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cGrossVehicleWeight);
				}
				if(tc_strcmp(attributeNameDup,"[VC]VEH_APPLN(VEH_APPLN)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehAppl);
				}
			}
			else if(tc_strcmp(SiamAttr.aVcClass,"LMV")==0)
			{
				if(tc_strcmp(attributeNameDup,"[VC]Seating Capacity(SEATING_CAP)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cSeatingCapacity);
				}
				if(tc_strcmp(attributeNameDup,"[VC]MAJORMODEL")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cMajorModel);
				}
				if(tc_strcmp(attributeNameDup,"[VC]MASCOT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cMascot);
				}
				if(tc_strcmp(attributeNameDup,"[VC]VEH_OVERALL_LENGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehicleLength);
				}
				if(tc_strcmp(attributeNameDup,"[VC]GROSS VEHICLE WEIGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cGrossVehicleWeight);
				}
			}
			else if(tc_strcmp(SiamAttr.aVcClass,"LCV")==0)
			{
				if(tc_strcmp(attributeNameDup,"[VC]Seating Capacity(SEATING_CAP)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cSeatingCapacity);
					printf("\nSiamAttr.cSeatingCapacity:[%s]",SiamAttr.cSeatingCapacity);fflush(stdout);
				}
				if(tc_strcmp(attributeValueDup,"NA")==0)
				{
					if(tc_strcmp(attributeNameDup,"[VC]Passenger Capacity(INTEND_PASSENGER_CAP)")==0)
					{
						tc_strdup(attributeValueDup,&SiamAttr.cSeatingCapacity);
					}
					printf("\nSiamAttr.cSeatingCapacity:[%s]",attributeValueDup);fflush(stdout);
				}


				if(tc_strcmp(attributeNameDup,"[VC]VEH_OVERALL_LENGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehicleLength);
					printf("\nSiamAttr.cVehicleLength:[%s]",SiamAttr.cVehicleLength);fflush(stdout);
				}

				if(tc_strcmp(attributeNameDup,"[VC]GROSS VEHICLE WEIGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cGrossVehicleWeight);
				}

				fflush(stdout);
				if(tc_strcmp(attributeNameDup,"[VC]VEH_APPLN(VEH_APPLN)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehAppl);
				}

				fflush(stdout);
			}
			else if(tc_strcmp(SiamAttr.aVcClass,"HCV")==0)
			{
				if(tc_strcmp(attributeNameDup,"[VC]Passenger Capacity(INTEND_PASSENGER_CAP)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cSeatingCapacity);
				}

				if(tc_strcmp(attributeNameDup,"[VC]VEH_OVERALL_LENGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehicleLength);
				}
				if(tc_strcmp(attributeNameDup,"[VC]CHASSIS(CHASSIS)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cChassis);
				}
				if(tc_strcmp(attributeNameDup,"[VC]VEH_APPLN(VEH_APPLN)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehAppl);
				}
				if(tc_strcmp(attributeNameDup,"MAX_PERMSIBL_GCW")==0)
				{
					tc_strdup(attributeValueDup,&sGrossCombWeight);
				}
				if(tc_strcmp(attributeNameDup,"[VC]GROSS VEHICLE WEIGHT")==0)
				{
					tc_strdup(attributeValueDup,&sGrossVehicleWeight);
				}

				/*if(tc_strcmp(SiamAttr.cChassis,"LPS")==0)
				{
					if(tc_strcmp(attributeNameDup,"MAX_PERMSIBL_GCW")==0)
					{
						SiamAttr.cGrossVehicleWeight = nlsStrDup(attributeValueDup);
					}
				}
				else
				{
					if(tc_strcmp(attributeNameDup,"[VC]GROSS VEHICLE WEIGHT")==0)
					{
						SiamAttr.cGrossVehicleWeight = nlsStrDup(attributeValueDup);
					}
				}*/
			}
			else if(tc_strcmp(SiamAttr.aVcClass,"MCV")==0)
			{
				if(tc_strcmp(attributeNameDup,"[VC]Passenger Capacity(INTEND_PASSENGER_CAP)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cSeatingCapacity);
				}

				if(tc_strcmp(attributeNameDup,"[VC]VEH_OVERALL_LENGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehicleLength);
				}
				if(tc_strcmp(attributeNameDup,"[VC]CHASSIS(CHASSIS)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cChassis);
				}
				if(tc_strcmp(attributeNameDup,"[VC]VEH_APPLN(VEH_APPLN)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehAppl);
				}
				if(tc_strcmp(attributeNameDup,"MAX_PERMSIBL_GCW")==0)
				{
					tc_strdup(attributeValueDup,&sGrossCombWeight);
				}
				if(tc_strcmp(attributeNameDup,"[VC]GROSS VEHICLE WEIGHT")==0)
				{;
					tc_strdup(attributeValueDup,&sGrossVehicleWeight);
				}
				/*if(tc_strcmp(SiamAttr.cChassis,"LPS")==0)
				{
					if(tc_strcmp(attributeNameDup,"MAX_PERMSIBL_GCW")==0)
					{
						SiamAttr.cGrossVehicleWeight = nlsStrDup(attributeValueDup);
					}
				}
				else
				{
					if(tc_strcmp(attributeNameDup,"[VC]GROSS VEHICLE WEIGHT")==0)
					{
						SiamAttr.cGrossVehicleWeight = nlsStrDup(attributeValueDup);
					}
				}*/
			}
			else if(tc_strcmp(SiamAttr.aVcClass,"UV_VAN")==0)
			{
				if(tc_strcmp(attributeNameDup,"[VC]Seating Capacity(SEATING_CAP)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cSeatingCapacity);
				}
				if(tc_strcmp(attributeNameDup,"[VC]VEH_OVERALL_LENGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehicleLength);
				}
				if(tc_strcmp(attributeNameDup,"[VC]GROSS VEHICLE WEIGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cGrossVehicleWeight);
				}
				if(tc_strcmp(attributeNameDup,"[VC]VEH_APPLN(VEH_APPLN)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehAppl);
				}
			}
			else if(tc_strcmp(SiamAttr.aVcClass,"BUS")==0)
			{
				if(tc_strcmp(attributeNameDup,"[VC]Passenger Capacity(INTEND_PASSENGER_CAP)")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cSeatingCapacity);
				}
				if(tc_strcmp(attributeNameDup,"[VC]VEH_OVERALL_LENGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cVehicleLength);
				}
				if(tc_strcmp(attributeNameDup,"[VC]GROSS VEHICLE WEIGHT")==0)
				{
					tc_strdup(attributeValueDup,&SiamAttr.cGrossVehicleWeight);
				}
			}
			printf("\n SiamAttr.aVcClass:[%s]",SiamAttr.aVcClass);fflush(stdout);

			if(tc_strcmp(attributeNameDup,"VAHAN MODEL NAME")==0 && strlen(attributeValueDup)>30)
			{
				char* VModName=NULL;
				tc_strdup(attributeValueDup,&VModName);
				val_len=strlen(VModName);
				printf("\n lenght for %s : [%d]",attributeNameDup,val_len);fflush(stdout);
			}
			printf("\n attributeNameDup:[%s]",attributeNameDup);fflush(stdout);

			if(tc_strcmp(attributeNameDup,"CERTIFICATE ISSUING AGENCY")==0 && strlen(attributeValueDup)>30)
			{
				char* CIAgName=NULL;
				tc_strdup(attributeValueDup,&CIAgName);
				val_len=strlen(CIAgName);
				printf("\n lenght for %s : [%d]",attributeNameDup,val_len);fflush(stdout);

					CIAgName = subString(CIAgName,30,val_len-1);

					tAusparch = ItAppLine (thAusparch) ;
					if (tAusparch == NULL)
					printf("ItAppLine BAPI_MAKT");fflush(stdout);

					SETCHAR(tAusparch->Mandt,"");
					SETCHAR(tAusparch->Objek,VCPartNumDup);
					SETCHAR(tAusparch->Mafid,"");
					SETCHAR(tAusparch->Klart,"001");
					SETCHAR(tAusparch->Atnam,"CERTIFICATE_ISSUING_AGENCY_1");
					SETCHAR(tAusparch->Atwrt,CIAgName);
					SETCHAR(tAusparch->Aennr,"");
					SETDATE(tAusparch->Datuv,"");
					SETCHAR(tAusparch->Lkenz,"");
					SETNUM(tAusparch->Atinn,"");
					
			fprintf(fUASAPMapping,"Set at SAP Attribute[CERTIFICATE_ISSUING_AGENCY_1],UA Attribute[%s]. UA Value[%s] Actual UA Value is [%s] \n",attributeNameDup,CIAgName,attributeValueDup); fflush(fUASAPMapping);
			
			
			}
			
			if(tc_strcmp(attributeNameDup,"VAHAN VEHICLE CATEGORY")==0 && strlen(attributeValueDup)>30)
			{
				char* VehCat=NULL;
				tc_strdup(attributeValueDup,&VehCat);
				val_len=strlen(VehCat);
				printf("\n lenght for %s : [%d]",attributeNameDup,val_len);fflush(stdout);

				VehCat = subString(VehCat,30,val_len-1);
				printf("\n Vahan Cat %s ",VehCat);fflush(stdout);

					tAusparch = ItAppLine (thAusparch) ;
					if (tAusparch == NULL)
					printf("ItAppLine BAPI_MAKT");fflush(stdout);

					SETCHAR(tAusparch->Mandt,"");
					SETCHAR(tAusparch->Objek,VCPartNumDup);
					SETCHAR(tAusparch->Mafid,"");
					SETCHAR(tAusparch->Klart,"001");
					SETCHAR(tAusparch->Atnam,"VAHAN_VEHICLE_CATEGORY_1");
					SETCHAR(tAusparch->Atwrt,VehCat);
					SETCHAR(tAusparch->Aennr,"");
					SETDATE(tAusparch->Datuv,"");
					SETCHAR(tAusparch->Lkenz,"");
					SETNUM(tAusparch->Atinn,"");
					
					fprintf(fUASAPMapping,"Set at SAP Attribute[VAHAN_VEHICLE_CATEGORY_1],UA Attribute[%s]. UA Value[%s] Actual UA Value is [%s] \n",attributeNameDup,VehCat,attributeValueDup); fflush(fUASAPMapping);
			}
			
			if(tc_strcmp(attributeNameDup,"CMVR_TYP_APPRVL_NO")==0 && strlen(attributeValueDup)>30)
			{
				char* CmvrNo=NULL;
				tc_strdup(attributeValueDup,&CmvrNo);
				val_len=strlen(CmvrNo);
				printf("\n lenght for %s : [%d]",attributeNameDup,val_len);fflush(stdout);

					CmvrNo = subString(CmvrNo,30,val_len-1);

					tAusparch = ItAppLine (thAusparch) ;
					if (tAusparch == NULL)
					printf("ItAppLine BAPI_MAKT");fflush(stdout);

					SETCHAR(tAusparch->Mandt,"");
					SETCHAR(tAusparch->Objek,VCPartNumDup);
					SETCHAR(tAusparch->Mafid,"");
					SETCHAR(tAusparch->Klart,"001");
					SETCHAR(tAusparch->Atnam,"CMVR_TYP_APPRVL_NO_1");
					SETCHAR(tAusparch->Atwrt,CmvrNo);
					SETCHAR(tAusparch->Aennr,"");
					SETDATE(tAusparch->Datuv,"");
					SETCHAR(tAusparch->Lkenz,"");
					SETNUM(tAusparch->Atinn,"");
					
					fprintf(fUASAPMapping,"Set at SAP Attribute[CMVR_TYP_APPRVL_NO_1],UA Attribute[%s]. UA Value[%s] Actual UA Value is [%s] \n",attributeNameDup,CmvrNo,attributeValueDup); fflush(fUASAPMapping);
			}
			
			if(tc_strcmp(attributeNameDup,"EXTENSION CERTIFICATE NUMBER")==0 && strlen(attributeValueDup)>30)
			{
				char* ExtCertNo=NULL;
				tc_strdup(attributeValueDup,&ExtCertNo);
				val_len=strlen(ExtCertNo);
				printf("\n lenght for %s : [%d]",attributeNameDup,val_len);fflush(stdout);

					ExtCertNo = subString(ExtCertNo,30,val_len-1);
					tAusparch = ItAppLine (thAusparch) ;
					if (tAusparch == NULL)
					printf("ItAppLine BAPI_MAKT");fflush(stdout);

					SETCHAR(tAusparch->Mandt,"");
					SETCHAR(tAusparch->Objek,VCPartNumDup);
					SETCHAR(tAusparch->Mafid,"");
					SETCHAR(tAusparch->Klart,"001");
					SETCHAR(tAusparch->Atnam,"CMVR_TYP_APPRVL_NO_3");
					SETCHAR(tAusparch->Atwrt,ExtCertNo);
					SETCHAR(tAusparch->Aennr,"");
					SETDATE(tAusparch->Datuv,"");
					SETCHAR(tAusparch->Lkenz,"");
					
					fprintf(fUASAPMapping,"Set at SAP Attribute[CMVR_TYP_APPRVL_NO_3],UA Attribute[%s]. UA Value[%s] Actual UA Value is [%s] \n",attributeNameDup,ExtCertNo,attributeValueDup); fflush(fUASAPMapping);
			}

			/***************************************for WBS NUMBER*******************************************************/
			if(tc_strcmp(attributeNameDup,"WBS")==0)
			{
				printf("\n WBS_NUMBER value is %s :",attributeValueDup);fflush(stdout);
				
				if(tc_strcmp(attributeValueDup,NULL)!=0 || tc_strcmp(attributeValueDup,"")!=0)
				{
					char   		*Wbsnumber=NULL;
					Wbsnumber = strtok( attributeValueDup, "_" );

					printf("\n WBS_NUMBER value after strtok is %s :",Wbsnumber);fflush(stdout);

					//ExtCertNo = subString(ExtCertNo,30,val_len-1);
					tAusparch = ItAppLine (thAusparch) ;
					if (tAusparch == NULL)
					printf("ItAppLine BAPI_MAKT");fflush(stdout);

					SETCHAR(tAusparch->Mandt,"");
					SETCHAR(tAusparch->Objek,VCPartNumDup);
					SETCHAR(tAusparch->Mafid,"");
					SETCHAR(tAusparch->Klart,"001");
					SETCHAR(tAusparch->Atnam,"WBS_NUMBER");
					SETCHAR(tAusparch->Atwrt,Wbsnumber);
					SETCHAR(tAusparch->Aennr,"");
					SETDATE(tAusparch->Datuv,"");
					SETCHAR(tAusparch->Lkenz,"");
					fprintf(fUASAPMapping,"Set at SAP Attribute[WBS_NUMBER],UA Attribute[%s]. UA Value[%s] Actual UA Value is [%s] \n",attributeNameDup,Wbsnumber,attributeValueDup); fflush(fUASAPMapping);
				}
				else 
				{
					printf("\n WBS_NUMBER value NULL");fflush(stdout);
				}
				
			}
	
			int n_entries = 2,n_found = 0,ii = 0;
	
			tag_t query = NULLTAG;
			tag_t *cntr_objects=NULLTAG;
			
			
			char    *qry_entries[2]  = {"SYSCD","Information-1"};
			char	**qry_values= (char **) MEM_alloc(5 * sizeof(char *));
			qry_values[0]	= "vcattr";
			qry_values[1]	= attributeNameDup;

			char *Information1=NULL;
			char* sap_attrnameDup=NULL;

			ITK_CALL(QRY_find("Control Objects...", &query));	
			if (query)
			{
				printf("\n *******[ControlObjects Query found]********* \n");fflush(stdout);
			}
			else
			{
				printf("\n *******[ControlObjects Query NOT Found]********* \n");fflush(stdout);
			}
			ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
			printf("\n number of Query found %d \n", n_found);fflush(stdout);
			char        *sap_attrname                    	= NULL;
			sap_attrname = (char *) MEM_alloc( 100 * sizeof(char) );
			tc_strcpy(sap_attrname,"");
			if(n_found==0)
			{
				 printf("\n %s AttributeName do not have entry in t5control, n_found:[%d]",attributeNameDup,n_found);fflush(stdout);
				 continue;
			 }
			 else
			 {
				for (ai=0;ai<n_found;ai++)
				{
					ITK_CALL ( AOM_ask_value_string(cntr_objects[ai],"t5_Userinfo1",&Information1));
					printf("\n t5_Userinfo1 is:%s",Information1);fflush(stdout);
					ITK_CALL ( AOM_ask_value_string(cntr_objects[ai],"t5_Userinfo2",&sap_attrnameDup));
					printf("\n t5_Userinfo2 sap_attrnameDup is: %s ",sap_attrnameDup);fflush(stdout);
					if(tc_strcmp(sap_attrnameDup,NULL)==0 || tc_strcmp(sap_attrnameDup,"")==0 )
					{
						printf("\nAttribute not present in control Table: [%s] [%s]\n",attributeNameDup,sap_attrnameDup);fflush(stdout);
						continue;
					}
					if(tc_strcmp(sap_attrnameDup,NULL)!=0 || tc_strcmp(sap_attrnameDup,"")!=0)
					{
						tc_strdup(sap_attrnameDup,&sap_attrname);
						printf("\n hello4");fflush(stdout);
					}
					printf("\t sap_attrname:[%s]",sap_attrname);fflush(stdout);
					printf("\n attributeValueDup %s",attributeValueDup);fflush(stdout);
					if(tc_strcmp(attributeValueDup,NULL)==0 || tc_strcmp(attributeValueDup,"")==0 )
					{
						printf("\nAttribute value not present in SpecHeader for :[%s] [%s]\n",attributeNameDup,sap_attrname);fflush(stdout);
						continue;
					}
					printf("\n SAP Attribute Value: %s",sap_attrname);fflush(stdout);
					printf("\n UA Attribute Value: %s",attributeValueDup);fflush(stdout);
					printf("\n -------------------");fflush(stdout);
					
					tAusparch = ItAppLine (thAusparch) ;
					if (tAusparch == NULL)
					printf("ItAppLine BAPI_MAKT");fflush(stdout);
					printf("set into SAP Attr into SAP Attr name:%s",sap_attrname);fflush(stdout);
					printf("set into SAP Attr Value From UA Attr value is:%s",attributeValueDup);fflush(stdout);
					SETCHAR(tAusparch->Mandt,"");
					SETCHAR(tAusparch->Objek,VCPartNumDup);
					SETCHAR(tAusparch->Mafid,"");
					SETCHAR(tAusparch->Klart,"001");
					SETCHAR(tAusparch->Atnam,sap_attrname);
					SETCHAR(tAusparch->Atwrt,attributeValueDup);
					SETCHAR(tAusparch->Aennr,"");
					SETDATE(tAusparch->Datuv,"");
					SETCHAR(tAusparch->Lkenz,"");
					SETNUM(tAusparch->Atinn,"");
					
					fprintf(fUASAPMapping,"Set at SAP Attribute[%s],UA Attribute[%s]. UA Value[%s]-->ControlObject \n",sap_attrname,attributeNameDup,attributeValueDup); fflush(fUASAPMapping);
				}
			}
			/*********************Attr Mapping Query End **************************/
		}
		
		printf("\n after For loop of VC attribute");fflush(stdout);

		if((tc_strcmp(SiamAttr.aVcClass,"HCV")==0)||(tc_strcmp(SiamAttr.aVcClass,"MCV")==0))
		{
			if(tc_strcmp(SiamAttr.cChassis,"LPS")==0)
			{
				tc_strdup(sGrossCombWeight,&SiamAttr.cGrossVehicleWeight);
			}
			else
			{
				tc_strdup(sGrossVehicleWeight,&SiamAttr.cGrossVehicleWeight);
			}
		}

		fprintf(fUASAPMapping,"Out Of VC Attribute Loop \n"); fflush(fUASAPMapping);
		if(tc_strcmp(VModName,NULL)!=0 || tc_strcmp(VModName,"")!=0 && val_len>30)
		{
			if(val_len>30 && val_len<60)
			{
				VModName1 = subString(VModName,30,val_len-1);
				
				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"VAHAN_MODEL_NAME_1");
				SETCHAR(tAusparch->Atwrt,VModName1);
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[VAHAN_MODEL_NAME_1],UA Attribute[VAHAN MODEL NAME]. Modified UA Value is [%s] \n",VModName1); fflush(fUASAPMapping);

				//Set VAHAN_MODEL_NAME_2 and VAHAN_MODEL_NAME_3 to NULL if already had some value in SAP
				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"VAHAN_MODEL_NAME_2");
				SETCHAR(tAusparch->Atwrt,"");
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				fprintf(fUASAPMapping,"Set at SAP Attribute[VAHAN_MODEL_NAME_2] Set VAHAN_MODEL_NAME_2 and VAHAN_MODEL_NAME_3 to NULL if already had some value in SAP(Already there in comment \n"); fflush(fUASAPMapping);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"VAHAN_MODEL_NAME_3");
				SETCHAR(tAusparch->Atwrt,"");
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				fprintf(fUASAPMapping,"Set at SAP Attribute[VAHAN_MODEL_NAME_3] Set VAHAN_MODEL_NAME_2 and VAHAN_MODEL_NAME_3 to NULL if already had some value in SAP(Already there in comment \n"); fflush(fUASAPMapping);
			}
			else if(val_len>60 && val_len<90)
			{
				VModName1 = subString(VModName,30,59);
				VModName2 = subString(VModName,60,val_len-1);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"VAHAN_MODEL_NAME_1");
				SETCHAR(tAusparch->Atwrt,VModName1);
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[VAHAN_MODEL_NAME_1],UA Attribute[VAHAN MODEL NAME]. Modified UA Value is [%s] \n",VModName1); fflush(fUASAPMapping);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"VAHAN_MODEL_NAME_2");
				SETCHAR(tAusparch->Atwrt,VModName2);
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[VAHAN_MODEL_NAME_2],UA Attribute[VAHAN MODEL NAME]. Modified UA Value is [%s] \n",VModName2); fflush(fUASAPMapping);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"VAHAN_MODEL_NAME_3");
				SETCHAR(tAusparch->Atwrt,"");
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[VAHAN_MODEL_NAME_3], Set Blank \n"); fflush(fUASAPMapping);
			}
			else if(val_len>90)
			{
				VModName1 = subString(VModName,30,59);
				VModName2 = subString(VModName,60,89);
				VModName3 = subString(VModName,90,val_len-1);
				
				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"VAHAN_MODEL_NAME_1");
				SETCHAR(tAusparch->Atwrt,VModName1);
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				fprintf(fUASAPMapping,"Set at SAP Attribute[VAHAN_MODEL_NAME_1],UA Attribute[VAHAN MODEL NAME]. Modified UA Value is [%s] \n",VModName1); fflush(fUASAPMapping);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"VAHAN_MODEL_NAME_2");
				SETCHAR(tAusparch->Atwrt,VModName2);
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[VAHAN_MODEL_NAME_2],UA Attribute[VAHAN MODEL NAME]. Modified UA Value is [%s] \n",VModName2); fflush(fUASAPMapping);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"VAHAN_MODEL_NAME_3");
				SETCHAR(tAusparch->Atwrt,VModName3);
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[VAHAN_MODEL_NAME_3],UA Attribute[VAHAN MODEL NAME]. Modified UA Value is [%s] \n",VModName3); fflush(fUASAPMapping);

			}
		}
		
		printf("\n BBBBBBBBBBBBBBBBBB");fflush(stdout);


		printf("\nURN_MODEL_CODE : [%s]",UrnCode);	fflush(stdout);	//Base VC number
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"URN_MODEL_CODE");
		SETCHAR(tAusparch->Atwrt,UrnCode);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[URN_MODEL_CODE],UA Attribute[Base VC item_id] UA Value[%s] \n",UrnCode); fflush(fUASAPMapping);
		
		printf("\n colour id is: %s",ColorIDPartDup);fflush(stdout);

		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"COLOUR");
		SETCHAR(tAusparch->Atwrt,ColorIDPartDup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[COLOUR],UA Attribute[till _ description of Xfr VC]. UA Value[%s] \n",ColorIDPartDup); fflush(fUASAPMapping);

		printf("\nVC DR Status : [%s]",PDRStat);fflush(stdout);		//VC DR Status
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"DR_STATUS");
		SETCHAR(tAusparch->Atwrt,PDRStat);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[DR_STATUS],UA Attribute[DR Status of Xfr VC]. UA Value[%s] \n",PDRStat); fflush(fUASAPMapping);

//MoRTH Attributes Starts here
if(cmvrFlag==1 && (tc_strcmp(st5Pollutant_CM1Dup,NULL)!=0 || tc_strcmp(st5Pollutant_CM1Dup,"")!=0 ))
{

		printf("\nCARBON_MONOXIDE : [%s]",st5Pollutant_CM1Dup);fflush(stdout);
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"CARBON_MONOXIDE");
		SETCHAR(tAusparch->Atwrt,st5Pollutant_CM1Dup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[CARBON_MONOXIDE],UA Attribute[t5_Pollutant_CM]. UA Value May Be modified[%s] \n",st5Pollutant_CM1Dup); fflush(fUASAPMapping);

		printf("\nHYDRO_CARBON : [%s]",st5Pollutant_HC1Dup);fflush(stdout);
	
		
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"HYDRO_CARBON");
		SETCHAR(tAusparch->Atwrt,st5Pollutant_HC1Dup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[HYDRO_CARBON],UA Attribute[t5_Pollutant_HC]. UA Value May Be modified[%s] \n",st5Pollutant_HC1Dup); fflush(fUASAPMapping);

		printf("\nNON_METHANE_HC : [%s]",st5Pollutant_NH1Dup);fflush(stdout);
	
		
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"NON_METHANE_HC");
		SETCHAR(tAusparch->Atwrt,st5Pollutant_NH1Dup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");

		fprintf(fUASAPMapping,"Set at SAP Attribute[NON_METHANE_HC],UA Attribute[t5_Pollutant_NH]. UA Value May Be modified[%s] \n",st5Pollutant_NH1Dup); fflush(fUASAPMapping);
		
		printf("\nREACTIVE_HC : [%s]",st5Pollutant_RHC1Dup);fflush(stdout);
		
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"REACTIVE_HC");
		SETCHAR(tAusparch->Atwrt,st5Pollutant_RHC1Dup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");


		fprintf(fUASAPMapping,"Set at SAP Attribute[REACTIVE_HC],UA Attribute[t5_Pollutant_RHC]. UA Value May Be modified[%s] \n",st5Pollutant_RHC1Dup); fflush(fUASAPMapping);
		
		printf("\nNOX : [%s]",st5Pollutant_NO1Dup);fflush(stdout);
		
		
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"NOX");
		SETCHAR(tAusparch->Atwrt,st5Pollutant_NO1Dup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[NOX],UA Attribute[t5_Pollutant_NO]. UA Value May Be modified[%s] \n",st5Pollutant_NO1Dup); fflush(fUASAPMapping);

		printf("\nHC_NOX : [%s]",st5Pollutant_HCNO1Dup);fflush(stdout);

		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"HC_NOX");
		SETCHAR(tAusparch->Atwrt,st5Pollutant_HCNO1Dup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[HC_NOX],UA Attribute[t5_Pollutant_HCNO]. UA Value May Be modified[%s] \n",st5Pollutant_HCNO1Dup); fflush(fUASAPMapping);

		printf("\nPM : [%s]",st5Pollutant_PM1Dup);fflush(stdout);
		
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"PM");
		SETCHAR(tAusparch->Atwrt,st5Pollutant_PM1Dup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");

		fprintf(fUASAPMapping,"Set at SAP Attribute[PM],UA Attribute[t5_Pollutant_PM]. UA Value May Be modified[%s] \n",st5Pollutant_PM1Dup); fflush(fUASAPMapping);
		
		printf("\nSOUND_LEVEL_OF_HORN : [%s]",st5Pollutant_HO1Dup);fflush(stdout);
		
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"SOUND_LEVEL_OF_HORN");
		SETCHAR(tAusparch->Atwrt,st5Pollutant_HO1Dup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[SOUND_LEVEL_OF_HORN],UA Attribute[t5_Pollutant_HO]. UA Value May Be modified[%s] \n",st5Pollutant_HO1Dup); fflush(fUASAPMapping);
		
		printf("\nPASS_BY_NOISE_VALUE : [%s]",st5BystanderPosDup);fflush(stdout);
			
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"PASS_BY_NOISE_VALUE");
		SETCHAR(tAusparch->Atwrt,st5BystanderPosDup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[PASS_BY_NOISE_VALUE],UA Attribute[t5_BystanderPos]. UA Value May Be modified[%s] \n",st5BystanderPosDup); fflush(fUASAPMapping);

//Form 22-A Part-II UV_VAN Related Attribute from CMVR Inent Form
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"BODY_BUILDER_ACCREDITATION_NUM");
		SETCHAR(tAusparch->Atwrt,BBBACNUMDup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[BODY_BUILDER_ACCREDITATION_NUM],UA Attribute[t5_BBBACNum]. UA Value May Be modified[%s] \n",BBBACNUMDup); fflush(fUASAPMapping);

		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"BODY_BLD_ACCR_CERT_ISSUE_DATE");
		SETCHAR(tAusparch->Atwrt,BBBACISDTDup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[BODY_BLD_ACCR_CERT_ISSUE_DATE],UA Attribute[t5_BBBACIsDt]. UA Value May Be modified[%s] \n",BBBACISDTDup); fflush(fUASAPMapping);

		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"BODY_BLD_ACCR_CERT_VAL_TO_DATE");
		SETCHAR(tAusparch->Atwrt,BBBACVLDTDup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[BODY_BLD_ACCR_CERT_VAL_TO_DATE],UA Attribute[t5_BBBACVlDt]. UA Value May Be modified[%s] \n",BBBACVLDTDup); fflush(fUASAPMapping);
		
		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"VEH_BODY_CONSTRUCTION_TAN");
		SETCHAR(tAusparch->Atwrt,VBCAPRCNUMDup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[VEH_BODY_CONSTRUCTION_TAN],UA Attribute[t5_VBCAprCNum]. UA Value May Be modified[%s] \n",VBCAPRCNUMDup); fflush(fUASAPMapping);

		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"VEH_BODY_CONSTR_TAN_DATE");
		SETCHAR(tAusparch->Atwrt,VBCAPRDTDup);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[VEH_BODY_CONSTR_TAN_DATE],UA Attribute[t5_VBCAprDt]. UA Value May Be modified[%s] \n",VBCAPRDTDup); fflush(fUASAPMapping);
}
else
{
	printf("\ncmver flag %d and st5Pollutant_CM1Dup:[%s]",cmvrFlag,st5Pollutant_CM1Dup);fflush(stdout);
	fprintf(fUASAPMapping,"Cmvr Object(MoRTH Attributes) not found \n"); fflush(fUASAPMapping);
}

printf("\n MoRTH Attributes End");fflush(stdout);
//MoRTH Attributes End
		if(tc_strcmp(ColorIDPartDup,NULL)!=0 || tc_strcmp(ColorIDPartDup,"")!=0 )
		{
			//getting tan number from PLM
			TatNoDup=getTatNumber(ColorIDPartDup);
			printf("\n TatNoDup:%s ",TatNoDup);fflush(stdout);
			if(tc_strcmp(TatNoDup,"")==0 ||tc_strcmp(TatNoDup,NULL)==0)
			{
				printf("\nFor Color ID : %s TAT Number not avialble in PLM",ColorIDPartDup);fflush(stdout);
				fprintf(fUASAPMapping,"For Color ID : %s TAT Number not avialble in UA \n",ColorIDPartDup); fflush(fUASAPMapping);
			}
			else
			{
				printf("\n TatNoDup:%s ",TatNoDup);fflush(stdout);
				//TatNo=nlsStrDup(TatNoDup);
				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);
				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"TAT_NUMBER");
				SETCHAR(tAusparch->Atwrt,TatNoDup);
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[TAT_NUMBER],Based on colour Id taken from colour master table \n"); fflush(fUASAPMapping);
			}
		}
		else
		{
			printf("\n colour id is null for getting tat no");fflush(stdout);
			fprintf(fUASAPMapping,"Colour id is null for getting TAT_NUMBER \n"); fflush(fUASAPMapping);
		}
		
		if(car_dml == 0)
		{
			tAusparch = ItAppLine (thAusparch) ;
			if (tAusparch == NULL)
			printf("ItAppLine BAPI_MAKT");fflush(stdout);

			SETCHAR(tAusparch->Mandt,"");
			SETCHAR(tAusparch->Objek,VCPartNumDup);
			SETCHAR(tAusparch->Mafid,"");
			SETCHAR(tAusparch->Klart,"001");
			SETCHAR(tAusparch->Atnam,"EQUIP_CLASS_NAME");
			SETCHAR(tAusparch->Atwrt,"ABU_EQ_CROSS_SERVE");
			SETCHAR(tAusparch->Aennr,"");
			SETDATE(tAusparch->Datuv,"");
			SETCHAR(tAusparch->Lkenz,"");
			SETNUM(tAusparch->Atinn,"");
			
			fprintf(fUASAPMapping,"Set at SAP Attribute[EQUIP_CLASS_NAME],Value set as 'ABU_EQ_CROSS_SERVE' is car flag is 0 \n"); fflush(fUASAPMapping);
		}
		else if(car_dml == 1)
		{
			tAusparch = ItAppLine (thAusparch) ;
			if (tAusparch == NULL)
			printf("ItAppLine BAPI_MAKT");fflush(stdout);

			SETCHAR(tAusparch->Mandt,"");
			SETCHAR(tAusparch->Objek,VCPartNumDup);
			SETCHAR(tAusparch->Mafid,"");
			SETCHAR(tAusparch->Klart,"001");
			SETCHAR(tAusparch->Atnam,"CHASSIS");
			SETCHAR(tAusparch->Atwrt,"");
			SETCHAR(tAusparch->Aennr,"");
			SETDATE(tAusparch->Datuv,"");
			SETCHAR(tAusparch->Lkenz,"");
			SETNUM(tAusparch->Atinn,"");
			
			fprintf(fUASAPMapping,"Set at SAP Attribute[CHASSIS],Value set as null for car Flag 1 \n"); fflush(fUASAPMapping);

			if(strcmp(chk,"2834") == 0)
			{
				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"EQUIP_CLASS_NAME");
				SETCHAR(tAusparch->Atwrt,"NANO_EQUIP");
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[EQUIP_CLASS_NAME],Value set[NANO_EQUIP] for project 2834 for car Flag 1 \n"); fflush(fUASAPMapping);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"SEATING_CAPACITY");
				/*SETCHAR(tAusparch->Atwrt,"4");*//*09.04.2011 request from manisha madam*/
				SETCHAR(tAusparch->Atwrt,SiamAttr.cSeatingCapacity);
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[SEATING_CAPACITY],UA Value [%s] UA Attribute[cSeatingCapacity ]for project 2834 for car Flag 1 \n",SiamAttr.cSeatingCapacity); fflush(fUASAPMapping);

				tAusparch = ItAppLine (thAusparch) ;	/*added on 11.06.2011*/
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"WHEEL_BASE_IN_MM");
				SETCHAR(tAusparch->Atwrt,"2230");
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[WHEEL_BASE_IN_MM], Value '2230' for project 2834 for car Flag 1 \n"); fflush(fUASAPMapping);
			}
			else
			{
				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"EQUIP_CLASS_NAME");
				SETCHAR(tAusparch->Atwrt,"INDICA_EQUIP");
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[EQUIP_CLASS_NAME], Value 'INDICA_EQUIP' for other that project 2834 for car Flag 1 \n"); fflush(fUASAPMapping);

				tAusparch = ItAppLine (thAusparch) ;
				if (tAusparch == NULL)
				printf("ItAppLine BAPI_MAKT");fflush(stdout);

				SETCHAR(tAusparch->Mandt,"");
				SETCHAR(tAusparch->Objek,VCPartNumDup);
				SETCHAR(tAusparch->Mafid,"");
				SETCHAR(tAusparch->Klart,"001");
				SETCHAR(tAusparch->Atnam,"SEATING_CAPACITY");
				/*SETCHAR(tAusparch->Atwrt,"5");*/ /*09.04.2011 request from manisha madam*/
				SETCHAR(tAusparch->Atwrt,SiamAttr.cSeatingCapacity);
				SETCHAR(tAusparch->Aennr,"");
				SETDATE(tAusparch->Datuv,"");
				SETCHAR(tAusparch->Lkenz,"");
				SETNUM(tAusparch->Atinn,"");
				
				fprintf(fUASAPMapping,"Set at SAP Attribute[SEATING_CAPACITY], UA Value[%s] for other that project 2834 for car Flag 1 \n",SiamAttr.cSeatingCapacity); fflush(fUASAPMapping);
			}

			tAusparch = ItAppLine (thAusparch) ;
			if (tAusparch == NULL)
			printf("ItAppLine BAPI_MAKT");fflush(stdout);

			SETCHAR(tAusparch->Mandt,"");
			SETCHAR(tAusparch->Objek,VCPartNumDup);
			SETCHAR(tAusparch->Mafid,"");
			SETCHAR(tAusparch->Klart,"001");
			SETCHAR(tAusparch->Atnam,"TYRE_QUANTITY");
			SETCHAR(tAusparch->Atwrt,"5");
			SETCHAR(tAusparch->Aennr,"");
			SETDATE(tAusparch->Datuv,"");
			SETCHAR(tAusparch->Lkenz,"");
			SETNUM(tAusparch->Atinn,"");
				
			fprintf(fUASAPMapping,"Set at SAP Attribute[TYRE_QUANTITY], Value '5' for other that project 2834 for car Flag 1 \n"); fflush(fUASAPMapping);
			
			tAusparch = ItAppLine (thAusparch) ;
			if (tAusparch == NULL)
			printf("ItAppLine BAPI_MAKT");fflush(stdout);

			SETCHAR(tAusparch->Mandt,"");
			SETCHAR(tAusparch->Objek,VCPartNumDup);
			SETCHAR(tAusparch->Mafid,"");
			SETCHAR(tAusparch->Klart,"001");
			SETCHAR(tAusparch->Atnam,"CLASS_OF_VEHICLE");
			SETCHAR(tAusparch->Atwrt,"CAR");
			SETCHAR(tAusparch->Aennr,"");
			SETDATE(tAusparch->Datuv,"");
			SETCHAR(tAusparch->Lkenz,"");
			SETNUM(tAusparch->Atinn,"");
			
			fprintf(fUASAPMapping,"Set at SAP Attribute[CLASS_OF_VEHICLE], Value 'CAR' for car Flag 1 \n"); fflush(fUASAPMapping);
		}
		
		printf("\n EEEEEEEEEEEEEEEE");fflush(stdout);
		printf("\n%s,",VCPartNumDup);fflush(stdout);
		printf("\n %s,",TechSpecDispNameDup);fflush(stdout);
		printf("\n %s,",SiamAttr.cSeatingCapacity);fflush(stdout);
		char *siamCode1 = NULL;
		siamCode1 = (char *) MEM_alloc( 100 * sizeof(char) );
		myDzSiamCode(ptrSiamAttr,siamCode1);
		printf("\nSiam Code received IS :: %s",siamCode1);

		/*printf("\n\n:%s:%s:%s:%s:",*part_noDup,TechSpecVehClassDup,headerNameDup,siamCode1);
		DZ_sim(*part_noDup,TechSpecVehClassDup,headerNameDup,hRevisionDup,hSeqDup,siamCode1);
		DZ_sim(*part_noDup,BussObj,headerNameDup,hRevisionDup,hSeqDup,siamCode1);
		printf("\nSiam Code received IS :: %s",siamCode1);*/

		//DZ_sim(*part_noDup,TechSpecVehClassDup,headerNameDup,hRevisionDup,hSeqDup,siamCode2);
		//fprintf(flog,",%s",siamCode2);
		char *siamCode2 = NULL;
		siamCode2 = (char *) MEM_alloc( 100 * sizeof(char) );
		myDzSiamCode2(ptrSiamAttr,siamCode2);
		printf("\n after function myDzSiamCode2 value of siamCode2 %s",siamCode2);fflush(stdout);

		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"SIAM_CLASSFN_CODE");
		SETCHAR(tAusparch->Atwrt,siamCode2);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[SIAM_CLASSFN_CODE], Value[%s] logic written  \n",siamCode2); fflush(fUASAPMapping);

		tAusparch = ItAppLine (thAusparch) ;
		if (tAusparch == NULL)
		printf("ItAppLine BAPI_MAKT");fflush(stdout);

		SETCHAR(tAusparch->Mandt,"");
		SETCHAR(tAusparch->Objek,VCPartNumDup);
		SETCHAR(tAusparch->Mafid,"");
		SETCHAR(tAusparch->Klart,"001");
		SETCHAR(tAusparch->Atnam,"SIAM_CLASSIFICATION_NEW");
		SETCHAR(tAusparch->Atwrt,siamCode1);
		SETCHAR(tAusparch->Aennr,"");
		SETDATE(tAusparch->Datuv,"");
		SETCHAR(tAusparch->Lkenz,"");
		SETNUM(tAusparch->Atinn,"");
		
		fprintf(fUASAPMapping,"Set at SAP Attribute[SIAM_CLASSIFICATION_NEW], Value[%s] logic written  \n",siamCode1); fflush(fUASAPMapping);
		
		if(tc_strcmp(siamCode2,"")==0)
		{
			sprintf(ferror_name,"Atributes_new_siamcode_%s.log",VCPartNumDup);
			//sprintf(ferror_name,"/data/omfprod/PLMSAP/PLM_SAP_VEH_ERC/VcAttributes_new_siamcode_%s.log",VcPartNumber);
			/*sprintf(ferror_name,"VcAttributes_New_siamcode_%s.log",VcPartNumber);*/
			ferror1 = fopen(ferror_name,"a");
			printf("New SiamCode is null for %s  VcPartNumber Please check.",VCPartNumDup);fflush(stdout);
			fprintf(ferror1,"\n New SiamCode2 is null for %s  VcPartNumber Please check.",VCPartNumDup);
			//fclose(ferror1);
		}
		else
		{
			sprintf(ferror_name,"Atributes_new_siamcode_%s.log",VCPartNumDup);
			ferror1 = fopen(ferror_name,"a");
			fprintf(ferror1,"\n siamCode2 is %s  VcPartNumber:%s for SAP Attibute:SIAM_CLASSFN_CODE ",siamCode2,VCPartNumDup);
		}
		if(tc_strcmp(siamCode1,"")==0)
		{
			sprintf(ferror_name,"Atributes_new_siamcode_%s.log",VCPartNumDup);
			//sprintf(ferror_name,"/data/omfprod/PLMSAP/PLM_SAP_VEH_ERC/VcAttributes_new_siamcode_%s.log",VcPartNumber);
			/*sprintf(ferror_name,"VcAttributes_New_siamcode_%s.log",VcPartNumber);*/
			ferror1 = fopen(ferror_name,"a");
			printf("old SiamCode is null for %s  VcPartNumber Please check.",VCPartNumDup);fflush(stdout);
			fprintf(ferror1,"\n Old SiamCode1 is null for %s  VcPartNumber Please check.",VCPartNumDup);
			//fclose(ferror1);
		}
		else
		{
			sprintf(ferror_name,"Atributes_new_siamcode_%s.log",VCPartNumDup);
			ferror1 = fopen(ferror_name,"a");
			fprintf(ferror1,"\nsiamCode1 is %s  VcPartNumber:%s for SAP Attibute:SIAM_CLASSIFICATION_NEW ",siamCode1,VCPartNumDup);
		}

		printf("\n BapiLogon ");fflush(stdout);
		hRfc = BapiLogon();
		printf("\n calling zpprfc_char_update");fflush(stdout);
		RfcRc = zpprfc_char_update(hRfc,&Class,&Sy_subrc,&Messageinf,thAusparch,xException);
		printf("\n after calling zpprfc_char_update");fflush(stdout);
		switch (RfcRc)
		{
			case RFC_OK :
			printf(" \n after connection");fflush(stdout);
				noOfAttribute = ItFill(thAusparch);
				printf(" \n after connection noOfAttribute %d 1",noOfAttribute);fflush(stdout);
				fprintf(fUASAPMapping," Final Updated into SAP As below \n"); fflush(fUASAPMapping);
				for (no_of_values = 1;no_of_values <= ItFill(thAusparch); no_of_values++)
				{
					printf(" \n after connection 111111");fflush(stdout);
					tAusparch = ItGetLine(thAusparch,no_of_values);
					//mat_type = (char *)malloc(500 * sizeof(char));
					tc_strcpy(attName[no_of_values],"");
					tc_strcpy(attValue[no_of_values],"");
					GETCHAR(tAusparch->Atnam,attName[no_of_values]);
					GETCHAR(tAusparch->Atwrt,attValue[no_of_values]);
					printf("\n%s %s",attName[no_of_values],attValue[no_of_values]);fflush(stdout);
				
					fprintf(fUASAPMapping,"%s --> %s \n",attName[no_of_values],attValue[no_of_values]); fflush(fUASAPMapping);
					//fprintf(fsuccess,"\n%30s %30s",attName[no_of_values],attValue[no_of_values]);

					//F_OUTK(attName[no_of_values],10,50,attValue[no_of_values]);

					if (tAusparch == NULL)
						printf("ItGetLineCHAR_DATA");fflush(stdout);
				}
				//F_OUTK("-------------",10,50,"-------------");
				NL;
				NL;
				printf(" \n after connection 2");fflush(stdout);
				GETCHAR(Messageinf.Type,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n IMessageinf.Type %s",s);fflush(stdout);
				//F_OUTK("TYPE",10,50,s);

				GETCHAR(Messageinf.Id,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.Id %s",s);fflush(stdout);
				//F_OUTK("ID",10,50,s);

				GETNUM(Messageinf.Number,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.Number %s",s);fflush(stdout);
				//F_OUTK("NUMBER",10,50,s);

				GETCHAR(Messageinf.Message,s);
				trimLeading(s);
				trimLeading(s);
				tc_strcat(s,VCPartNumDup);
				printf("\n Messageinf.Message %s",s);fflush(stdout);
				//F_OUTK("MESSAGE",10,50,s);

				GETCHAR(Messageinf.Log_No,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.Log_No %s",s);fflush(stdout);
				//F_OUTK("LOG_NO",10,50,s);

				GETNUM(Messageinf.Log_Msg_No,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.Log_Msg_No %s",s);fflush(stdout);
				//F_OUTK("LOG_MSG_NO",10,50,s);

				GETCHAR(Messageinf.Message_V1,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.Message_V1 %s",s);fflush(stdout);
				//F_OUTK("MESSAGE_V1",10,50,s);

				GETCHAR(Messageinf.Message_V2,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.Message_V2 %s",s);fflush(stdout);
				//F_OUTK("MESSAGE_V2",10,50,s);

				GETCHAR(Messageinf.Message_V3,s);
				trimLeading(s);
				trimLeading(s);
				printf("Messageinf.Message_V3 %s",s);fflush(stdout);
				//F_OUTK("MESSAGE_V3",10,50,s);

				GETCHAR(Messageinf.Message_V4,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.Message_V4 %s",s);fflush(stdout);
				//F_OUTK("MESSAGE_V4",10,50,s);

				GETCHAR(Messageinf.Parameter,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.Parameter %s",s);fflush(stdout);
				//F_OUTK("PARAMETER",10,50,s);

				GETINT(Messageinf.Row,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.Row %s",s);fflush(stdout);
				//F_OUTK("ROW",10,50,s);

				GETCHAR(Messageinf.Field,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.Field %s",s);fflush(stdout);
				//F_OUTK("FIELD",10,50,s);

				GETCHAR(Messageinf.System,s);
				trimLeading(s);
				trimLeading(s);
				printf("\n Messageinf.System %s",s);fflush(stdout);
				//F_OUTK("SYSTEM",10,50,s);
				NL;
				//GETCHAR(Messageinf.Msgtx,cMessage);
				//printf("\nMessage %s:[ %255s ]\n",VCPartNumDup,cMessage);fflush(stdout);
				//fprintf(fsuccess,"\nMessage %s:[ %255s ]\n",VCPartNumDup,cMessage);
			break;
			case RFC_EXCEPTION :
				printf("\nRFC EXCEPTION:-%s",xException);fflush(stdout);
			break;
			case RFC_SYS_EXCEPTION :
				printf("\nSYSTEM EXCEPTION RAISED");fflush(stdout);
			break;
			case RFC_FAILURE :
				printf("\nFAILURE");fflush(stdout);
			break;
			default :
				printf("\nOTHER FAILURE");fflush(stdout);
		}
		if (ItDelete(thAusparch) != 0)
		printf("ItDelete BOM_ITEM");fflush(stdout);
		RfcClose(hRfc);

	}
}

int getAllReleasedPartDML1(char *partNumber,tag_t *latestPart)
  {
				 			  
	int ifail = ITK_ok;
	int  count            = 0;
	tag_t *itemrevs = NULLTAG;        
	char *relstat="T5_LcsErcRlzd";

	char *qry_entries[] ={"Item ID","Release Status"};
	char *qry_values[] = {partNumber,relstat};
	int            num_to_sort=1;
	char*         keys[]={"creation_date"};
	int orders[]={1};
 
	tag_t query = NULLTAG;

	ITK_CALL(QRY_find2("Item Revision...", &query));
	ITK_CALL(QRY_execute_with_sort(query, 2, qry_entries, qry_values,num_to_sort,keys,orders, &count, &itemrevs));
	int x=0;
	char *dispstr;
	char *dt;
	 for(x=0;x<count;x++)
	 {
	 
		 *latestPart=itemrevs[x];
		 AOM_UIF_ask_value(*latestPart,"object_string", &dispstr);
		 AOM_UIF_ask_value(*latestPart,"creation_date", &dt);
		 printf("\n [%d] [%s] [%s]",x,dispstr,dt);fflush(stdout);
		fprintf(fsuccess,"\n [%d] [%s] [%s]",x,dispstr,dt);fflush(fsuccess);
	 }
	fprintf(fsuccess,"\n Sending latest ERC Release Part Object [%d] [%s] [%s]",x,dispstr,dt);fflush(fsuccess);
	 return ifail;
  } 

int getClassifiedValue(char ***bufferedXmlStrOut,int *buff_cnt,int* vcattr,struct VCAttrDetails VCAttrDetailsList[])
{
	int ifail = ITK_ok;
	int m =0;
	int m1 =0;
	printf("\nBuff count=%d\n",*buff_cnt);fflush(stdout);
	char* ModPartNUmberREvseq	= NULL;
	char* ModPartNUmberREvseq1	= NULL;
	char* ModPartNum	= NULL;
	
	printf("\nTotal Number of Model Found=%d\n",*buff_cnt);fflush(stdout);
	fprintf(fUASAPMapping,"\n Number of Solved Module:%d",*buff_cnt); fflush(fUASAPMapping);
	for(m1=0;m1<*buff_cnt;m1++)
	{
		ModPartNUmberREvseq1	= NULL;
		ModPartNUmberREvseq1 = (*bufferedXmlStrOut)[m1];
		printf("\nModel solved Part number rev seq: %s",ModPartNUmberREvseq1);fflush(stdout);
		fprintf(fUASAPMapping,"\n :%s",ModPartNUmberREvseq1); fflush(fUASAPMapping);
	}
	
	m1=0;
	char**	ModPartNumSet = NULL;
	ModPartNumSet = (char**)MEM_alloc( 1 * sizeof *ModPartNumSet );
	int	ModPrtSr=0;
	for(m1=0;m1<*buff_cnt;m1++)
	{
		ModPartNum	= NULL;
		ModPartNUmberREvseq = (*bufferedXmlStrOut)[m1];
		ModPartNum = strtok (ModPartNUmberREvseq,"/");
		printf("\nModel Part number:: %s",ModPartNum);fflush(stdout);
		setAddStr(&ModPrtSr,&ModPartNumSet,ModPartNum);
	}
	m1=0;
	char**	ModPartNumUqSet = NULL;
	ModPartNumUqSet = (char**)MEM_alloc( 1 * sizeof *ModPartNumUqSet );
	int	ModPrtSrUq=0;
	
	for(m1=0;m1<ModPrtSr;m1++)
	{
		int FoundFlag=0;
		ModPartNum	= NULL;
		printf("\n%s",(ModPartNumSet)[m1]);fflush(stdout);
		ModPartNum = (ModPartNumSet)[m1];
		printf("\n Serching part number %s",ModPartNum);fflush(stdout);
		int j=0;
		for(j=0;j<ModPrtSrUq;j++) 
		{
			printf("\n Compareing with  ===%s",(ModPartNumUqSet)[j]);fflush(stdout);
			if(tc_strcmp((ModPartNumUqSet)[j],ModPartNum)==0)
			{
				printf("\n String Found ===%d",j);fflush(stdout);
				FoundFlag=1;
				break;
			}
			else
			{
				printf("\n Part Number NOT Found %s",ModPartNum);fflush(stdout);
				//setAddStr(&ModPrtSrUq,&ModPartNumUqSet,ModPartNum);
				//FoundFlag=1;
			}
		
		}
		if(FoundFlag==0)
		{
			printf("\n Part Number %s Added",ModPartNum);fflush(stdout);
			setAddStr(&ModPrtSrUq,&ModPartNumUqSet,ModPartNum);
		}
	}
	m1=0;
	printf("\nTotal Number of Unique Model Found=%d\n",ModPrtSrUq);fflush(stdout);
	fprintf(fUASAPMapping,"\n Number of Solved Unique Module:%d",ModPrtSrUq); fflush(fUASAPMapping);
	for(m1=0;m1<ModPrtSrUq;m1++)
	{
		ModPartNum	= NULL;
		ModPartNum = (ModPartNumUqSet)[m1];
		printf("\nFinal Unique set is: %s",ModPartNum);fflush(stdout);
		fprintf(fUASAPMapping,"\n :%s",ModPartNum); fflush(fUASAPMapping);
	}
	for(m=0;m<ModPrtSrUq;m++)
	{
		ModPartNum	= NULL;
		printf("\n Loop Number %d",m);fflush(stdout);
		tag_t Modelrev_tag = NULLTAG;
		ModPartNum = (ModPartNumUqSet)[m];
		printf("\nModel Part number: %s",ModPartNum);fflush(stdout);
		
		if(ITEM_find_item(ModPartNum,&Modelrev_tag)!=ITK_ok)PrintErrorStack();
		printf("\n selected part part Master found");fflush(stdout);
		
		tag_t			classificationObject = NULLTAG;
		int theAttributeCount =0;
		int *theAttributeIds ;
		char 			**theAttributeNames;
		int *theAttributeValCounts=0;
		char***       theAttributeValues;
		char***       theAttributeOptimizedUnits;
		char* 	attrId 					= NULL;
		attrId = (char *) MEM_alloc( 50 * sizeof(char) );
		char 	*attributeNameDup 			= NULL;
		char 	*attributeValueDup 			= NULL;
		attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
		attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
		int i,x=0;
		int TotVCAttrCount=0;
		
		char*	 ModelrevPartRev = NULL;
		
		ITK_CALL(ICS_ask_classification_object(Modelrev_tag,&classificationObject));
	
		if (classificationObject != NULLTAG)
		{
		ITK_CALL( ICS_ico_ask_attributes_optimized(classificationObject,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
		printf("### ICS_ico_ask_named_attributes nAttributes = %d\n", theAttributeCount);fflush(stdout);
		if(theAttributeCount>0)
		{
			for(i=0;i<theAttributeCount;i++)
				{
					
					TotVCAttrCount=TotVCAttrCount+theAttributeCount;
					
					printf("\n theAttributeIds id:[%d]",theAttributeIds[i]);fflush(stdout);
					printf("\n theAttributeNames:[%s]",theAttributeNames[i]);fflush(stdout);
					sprintf(attrId,"%d",theAttributeIds[i]);
					printf("\n attrId:[%s]",attrId);fflush(stdout);
						
					tc_strcpy(attributeNameDup,"");
					tc_strcpy(attributeNameDup,theAttributeNames[i]);
					
					printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,i);fflush(stdout);
					
					tc_strcpy(attributeValueDup,"");
					
					printf("\n Number of attribute value is %d ",*theAttributeValCounts);fflush(stdout);
					
					for(x=0;x<theAttributeValCounts[i];x++)
					{

					printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[i][x]);fflush(stdout);
					tc_strcat(attributeValueDup,theAttributeValues[i][x]);
					printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
					}
					printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);
					tc_strcpy(VCAttrDetailsList[*vcattr].VCAttrID,attrId);
					tc_strcpy(VCAttrDetailsList[*vcattr].VCAttrName,attributeNameDup);
					tc_strcpy(VCAttrDetailsList[*vcattr].VCAttrNameValue,attributeValueDup);
					
					printf("\n attribute id in loop :[%s]",VCAttrDetailsList[*vcattr].VCAttrID);fflush(stdout);
					printf("\n attribute name  in loop:[%s]",VCAttrDetailsList[*vcattr].VCAttrName);fflush(stdout);
					printf("\n attribute Value in loop:[%s]",VCAttrDetailsList[*vcattr].VCAttrNameValue);fflush(stdout);
					*vcattr=*vcattr+1;
					
				}
				printf("\n total VC attribute value:[%d] ",TotVCAttrCount);fflush(stdout);
				printf("\n total vcattr value:[%d] ",*vcattr);fflush(stdout);
	}
	}
	else
	{
		printf("\n VCclassificationObject NOt found");fflush(stdout);
	}
	}
	printf("\n END For Loop");fflush(stdout);
int j=0;
 for(j=0 ;j<*vcattr;j++ )
	{
	printf("\n value of J:[%d] ",j);fflush(stdout);fflush(stdout);
	printf("\n attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
	printf("\n attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
	printf("\n attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);

		  
	}
	printf("\nGoing from getClassifiedValue");fflush(stdout);
return ifail;									
}	
int ITK_user_main(int argc, char* argv[])
{
    int status;
	int resultCount =0;
	int n_entries = 1;
	int n_tags_found = 1;
	int tskcnt =0,t=0,p=0;

	tag_t queryTag = NULLTAG;
	tag_t PartTag= NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t resultOutputTag = NULLTAG;


	char* part_noDup = NULL;

	char *PartNum=NULL;
	char *PartNumDup=NULL;
	char *PartRev=NULL;
	char *part_type=NULL;
	char *unit=NULL;
	char *LatRevName=NULL;
	char *chrp=NULL;
	char *part_typeDup=NULL;
	char *descDup=NULL;
	char *desc=NULL;
	char *PartRevDup=NULL;
	char *PartRelStat=NULL;

	char *inputPart=NULL;
	char  type_name[TCTYPE_name_size_c+1];
	const char *cTemp="item_id";
	static RFC_RC RfcRc;
	tag_t*			TechSPecObjSet			= NULLTAG;
	int TechSpecCount=0;
	tag_t			TechSPecObj				= NULLTAG;
	char** bufferedXmlStrOut;
	int buff_cnt=0;
	
	tag_t			snapshotObj				= NULLTAG;
	int snapshotCount=0;
	tag_t*			snapshotObjSet			= NULLTAG;
	char   snapshotObjtype_name[TCTYPE_name_size_c+1];
	tag_t snapshotObjTypeTag=NULLTAG;
	char*	 snapshot_itemid			= NULL;
	char* SSTopLineRev	= NULL;
	UrnCode = NULL;
	int vcattr =0;
	struct VCAttrDetails VCAttrDetailsList[5000];
	descDup = (char *)malloc(500 * sizeof(char));

		char* usr={"ercjsup"};
		char* upw={"XYT1ESA"};
		char* ugp={"ERC_Designers_Group"};
		char *s;
		status = ITK_init_module( usr,upw,ugp);
		if ( status != ITK_ok)
		{
		EMH_ask_error_text( status, &s);
		printf("Error with ITK_init_module: %s \n",s);fflush(stdout);
		MEM_free(s);
		return status;
		}
		else 
		{
			printf("Logon to succesful as %s.\n", usr);fflush(stdout);	
		}
		inputPart = ITK_ask_cli_argument("-d=");
		
		printf("\n inputPart1111:%s: \n ", inputPart);fflush(stdout);

		if(tc_strcmp(inputPart,"")==0)
		{
			printf("\nPart Number\n");fflush(stdout);
		}
		char 	currentDateTime[100]			= "";
		time_t 	now;
		struct 	tm	when;
		time(&now);
		when = *localtime(&now);
	
		strftime(currentDateTime,100,"%d_%m_%Y_%H_%M_%S",&when);
		
		sprintf(fUASAPMapping_name,"%s-%s.log",inputPart,currentDateTime);
		fUASAPMapping = fopen(fUASAPMapping_name,"w");
		
		sprintf(fsuccess_name,"Erc_Sap_Classfication_%s_%s.log",inputPart,currentDateTime);
		fsuccess = fopen(fsuccess_name,"a");fflush(fsuccess);

		fprintf(fsuccess,"\ninputPart:%s: \n ", inputPart);fflush(fsuccess);
		
		ITK_CALL(getAllReleasedPartDML1(inputPart,&PartTag));

		if(PartTag!=NULLTAG)
			{
				ColorIDPartDup=NULL;					
				ColorIDPart=NULL;	
				int PrtLen=0;
				ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
				tc_strdup(PartNum,&part_noDup);
				
				printf("\npart_noDup [%s]", part_noDup);fflush(stdout);
				
				PrtLen=strlen(part_noDup);
				printf("\nPart lenght  [%d]", PrtLen);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
				tc_strdup(PartRev,&PartRevDup);
				
				printf("\nPartRevDup [%s]", PartRevDup);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
				tc_strdup(part_type,&part_typeDup);
				
				printf("\nPart Typeee [%s]", part_typeDup);fflush(stdout);
				
				ITK_CALL(AOM_UIF_ask_value(PartTag,"object_desc",&desc));
				tc_strdup(desc,&descDup);
				printf("\nPart Number [%s]", descDup);fflush(stdout);
				
				char* ColIndPart = NULL;
				char* ColIndPartDup = NULL;
				
				ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&ColIndPart));
				
				if(tc_strcmp(ColIndPart,NULL)!=0 || tc_strcmp(ColIndPart,"")!=0 )
				{
					tc_strdup(ColIndPart,&ColIndPartDup);
				}
				else
				{
					tc_strdup("",&ColIndPartDup);
				}
				printf("\n ColIndPartDup [%s]", ColIndPartDup);fflush(stdout);

				ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&PartRelStat));
				
				printf("\n Release status is [%s]", PartRelStat);fflush(stdout);
				if(tc_strstr(PartRelStat,"ERC Released")!=NULL)
				{
					char* PartColInd = NULL;
					ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&PartColInd));
					printf("\n  colour indicator : %s",PartColInd);	fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourID",&ColorIDPart));
					printf("\n  ColorIDPart : %s",ColorIDPart);	fflush(stdout);	
					if(tc_strcmp(ColorIDPart,NULL)!=0 || tc_strcmp(ColorIDPart,"")!=0 )
						{
							tc_strdup(ColorIDPart,&ColorIDPartDup);
						}
						else
						{
							tc_strdup("",&ColorIDPartDup);
						}
						printf("\n  ColorIDPart : %s",ColorIDPartDup);	fflush(stdout);
					if (tc_strcmp(PartColInd,"C")==0)
						{
							if(tc_strstr(descDup,ColorIDPartDup)==NULL)
							{
								printf("\nVC Color ID and VC Desc Alias are Different...Copying Color ID ALIAS\n");
								ColorIDPartDup = strtok( descDup, "-" );
								
								printf("\n  ColorIDPartDup for colour part : %s",ColorIDPartDup);	fflush(stdout);
							}
						
						}
						printf("\n  final ColorIDPartDup : %s",ColorIDPartDup);	fflush(stdout);	
						if (tc_strcmp(PartColInd,"C")==0)
						{
							tag_t   NonCol_Prt_rel_type     = NULLTAG;
							int     NonColcount      =  0;
							tag_t	*NonColPart_tag		= NULL;
							tag_t   NonColPartObjm     = NULLTAG;
							char*	 NonColPartNo = NULL;
							char*	 NonColPartRev = NULL;
							char*	 NonColPartPrtType = NULL;
							tag_t VPartTag = NULLTAG;
							if(GRM_find_relation_type("TC_Is_Represented_By",&NonCol_Prt_rel_type)!=ITK_ok)PrintErrorStack();
							if (NonCol_Prt_rel_type!=NULLTAG)
							{
								if(GRM_list_secondary_objects_only(PartTag,NonCol_Prt_rel_type,&NonColcount,&NonColPart_tag)!=ITK_ok)PrintErrorStack();
								printf("\n  NOnCol5:NonColcount: %d",NonColcount);	fflush(stdout);
								NonColPartObjm=NonColPart_tag[0];
								AOM_ask_value_string(NonColPartObjm,"item_id",&NonColPartNo);
								AOM_ask_value_string(NonColPartObjm,"item_revision_id",&NonColPartRev);
								AOM_ask_value_string(NonColPartObjm,"t5_PartType",&NonColPartPrtType);
								printf("\n Non Colour part Number:%s ",NonColPartNo);fflush(stdout);
								printf("\n Non Colour part rev:%s ",NonColPartRev);fflush(stdout);
								printf("\n Non Colour part Type:%s ",NonColPartPrtType);fflush(stdout);
								tc_strdup(NonColPartNo,&UrnCode);
											
								tag_t   window,rule,top_line = NULLTAG;
								int VpartCount = 0;
								tag_t  *children=NULLTAG;
								tag_t   VchildPart=NULLTAG;
								int iChildItemTag=0;
								char *VPrtNum=NULL;
								char *VPrtNumRevId=NULL;
								char *VPrtType=NULL;
								if (tc_strcmp(NonColPartPrtType,"VC")==0)
								{
									ITKCALL(BOM_create_window (&window));
									if(CFM_find( "ERC release and above", &rule )!=ITK_ok)PrintErrorStack();
									ITKCALL(BOM_set_window_config_rule(window,rule));
									BOM_set_window_top_line(window, null_tag,NonColPartObjm ,null_tag, &top_line);
									ITKCALL(BOM_line_ask_child_lines (top_line, &VpartCount, &children));
									printf("\n No of child objects are n : %d",VpartCount);fflush(stdout);
									if(VpartCount>0)
									{
										BOM_line_unpack (children[0]);
										BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
										BOM_line_ask_attribute_tag(children[0], iChildItemTag, &VPartTag);
										if(VPartTag!=NULLTAG)
										{
											AOM_ask_value_string(VPartTag,"item_id",&VPrtNum);
											AOM_ask_value_string(VPartTag,"item_revision_id",&VPrtNumRevId);
											ITK_CALL(AOM_ask_value_string(VPartTag,"t5_PartType",&VPrtType));
											printf("\n\n\t\t VPrtNum : %s\n",VPrtNum);fflush(stdout);
											printf("\n\n\t\t VPrtNumRevId : %s\n",VPrtNumRevId);fflush(stdout);
											printf("\n\n\t\t VPrtType : %s\n",VPrtType);fflush(stdout);
										}
									}
									bufferedXmlStrOut=NULL;
									buff_cnt=0;
									char	*ModPartAct	=	NULL;
									ModPartAct	=	(char	*)MEM_alloc(300);
									tc_strcpy(ModPartAct,VPrtNum);
									tc_strcat(ModPartAct,"/");
									tc_strcat(ModPartAct,VPrtNumRevId);

									printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
									setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
									tm_ebom_mbom_rpt(VPartTag,&bufferedXmlStrOut,&buff_cnt);
									printf("\n Calling getClassifiedValue"); fflush(stdout);
									printf("\n Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
									ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
									printf("\n After calling getClassifiedValue"); fflush(stdout);
									int j=0;
									for(j=0 ;j<vcattr;j++ )
									{
										printf("\n value of J:[%d] ",j);fflush(stdout);fflush(stdout);
										printf("\n attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
										printf("\n attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
										printf("\n attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
									}
									printf("\n\t calling for getMoRTHAttributes value for vechicle");	fflush(stdout);
									getMoRTHAttributes(VPartTag);
									printf("\n\t getMoRTHAttributes value Updated for vechicle");	fflush(stdout);
									ITK_CALL(AOM_ask_value_tags(VPartTag,"T5_VCSpec",&TechSpecCount,&TechSPecObjSet));
									if(TechSpecCount)
									{
										TechSPecObj=TechSPecObjSet[0];
									}
									printf("\n hello2 UrnCode is %s",UrnCode);fflush(stdout);	
									ClassificationView1(PartTag,part_noDup,part_noDup,&TechSPecObj,vcattr,VCAttrDetailsList);
									
								}
								else if (tc_strcmp(NonColPartPrtType,"CCVC")==0)
								{
									snapshotObjSet			= NULLTAG;
									snapshotCount=0;
									
									ITK_CALL(AOM_ask_value_tags(NonColPartObjm,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet));
									
									snapshotObj				= NULLTAG;
									printf("\n nowwwwwwwwwww snapshotCount:[%d] ******",snapshotCount); fflush(stdout);
									snapshotObj=snapshotObjSet[0];
									snapshotObjTypeTag=NULLTAG;
									if(TCTYPE_ask_object_type(snapshotObj,&snapshotObjTypeTag));
									if(TCTYPE_ask_name(snapshotObjTypeTag,snapshotObjtype_name));
									printf("\n\t snapshotObjtype_name := %s", snapshotObjtype_name);fflush(stdout);
									tag_t item_rev_tags	= NULLTAG;

									snapshot_itemid			= NULL;
									SSTopLineRev	= NULL;
									bufferedXmlStrOut=NULL;
									buff_cnt=0;
									
									char	*ModPartAct	=	NULL;
									ModPartAct	=	(char	*)MEM_alloc(300);
									tc_strcpy(ModPartAct,NonColPartNo);
									tc_strcat(ModPartAct,"/");
									tc_strcat(ModPartAct,NonColPartRev);

									printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
									setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
									if (tc_strcmp(snapshotObjtype_name,"Snapshot")==0)
									{
										ITK_CALL(AOM_ask_value_string(snapshotObj,"object_name",&snapshot_itemid));
										printf("\n\t snapshot_itemid :%s",snapshot_itemid);	fflush(stdout);
							
										 ITKCALL(AOM_UIF_ask_value(snapshotObj,"topLine",&SSTopLineRev));
										printf("\nSnapshot Top Line : %s",SSTopLineRev);fflush(stdout);

										ITKCALL(AOM_ask_value_tag(snapshotObj,"topLine",&item_rev_tags));
										//printf("\nSnapshot Top Line : %s",item_rev_tags);fflush(stdout);
										tm_ebom_snapshot(snapshot_itemid,&bufferedXmlStrOut,&buff_cnt);	
									}
									printf("\n Calling getClassifiedValue"); fflush(stdout);
									printf("\n Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
									ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
									printf("\n After calling getClassifiedValue"); fflush(stdout);
									int j=0;
									for(j=0 ;j<vcattr;j++ )
									{
										printf("\n value of J:[%d] ",j);fflush(stdout);fflush(stdout);
										printf("\n attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
										printf("\n attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
										printf("\n attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
									}
									ITK_CALL(AOM_ask_value_tags(NonColPartObjm,"T5_VCSpec",&TechSpecCount,&TechSPecObjSet));
									if(TechSpecCount)
									{
										TechSPecObj=TechSPecObjSet[0];
									}
									printf("\n hello2 UrnCode is %s",UrnCode);fflush(stdout);
									printf("\n\t calling for getMoRTHAttributes value for vechicle");	fflush(stdout);
									getMoRTHAttributes(VPartTag);
									printf("\n\t getMoRTHAttributes value Updated for vechicle");	fflush(stdout);
									ClassificationView1(PartTag,part_noDup,part_noDup,&TechSPecObj,vcattr,VCAttrDetailsList);
								}
								else
								{
								}
							}
						}
						else
						{
							printf("\n NON Colour VC"); fflush(stdout);
							if (tc_strcmp(part_typeDup,"VC")==0)
							{
								tc_strdup(part_noDup,&UrnCode);
								tag_t   window,rule,top_line = NULLTAG;
								int VpartCount,p1,k = 0;
								tag_t  *children=NULLTAG;
								tag_t   VchildPart=NULLTAG;
								int iChildItemTag=0;
								tag_t   t_ChildItemRev;
								char * VPrtNum =NULL ;
								char * VPrtNumRevId=NULL ;
								tag_t VPartMaster = NULLTAG;
								tag_t VPartTag= NULLTAG;
								ITKCALL(BOM_create_window (&window));
								if(CFM_find( "ERC release and above", &rule )!=ITK_ok)PrintErrorStack();
								ITKCALL(BOM_set_window_config_rule(window,rule));
								BOM_set_window_top_line(window, null_tag,PartTag ,null_tag, &top_line);
								ITKCALL(BOM_line_ask_child_lines (top_line, &VpartCount, &children));
								printf("\n\n\t\t No of child objects are n : %d\n",VpartCount);fflush(stdout);
								
								for (k = 0; k < VpartCount; k++)
								{
									BOM_line_unpack (children[k]);
									BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
									BOM_line_ask_attribute_tag(children[k], iChildItemTag, &VPartTag);
									if(VPartTag!=NULLTAG)
									{
										AOM_ask_value_string(VPartTag,"item_id",&VPrtNum);
										AOM_ask_value_string(VPartTag,"item_revision_id",&VPrtNumRevId);
										printf("\n\n\t\t VPrtNum : %s\n",VPrtNum);fflush(stdout);
										printf("\n\n\t\t VPrtNumRevId : %s\n",VPrtNumRevId);fflush(stdout);
									}
								}
								ITK_CALL(AOM_ask_value_tags(VPartTag,"T5_VCSpec",&TechSpecCount,&TechSPecObjSet));
								bufferedXmlStrOut=NULL;
								buff_cnt=0;
								char	*ModPartAct	=	NULL;
								ModPartAct	=	(char	*)MEM_alloc(300);
								tc_strcpy(ModPartAct,VPrtNum);
								tc_strcat(ModPartAct,"/");
								tc_strcat(ModPartAct,VPrtNumRevId);

								printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
								setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
								tm_ebom_mbom_rpt(VPartTag,&bufferedXmlStrOut,&buff_cnt);
								
								printf("\n Calling getClassifiedValue"); fflush(stdout);
								printf("\n Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
								ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
								printf("\n After calling getClassifiedValue"); fflush(stdout);
								int j=0;
								for(j=0 ;j<vcattr;j++ )
								{
									printf("\n value of J:[%d] ",j);fflush(stdout);fflush(stdout);
									printf("\n attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
									printf("\n attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
									printf("\n attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
								}
								printf("\n\t calling for getMoRTHAttributes value for vechicle");	fflush(stdout);
								getMoRTHAttributes(VPartTag);
								printf("\n\t getMoRTHAttributes value Updated for vechicle");	fflush(stdout);
								ITK_CALL(AOM_ask_value_tags(VPartTag,"T5_VCSpec",&TechSpecCount,&TechSPecObjSet));
								if(TechSpecCount)
								{
									TechSPecObj=TechSPecObjSet[0];
								}
								printf("\n hello2 UrnCode is %s",UrnCode);fflush(stdout);
								ClassificationView1(PartTag,part_noDup,part_noDup,&TechSPecObj,vcattr,VCAttrDetailsList);
							}
							else if (tc_strcmp(part_typeDup,"CCVC")==0)
							{
								tc_strdup(part_noDup,&UrnCode);
								char	*CCVCPrtNum	=	NULL;
								char	*CCVCPrtNumRevId	=	NULL;
								AOM_ask_value_string(PartTag,"item_id",&CCVCPrtNum);
								AOM_ask_value_string(PartTag,"item_revision_id",&CCVCPrtNumRevId);
								printf("\n\n\t\t CCVCPrtNum : %s\n",CCVCPrtNum);fflush(stdout);
								printf("\n\n\t\t CCVCPrtNumRevId : %s\n",CCVCPrtNumRevId);fflush(stdout);
								snapshotCount=0;
								snapshotObjSet			= NULLTAG;
								ITK_CALL(AOM_ask_value_tags(PartTag,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet));
								snapshotObj				= NULLTAG;
								printf("\n nowwwwwwwwwww snapshotCount:[%d] ******",snapshotCount); fflush(stdout);
								snapshotObj=snapshotObjSet[0];
								snapshotObjTypeTag=NULLTAG;
								if(TCTYPE_ask_object_type(snapshotObj,&snapshotObjTypeTag));
								if(TCTYPE_ask_name(snapshotObjTypeTag,snapshotObjtype_name));
								printf("\n\t snapshotObjtype_name := %s", snapshotObjtype_name);fflush(stdout);
								tag_t item_rev_tags	= NULLTAG;

								snapshot_itemid			= NULL;
								SSTopLineRev	= NULL;
								bufferedXmlStrOut=NULL;
								buff_cnt=0;
								char	*ModPartAct	=	NULL;
								ModPartAct	=	(char	*)MEM_alloc(300);
								tc_strcpy(ModPartAct,CCVCPrtNum);
								tc_strcat(ModPartAct,"/");
								tc_strcat(ModPartAct,CCVCPrtNumRevId);

								printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
								setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
								if (tc_strcmp(snapshotObjtype_name,"Snapshot")==0)
								{
									ITK_CALL(AOM_ask_value_string(snapshotObj,"object_name",&snapshot_itemid)); 
									printf("\n\t snapshot_itemid :%s",snapshot_itemid);	fflush(stdout);
						
									ITKCALL(AOM_UIF_ask_value(snapshotObj,"topLine",&SSTopLineRev));
									printf("\nSnapshot Top Line : %s",SSTopLineRev);fflush(stdout);

									ITKCALL(AOM_ask_value_tag(snapshotObj,"topLine",&item_rev_tags));
									//printf("\nSnapshot Top Line : %s",item_rev_tags);fflush(stdout);
									tm_ebom_snapshot(snapshot_itemid,&bufferedXmlStrOut,&buff_cnt);	
								}
								printf("\n Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
								printf("\n Calling getClassifiedValue"); fflush(stdout);
								ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
								printf("\n After calling getClassifiedValue"); fflush(stdout);
								int j=0;
								for(j=0 ;j<vcattr;j++ )
								{
									printf("\n value of J:[%d] ",j);fflush(stdout);fflush(stdout);
									printf("\n attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
									printf("\n attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
									printf("\n attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
								}
								ITK_CALL(AOM_ask_value_tags(PartTag,"T5_VCSpec",&TechSpecCount,&TechSPecObjSet));
								if(TechSpecCount)
								{
									TechSPecObj=TechSPecObjSet[0];
								}
								printf("\n hello2 UrnCode is %s",UrnCode);fflush(stdout);
								printf("\n\t calling for getMoRTHAttributes value for vechicle");	fflush(stdout);
								getMoRTHAttributes(PartTag);
								printf("\n\t getMoRTHAttributes value Updated for vechicle");	fflush(stdout);
								ClassificationView1(PartTag,part_noDup,part_noDup,&TechSPecObj,vcattr,VCAttrDetailsList);
							}
							else if (tc_strcmp(part_typeDup,"V")==0 && strlen(part_noDup)==9)
							{
								bufferedXmlStrOut=NULL;
								buff_cnt=0;
								char	*ModPartAct	=	NULL;
								ModPartAct	=	(char	*)MEM_alloc(300);
								tc_strcpy(ModPartAct,part_noDup);
								tc_strcat(ModPartAct,"/");
								tc_strcat(ModPartAct,PartRevDup);

								printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
								setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
								tm_ebom_mbom_rpt(PartTag,&bufferedXmlStrOut,&buff_cnt);
								
								printf("\n Calling getClassifiedValue"); fflush(stdout);
								printf("\n Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
								ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
								printf("\n After calling getClassifiedValue"); fflush(stdout);
								int j=0;
								for(j=0 ;j<vcattr;j++ )
								{
									printf("\n value of J:[%d] ",j);fflush(stdout);fflush(stdout);
									printf("\n attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
									printf("\n attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
									printf("\n attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
								}
								ITK_CALL(AOM_ask_value_tags(PartTag,"T5_VCSpec",&TechSpecCount,&TechSPecObjSet));
								if(TechSpecCount)
								{
									TechSPecObj=TechSPecObjSet[0];
								}
								printf("\n\t calling for getMoRTHAttributes value for vechicle");	fflush(stdout);
								getMoRTHAttributes(PartTag);
								printf("\n\t getMoRTHAttributes value Updated for vechicle");	fflush(stdout);
								
								int		n_parents = 0;
								int		jd = 0;
								int *levels = 0;
								tag_t *parents = NULLTAG;
								
								ITKCALL(PS_where_used_all(PartTag,1,&n_parents,&levels,&parents));
								printf("\n\t Total Parent Part : %d",n_parents); fflush(stdout); 
								if(n_parents>0)
									{
										for (jd=0;jd<n_parents;jd++ )
										{
											tag_t ParentVCTag = NULLTAG;
											char* VCPartNumber = NULL;
											char* VCPartNumberRevId = NULL;
											char* PColorIDPart = NULL;
											ColorIDPartDup = NULL;
											ParentVCTag=parents[jd];

											ITKCALL(AOM_ask_value_string(ParentVCTag,"item_id",&VCPartNumber));
											printf("\nVCPartNumber : %s",VCPartNumber);fflush(stdout);
											AOM_ask_value_string(ParentVCTag,"item_revision_id",&VCPartNumberRevId);
											printf("\nVCPartNumberRevId : %s",VCPartNumberRevId);fflush(stdout);
											ITK_CALL(AOM_ask_value_string(ParentVCTag,"t5_ColourID",&PColorIDPart));
											printf("\n  Parent ColorIDPart : %s",PColorIDPart);	fflush(stdout);	
											
											if(tc_strcmp(PColorIDPart,NULL)!=0 || tc_strcmp(PColorIDPart,"")!=0 )
												{
													tc_strdup(PColorIDPart,&ColorIDPartDup);
												}
												else
												{
													tc_strdup("",&ColorIDPartDup);
												}
												printf("\n  PColorIDPart : %s",ColorIDPartDup);	fflush(stdout);
						
											tc_strdup(VCPartNumber,&UrnCode);
											printf("\n hello2 UrnCode is %s",UrnCode);fflush(stdout);
											ClassificationView1(ParentVCTag,VCPartNumber,VCPartNumber,&TechSPecObj,vcattr,VCAttrDetailsList);
										}
									}
							}
							else
							{
								printf("\n In Valide Part type : %s or Part Lenght: %d",part_typeDup,PrtLen);fflush(stdout);
								//printf("\n In Valide Part Lenght : %d",);fflush(stdout);
							}
						}
				}
			}
		


		printf("\nERC DML Transfer Program Completed\n");fflush(stdout);
		fprintf(fsuccess,"\nERC DML Transfer Program Completed\n");fflush(fsuccess);

		return status;
		ITK_CALL(POM_logout(false));

}
;

