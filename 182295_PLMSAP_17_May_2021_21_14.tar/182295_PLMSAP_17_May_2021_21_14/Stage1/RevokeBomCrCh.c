#define TE_MAXLINELEN  128

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <time.h>

#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"
#include "t.h"
#include "ppe.h"

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}


#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

char cpydml_no[50]={0};
char *PlmDmlSuff = NULL;
char *PlmDmlSuffOrig = NULL;
char *meas_unit=NULL;
char fsuccess_name[200]={0};

struct node
{
	char sr_no[5];
	char *part;
	float qty;
	char uq[4];
	char tempcsrel[2];
	char mat_prov_ind[2];
	char * make_buy_indDup; // added by rajendra on 9.9.16
	float usgProb;
	struct node *next;
};
struct usgProbnode
{
	char sr_no[5];
	char *part;
	float usgProb;
	struct usgProbnode *next;
};
struct DmlEpaNode
{
	char DmlEpa[50];
	char ClosureTimeStamp[11];
	char DmlLifeCycleState[30];
	struct DmlEpaNode *next;
};
//static char profit_centre_sap[8]={0};
//static char plan_calendar[5]={0};
//static char overhd_grp[11]={0};
//static char origin_group[11]={0};
//static char plantcode[5]={0};
static char CMakeBuy1[45]={0};
static char CTmpMakeBuy1[45]={0};

char *plantcode	= NULL;
char *iSapServer = NULL;
char *nomenclatureDup	= NULL;
char *apl_release_date = NULL;
char *Current_date_time = NULL;
tag_t MypartObjs		= NULLTAG;
char fsuccess_name[200];
char DMLDescription[100];
FILE *fsuccess;
//FILE *fp;
char *dml_numAP	= NULL;
char *dml_numAP1 = NULL;
//char dml_numAP1[13]		= {0};
static char projectcode[5]={0};

//int PlantChk(char *plant);
void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);
void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str);
tag_t GetAllAssemblies(tag_t PartOPtr);
void ParentBomCreate(tag_t PartOPtr);
//void t5SortBOMObjsByClosureTimeStamp(tag_t	*itemObjs,tag_t	*relObjs);
void my_free(struct node* start);
void SapBomCreate(struct node *head,char *assy_noDup,char *AssemblyRevisionDup,char *SequenceRevisionDup,char *OrganizationIDDup);
void SapBomChange(struct node *head,char *assy_noDup,char *AssemblyRevisionDup,char *SequenceRevisionDup,char *OrganizationIDDup);
void display1(struct node *head,char *assy_noDup);
struct node* createnode(char sr_no[5],char *part,float* qty,char uq[4],char tempcsrel[2],char mat_prov_ind[2],char *make_buy_indDup);
int search(struct node* start,char *part,float* qty);
char* subString(char* mainStringf, int fromCharf, int toCharf);
int checkFrozenViewList(tag_t Part);
void  rfc_error(char *operation);
RFC_HANDLE BapiLogon(void);
RFC_RC ccap_ecn_create(RFC_HANDLE hRfc,AENR_API01 *,CSDATA_XFELD *,CSDATA_XFELD *,CSDATA_XFELD *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AEEF_API01 *,AENRB_AENNR *,ITAB_H,ITAB_H,ITAB_H,ITAB_H,ITAB_H,char *);
void ChangeNoCreate(void);
RFC_RC cll_ccap_ecn_create(RFC_HANDLE);
RFC_RC  cad_create_bom_with_sub_items(RFC_HANDLE hRfc, DRAW_LOEDK *eIAutoPosnr, CAD_BICSK *eIBomHeader, CAD_BICSK *iEBomHeader, MESSAGE_MSGTX *iEMessage, CAD_RETURN_MESSAGE_LEN *iEMessageLen, CAD_RETURN_VALUE *iEReturn, ITAB_H thBomItem, char *xException);
RFC_RC  zcad_change_bom_with_sub_items(RFC_HANDLE hRfc,CAD_BICSK *eIBomHeader,CAD_RETURN_VALUE *iEReturn,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_BICSK *iEBomHeader,ITAB_H thBomItem,char *xException);
RFC_RC  cll_cad_create_bom_with_sub_items(RFC_HANDLE hRfc);

RFC_RC UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2(RFC_HANDLE	hRfc, MARA_MATNR *eMARA_MATNR, MARC_WERKS *eMARC_WERKS, STZU_STLAN *eSTZU_STLAN, STKO_STLAL *eSTKO_STLAL, TC04_CAPID *eTC04_CAPID, STKO_DATUV *eSTKO_DATUV, ITAB_H thSTB, ITAB_H thMATCAT, char *xException );
struct usgProbnode* createnode2(char sr_no[5],char *part,float* usgProb);
struct usgProbnode* GetUsageProb(char *assy_noDup);
void my_free2(struct usgProbnode* start);
void compareUsage(struct usgProbnode *pUP,struct node *start);
void display2(struct usgProbnode *head,char *assy_noDup);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
int findNextRelRev(tag_t CurRevTag);

void trimString(char * str)
{
	int i = 0;
    for (i = 0; i < tc_strlen(str); i++)
	{
		//printf("\n%d %c",i,str[i]);
		if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
		{
			str[i] = '\0';
		}     
	}
}


RFC_RC UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2(RFC_HANDLE	hRfc, MARA_MATNR *eMARA_MATNR, MARC_WERKS *eMARC_WERKS, STZU_STLAN *eSTZU_STLAN, STKO_STLAL *eSTKO_STLAL, TC04_CAPID *eTC04_CAPID, STKO_DATUV *eSTKO_DATUV,ITAB_H  thSTB, ITAB_H  thMATCAT, char *xException )
{

	static RFC_RC RfcRc;

	RFC_PARAMETER Exporting[7];
	RFC_PARAMETER Importing[1];
	RFC_TABLE Tables[3];
	char *RfcException = NULLTAG;

	Exporting[0].name = "MTNRV";		//Material/Partno
	Exporting[0].nlen = 5;
	Exporting[0].type = TYPC;
	Exporting[0].leng = sizeof(MARA_MATNR);
	Exporting[0].addr = eMARA_MATNR;

	Exporting[1].name = "WERKS";		//Material Plant input
	Exporting[1].nlen = 5;
	Exporting[1].type = TYPC;
	Exporting[1].leng = sizeof(MARC_WERKS);
	Exporting[1].addr = eMARC_WERKS;

	Exporting[2].name = "STLAN";		//BOM Usage input
	Exporting[2].nlen = 5;
	Exporting[2].type = TYPC;
	Exporting[2].leng = sizeof(STZU_STLAN);
	Exporting[2].addr = eSTZU_STLAN;

	Exporting[3].name = "STLAL";		//Alternative BOM
	Exporting[3].nlen = 5;
	Exporting[3].type = TYPC;
	Exporting[3].leng = sizeof(STKO_STLAL);
	Exporting[3].addr = eSTKO_STLAL;

	Exporting[4].name = "CAPID";		//Application identifier PP01
	Exporting[4].nlen = 5;
	Exporting[4].type = TYPC;
	Exporting[4].leng = sizeof(TC04_CAPID);
	Exporting[4].addr = eTC04_CAPID;

	Exporting[5].name = "DATUV";		//Valid from date [dd.mm.yyyy][e.g. 06.07.2013]
	Exporting[5].nlen = 5;
	Exporting[5].type = TYPC;
	Exporting[5].leng = sizeof(STKO_DATUV);
	Exporting[5].addr = eSTKO_DATUV;

	Exporting[6].name = NULLTAG;


	Tables[0].name     = "STB";
	Tables[0].nlen     = 3;
	Tables[0].type     = handleOfSTB;
	Tables[0].ithandle = thSTB;

	Tables[1].name     = "MATCAT";
	Tables[1].nlen     = 6;
	Tables[1].type     = handleOfMATCAT;
	Tables[1].ithandle = thMATCAT;

	Tables[2].name     = NULLTAG;

	RfcRc = RfcCall(hRfc,"ZPPRFC_CS_BOM_EXPL_MAT_V2",Exporting,Tables);

	switch (RfcRc)
	{

		case RFC_OK :

			Importing[0].name = NULLTAG;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
			case RFC_SYS_EXCEPTION :
				strcpy(xException,RfcException);
				//printf ("exception1");  fflush(stdout);
			break;
			case RFC_EXCEPTION :
				strcpy(xException,RfcException);
				//printf ("exception2");  fflush(stdout);
			break;
			default:;
			}
		break;
		default:
			printf("\ndefault case"); fflush(stdout);
		break;
	}
	return RfcRc;
}

struct usgProbnode* createnode2(char sr_no[5],char *part,float* usgProb)
{
	struct usgProbnode* q=NULL;
	//printf("In createnode2 Function....\n");
	q=(struct usgProbnode*)malloc(sizeof(struct usgProbnode));
	q->part=part;
	strcpy(q->sr_no,sr_no);
	q->usgProb = *usgProb;
	q->next=NULL;
	return q;
}

void display2(struct usgProbnode *head,char *assy_noDup)
{
	struct usgProbnode *q = NULLTAG;
	for(q = head; q != NULL; q = q -> next)
	{
		printf("\n\t %s %-15s %7.3f ",q->sr_no, q->part, q->usgProb);
	}
}



void my_free2(struct usgProbnode* start)
{
	struct usgProbnode* prev;
	struct usgProbnode* ptr;
	printf("\nErazing Linklist Started...\n");
	fprintf(fsuccess,"\nErazing Linklist Started...\n");
	for(prev = start, ptr = start; ptr != NULLTAG, prev = ptr;ptr = ptr->next)
	{
		printf("#");
		fprintf(fsuccess,"#");
		free(prev);
	}
	start = NULLTAG;
	printf("\nErazing Linklist Completed.\n");
	fprintf(fsuccess,"\nErazing Linklist Completed.\n");

}

struct usgProbnode*  GetUsageProb(char *assy_noDup)
{
	struct usgProbnode *startUsg=NULLTAG, *p=NULLTAG, *t=NULLTAG;
	int		ret = 0;
	float usgPrbFloat = 0.000f;
	//float sumUsgProb = 0.000f;

	char xException[256];
	char s[1024]={0};

	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc3;

	MARA_MATNR	eMARA_MATNR;
	MARC_WERKS	eMARC_WERKS;
	STZU_STLAN	eSTZU_STLAN;
	STKO_STLAL	eSTKO_STLAL;
	TC04_CAPID	eTC04_CAPID;
	STKO_DATUV	eSTKO_DATUV;

	ITAB_H thMATCAT = ITAB_NULL;
	ITAB_H thSTB  = ITAB_NULL;
	STB *tSTB;

	unsigned crow;
	char cUsgProbStr[2000];
	//char *cUsgProbStr = NULL;
	char *sumStr = NULL;
	char *cUsgProbChildP = NULL;
	char *GrpChildPart = NULL;
	char *cItemNoSap = NULL;
	char *date  = NULL;
	char *year  = NULL;
	char *month = NULL;
	char *daydt = NULL;
	char *sapIpDt = NULL;
	char* timestamp = NULL;

	time_t NowTime;
	struct tm *timeinfo;

	timestamp = (char *) MEM_alloc(20 * sizeof(char ));
	sapIpDt = (char *) MEM_alloc(9 * sizeof(char ));
	cItemNoSap = (char *) MEM_alloc(20 * sizeof(char ));
	cUsgProbChildP = (char *) MEM_alloc(20 * sizeof(char ));

	hRfc = BapiLogon();
	
	time(&NowTime);
	timeinfo = localtime(&NowTime);
	strftime(timestamp, 20, "%Y-%m-%d-%H_%M_%S", timeinfo);
	printf("\ntimestamp %s",timestamp);

	/*date = sysGetDate2();
	year = subString(date,0,4);
	month = subString(date,5,2);
	daydt = subString(date,8,2);*/

	year = strtok ( timestamp, "-" );
	month = strtok ( NULL, "-" );
	daydt = strtok ( NULL, "-" );

	tc_strcpy(sapIpDt,"");
	tc_strcpy(sapIpDt,year);
	tc_strcat(sapIpDt,month);
	tc_strcat(sapIpDt,daydt);
	printf("\n eSTKO_DATUV:[%s] \n",sapIpDt); fflush(stdout);

	SETCHAR(eMARA_MATNR,assy_noDup);
	SETCHAR(eMARC_WERKS,plantcode);
	if (!tc_strcmp(plantcode,"2001"))
	{
		SETCHAR(eSTZU_STLAN,"2");
	}
	else
	{
		SETCHAR(eSTZU_STLAN,"1");
	}
	SETCHAR(eSTKO_STLAL,"01");
	SETCHAR(eTC04_CAPID,"PP01");
	SETCHAR(eSTKO_DATUV,sapIpDt);

	thSTB = ITAB_NULL;

	if (thSTB==ITAB_NULL)
	{
		thSTB = ItCreate("STB",sizeof(STB),0,0);
		if (thSTB==ITAB_NULL)
			rfc_error("ItCreate STB");
	}
	else if (ItFree(thSTB) != 0)
	{
		rfc_error("ItFree STB");
	}

	thMATCAT = ITAB_NULL;

	if (thMATCAT==ITAB_NULL)
	{
		thMATCAT = ItCreate("MATCAT",sizeof(MATCAT),0,0);
		if (thMATCAT==ITAB_NULL)
			rfc_error("ItCreate MATCAT");
	}
	else if (ItFree(thMATCAT) != 0)
	{
		rfc_error("ItFree MATCAT");
	}

	//sumUsgProb = 0.000f;
	RfcRc3 = UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2(	hRfc,
												&eMARA_MATNR,
												&eMARC_WERKS,
												&eSTZU_STLAN,
												&eSTKO_STLAL,
												&eTC04_CAPID,
												&eSTKO_DATUV,
												thSTB,
												thMATCAT,
												xException
											  );

	printf("\nno of childs fetched for G-part::[%s][%d]\n",assy_noDup,ItFill(thSTB));
	if (ItFill(thSTB)>0)
	{
		startUsg = NULL;
		p = NULL;
		t = NULL;
		ret = 0;

		switch (RfcRc3)
		{
			case RFC_OK :
				//printf("\n In RFC_OK case of UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2...");
				printf("\n Previous Revision Bom Details from SAP...Before updation");
				//printf("\nno of row fetched from thSTB:[%d]\n",ItFill(thSTB));
				//strcpy(cUsgProbStr,"");
				for (crow = 1;crow <= ItFill(thSTB); crow++)
				{
					tSTB = ItGetLine(thSTB,crow);
					if (tSTB == NULL)
					{
						rfc_error("ItGetLineBOM_ITEM");
					}

					printf("\n\t crow :[%d]",crow );
					GETCHAR(tSTB->POSNR, cItemNoSap	);		//OUTS(".....POSNR",10,30, cItemNoSap);
					GETCHAR(tSTB->IDNRK, cUsgProbChildP	);	//OUTS(".....IDNRK",10,30, cUsgProbChildP);

					GETBCD	(tSTB->EWAHR,s,0);
					usgPrbFloat = atof(s);
					sprintf(cUsgProbStr,"%1.3f",atof(s));	//OUTS(".....EWAHR",10,30, cUsgProbStr);

					printf("\n...POSNR:%s",cItemNoSap);
					fprintf(fsuccess,"\n...POSNR:%s",cItemNoSap);
					printf("\n...IDNRK:%s",cUsgProbChildP);
					fprintf(fsuccess,"\n...IDNRK:%s",cUsgProbChildP);
					printf("\n...EWAHR:%s",cUsgProbStr);
					fprintf(fsuccess,"\n...EWAHR:%f",usgPrbFloat);

					trimString(cItemNoSap);
					trimString(cUsgProbChildP);
					tc_strdup(cUsgProbChildP,&GrpChildPart);

					if(p==NULL)
					{

						//sr_no1 = 1 ;
						//sprintf(sr_no,"%04d",sr_no1);
						p = createnode2(cItemNoSap,GrpChildPart,&usgPrbFloat);
						startUsg = p;
					}
					else
					{
						//ret = search(startUsg,cUsgProbChildP,&usgPrbFloat);
						//if(ret == 1)
						//{
							 t=startUsg;
							 while(t->next!=NULL)
							 {
								 t=t->next;
							 }
							 //sr_no1 = sr_no1 + 1 ;
							 //sprintf(cItemNoSap,"%04d",sr_no1);
							 t->next = createnode2(cItemNoSap,GrpChildPart,&usgPrbFloat);
						//}
					}
					//sumUsgProb = sumUsgProb + usgPrbFloat;
				}
				break;
			case RFC_EXCEPTION :
				//printf("\nRFC_EXCEPTION"); fflush(stdout);
				break;
			case RFC_SYS_EXCEPTION :
				//printf("\nRFC_SYS_EXCEPTION"); fflush(stdout);
				break;
			case RFC_FAILURE :
				//printf("\nfailure"); fflush(stdout);
				break;
			default :
				//printf("\nother failure"); fflush(stdout);
				break;
		}

		if (ItDelete(thSTB) != 0)
			rfc_error("ItDelete STB");
		if (ItDelete(thMATCAT) != 0)
			rfc_error("ItDelete MATCAT");
	}

	//display2(startUsg, assy_noDup);

	RfcClose(hRfc);
	return startUsg;
}

void compareUsage(struct usgProbnode *pUP,struct node *start)
{
	struct usgProbnode *p = NULL;
	struct node *q = NULL;

	printf("\nSAP Bom List");
	fprintf(fsuccess,"\nSAP Bom List");
	for(p = pUP;p!=NULL;p = p->next)
	{
		printf("\n[%s,%s,%f]",p->sr_no,p->part,p->usgProb);
		fprintf(fsuccess,"\n[%s,%s,%f]",p->sr_no,p->part,p->usgProb);
	}
//	printf("\nPLM");
//	for(q = start;q!=NULL;q = q->next)
//	{
//		printf("\n[%s,%s,%f]",q->sr_no,q->part,q->usgProb);
//	}

	for(q = start;q!=NULL;q = q->next)
	{
		for(p = pUP;p!=NULL;p = p->next)
		{
			//printf("\n[%s,%s]",q->part,p->part);
			if(tc_strcmp(q->part,p->part)==0)
			{
				q->usgProb = p->usgProb;
			}
		}
	}

	printf("\nPLM Bom List");
	fprintf(fsuccess,"\nPLM Bom List");
	for(q = start;q!=NULL;q = q->next)
	{
		printf("\n[%s,%s,%f]",q->sr_no,q->part,q->usgProb);
		fprintf(fsuccess,"\n[%s,%s,%f]",q->sr_no,q->part,q->usgProb);
	}
}

/*status t5SortBOMObjsByClosureTimeStamp(tag_t	*itemObjs,tag_t	*relObjs,integer* mfail)
{
	status			dstat		= OKAY;
   	char			*mod_name 	= "t5SortBOMObjsByDate";
	tag_t    tmpItemObjs    = NULL;
	tag_t    tmpRelObjs     = NULL;
   	tag_t		relObj		= NULL;
   	tag_t		itemObj		= NULL;
   	tag_t		relTObj		= NULL;
   	tag_t		itemTObj	= NULL;
	integer			count		= 0;
	integer			cmpCount	= 0;
	tag_t		tmpRelObj	= 0;
	string			curCreDate		= NULL;
	string			tmpcurCreDate	= NULL;
	string			cmpCreDate		= NULL;
	string			tmpcmpCreDate	= NULL;
	*mfail 		= USC_OKAY;


	for(count=0; count<setSize(*relObjs); count++)
	{
		itemObj = setGet(*itemObjs, count);
		relObj = setGet(*relObjs, count);


		if(count == 0)
		{
			if(dstat = ulyCopyObjectToSet(itemObj, &tmpItemObjs)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(relObj, &tmpRelObjs)) goto CLEANUP;
			continue;
		}

		if(dstat = objCopy(&relTObj, relObj)) goto CLEANUP;
		if(dstat = objCopy(&itemTObj, itemObj)) goto CLEANUP;


		if(dstat = objGetAttribute(relObj, ClosureTimeStampAttr, &curCreDate)) goto CLEANUP;
		tmpcurCreDate = tc_strdup(curCreDate);


		for(cmpCount=0; cmpCount<setSize(tmpRelObjs); cmpCount++)
		{
			tmpRelObj = setGet(tmpRelObjs, cmpCount);

			if(dstat = objGetAttribute(tmpRelObj, ClosureTimeStampAttr, &cmpCreDate)) goto CLEANUP;
			tmpcmpCreDate = tc_strdup(cmpCreDate);

			if(tc_strcmp(tmpcurCreDate,tmpcmpCreDate) <= 0)
			{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
				break;
			}
		}
		if(cmpCount == setSize(tmpRelObjs))
		{
			low_set_insrt(tmpRelObjs, cmpCount, relTObj);
			low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
		}
	}

	//free memory and assign to new set sorted objects
	objDisposeAll(*itemObjs); *itemObjs = NULLTAG;
	objDisposeAll(*relObjs); *relObjs = NULLTAG;

	*itemObjs = tmpItemObjs;
	*relObjs = tmpRelObjs;

CLEANUP:


	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
   	return( dstat );
}*/

void my_free(struct node* start)
{
	struct node* prev;
	struct node* ptr;
	printf("\nErazing Linklist Started...\n");
	fprintf(fsuccess,"\nErazing Linklist Started...\n");
	//for(prev = start, ptr = start; ptr != NULL, prev = ptr;ptr = ptr->next)
	for(prev = start, ptr = start; ptr != NULL, prev = ptr;ptr = ptr->next)
	{
		printf("#");
		fprintf(fsuccess,"#");
		free(prev);
	}
	start = NULL;
	printf("\nErazing Linklist Completed.\n");
	fprintf(fsuccess,"\nErazing Linklist Completed.\n");

}
void SapBomCreate(struct node *head,char *assy_noDup,char *AssemblyRevisionDup,char *SequenceRevisionDup,char *OrganizationIDDup)
{
	struct node *p=NULL;
	char sap_qty[18];
	char s[1024] = {0};
	char ReturnValue[2]={0};
	char ReturnMessage[1024] = {0};
//	FILE* fpDelFile = NULL;
//	char DelFileName[200]={0};
    int plantflg=0;


	char xException[256];
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;

	CAD_BICSK eIBomHeader;
	DRAW_LOEDK eIAutoPosnr;
	CAD_BICSK iEBomHeader;
	MESSAGE_MSGTX iEMessage;
	CAD_RETURN_MESSAGE_LEN iEMessageLen;
	CAD_RETURN_VALUE iEReturn;
	ITAB_H thBomItem = ITAB_NULL;
	CAD_BOM_ITEM *tBomItem;

	hRfc = BapiLogon();
	thBomItem = ITAB_NULL;
	if (thBomItem==ITAB_NULL)
	{
		thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
		if (thBomItem==ITAB_NULL)
				rfc_error("ItCreateBOM_ITEM");
	}
	else
	{
		if (ItFree(thBomItem) != 0)
			rfc_error("ItFreeBOM_ITEM");
	}

	printf("\nAssembly:[%s]",assy_noDup);
	printf("\nChange No:[%s]",dml_numAP1);
	printf("\nPlant:[%s]",plantcode);

	printf("\nAssembly:[%s,%s,%s]",assy_noDup,dml_numAP1,plantcode);

	fprintf(fsuccess,"\nAssembly:[%s,%s,%s]",assy_noDup,dml_numAP1,plantcode);


	SETCHAR(eIAutoPosnr,"");
	SETCHAR(eIBomHeader.Matnr,assy_noDup);
	SETCHAR(eIBomHeader.Werks,plantcode);
	SETCHAR(eIBomHeader.Stlan,"1");
	SETCHAR(eIBomHeader.Stlal,"01");
	SETCHAR(eIBomHeader.Aennr,dml_numAP1);
	SETCHAR(eIBomHeader.Datuv,"");
	SETCHAR(eIBomHeader.Stype,"");
	SETCHAR(eIBomHeader.Tcode,"");
	SETCHAR(eIBomHeader.Bmein,"");
	SETCHAR(eIBomHeader.Bmeng,"");
	SETCHAR(eIBomHeader.Cadkz,"");
	SETCHAR(eIBomHeader.Datub,"");
	SETCHAR(eIBomHeader.Emeng,"");
	SETCHAR(eIBomHeader.Equnr,"");
	SETCHAR(eIBomHeader.Exstl,"");
	SETCHAR(eIBomHeader.Labor,"");
	SETCHAR(eIBomHeader.Loekz,"");
	SETCHAR(eIBomHeader.Losbs,"");
	SETCHAR(eIBomHeader.Losvn,"");
	SETCHAR(eIBomHeader.Selal,"");
	SETCHAR(eIBomHeader.Serge,"");
	SETCHAR(eIBomHeader.Stktx,"");
	SETCHAR(eIBomHeader.Stlbe,"");
	SETCHAR(eIBomHeader.Stlst,"");
	SETCHAR(eIBomHeader.Vmtnr,"");
	SETCHAR(eIBomHeader.Ztext,"");
	SETCHAR(eIBomHeader.Revlv,"");
	SETCHAR(eIBomHeader.Tplnr,"");
	SETCHAR(eIBomHeader.Dokar,"");
	SETCHAR(eIBomHeader.Doknr,"");
	SETCHAR(eIBomHeader.Doktl,"");
	SETCHAR(eIBomHeader.Dokvr,"");
	SETCHAR(eIBomHeader.Vbeln,"");
	SETNUM(eIBomHeader.Vbpos,"000000");
	SETCHAR(eIBomHeader.Stobj,"");
	SETCHAR(eIBomHeader.Vdknr,"");
	SETCHAR(eIBomHeader.Vdkar,"");
	SETCHAR(eIBomHeader.Vdktl,"");
	SETCHAR(eIBomHeader.Vdkvr,"");
	SETCHAR(eIBomHeader.Veqnr,"");
	SETCHAR(eIBomHeader.Vtpnr,"");
	SETCHAR(eIBomHeader.Pspnr,"");
	SETCHAR(eIBomHeader.Oitxt,"");
	SETCHAR(eIBomHeader.MatnrLong,"");



	for(p = head; p != NULL; p = p -> next)
	{


		sprintf(sap_qty,"%7.3f", p->qty);
		printf("\n\t %s %-15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel);
		fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel);

		tBomItem = ItAppLine(thBomItem);
		if (tBomItem == NULL)
		printf("ItAppLineBOM_ITEM");

		SETCHAR(tBomItem->Idnrk,p->part);
		SETCHAR(tBomItem->Menge,sap_qty);
		SETCHAR(tBomItem->Postp,"L");
		SETCHAR(tBomItem->Posnr,p->sr_no);
//		if(nlsStrNCmp(assy_noDup,"G",1)==0)
		
		if(*assy_noDup=='G')
		{
			SETCHAR(tBomItem->Alpgr,"a1");
			SETNUM(tBomItem->Alprf,"1");
			//SETCHAR(tBomItem->Ewahr,"000");
            
            //plantflg=PlantChk(plantcode);
			if(tc_strcmp(p->sr_no,"0001")==0)
			{
				SETCHAR(tBomItem->Ewahr,"100");
			}
			else
			{
			   SETCHAR(tBomItem->Ewahr,"000");
			}

			SETCHAR(tBomItem->Alpst,"1");
		}
		else
		{
			SETCHAR(tBomItem->Alpgr,"");
			SETNUM(tBomItem->Alprf,"");
			SETCHAR(tBomItem->Ewahr,"");
			SETCHAR(tBomItem->Alpst,"");
		}
		SETCHAR(tBomItem->Verti,"");
		SETCHAR(tBomItem->Sanka,p->tempcsrel);
		SETCHAR(tBomItem->Sanfe,"");
		SETCHAR(tBomItem->Beikz,p->mat_prov_ind);
		SETCHAR(tBomItem->Selsb,"");
		SETCHAR(tBomItem->Schgt,"");
		SETCHAR(tBomItem->Meins,p->uq);
		SETCHAR(tBomItem->Potx1,"");
		SETCHAR(tBomItem->Dspst,"");
		SETCHAR(tBomItem->Lgort,"");
		SETCHAR(tBomItem->Sortf,"");
		SETCHAR(tBomItem->Potx2,"");
		SETCHAR(tBomItem->Upskz,"");
		SETCHAR(tBomItem->Auskz,"");
		SETCHAR(tBomItem->Alpos,"");
		SETCHAR(tBomItem->Ausch,"0.00");
		SETCHAR(tBomItem->Avoau,"0.00");
		SETCHAR(tBomItem->Cadpo,"");
		SETCHAR(tBomItem->Ekgrp,"");
		SETCHAR(tBomItem->Erskz,"");
		SETCHAR(tBomItem->Fmeng,"");
		SETCHAR(tBomItem->Lifnr,"");
		SETCHAR(tBomItem->Lifzt,"");
		SETCHAR(tBomItem->Matkl,"");
		SETCHAR(tBomItem->Netau,"");
		SETCHAR(tBomItem->Nfmat,"");
		SETCHAR(tBomItem->Nlfzt,"");
		SETCHAR(tBomItem->Peinh,"");
		SETCHAR(tBomItem->Preis,"");
		SETCHAR(tBomItem->Pswrk,"");
		SETCHAR(tBomItem->Rekrs,"");
		SETCHAR(tBomItem->Rform,"");
		SETCHAR(tBomItem->Roanz,"");
		SETCHAR(tBomItem->Roame,"");
		SETCHAR(tBomItem->Rokme,"");
		SETCHAR(tBomItem->Romei,"");
		SETCHAR(tBomItem->Romen,"");
		SETCHAR(tBomItem->Roms1,"");
		SETCHAR(tBomItem->Roms2,"");
		SETCHAR(tBomItem->Roms3,"");
		SETCHAR(tBomItem->Rvrel,"");
		SETCHAR(tBomItem->Sakto,"");
		SETCHAR(tBomItem->Sanin,"");
		SETCHAR(tBomItem->Sanko,"");
		SETCHAR(tBomItem->Sanvs,"");
		SETCHAR(tBomItem->Selal,"");
		SETCHAR(tBomItem->Selid,"");
		SETCHAR(tBomItem->Selpo,"");
		SETCHAR(tBomItem->Stkkz,"");
		SETCHAR(tBomItem->Stktx,"");
		SETCHAR(tBomItem->Stlal,"");
		SETCHAR(tBomItem->Stlkz,"");
		SETCHAR(tBomItem->Webaz,"");
		SETCHAR(tBomItem->Waers,"");
		SETCHAR(tBomItem->Dokar,"");
		SETCHAR(tBomItem->Doknr,"");
		SETCHAR(tBomItem->Dokvr,"");
		SETCHAR(tBomItem->Doktl,"");
		SETCHAR(tBomItem->Ekorg,"");
		SETCHAR(tBomItem->Class,"");
		SETCHAR(tBomItem->Klart,"");
		SETCHAR(tBomItem->Potpr,"");
		SETCHAR(tBomItem->Prvbe,"");
		SETCHAR(tBomItem->Nfeag,"");
		SETCHAR(tBomItem->Nfgrp,"");
		SETCHAR(tBomItem->Kzkup,"");
		SETCHAR(tBomItem->Intrm,"");
		SETCHAR(tBomItem->Kzclb,"");
		SETCHAR(tBomItem->Nlfzv,"");
		SETCHAR(tBomItem->Nlfmv,"");
		SETCHAR(tBomItem->Rfpnt,"");
		SETCHAR(tBomItem->MatnrLong,"");
	}

	RfcRc = cad_create_bom_with_sub_items(hRfc,&eIAutoPosnr,&eIBomHeader,&iEBomHeader,&iEMessage,&iEMessageLen,&iEReturn,thBomItem,xException);
	 switch (RfcRc)
	  {
	     case RFC_OK :
							/*for (crow = 1;crow <= ItFill(thBomItem); crow++)
							{
							    tBomItem = ItGetLine(thBomItem,crow);
							    if (tBomItem == NULL)
									printf("ItGetLineBOM_ITEM");
								strcpy(comp_sap,"");
							    strncpy(comp_sap,tBomItem->Idnrk,15);
							    printf("\nBomItem:%04d %15s",crow,comp_sap);
							    fprintf(fsuccess,"\nBomItem:%04d %15s",crow,comp_sap);
							}*/
							printf("\nMESSAGE FOR BOM %s CREATE:%s",assy_noDup,iEMessage);
							fprintf(fsuccess,"\nMSG RCVD:MESSAGE FOR BOM %s CREATE:%s",assy_noDup,iEMessage);
							GETCHAR(iEReturn,s);F_OUTK("iEReturn",00,20,s);
							GETCHAR(iEMessage,s);F_OUTK("iEMessage",00,20,s);
							strcpy(ReturnValue,"");
							printf("\nReturn Value [%s]\n",iEReturn);
							GETCHAR(iEReturn,ReturnValue);
							printf("\nReturn Value [%s]\n",ReturnValue);
							if(tc_strcmp(ReturnValue,"D")==0)
							{
								printf("Assy or comp Makred for ZI %s,%s\n",plantcode,assy_noDup);
								//fprintf(fpDelFile,"%s,%s,%s\n",dmlnost,plantcode,cAssemblyNo);
							}
							strcpy(ReturnMessage,"");
							GETCHAR(iEMessage,ReturnMessage);
							printf("\nReturn Message [%s]\n",ReturnMessage);
							if(tc_strlen(ReturnMessage)>0)
							if(tc_strstr(ReturnMessage,"BOM item due to material status ZI 'Inactive Material Block '"))
							{
								printf("Assy or comp Makred for ZI %s,%s\n",plantcode,assy_noDup);
								//fprintf(fpDelFile,"%s,%s,%s\n",dmlnost,plantcode,cAssemblyNo);
							}
							printf("\nMESSAGE FOR %s BOM change:%.60s\n",assy_noDup,ReturnMessage);
							fprintf(fsuccess,"\nMESSAGE FOR %s BOM change:%.60s\n",assy_noDup,ReturnMessage);
							break;
	     case RFC_EXCEPTION :
							printf("\nexception");
							fprintf(fsuccess,"\nexception");
							break;
	     case RFC_SYS_EXCEPTION :
							printf("\nsystem exception raised");
							fprintf(fsuccess,"\nsystem exception raised");
							break;
	     case RFC_FAILURE :
							printf("\nfailure");
							fprintf(fsuccess,"\nfailure");
							break;
	     default :
							printf("\nother failure");
							fprintf(fsuccess,"\nother failure");
							break;
	   }
	 if (ItDelete(thBomItem) != 0)
	   rfc_error("ItDelete BOM_ITEM");
	 RfcClose(hRfc);
	//fclose(fpDelFile);
}

void SapBomChange(struct node *head,char *assy_noDup,char *AssemblyRevisionDup,char *SequenceRevisionDup,char *OrganizationIDDup)
{
	struct node *p=NULL;
	char sap_qty[18];
	char s[1024];
	char xException[256];
	char ReturnMessage[1024] = {0};
	char ReturnValue[2]={0};

	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;
	CAD_BICSK eIBomHeader;
	//DRAW_LOEDK eIAutoPosnr;
	CAD_BICSK iEBomHeader;
	MESSAGE_MSGTX iEMessage;
	CAD_RETURN_MESSAGE_LEN iEMessageLen;
	CAD_RETURN_VALUE iEReturn;
	ITAB_H thBomItem = ITAB_NULL;
	CAD_BOM_ITEM *tBomItem;
	float sumUsgProb = 0.000f;
	char NCUsgFileName[200]={0};
	FILE* fpUsgProb = NULL;
	char strUP[11]={0};
	char todayDate[11]={0};

	getTodayDate(todayDate);
	//sprintf(NCUsgFileName,"%s/PLMSAP/UsgProbGrp_%s.txt",getenv("ONLREP"),todayDate);
	//sprintf(NCUsgFileName,"%s/PLMSAP/PLM_SAP_LOG/UsgProbGrp_%s_%s.txt",getenv("ONLREP"),plantcode,todayDate);

	sprintf(NCUsgFileName,"UsgProbGrp_%s_%s.txt",plantcode,todayDate);

	//sprintf(NCUsgFileName,"UsgProbGrp_%s_%s.txt",plantcode,todayDate);
	fpUsgProb = fopen(NCUsgFileName,"a");

	hRfc = BapiLogon();
	thBomItem = ITAB_NULL;
	if (thBomItem==ITAB_NULL)
	{
		thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
		if (thBomItem==ITAB_NULL)
				rfc_error("ItCreateBOM_ITEM");
	}
	else
	{
		if (ItFree(thBomItem) != 0)
			rfc_error("ItFreeBOM_ITEM");
	}

	printf("\nAssembly:[%s]",assy_noDup);
	printf("\nChange No:[%s]",dml_numAP1);
	printf("\nPlant:[%s]",plantcode);

	printf("\nAssembly:[%s,%s,%s]",assy_noDup,dml_numAP1,plantcode);

	fprintf(fsuccess,"\nAssembly:[%s,%s,%s]",assy_noDup,dml_numAP1,plantcode);

	SETCHAR(eIBomHeader.Matnr,assy_noDup);			/*assembly*/
	SETCHAR(eIBomHeader.Werks,plantcode);			/*Plant*/
	SETCHAR(eIBomHeader.Stlan,"1");					/*usage*/
	SETCHAR(eIBomHeader.Stlal,"01");				/*alternative*/
	SETCHAR(eIBomHeader.Aennr,dml_numAP1);			/*dml_numAP1 DMLNO with ST */
	SETCHAR(eIBomHeader.Datuv,"");					/*FROM date*/
	SETCHAR(eIBomHeader.Datub,"31.12.9999");		/*TO date*/
	SETCHAR(eIBomHeader.Stype,"");
	SETCHAR(eIBomHeader.Tcode,"");
	SETCHAR(eIBomHeader.Bmein,"");
	SETCHAR(eIBomHeader.Bmeng,"");
	SETCHAR(eIBomHeader.Cadkz,"");
	SETCHAR(eIBomHeader.Emeng,"");
	SETCHAR(eIBomHeader.Equnr,"");
	SETCHAR(eIBomHeader.Exstl,"");
	SETCHAR(eIBomHeader.Labor,"");
	SETCHAR(eIBomHeader.Loekz,"");
	SETCHAR(eIBomHeader.Losbs,"");
	SETCHAR(eIBomHeader.Losvn,"");
	SETCHAR(eIBomHeader.Selal,"");
	SETCHAR(eIBomHeader.Serge,"");
	SETCHAR(eIBomHeader.Stktx,"");
	SETCHAR(eIBomHeader.Stlbe,"");
	SETCHAR(eIBomHeader.Stlst,"");
	SETCHAR(eIBomHeader.Vmtnr,"");
	SETCHAR(eIBomHeader.Ztext,"");
	SETCHAR(eIBomHeader.Revlv,"");
	SETCHAR(eIBomHeader.Tplnr,"");
	SETCHAR(eIBomHeader.Dokar,"");
	SETCHAR(eIBomHeader.Doknr,"");
	SETCHAR(eIBomHeader.Doktl,"");
	SETCHAR(eIBomHeader.Dokvr,"");
	SETCHAR(eIBomHeader.Vbeln,"");
	SETNUM(eIBomHeader.Vbpos,"000000");
	SETCHAR(eIBomHeader.Stobj,"");
	SETCHAR(eIBomHeader.Vdknr,"");
	SETCHAR(eIBomHeader.Vdkar,"");
	SETCHAR(eIBomHeader.Vdktl,"");
	SETCHAR(eIBomHeader.Vdkvr,"");
	SETCHAR(eIBomHeader.Veqnr,"");
	SETCHAR(eIBomHeader.Vtpnr,"");
	SETCHAR(eIBomHeader.Pspnr,"");
	SETCHAR(eIBomHeader.Oitxt,"");
	SETCHAR(eIBomHeader.MatnrLong,"");

	sumUsgProb = 0.000f;

	for(p = head; p != NULL; p = p -> next)
	{
		sprintf(sap_qty,"%7.3f", p->qty);

		tBomItem = ItAppLine(thBomItem);
		if (tBomItem == NULL)
		printf("ItAppLineBOM_ITEM");

		SETCHAR(tBomItem->Idnrk,p->part);
		SETCHAR(tBomItem->Menge,sap_qty);
		SETCHAR(tBomItem->Postp,"L");
		SETCHAR(tBomItem->Posnr,p->sr_no);
		
		//if(tc_strncasecmp(assy_noDup,"G",1)==0)
		if(*assy_noDup=='G')
		{
			SETCHAR(tBomItem->Alpgr,"a1");
			SETNUM(tBomItem->Alprf,"1");
			SETCHAR(tBomItem->Alpst,"1");

			sprintf(strUP,"%7.3f", p->usgProb);
			if(tc_strcmp(strUP,"")!=0)
			{
				SETCHAR(tBomItem->Ewahr,strUP);		// Group's child Usage Probability Added on dated 26.09.2013
			}
			else
			{
				SETCHAR(tBomItem->Ewahr,"");
			}

			sumUsgProb = sumUsgProb + (p->usgProb);

			printf("\n\t%15s %4s 1 01 %12s %s %-15s %7.3f %3s %3s %3s a1 1  1 	%7.3f",assy_noDup,plantcode,dml_numAP1,p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel,p->usgProb);
			fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s  %7.3f",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel,p->usgProb);

		}
		else
		{
			printf("\n\t%15s %4s 1 01 %12s %s %-15s %7.3f %3s %3s %3s  %7.3f",assy_noDup,plantcode,dml_numAP1,p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel,p->usgProb);
			fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s  %7.3f",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel,p->usgProb);

			SETCHAR(tBomItem->Alpgr,"");
			SETNUM(tBomItem->Alprf,"");
			SETCHAR(tBomItem->Ewahr,"");
			SETCHAR(tBomItem->Alpst,"");
		}
		SETCHAR(tBomItem->Verti,"");
		SETCHAR(tBomItem->Beikz,p->mat_prov_ind);
		SETCHAR(tBomItem->Selsb,"");
		if (tc_strcmp(sap_qty,"99") != 0)
		{
			//strcpy(blk_ind,"");
			SETCHAR(tBomItem->Schgt,"");//blk_ind
		}
		else
		{
			//strcpy(blk_ind,"");
			strcpy(p->tempcsrel,"1");
			SETCHAR(tBomItem->Schgt,"");//blk_ind
		}
		SETCHAR(tBomItem->Sanka,p->tempcsrel);
		SETCHAR(tBomItem->Schgt,"");/*blk_ind*/
		SETCHAR(tBomItem->Meins,p->uq);
		SETCHAR(tBomItem->Potx1,"");	//bomtxt
		SETCHAR(tBomItem->Sanfe,"");
		SETCHAR(tBomItem->Dspst,"");
		SETCHAR(tBomItem->Upskz,"");
		SETCHAR(tBomItem->Auskz,"");
		SETCHAR(tBomItem->Alpos,"");
		SETCHAR(tBomItem->Ausch,"");
		SETCHAR(tBomItem->Avoau,"");
		SETCHAR(tBomItem->Cadpo,"");
		SETCHAR(tBomItem->Ekgrp,"");
		SETCHAR(tBomItem->Erskz,"");
		SETCHAR(tBomItem->Fmeng,"");
		SETCHAR(tBomItem->Lifnr,"");
		SETCHAR(tBomItem->Lifzt,"");
		SETCHAR(tBomItem->Matkl,"");
		SETCHAR(tBomItem->Netau,"");
		SETCHAR(tBomItem->Nfmat,"");
		SETCHAR(tBomItem->Nlfzt,"");
		SETCHAR(tBomItem->Peinh,"");
		SETCHAR(tBomItem->Preis,"");
		SETCHAR(tBomItem->Potx2,"");
		SETCHAR(tBomItem->Pswrk,"");
		SETCHAR(tBomItem->Rekrs,"");
		SETCHAR(tBomItem->Rform,"");
		SETCHAR(tBomItem->Roanz,"");
		SETCHAR(tBomItem->Roame,"");
		SETCHAR(tBomItem->Rokme,"");
		SETCHAR(tBomItem->Romei,"");
		SETCHAR(tBomItem->Romen,"");
		SETCHAR(tBomItem->Roms1,"");
		SETCHAR(tBomItem->Roms2,"");
		SETCHAR(tBomItem->Roms3,"");
		SETCHAR(tBomItem->Rvrel,"");
		SETCHAR(tBomItem->Sakto,"");
		SETCHAR(tBomItem->Sanin,"");
		SETCHAR(tBomItem->Sanko,"");
		SETCHAR(tBomItem->Sanvs,"");
		SETCHAR(tBomItem->Selal,"");
		SETCHAR(tBomItem->Selid,"");
		SETCHAR(tBomItem->Selpo,"");
		SETCHAR(tBomItem->Sortf,"");
		SETCHAR(tBomItem->Stkkz,"");
		SETCHAR(tBomItem->Stktx,"");
		SETCHAR(tBomItem->Stlal,"");
		SETCHAR(tBomItem->Stlkz,"");
		SETCHAR(tBomItem->Webaz,"");
		SETCHAR(tBomItem->Waers,"");
		SETCHAR(tBomItem->Dokar,"");
		SETCHAR(tBomItem->Doknr,"");
		SETCHAR(tBomItem->Dokvr,"");
		SETCHAR(tBomItem->Doktl,"");
		SETCHAR(tBomItem->Ekorg,"");
		SETCHAR(tBomItem->Lgort,"");
		SETCHAR(tBomItem->Class,"");
		SETCHAR(tBomItem->Klart,"");
		SETCHAR(tBomItem->Potpr,"");
		SETCHAR(tBomItem->Prvbe,"");
		SETCHAR(tBomItem->Nfeag,"");
		SETCHAR(tBomItem->Nfgrp,"");
		SETCHAR(tBomItem->Kzkup,"");
		SETCHAR(tBomItem->Intrm,"");
		SETCHAR(tBomItem->Kzclb,"");
		SETCHAR(tBomItem->Nlfzv,"");
		SETCHAR(tBomItem->Nlfmv,"");
		SETCHAR(tBomItem->Rfpnt,"");
		SETCHAR(tBomItem->MatnrLong,"");


	}

	//if(tc_strncasecmp(assy_noDup,"G",1)==0)
	if(*assy_noDup=='G')
	{
		printf("\n\nGroup:[%s %s %s] plantcode:[%s] And Usage Probability Sum is:[%7.3f]",assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,plantcode,sumUsgProb);fflush(stdout);
		fprintf(fsuccess,"\n\nGroup:[%s %s %s] plantcode:[%s] And Usage Probability Sum is:[%7.3f]",assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,plantcode,sumUsgProb);fflush(stdout);

        if (sumUsgProb <100)
		{
			printf("\nUsage Probability Sum [%7.3f] is less than 100 for G-part:[%s %s %s][%s] Project:[%s]\n",sumUsgProb,assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,plantcode,projectcode);fflush(stdout);
			fprintf(fsuccess,"\nUsage Probability Sum [%7.3f] is less than 100 for G-part:[%s %s %s][%s] Project:[%s]\n",sumUsgProb,assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,plantcode,projectcode);fflush(fsuccess);
			for(p = head; p != NULL; p = p -> next)
			{
				fprintf(fpUsgProb,"\n%s,%s,%s,%s,%7.3f,%s,%s,%s",assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,p->part,p->qty,plantcode,p->make_buy_indDup,strUP);fflush(fpUsgProb);
				printf("\nUsage Probability Details:%s,%s,%s,%s,%7.3f,%s,%s,%s",assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,p->part,p->qty,plantcode,p->make_buy_indDup,strUP);fflush(fpUsgProb);fflush(stdout);
			}
			fprintf(fpUsgProb,"\n");
			printf("\n");fflush(stdout);
		}
	}

	RfcRc = zcad_change_bom_with_sub_items(hRfc,&eIBomHeader,&iEReturn,&iEMessage,&iEMessageLen,&iEBomHeader,thBomItem,xException);
	switch (RfcRc)
	{
		case RFC_OK :
	 		/*for (crow = 1;crow <= ItFill(thBomItem); crow++)
			{
				tBomItem = ItGetLine(thBomItem,crow);
				if (tBomItem == NULL)
					rfc_error("ItGetLineBOM_ITEM");
				strncpy(comp_part_sap,tBomItem->Idnrk,15);
				printf("\n\t:%s",comp_part_sap);
				fprintf(fsuccess,"\n\t:%s",comp_part_sap);
			}*/
			strcpy(ReturnValue,"");
			printf("\nReturn Value [%s]\n",iEReturn);
			GETCHAR(iEReturn,ReturnValue);
			//nlsStrTrimTrailWhiteSpace(ReturnValue);
			//nlsStrTrimLeadWhiteSpace(ReturnValue);
			printf("\nReturn Value [%s]\n",ReturnValue);
			if(tc_strcmp(ReturnValue,"D")==0)
			{
				printf("Assy or comp Makred for ZI %s,%s\n",plantcode,assy_noDup);
				//fprintf(fpDelFile,"%s,%s,%s\n",dmlnost,plantcode,cAssemblyNo);
			}
			GETCHAR(iEMessage,ReturnMessage);
			//nlsStrTrimTrailWhiteSpace(ReturnMessage);
			//nlsStrTrimLeadWhiteSpace(ReturnMessage);
			printf("\nReturn Message [%s]\n",ReturnMessage);
			if(tc_strlen(ReturnMessage)>0)
			if(tc_strstr(ReturnMessage,"BOM item due to material status ZI 'Inactive Material Block '"))
			{
				printf("Assy or comp Makred for ZI %s,%s\n",plantcode,assy_noDup);
				//fprintf(fpDelFile,"%s,%s,%s\n",dmlnost,plantcode,cAssemblyNo);
			}
			printf("\nMessage for Bom Change:%s %s",assy_noDup,iEMessage);
			fprintf(fsuccess,"\nMessage for Bom Change:%s  %s ",assy_noDup,iEMessage);
			//NL;NL;
			//GETCHAR(iEReturn,s);F_OUTK("iEReturn",00,20,s);
			//GETCHAR(iEMessage,s);F_OUTK("iEMessage",00,20,s);

		break;

		case RFC_EXCEPTION :
			 printf("EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION :
			rfc_error("SYSTEM EXCEPTION RAISED");
		break;
		case RFC_FAILURE :
			rfc_error("failure");
		break;
		default :
			rfc_error("other failure");
		break;
	}
	if (ItDelete(thBomItem) != 0)
		rfc_error("ItDelete BOM_ITEM");
	RfcClose(hRfc);
	/*if(fpDelFile)
	fclose(fpDelFile);
	fpDelFile=NULL;*/

	if(fpUsgProb)
	fclose(fpUsgProb);
	fpUsgProb=NULL;

}
void display1(struct node *head,char *assy_noDup)
{
	struct node *p=NULL;
	//fprintf(fp,"\n%15s", assy_noDup);
	for(p = head; p != NULL; p = p -> next)
	{
		printf("\n\t %s %-15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel);
		fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel);
		//fprintf(fp,"\n%15s", p -> part);
	}

}

struct node* createnode(char sr_no[5],char *part,float* qty,char uq[4],char tempcsrel[2],char mat_prov_ind[2],char *make_buy_indDup)
{
	struct node* p = NULL;

	p = (struct node*)malloc(sizeof(struct node));

	p->part = part;
	strcpy(p->sr_no,sr_no);
	strcpy(p->uq,uq);
	strcpy(p->mat_prov_ind,mat_prov_ind);
	strcpy(p->tempcsrel,tempcsrel);
	p->make_buy_indDup=make_buy_indDup;
	p->qty = *qty;
	p->usgProb = 0.000f;
	p->next = NULL;
	return p;
}

int search(struct node* start,char *part,float* qty)
{
	struct node* p;
	int found = 1 ;

	p=start;
	/*while(p->next!=NULL)*/
	while(p!=NULL)
	{
			if(strcmp(p->part,part)==0)
			{
					//found;
					p->qty = p->qty + *qty;
					found = 0;
					break;
			}
			else
			{
				p=p->next;
				found = 1 ;
			}

		}
	return found;
}

char* subString(char* mainStringf, int fromCharf, int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

int findNextRelRev(tag_t CurRevTag)
{
	int status;
	tag_t	NextRelRev	= NULLTAG;
	tag_t	CurRevMas	= NULLTAG;
	tag_t	*allRevTag	= NULLTAG;
	char*	revNum	= NULL;
	char*	PrtRelStat	= NULL;
	char*	CurRevSeq	= NULL;
	char*	CurRev		= NULL;
	char*	nxtRevSeq	= NULL;
	char*	nxtRev		= NULL;

	int i = 0, revCnt = 0,nextOffFound = 0;

	printf("\n****Finding Next Official Revision****\n");fflush(stdout);
	ITK_CALL(AOM_UIF_ask_value(CurRevTag,"item_id",&revNum));
	printf("\nChecking Next Offcial Revision for : %s", revNum);fflush(stdout);

	ITK_CALL(ITEM_find_item(revNum, &CurRevMas));
	ITK_CALL(ITEM_list_all_revs(CurRevMas, &revCnt, &allRevTag));
	ITK_CALL(AOM_UIF_ask_value(CurRevTag,"item_revision_id",&CurRevSeq));
	CurRev = strtok(CurRevSeq,";");
	printf("\nTotal Revision Found : %d", revCnt);fflush(stdout);

	if(revCnt > 0)
	{
		for(i = revCnt-1; i >= 0 ; i--)
		{
			ITK_CALL(AOM_UIF_ask_value(allRevTag[i],"item_revision_id",&nxtRevSeq));
			nxtRev = strtok(nxtRevSeq,";");
			printf("\nCurrent Rev %s Latest Rev: %s",CurRev,nxtRev);fflush(stdout);

			if(tc_strcmp(CurRev,nxtRev)!=0)
			{
				ITK_CALL(AOM_UIF_ask_value(allRevTag[i],"release_status_list",&PrtRelStat));
				printf("\n%d Release Status : %s ",i,PrtRelStat);fflush(stdout);
				if(tc_strstr(PrtRelStat,"STDSIC Released")!=NULL)
				{

					NextRelRev = allRevTag[i];
					nextOffFound = 1;
					printf("\nNext Official Revision found...Current Rev %s Latest Rev: %s",CurRev,nxtRev);fflush(stdout);
					fprintf(fsuccess,"\nNext Official Revision found...Current Rev %s Latest Rev: %s",CurRev,nxtRev);fflush(stdout);
					break;
				}
			}
			else
			{
				printf("\nNext Official Revision not found...Current Rev %s Latest Rev: %s",CurRev,nxtRev);fflush(stdout);
				fprintf(fsuccess,"\nNext Official Revision not found...Current Rev %s Latest Rev: %s",CurRev,nxtRev);fflush(stdout);
				break;
			}
		}
	}

	return nextOffFound;
}

extern int ITK_user_main (int argc, char ** argv )
{
    int status;
	struct usgProbnode *pUP = NULLTAG;
	tag_t ChildOPtr		= NULLTAG;
	tag_t ChildOPtrCpy	= NULLTAG;
	tag_t PartOPtr		= NULLTAG;
	tag_t closure_tag	= NULLTAG;

	tag_t *partObjs		= NULLTAG;
	tag_t *closure_tags = NULLTAG;

	char *sUserName		= NULL;
	char *sPassword 	= NULL;
	char *AssyNo=NULL;
	char *sRevision=NULL;
	char *sSequence=NULL;
	char *mat_prov_ind=NULL;
	char *meas_unit=NULL;
	char *sr_no=NULL;
	char *tempcsrel=NULL;

	int ret;
	int i = 0;
	int n_closure_tags = 0;
	static int sr_no1 = 0;

	char *assy_no = NULL;
	char *assy_noDup = NULL;
	char *bl_mkbuy_string = NULL;
	char *RevisionRule = NULL;
	char *ClosureRule = NULL;
	char *make_buy_ind = NULL;
	char *make_buy_indDup = NULL;
	char *part_no = NULL;
	char *part_noDup = NULL;
	char *taskId = NULL;
	char *taskIdDup = NULL;
	char *unit = NULL;
	char *unitDup = NULL;

	char *owner = NULL;
	char *ownerDup = NULL;
	char *prjcode = NULL;
	char *prjcodeDup = NULL;
	char *prtType = NULL;
	char *prtTypeDup = NULL;
	char *qty = NULL;
	char *qtyDup = NULL;
	char *qty_req_info = NULL;
	char *qty_req_infoDup = NULL;
	char *relzstate = NULL;
	char *relzstateDup = NULL;
	struct node *start=NULL;
	struct node *p=NULL;
	struct node *q=NULL;
	float floatQty= 0.000;
	int mcSeriesRawPartflag = 1;
	char *iOrganizationID=NULL;
	char *StdDate=NULL;
	char *MonYear=NULL;
	char *inputDmlNumber=NULL;
	char *inputPlantCode=NULL;

	char *ChildPrtCls = NULL;
	//SetOfStrings dbScopeStr = NULL;
	int ic = 0 ;
	char *pMkeBuyIndicator = NULL;
	char *pMkeBuyIndicatorDup = NULL;
	char *AssemblyRevision = NULL;
	char *AssemblyRevisionDup = NULL;
	char *SequenceRevision = NULL;
	char *SequenceRevisionDup = NULL;
	char *OrganizationID = NULL;
	char *OrganizationIDDup = NULL;
	char *carcs = NULL;
	char *myDate = NULL;
	
	int n_entries;
	int resultCount = 0;
	int CntChildP = 0;
	int ChildItemTag = 0;
	int Item_ID=0,Item_UoM=0,Item_Owner=0;
	char *LatRevName		= NULL;
	char *POwnerName		= NULL;
	char *POwnerNameDup		= NULL;
	char *PartRelStatus		= NULL;
	char *ChildRelStatus	= NULL;
	char *InpRevSeq			= NULL;
	char *ChildRevName		= NULL;
	char *ChildOwnName		= NULL;
	char *ChildPartType		= NULL;
	char *ChildPrtQty		= NULL;
	char *ChildQtyDup		= NULL;
	char *ChildPrtUoM		= NULL;
	char *Plant_MakeBuy		= NULL;

	tag_t		queryTag			= NULLTAG;
	tag_t		LatestPRev			= NULLTAG;
	tag_t		window				= NULLTAG;
	tag_t		rule				= NULLTAG;
	tag_t		*outTag				= NULLTAG;
	tag_t		PerentLine			= NULLTAG;
	tag_t		*ChildPartLine		= NULLTAG;
	tag_t		ChildItemRevTag		= NULLTAG;
	tag_t		*RwPartItemMst		= NULLTAG;
	tag_t		RwPartMstTag		= NULLTAG;
	tag_t		RwPartRel			= NULLTAG;
	tag_t		RawPartRelTag		= NULLTAG;

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	meas_unit	=(char *) malloc(500 * sizeof(char));
	sr_no		=(char *) malloc(500 * sizeof(char));

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	sUserName		= ITK_ask_cli_argument("-u=");
	sPassword		= ITK_ask_cli_argument("-p=");
	AssyNo			= ITK_ask_cli_argument("-i=");
	sRevision		= ITK_ask_cli_argument("-r=");
	sSequence		= ITK_ask_cli_argument("-s=");
	plantcode		= ITK_ask_cli_argument("-t=");
	dml_numAP1		= ITK_ask_cli_argument("-d=");
	iSapServer		= ITK_ask_cli_argument("-c=");

	printf("\nInput Assay %s	Revision [%s] Sequence [%s]	plantcode [%s]	changeNo [%s] iSapServer [%s]\n", AssyNo,sRevision,sSequence,plantcode,dml_numAP1,iSapServer);

	tc_strdup(sRevision,&AssemblyRevisionDup);
	tc_strdup(sSequence,&SequenceRevisionDup);
	tc_strdup("ERC",&OrganizationIDDup);

	//sprintf(fsuccess_name,"TCUA_SAP_BOM_CrCh_%s.log",AssyNo);
	sprintf(fsuccess_name,"/user/plmsap/PLMSAP/ONE_TIME_LOG/TCUA_SAP_BOM_CrCh_%s.log",AssyNo);
	fsuccess = fopen(fsuccess_name,"a");
	if(fsuccess == NULL)
	printf("\nUnable To open Or Create Log  file");

	//char *qry_entries[1] = {"ID"};
	n_entries=2;
	char *qry_entries[2] = {"Item ID","Revision"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	InpRevSeq = NULL;
	InpRevSeq=(char *) MEM_alloc(50);
	strcpy(InpRevSeq,sRevision);
	strcat(InpRevSeq,"*");
	strcat(InpRevSeq,sSequence);

	qry_values[0] = AssyNo;
	qry_values[1] = InpRevSeq;

	//if(QRY_find("PartMatQ", &queryTag));
	if(QRY_find("Unique RevSeq", &queryTag));
	/*if(queryTag)
	{
		printf("\nFound Query PartMatQuery\n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query PartMatQuery\n");fflush(stdout);
	}*/
	
	//Executing query
	if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));

	printf("\nresultCount :%d:\n",resultCount);fflush(stdout);

	if(resultCount>0)
	{
		printf("\nPart Found : %s Query Executed Succesfully",AssyNo);fflush(stdout);
		PartOPtr=partObjs[0];
	}
	else
	{ 
		printf("Part Not %s found in TCUA",AssyNo); 
		goto CLEANUP;
	}

	if (tc_strcmp(plantcode,"1100")==0)
	{
		tc_strdup("t5_CarMakeBuyIndicator",&Plant_MakeBuy);
		tc_strdup("bl_Design Revision_t5_CarMakeBuyIndicator",&bl_mkbuy_string);
		tc_strdup("STDC Released and Above",&RevisionRule);
		tc_strdup("BOMViewClosureRuleSTDC",&ClosureRule);
	}

	//ITK_CALL(ITEM_ask_latest_rev(PartOPtr,&LatestPRev));	
	ITK_CALL(AOM_UIF_ask_value(PartOPtr,"object_string",&LatRevName));
	ITK_CALL(AOM_UIF_ask_value(PartOPtr,"owning_user",&POwnerName));
	tc_strdup(POwnerName,&POwnerNameDup);
	ITK_CALL(AOM_UIF_ask_value(PartOPtr,"release_status_list",&PartRelStatus));
	ITK_CALL(AOM_ask_value_string(PartOPtr,"t5_PartType",&prtType));
	ITK_CALL(AOM_UIF_ask_value(PartOPtr,"item_id",&assy_no));
	tc_strdup(prtType,&prtTypeDup);
	tc_strdup(assy_no,&assy_noDup);

	printf("\nPartName: %s	POwnerName: %s",LatRevName,POwnerName);fflush(stdout);
	printf("\nPart Number: %s	Part Type: %s",assy_no,prtType);fflush(stdout);
	
	if(	tc_strcmp(prtTypeDup,"D")==0 ||
		tc_strcmp(prtTypeDup,"DA")==0 ||
		tc_strcmp(prtTypeDup,"DC")==0 ||
		tc_strcmp(prtTypeDup,"IFD")==0 ||
		tc_strcmp(prtTypeDup,"IM")==0 ||
		tc_strcmp(prtTypeDup,"CP")==0
	)
	{
		printf("\nDesign Revision [%s] has Type [%s] Exiting...\n",assy_no,prtType);
		fprintf(fsuccess,"\nDesign Revision [%s] has Type [%s] Exiting...\n",assy_no,prtType);
		goto CLEANUP;
	}

	if(tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)
	{
		printf("\nPartName: %s	ReleaseStatus: %s",assy_no,PartRelStatus);fflush(stdout);
		fprintf(fsuccess,"\nPartName: %s	ReleaseStatus: %s",assy_no,PartRelStatus);fflush(stdout);
	}
	else
	{
		printf("\nPart %s PartRelStatus: %s Part not STDSIC Released...\n",assy_no,PartRelStatus);
		fprintf(fsuccess,"\nPart %s PartRelStatus: %s Part not STDSIC Released...\n",assy_no,PartRelStatus);
		goto CLEANUP;
	}

	if (findNextRelRev(PartOPtr)==1)
	{
		printf("\nNext Official Revision Found for Part %s ...Skipping Bom Transfer\n",LatRevName);
		fprintf(fsuccess,"\nNext Official Revision Found for Part %s ...Skipping Bom Transfer\n",LatRevName);
		//goto CLEANUP;
	}

	if(tc_strcmp(prtTypeDup,"M") == 0 ||
		tc_strcmp(prtTypeDup,"V") == 0 ||
		tc_strcmp(prtTypeDup,"VC") == 0 ||
		tc_strcmp(prtTypeDup,"T") == 0 ||
		tc_strcmp(prtTypeDup,"SA") == 0 ||
		tc_strcmp(prtTypeDup,"SP") == 0 ||
		tc_strcmp(prtTypeDup,"A") == 0 ||
		tc_strcmp(prtTypeDup,"G") == 0 ||
		tc_strcmp(prtTypeDup,"R") == 0 ||
		tc_strcmp(prtTypeDup,"C") == 0)
	{
		printf("\nExpanding %s BOM...",assy_no);
		fprintf(fsuccess,"\nExpanding %s BOM...",assy_no);

		BOM_create_window (&window);
		CFM_find(RevisionRule,&rule );
		printf("\nSetting RevisionRule : %s",RevisionRule);
		fprintf(fsuccess,"\nSetting RevisionRule : %s",RevisionRule);
		BOM_set_window_config_rule( window, rule );	
		//Setting Closure Rule Start
		printf("\nSetting ClosureRule : %s",ClosureRule);
		fprintf(fsuccess,"\nSetting ClosureRule : %s",ClosureRule);
		ITK_CALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &n_closure_tags, &closure_tags ));
		printf("\nn_closure_tags found %d",n_closure_tags);fflush(stdout);
		if(n_closure_tags > 0)
		{
			closure_tag=closure_tags[0];
			ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
		}
		else
		{
			goto CLEANUP;
		}
		//Setting Closure Rule End
		BOM_set_window_pack_all (window, true);
		BOM_set_window_top_line (window, null_tag, PartOPtr, null_tag, &PerentLine);
		BOM_line_ask_child_lines(PerentLine, &CntChildP, &ChildPartLine);

		if (tc_strcmp(prtTypeDup,"R")==0|| tc_strcmp(prtTypeDup,"SP")==0)
		{
			ITK_CALL(GRM_find_relation_type("T5_RPtRel",&RwPartRel));
			ITK_CALL(AOM_ask_value_tags(PartOPtr,"T5_RPtRel",&CntChildP,&RwPartItemMst));
			printf("\nChild Raw Part Count : %d",CntChildP);fflush(stdout);
			fprintf(fsuccess,"\nChild Raw Part Count : %d",CntChildP);fflush(stdout);
		}

		if(CntChildP>0)
		{
			//Child part loop
			for(i=0;i<CntChildP;i++)
			{
				if (tc_strcmp(prtTypeDup,"R")==0 || tc_strcmp(prtTypeDup,"SP")==0)
				{
					RwPartMstTag=RwPartItemMst[i];
					ITK_CALL(ITEM_ask_latest_rev(RwPartMstTag,&ChildOPtr));
					
					ITK_CALL(AOM_ask_value_string(ChildOPtr,"item_id",&ChildRevName));
					ITK_CALL(AOM_ask_value_string(ChildOPtr,"t5_uom",&ChildPrtUoM));
					ITK_CALL(AOM_ask_value_string(ChildOPtr,"t5_PartType",&ChildPartType));
					ITK_CALL(AOM_UIF_ask_value(ChildOPtr,"release_status_list",&ChildRelStatus));
					ITK_CALL(AOM_ask_value_string(ChildOPtr,Plant_MakeBuy,&make_buy_ind));

					ITK_CALL(GRM_find_relation(PartOPtr,RwPartMstTag,RwPartRel,&RawPartRelTag));
					ITK_CALL(AOM_UIF_ask_value(RawPartRelTag,"t5_UsageRT",&ChildPrtQty));
					tc_strdup(ChildPrtQty,&ChildQtyDup);
					printf("\nChild Raw Part :%s,%s,%s,%s",ChildRevName,ChildPrtUoM,ChildPartType,ChildPrtQty);
					fprintf(fsuccess,"\nChild Raw Part :%s,%s,%s,%s",ChildRevName,ChildPrtUoM,ChildPartType,ChildPrtQty);
				}
				else
				{
					ChildOPtr=ChildPartLine[i];

					BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID);
					BOM_line_ask_attribute_string(ChildOPtr, Item_ID, &ChildRevName);
					
					BOM_line_look_up_attribute ("bl_Design_t5_uom",&Item_UoM);
					BOM_line_ask_attribute_string(ChildOPtr,Item_UoM,&ChildPrtUoM);

					BOM_line_look_up_attribute ("awb0RevisionOwningUser",&Item_Owner);
					BOM_line_ask_attribute_string(ChildOPtr,Item_Owner,&ChildOwnName);

					AOM_ask_value_string(ChildOPtr,"bl_quantity",&ChildPrtQty);
					tc_strdup(ChildPrtQty,&ChildQtyDup);

					AOM_ask_value_string(ChildOPtr,"bl_occ_t5_Qri",&qty_req_info);
					tc_strdup(qty_req_info,&qty_req_infoDup);

					AOM_ask_value_string(ChildOPtr,"bl_Design Revision_t5_PartType",&ChildPartType);
					
					AOM_ask_value_string(ChildOPtr,bl_mkbuy_string,&make_buy_ind);
					tc_strdup(make_buy_ind,&make_buy_indDup);

					ITK_CALL(AOM_UIF_ask_value(ChildOPtr,"bl_rev_release_status_list",&ChildRelStatus));
				}
				printf("\nChild Part Number [%s] Part Qty [%s]	UoM [%s]	Owner [%s]",ChildRevName,ChildPrtQty,ChildPrtUoM,ChildOwnName);
				
				if (
					tc_strcmp(ChildPartType,"D")==0 ||
					tc_strcmp(ChildPartType,"DA")==0 ||
					tc_strcmp(ChildPartType,"DC")==0 ||
					tc_strcmp(ChildPartType,"IFD")==0 ||
					tc_strcmp(ChildPartType,"IM")==0 ||
					tc_strcmp(ChildPartType,"CP")==0
					)
				{
					printf("\nSkipping Child Part [%s] as Part Type [%s]",ChildRevName,ChildPartType);
					fprintf(fsuccess,"\nSkipping Child Part [%s] as Part Type [%s]",ChildRevName,ChildPartType);
					continue;
				}

				if(tc_strstr(ChildRelStatus,"STDSIC Released")==NULL)
				{
					printf("\nChild Part %s ChildRelStatus: %s Part not STDSIC Released...Skipping\n",ChildRevName,ChildRelStatus);
					fprintf(fsuccess,"\nChild Part %s ChildRelStatus: %s Part not STDSIC Released...Skipping\n",ChildRevName,ChildRelStatus);
					continue;
				}

				if(tc_strlen(make_buy_ind)==0 || tc_strcmp(make_buy_ind,"NA")==0)
				{
					printf("\nSkipping Child Part [%s] as Plant Make/Buy is NULL or NA",ChildRevName);
					fprintf(fsuccess,"\nSkipping Child Part [%s] as Plant Make/Buy is NULL or NA",ChildRevName);
					continue;
				}

				if(tc_strcmp(ChildPrtQty, "") == 0 || tc_strcmp(ChildPrtQty,"0") == 0 || tc_strcmp(ChildPrtQty,"0.00000") == 0)
				{
					printf("\nChild Part Number [%s] Part Qty [%s] hence skipping",ChildRevName,ChildPrtQty);
					fprintf(fsuccess,"\nChild Part Number [%s] Part Qty [%s] hence skipping",ChildRevName,ChildPrtQty);
					continue;
				}

				if(tc_strstr(ChildRevName,"_") !=NULL)
				{
					printf("\nChild Part Number [%s] Skipping Dummy/Underscore Part",ChildRevName,ChildPrtQty);
					fprintf(fsuccess,"\nChild Part Number [%s] Skipping Dummy/Underscore Part",ChildRevName,ChildPrtQty);
					continue;
				}

				if(tc_strlen(ChildPrtUoM)>0)
				{
					tc_strdup(ChildPrtUoM,&unitDup);
					if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
						else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
						else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
						else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
						else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
						else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
						else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
						else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
						else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
						else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
						else
						{
							tc_strdup("EA",&unitDup);
							tc_strcpy(meas_unit,"EA");
						}
				}
				else tc_strcpy(meas_unit,"EA");
					
					//printf("\nunitDup [%s] meas_unit [%s]",unitDup,meas_unit);
					fprintf(fsuccess,"\nunitDup [%s] meas_unit [%s]",unitDup,meas_unit);

				//Quantity Conversion Logic Start
				if(tc_strlen(ChildPrtQty)<=0)
				{
					tc_strdup("999999",&ChildQtyDup);
					printf("\nConverting Part %s as quantity is %s Null quantity hence exiting",ChildRevName,ChildQtyDup);fflush(stdout);
					fprintf(fsuccess,"\nConverting  this Part %s as quantity %s Null quantity hence exiting",ChildRevName,ChildQtyDup);fflush(stdout);
					continue;
				}

				if(tc_strcmp(ChildPrtQty,"99")==0)
				{
					tc_strdup("999999",&ChildQtyDup);
					printf("\nConverting Part %s as quantity is %s ",ChildRevName,ChildQtyDup);fflush(stdout);
					fprintf(fsuccess,"\n Converting  this Part %s as quantity %s",ChildRevName,ChildQtyDup);fflush(stdout);

				}
				if(tc_strcmp(ChildPrtQty,"97")==0)
				{
					tc_strdup("0",&ChildQtyDup);
					printf("\nConverting Part %s as 97-quantity is %s ",ChildRevName,ChildQtyDup); fflush(stdout);
					fprintf(fsuccess,"\nConverting  this Part %s as 97-quantity %s",ChildRevName,ChildQtyDup); fflush(stdout);
				}


				if((tc_strcmp(ChildPrtQty,"0")==0 || tc_strcmp(ChildPrtQty,"0.00000") == 0) && ((tc_strcmp(qty_req_infoDup,"NA")==0) || (tc_strcmp(qty_req_infoDup,"+")==0)))
				{
					printf("\nSkipping this Part %s as quantity is %s and Quantity Required information  is %s",ChildRevName,ChildPrtQty,qty_req_infoDup);fflush(stdout);
					fprintf(fsuccess,"\nSkipping this Part %s as quantity is %s and Quantity Required information  is %s",ChildRevName,ChildPrtQty,qty_req_infoDup);fflush(stdout);
					continue;
				}
				
				if((tc_strcmp(ChildPrtQty,"1")==0) && (tc_strcmp(qty_req_infoDup,"+")==0))
				{
					printf("\nSkipping this Part %s as quantity is %s and Quantity Required information  is %s",ChildRevName,ChildPrtQty,qty_req_infoDup);fflush(stdout);
					fprintf(fsuccess,"\nSkipping this Part %s as quantity is %s and Quantity Required information  is %s",ChildRevName,ChildPrtQty,qty_req_infoDup);fflush(stdout);
					continue;
				}
				
				if((tc_strcmp(ChildPrtQty,"0")==0 || tc_strcmp(ChildPrtQty,"0.00000") == 0) && (tc_strcmp(qty_req_infoDup,"AR")==0))
				{
					tc_strdup("1",&ChildQtyDup);
					printf("\nquantity after AR logic %s,%s",ChildRevName,ChildPrtQty);fflush(stdout);
					fprintf(fsuccess,"\nquantity after AR logic %s,%s",ChildRevName,ChildPrtQty);fflush(stdout);
				}
				
				if(tc_strcmp(ChildPrtQty,"999999")==0)
				{
					if((tc_strcmp(meas_unit,"KG")==0) || (tc_strcmp(meas_unit,"L")==0) || (tc_strcmp(meas_unit,"M")==0) || (tc_strcmp(meas_unit,"M2")==0) || (tc_strcmp(meas_unit,"M3")==0))
					{
						tc_strdup("0.001",&ChildQtyDup);
					}
					else
					{
						tc_strdup("1",&ChildQtyDup);
					}
					printf("\nQuantity for 99 QTY:::[%s],[%s]",ChildPrtQty,meas_unit);fflush(stdout);
					fprintf(fsuccess,"\nQuantity for 99 QTY:::[%s],[%s]",ChildPrtQty,meas_unit);fflush(stdout);
				}

				if((tc_strcmp(ChildPrtQty,"1")==0) && (tc_strcmp(qty_req_infoDup,"AR")==0))
				{
					if((tc_strcmp(meas_unit,"KG")==0) || (tc_strcmp(meas_unit,"L")==0) || (tc_strcmp(meas_unit,"M")==0) || (tc_strcmp(meas_unit,"M2")==0) || (tc_strcmp(meas_unit,"M3")==0))
					{
						tc_strdup("0.001",&ChildQtyDup);
					}
					else
					{
						tc_strdup("1",&ChildQtyDup);
					}
					printf("\nQuantity for [1-AR] QTY:::[%s],[%s]",ChildPrtQty,meas_unit);fflush(stdout);
					fprintf(fsuccess,"\nQuantity for [1-AR] QTY:::[%s],[%s]",ChildPrtQty,meas_unit);fflush(stdout);
				}
				//Quantity Conversion Logic End

					if(tc_strlen(make_buy_ind)>0)
					{
						tc_strdup(make_buy_ind,&make_buy_indDup);

						if(tc_strcmp(make_buy_indDup,"F18") == 0)
						{
							tc_strdup("L",&mat_prov_ind);
							tc_strdup("1",&tempcsrel);
						}
						else
						{
							tc_strdup("",&mat_prov_ind);
							tc_strdup("X",&tempcsrel);
						}
					}


					tc_strdup(ChildRevName,&part_noDup);
					floatQty = atof(ChildQtyDup);

					printf("\nFinal Node String [%s][%7.3f][%s][%s][%s][%s]",part_noDup,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);
					fprintf(fsuccess,"\nFinal Node String [%s][%7.3f][%s][%s][%s][%s]",part_noDup,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);

					if(p==NULL)
					{
						sr_no1 = 1 ;
						sprintf(sr_no,"%04d",sr_no1);
						p = createnode(sr_no,part_noDup,&floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);
						start = p;
					}
					else
					{
						ret = search(start,part_noDup,&floatQty);
						if(ret==1)
						{
							 q=start;
							 while(q->next!=NULL)
							 {
								 q=q->next;
							 }
							sr_no1 = sr_no1 + 1 ;
							sprintf(sr_no,"%04d",sr_no1);
							q->next=createnode(sr_no,part_noDup,&floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);
						}
					}
			}//For Loop Child Part


			if(sr_no1 < 1)
			{
				printf("\nDo not have structure in PLM %s",assy_noDup);
				fprintf(fsuccess,"\nDo not have structure in PLM %s",assy_noDup);
				goto CLEANUP;
			}
			else
			{
				/*Current_date_time = nlsStrAlloc(20);
				strcpy(Current_date_time,"");
				getTodayDateCal(Current_date_time);
				printf("\nTimeCalcMidCr:[%s] for Assy:[%s]",Current_date_time,AssyNo);
				fprintf(fsuccess,"\nTimeCalcMidCr:[%s] for Assy:[%s]",Current_date_time,AssyNo);*/
				SapBomCreate(start,assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,OrganizationIDDup);

				/*Current_date_time = nlsStrAlloc(20);
				strcpy(Current_date_time,"");
				getTodayDateCal(Current_date_time);
				printf("\nTimeCalcMidCh:[%s] for Assy:[%s]",Current_date_time,AssyNo);
				fprintf(fsuccess,"\nTimeCalcMidCh:[%s] for Assy:[%s]",Current_date_time,AssyNo);*/

				if(*assy_no=='G')
				{
					printf("\nMain::Part %s is G-part, hence going to check Usage Probability..", assy_noDup);
					fprintf(fsuccess,"\nMain::Part %s is G-part, hence going to check Usage Probability..", assy_noDup);

					pUP = GetUsageProb(assy_no);
					compareUsage(pUP,start);
					my_free2(pUP);
				}

				SapBomChange(start,assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,OrganizationIDDup);
				//display1(start,assy_noDup);
				my_free(start);

				/*Current_date_time = nlsStrAlloc(20);
				strcpy(Current_date_time,"");
				getTodayDateCal(Current_date_time);
				printf("\nTimeCalcEnd:[%s] for Assy:[%s]",Current_date_time,AssyNo);
				fprintf(fsuccess,"\nTimeCalcEnd:[%s] for Assy:[%s]",Current_date_time,AssyNo);*/

				goto CLEANUP;

			}
		}
		else
		{
			 printf("\nNO BOM found for %s Module in PLM",assy_noDup);
			 fprintf(fsuccess,"\nNO BOM found for %s Module in PLM",assy_noDup);
			 goto CLEANUP;
		}

	}//If Module
	{
		printf("\nDesign Revision [%s] has PartType [%s] Exiting...\n",assy_no,prtType);
		goto CLEANUP;
	}

	CLEANUP:
		printf("\nCLEANUP..."); fflush(stdout);
		ITK_CALL(POM_logout(false));
		return status;

	EXIT:
		printf("\nExiting...\n");
		ITK_CALL(POM_logout(false));
		return status;
}


RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;

	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

/*
void ChangeNoCreate(void)
{

	static RFC_RC RfcRc;


	hRfc = BapiLogon();
	if (hRfc == 0)
		printf("\nRFC connection is not present.");
	else
	{
		RfcRc = cll_ccap_ecn_create(hRfc);
	}

}*/



/*RFC_RC cll_ccap_ecn_create(RFC_HANDLE hRfc)*/
/*void ChangeNoCreate(void)
{
		static RFC_HANDLE hRfc;
		static RFC_RC RfcRc;

		int noOfParts;
		string	partNoS			= NULLTAG;
		string	partNoDupS		= NULLTAG;
		status	dstat			= OKAY;


		AENR_API01 eChangeHeader;
		CSDATA_XFELD eFlAle;
		CSDATA_XFELD eFlCommitAndWait;
		CSDATA_XFELD eFlNoCommitWork;
		AENV_API01 eObjectBom;
		AENV_API01 eObjectBomCus;
		AENV_API01 eObjectBomDoc;
		AENV_API01 eObjectBomEqui;
		AENV_API01 eObjectBomLoc;
		AENV_API01 eObjectBomMat;
		AENV_API01 eObjectBomPsp;
		AENV_API01 eObjectBomStd;
		AENV_API01 eObjectChar;
		AENV_API01 eObjectCls;
		AENV_API01 eObjectClsMaint;
		AENV_API01 eObjectConfProf;
		AENV_API01 eObjectDep;
		AENV_API01 eObjectDoc;
		AENV_API01 eObjectHazmat;
		AENV_API01 eObjectMat;
		AENV_API01 eObjectPhrase;
		AENV_API01 eObjectPvs;
		AENV_API01 eObjectPvsAlt;
		AENV_API01 eObjectPvsRel;
		AENV_API01 eObjectPvsVar;
		AENV_API01 eObjectSubstance;
		AENV_API01 eObjectTlist;
		AENV_API01 eObjectTlist2;
		AENV_API01 eObjectTlistA;
		AENV_API01 eObjectTlistE;
		AENV_API01 eObjectTlistM;
		AENV_API01 eObjectTlistN;
		AENV_API01 eObjectTlistQ;
		AENV_API01 eObjectTlistR;
		AENV_API01 eObjectTlistS;
		AENV_API01 eObjectTlistT;
		AENV_API01 eObjectValidMatvers;
		AENV_API01 eObjectVarTab;
		AEEF_API01 eValueAssign;
		AENRB_AENNR iChangeNo;
		ITAB_H thAltDates = ITAB_NULLTAG;
		ITAB_H thEffectivity = ITAB_NULLTAG;
		ITAB_H thObjmgrec = ITAB_NULLTAG;
		ITAB_H thTextheader = ITAB_NULLTAG;
		ITAB_H thTextlines = ITAB_NULLTAG;
		char xException[256];
		AEOI_API01 *tObjmgrec;

		hRfc = BapiLogon();
		printf("change no create");
		printf("\nChangeno create[%s,%s,%s]",dml_numAP1,apl_release_date,DMLDescription);
		SETCHAR(eChangeHeader.ChangeNo,dml_numAP1);//dml_no
		SETNUM(eChangeHeader.Status,"01");
		SETCHAR(eChangeHeader.AuthGroup,"");
		SETCHAR(eChangeHeader.ValidFrom,apl_release_date);//rlz_date
		SETCHAR(eChangeHeader.Descript,DMLDescription);//tempstr
		SETCHAR(eChangeHeader.ReasonChg,"");
		SETCHAR(eChangeHeader.DeletionMark,"");
		SETCHAR(eChangeHeader.IndateRule,"");
		SETCHAR(eChangeHeader.OutdateRule,"");
		SETCHAR(eChangeHeader.Function,"");
		SETCHAR(eChangeHeader.ChangeLeader,"");
		SETCHAR(eChangeHeader.EffectivityType,"");
		SETCHAR(eChangeHeader.OverridingMark,"");
		SETNUM(eChangeHeader.Rank,"");
		SETNUM(eChangeHeader.ReleaseKey,"");
		SETCHAR(eChangeHeader.StatusProfile,"");
		SETCHAR(eChangeHeader.TechRel,"");
		SETCHAR(eChangeHeader.BasicChange,"");
		SETCHAR(eFlAle,"");
		SETCHAR(eFlCommitAndWait,"X");
		SETCHAR(eFlNoCommitWork,"");
		SETCHAR(eObjectBom.Active,"");
		SETCHAR(eObjectBom.Locked,"");
		SETCHAR(eObjectBom.ObjRequ,"");
		SETCHAR(eObjectBom.MgtrecGen,"");
		SETCHAR(eObjectBom.GenNew,"");
		SETCHAR(eObjectBom.GenDialog,"");
		SETCHAR(eObjectBomCus.Active,"");
		SETCHAR(eObjectBomCus.Locked,"");
		SETCHAR(eObjectBomCus.ObjRequ,"");
		SETCHAR(eObjectBomCus.MgtrecGen,"");
		SETCHAR(eObjectBomCus.GenNew,"");
		SETCHAR(eObjectBomCus.GenDialog,"");
		SETCHAR(eObjectBomDoc.Active,"");
		SETCHAR(eObjectBomDoc.Locked,"");
		SETCHAR(eObjectBomDoc.ObjRequ,"");
		SETCHAR(eObjectBomDoc.MgtrecGen,"");
		SETCHAR(eObjectBomDoc.GenNew,"");
		SETCHAR(eObjectBomDoc.GenDialog,"");
		SETCHAR(eObjectBomEqui.Active,"");
		SETCHAR(eObjectBomEqui.Locked,"");
		SETCHAR(eObjectBomEqui.ObjRequ,"");
		SETCHAR(eObjectBomEqui.MgtrecGen,"");
		SETCHAR(eObjectBomEqui.GenNew,"");
		SETCHAR(eObjectBomEqui.GenDialog,"");
		SETCHAR(eObjectBomLoc.Active,"");
		SETCHAR(eObjectBomLoc.Locked,"");
		SETCHAR(eObjectBomLoc.ObjRequ,"");
		SETCHAR(eObjectBomLoc.MgtrecGen,"");
		SETCHAR(eObjectBomLoc.GenNew,"");
		SETCHAR(eObjectBomLoc.GenDialog,"");
		SETCHAR(eObjectBomMat.Active,"X");
		SETCHAR(eObjectBomMat.Locked,"");
		SETCHAR(eObjectBomMat.ObjRequ,"X");
		SETCHAR(eObjectBomMat.MgtrecGen,"X");
		SETCHAR(eObjectBomMat.GenNew,"");
		SETCHAR(eObjectBomMat.GenDialog,"");
		SETCHAR(eObjectBomPsp.Active,"");
		SETCHAR(eObjectBomPsp.Locked,"");
		SETCHAR(eObjectBomPsp.ObjRequ,"");
		SETCHAR(eObjectBomPsp.MgtrecGen,"");
		SETCHAR(eObjectBomPsp.GenNew,"");
		SETCHAR(eObjectBomPsp.GenDialog,"");
		SETCHAR(eObjectBomStd.Active,"");
		SETCHAR(eObjectBomStd.Locked,"");
		SETCHAR(eObjectBomStd.ObjRequ,"");
		SETCHAR(eObjectBomStd.MgtrecGen,"");
		SETCHAR(eObjectBomStd.GenNew,"");
		SETCHAR(eObjectBomStd.GenDialog,"");
		SETCHAR(eObjectChar.Active,"");
		SETCHAR(eObjectChar.Locked,"");
		SETCHAR(eObjectChar.ObjRequ,"");
		SETCHAR(eObjectChar.MgtrecGen,"");
		SETCHAR(eObjectChar.GenNew,"");
		SETCHAR(eObjectChar.GenDialog,"");
		SETCHAR(eObjectCls.Active,"");
		SETCHAR(eObjectCls.Locked,"");
		SETCHAR(eObjectCls.ObjRequ,"");
		SETCHAR(eObjectCls.MgtrecGen,"");
		SETCHAR(eObjectCls.GenNew,"");
		SETCHAR(eObjectCls.GenDialog,"");
		SETCHAR(eObjectClsMaint.Active,"");
		SETCHAR(eObjectClsMaint.Locked,"");
		SETCHAR(eObjectClsMaint.ObjRequ,"");
		SETCHAR(eObjectClsMaint.MgtrecGen,"");
		SETCHAR(eObjectClsMaint.GenNew,"");
		SETCHAR(eObjectClsMaint.GenDialog,"");
		SETCHAR(eObjectConfProf.Active,"");
		SETCHAR(eObjectConfProf.Locked,"");
		SETCHAR(eObjectConfProf.ObjRequ,"");
		SETCHAR(eObjectConfProf.MgtrecGen,"");
		SETCHAR(eObjectConfProf.GenNew,"");
		SETCHAR(eObjectConfProf.GenDialog,"");
		SETCHAR(eObjectDep.Active,"");
		SETCHAR(eObjectDep.Locked,"");
		SETCHAR(eObjectDep.ObjRequ,"");
		SETCHAR(eObjectDep.MgtrecGen,"");
		SETCHAR(eObjectDep.GenNew,"");
		SETCHAR(eObjectDep.GenDialog,"");
		SETCHAR(eObjectDoc.Active,"X");
		SETCHAR(eObjectDoc.Locked,"");
		SETCHAR(eObjectDoc.ObjRequ,"X");
		SETCHAR(eObjectDoc.MgtrecGen,"X");
		SETCHAR(eObjectDoc.GenNew,"");
		SETCHAR(eObjectDoc.GenDialog,"");
		SETCHAR(eObjectHazmat.Active,"");
		SETCHAR(eObjectHazmat.Locked,"");
		SETCHAR(eObjectHazmat.ObjRequ,"");
		SETCHAR(eObjectHazmat.MgtrecGen,"");
		SETCHAR(eObjectHazmat.GenNew,"");
		SETCHAR(eObjectHazmat.GenDialog,"");
		SETCHAR(eObjectMat.Active,"X");
		SETCHAR(eObjectMat.Locked,"");
		SETCHAR(eObjectMat.ObjRequ,"X");
		SETCHAR(eObjectMat.MgtrecGen,"X");
		SETCHAR(eObjectMat.GenNew,"");
		SETCHAR(eObjectMat.GenDialog,"");
		SETCHAR(eObjectPhrase.Active,"");
		SETCHAR(eObjectPhrase.Locked,"");
		SETCHAR(eObjectPhrase.ObjRequ,"");
		SETCHAR(eObjectPhrase.MgtrecGen,"");
		SETCHAR(eObjectPhrase.GenNew,"");
		SETCHAR(eObjectPhrase.GenDialog,"");
		SETCHAR(eObjectPvs.Active,"");
		SETCHAR(eObjectPvs.Locked,"");
		SETCHAR(eObjectPvs.ObjRequ,"");
		SETCHAR(eObjectPvs.MgtrecGen,"");
		SETCHAR(eObjectPvs.GenNew,"");
		SETCHAR(eObjectPvs.GenDialog,"");
		SETCHAR(eObjectPvsAlt.Active,"");
		SETCHAR(eObjectPvsAlt.Locked,"");
		SETCHAR(eObjectPvsAlt.ObjRequ,"");
		SETCHAR(eObjectPvsAlt.MgtrecGen,"");
		SETCHAR(eObjectPvsAlt.GenNew,"");
		SETCHAR(eObjectPvsAlt.GenDialog,"");
		SETCHAR(eObjectPvsRel.Active,"");
		SETCHAR(eObjectPvsRel.Locked,"");
		SETCHAR(eObjectPvsRel.ObjRequ,"");
		SETCHAR(eObjectPvsRel.MgtrecGen,"");
		SETCHAR(eObjectPvsRel.GenNew,"");
		SETCHAR(eObjectPvsRel.GenDialog,"");
		SETCHAR(eObjectPvsVar.Active,"X");
		SETCHAR(eObjectPvsVar.Locked,"");
		SETCHAR(eObjectPvsVar.ObjRequ,"X");
		SETCHAR(eObjectPvsVar.MgtrecGen,"X");
		SETCHAR(eObjectPvsVar.GenNew,"");
		SETCHAR(eObjectPvsVar.GenDialog,"");
		SETCHAR(eObjectSubstance.Active,"");
		SETCHAR(eObjectSubstance.Locked,"");
		SETCHAR(eObjectSubstance.ObjRequ,"");
		SETCHAR(eObjectSubstance.MgtrecGen,"");
		SETCHAR(eObjectSubstance.GenNew,"");
		SETCHAR(eObjectSubstance.GenDialog,"");
		SETCHAR(eObjectTlist.Active,"");
		SETCHAR(eObjectTlist.Locked,"");
		SETCHAR(eObjectTlist.ObjRequ,"");
		SETCHAR(eObjectTlist.MgtrecGen,"");
		SETCHAR(eObjectTlist.GenNew,"");
		SETCHAR(eObjectTlist.GenDialog,"");
		SETCHAR(eObjectTlist2.Active,"");
		SETCHAR(eObjectTlist2.Locked,"");
		SETCHAR(eObjectTlist2.ObjRequ,"");
		SETCHAR(eObjectTlist2.MgtrecGen,"");
		SETCHAR(eObjectTlist2.GenNew,"");
		SETCHAR(eObjectTlist2.GenDialog,"");
		SETCHAR(eObjectTlistA.Active,"");
		SETCHAR(eObjectTlistA.Locked,"");
		SETCHAR(eObjectTlistA.ObjRequ,"");
		SETCHAR(eObjectTlistA.MgtrecGen,"");
		SETCHAR(eObjectTlistA.GenNew,"");
		SETCHAR(eObjectTlistA.GenDialog,"");
		SETCHAR(eObjectTlistE.Active,"");
		SETCHAR(eObjectTlistE.Locked,"");
		SETCHAR(eObjectTlistE.ObjRequ,"");
		SETCHAR(eObjectTlistE.MgtrecGen,"");
		SETCHAR(eObjectTlistE.GenNew,"");
		SETCHAR(eObjectTlistE.GenDialog,"");
		SETCHAR(eObjectTlistM.Active,"");
		SETCHAR(eObjectTlistM.Locked,"");
		SETCHAR(eObjectTlistM.ObjRequ,"");
		SETCHAR(eObjectTlistM.MgtrecGen,"");
		SETCHAR(eObjectTlistM.GenNew,"");
		SETCHAR(eObjectTlistM.GenDialog,"");
		SETCHAR(eObjectTlistN.Active,"");
		SETCHAR(eObjectTlistN.Locked,"");
		SETCHAR(eObjectTlistN.ObjRequ,"");
		SETCHAR(eObjectTlistN.MgtrecGen,"");
		SETCHAR(eObjectTlistN.GenNew,"");
		SETCHAR(eObjectTlistN.GenDialog,"");
		SETCHAR(eObjectTlistQ.Active,"");
		SETCHAR(eObjectTlistQ.Locked,"");
		SETCHAR(eObjectTlistQ.ObjRequ,"");
		SETCHAR(eObjectTlistQ.MgtrecGen,"");
		SETCHAR(eObjectTlistQ.GenNew,"");
		SETCHAR(eObjectTlistQ.GenDialog,"");
		SETCHAR(eObjectTlistR.Active,"");
		SETCHAR(eObjectTlistR.Locked,"");
		SETCHAR(eObjectTlistR.ObjRequ,"");
		SETCHAR(eObjectTlistR.MgtrecGen,"");
		SETCHAR(eObjectTlistR.GenNew,"");
		SETCHAR(eObjectTlistR.GenDialog,"");
		SETCHAR(eObjectTlistS.Active,"");
		SETCHAR(eObjectTlistS.Locked,"");
		SETCHAR(eObjectTlistS.ObjRequ,"");
		SETCHAR(eObjectTlistS.MgtrecGen,"");
		SETCHAR(eObjectTlistS.GenNew,"");
		SETCHAR(eObjectTlistS.GenDialog,"");
		SETCHAR(eObjectTlistT.Active,"");
		SETCHAR(eObjectTlistT.Locked,"");
		SETCHAR(eObjectTlistT.ObjRequ,"");
		SETCHAR(eObjectTlistT.MgtrecGen,"");
		SETCHAR(eObjectTlistT.GenNew,"");
		SETCHAR(eObjectTlistT.GenDialog,"");
		SETCHAR(eObjectValidMatvers.Active,"");
		SETCHAR(eObjectValidMatvers.Locked,"");
		SETCHAR(eObjectValidMatvers.ObjRequ,"");
		SETCHAR(eObjectValidMatvers.MgtrecGen,"");
		SETCHAR(eObjectValidMatvers.GenNew,"");
		SETCHAR(eObjectValidMatvers.GenDialog,"");
		SETCHAR(eObjectVarTab.Active,"");
		SETCHAR(eObjectVarTab.Locked,"");
		SETCHAR(eObjectVarTab.ObjRequ,"");
		SETCHAR(eObjectVarTab.MgtrecGen,"");
		SETCHAR(eObjectVarTab.GenNew,"");
		SETCHAR(eObjectVarTab.GenDialog,"");
		SETCHAR(eValueAssign.ValidFrom,"");
		SETCHAR(eValueAssign.ValidTo,"");
		SETCHAR(eValueAssign.DateMark,"");
		SETCHAR(eValueAssign.Material,"");
		SETCHAR(eValueAssign.SerialnrLow,"");
		SETCHAR(eValueAssign.SerialnrHigh,"");
		SETCHAR(eValueAssign.Class,"");
		SETCHAR(eValueAssign.Classty,"");
		SETCHAR(eValueAssign.Startup,"");
		SETCHAR(eValueAssign.Plant,"");
		SETCHAR(eValueAssign.SernrOi,"");
		SETCHAR(eValueAssign.FlDelete,"");

		if (thAltDates==ITAB_NULLTAG)
		{
			thAltDates = ItCreate("ALT_DATES", sizeof(AEDT_API01), 0, 0);
			if (thAltDates == ITAB_NULLTAG)
				printf("\nItCreate ALT_DATES");
		}
		else if (ItFree(thAltDates) != 0)
			printf("\nItFree ALT_DATES");

		if (thEffectivity==ITAB_NULLTAG)
		{
			thEffectivity = ItCreate("EFFECTIVITY", sizeof(AEEF_API01), 0, 0);
			if (thEffectivity == ITAB_NULLTAG)
				printf("\nItCreate EFFECTIVITY");
		}
		else if (ItFree(thEffectivity) != 0)
			printf("\nItFree EFFECTIVITY");

		if (thObjmgrec==ITAB_NULLTAG)
		{
			thObjmgrec = ItCreate("OBJMGREC", sizeof(AEOI_API01), 0, 0);
			if (thObjmgrec==ITAB_NULLTAG)
				printf("\nItCreate OBJMGREC");
		}
		else if (ItFree(thObjmgrec) != 0)
			printf("\nItFree OBJMGREC");

		if (thTextheader==ITAB_NULLTAG)
		{
			thTextheader = ItCreate("TEXTHEADER", sizeof(CCTHEAD), 0, 0);
			if (thTextheader==ITAB_NULLTAG)
				printf("\nItCreate TEXTHEADER");
		 }
		else if (ItFree(thTextheader) != 0)
			printf("\nItFree TEXTHEADER");

		if (thTextlines==ITAB_NULLTAG)
		{
			thTextlines = ItCreate("TEXTLINES", sizeof(CCTLINE), 0, 0);
			if (thTextlines==ITAB_NULLTAG)
				printf("\nItCreate TEXTLINES");
		}
		else if (ItFree(thTextlines) != 0)
			printf("\nItFree TEXTLINES");

		for (noOfParts = 0; noOfParts < setSize(MypartObjs); noOfParts++)
		{
				if(dstat = objGetAttribute(setGet(MypartObjs,noOfParts),"PartNumber",&partNoS)) goto EXIT;
				partNoDupS=tc_strdup(partNoS);

			tObjmgrec = ItAppLine(thObjmgrec);
			if (tObjmgrec == NULLTAG)
				printf("\nItAppLine OBJMGREC");

			SETCHAR(tObjmgrec->AltDate,"");
			SETNUM(tObjmgrec->ChgObjtyp,"");
			SETNUM(tObjmgrec->ChgObjtyp,"4");
			SETCHAR(tObjmgrec->BomCat,"");
			SETCHAR(tObjmgrec->BomStdObject,"");
			SETCHAR(tObjmgrec->BomUsage,"");
			SETNUM(tObjmgrec->Chgtypeobj,"");
			SETCHAR(tObjmgrec->DescrObj,"");
			SETCHAR(tObjmgrec->DocType,"");
			SETCHAR(tObjmgrec->DocNumber,"");
			SETCHAR(tObjmgrec->DocVers,"");
			SETCHAR(tObjmgrec->DocPart,"");
			SETCHAR(tObjmgrec->Equipment,"");
			SETCHAR(tObjmgrec->FuncLoc,"");
			SETCHAR(tObjmgrec->Material,partNoDupS);
			SETCHAR(tObjmgrec->Plant,"");
			SETCHAR(tObjmgrec->PspElement,"");
			SETCHAR(tObjmgrec->PvsType,"");
			SETCHAR(tObjmgrec->PvsNode,"");
			SETCHAR(tObjmgrec->PvsClassNumber,"");
			SETCHAR(tObjmgrec->PvsClassType,"");
			SETCHAR(tObjmgrec->PvsVariant,"");
			SETCHAR(tObjmgrec->SdOrder,"");
			SETNUM(tObjmgrec->SdOrderI,"");
			SETNUM(tObjmgrec->Textkey,"");
			SETCHAR(tObjmgrec->TlistType,"");
			SETCHAR(tObjmgrec->TlistGrp,"");
			SETCHAR(tObjmgrec->ObjChglock,"");
			SETCHAR(tObjmgrec->StatusProfObj,"");
			SETCHAR(tObjmgrec->FlDelete,"");
		}
	RfcRc = ccap_ecn_create(hRfc,&eChangeHeader,&eFlAle,&eFlCommitAndWait,&eFlNoCommitWork,&eObjectBom,&eObjectBomCus,&eObjectBomDoc,&eObjectBomEqui,&eObjectBomLoc,&eObjectBomMat,&eObjectBomPsp,&eObjectBomStd,&eObjectChar,&eObjectCls,&eObjectClsMaint,&eObjectConfProf,&eObjectDep,&eObjectDoc,&eObjectHazmat,&eObjectMat,&eObjectPhrase,&eObjectPvs,&eObjectPvsAlt,&eObjectPvsRel,&eObjectPvsVar,&eObjectSubstance,&eObjectTlist,&eObjectTlist2,&eObjectTlistA,&eObjectTlistE,&eObjectTlistM,&eObjectTlistN,&eObjectTlistQ,&eObjectTlistR,&eObjectTlistS,&eObjectTlistT,&eObjectValidMatvers,&eObjectVarTab,&eValueAssign,&iChangeNo,thAltDates,thEffectivity,thObjmgrec,thTextheader,thTextlines,xException);
	switch (RfcRc)
	{
		case RFC_OK:
			printf("\nReturned value from ecn creat: %u",RFC_OK);
		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception: %s",xException);
		break;
		default:;
	}

EXIT:
	printf("exit from bapi");

	RfcClose(hRfc);
}*/

RFC_RC  cad_create_bom_with_sub_items(RFC_HANDLE hRfc, DRAW_LOEDK *eIAutoPosnr, CAD_BICSK *eIBomHeader, CAD_BICSK *iEBomHeader, MESSAGE_MSGTX *iEMessage, CAD_RETURN_MESSAGE_LEN *iEMessageLen, CAD_RETURN_VALUE *iEReturn, ITAB_H thBomItem, char *xException)
{
  // RFC variables
  RFC_PARAMETER Exporting[3];
  RFC_PARAMETER Importing[5];
  RFC_TABLE Tables[2];
  RFC_RC RfcRc;
  char *RfcException = NULLTAG;
  // define export params
  Exporting[0].name = "I_AUTO_POSNR";
  Exporting[0].nlen = 12;
  Exporting[0].type = TYPC;
  Exporting[0].leng = sizeof(DRAW_LOEDK);
  Exporting[0].addr = eIAutoPosnr;

  Exporting[1].name = "I_BOM_HEADER";
  Exporting[1].nlen = 12;
  Exporting[1].type = handleOfCAD_BICSK;
  Exporting[1].leng = sizeof(CAD_BICSK);
  Exporting[1].addr = eIBomHeader;

  Exporting[2].name = NULLTAG;

  Tables[0].name     = "BOM_ITEM";
  Tables[0].nlen     = 8;
  Tables[0].type     = handleOfCAD_BOM_ITEM;
  Tables[0].ithandle = thBomItem;

  Tables[1].name = NULLTAG;

  RfcRc = RfcCall(hRfc,"CAD_CREATE_BOM_WITH_SUB_ITEMS",Exporting,Tables);
  switch (RfcRc)
  {
    case RFC_OK :

		  Importing[0].name = "E_BOM_HEADER";
		  Importing[0].nlen = 12;
		  Importing[0].type = handleOfCAD_BICSK;
		  Importing[0].leng = sizeof(CAD_BICSK);
		  Importing[0].addr = iEBomHeader;

		  Importing[1].name = "E_MESSAGE";
		  Importing[1].nlen = 9;
		  Importing[1].type = TYPC;
		  Importing[1].leng = sizeof(MESSAGE_MSGTX);
		  Importing[1].addr = iEMessage;

		  Importing[2].name = "E_MESSAGE_LEN";
		  Importing[2].nlen = 13;
		  Importing[2].type = TYPC;
		  Importing[2].leng = sizeof(CAD_RETURN_MESSAGE_LEN);
		  Importing[2].addr = iEMessageLen;

		  Importing[3].name = "E_RETURN";
		  Importing[3].nlen = 8;
		  Importing[3].type = TYPC;
		  Importing[3].leng = sizeof(CAD_RETURN_VALUE);
		  Importing[3].addr = iEReturn;

		  Importing[4].name = NULLTAG;

		  RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
		  // printf("\nMessage Received:%s",RfcException);

	switch (RfcRc)
	{
		case RFC_SYS_EXCEPTION :
			strcpy(xException,RfcException);
			printf("\nRFC_SYS_EXCEPTION: %s",xException);
			break;
		case RFC_EXCEPTION :
			strcpy(xException,RfcException);
			printf("\nRFC_EXCEPTION    : %s",xException);
			break;
			default:;
	}
	break;
	default:
			printf("\nNot ok");

  }
  return RfcRc;
}

RFC_RC  zcad_change_bom_with_sub_items(RFC_HANDLE hRfc,CAD_BICSK *eIBomHeader,CAD_RETURN_VALUE *iEReturn,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_BICSK *iEBomHeader,ITAB_H thBomItem,char *xException)
{
	char *RfcException = NULLTAG;
	RFC_PARAMETER Exporting[2];
	RFC_PARAMETER Importing[5];
	RFC_TABLE Tables[2];
	RFC_RC RfcRc;

	Exporting[0].name = "I_BOM_HEADER";
	Exporting[0].nlen = 12;
	Exporting[0].type = handleOfCAD_BICSK;
	Exporting[0].leng = sizeof(CAD_BICSK);
	Exporting[0].addr = eIBomHeader;

	Exporting[1].name = NULLTAG;

	Tables[0].name     = "BOM_ITEM";
	Tables[0].nlen     = 8;
	Tables[0].type     = handleOfCAD_BOM_ITEM;
	Tables[0].ithandle = thBomItem;

	Tables[1].name = NULLTAG;

	RfcRc = RfcCall(hRfc,"ZCAD_CHANGE_BOM_WITH_SUB_ITEMS",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK :
			Importing[0].name = "E_RETURN";
			Importing[0].nlen = 8;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(CAD_RETURN_VALUE);
			Importing[0].addr = iEReturn;

			Importing[1].name = "E_MESSAGE";
			Importing[1].nlen = 9;
			Importing[1].type = TYPC;
			Importing[1].leng = sizeof(MESSAGE_MSGTX);
			Importing[1].addr = iEMessage;

			Importing[2].name = "E_MESSAGE_LEN";
			Importing[2].nlen = 13;
			Importing[2].type = TYPC;
			Importing[2].leng = sizeof(CAD_RETURN_MESSAGE_LEN);
			Importing[2].addr = iEMessageLen;

			Importing[3].name = "E_BOM_HEADER";
			Importing[3].nlen = 12;
			Importing[3].type = handleOfCAD_BICSK;
			Importing[3].leng = sizeof(CAD_BICSK);
			Importing[3].addr = iEBomHeader;

			Importing[4].name = NULLTAG;


			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION :
					strcpy(xException,RfcException);
					printf("RFC_SYS_EXCEPTION:%s",xException);
				break;
				case RFC_EXCEPTION :
					strcpy(xException,RfcException);
					printf("RFC_EXCEPTION:    %s",xException);
				break;
				default:;
			}
		default:;
	}
	return RfcRc;
}