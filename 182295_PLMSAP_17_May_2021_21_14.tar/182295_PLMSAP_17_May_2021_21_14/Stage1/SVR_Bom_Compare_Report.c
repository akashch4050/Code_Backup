/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : SVR_Bom_Mismatch.c
* Created By                   : Amol Narke
* Created On                   : 25/08/2020
* Project                      : Tata Motors TCUA-SAP Interface
* Methods Defined              :
* Description                  : TCUA - SAP SVR BOM Mismatch report
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <time.h>
#include <tccore/tctype.h>

#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"
#include "t.h"
#include "ppe.h"

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

FILE *fsuccess;
FILE *fMisReport;

char *iSapServer = NULL;

char* ReportName	= NULL;

char cpydml_no[50]={0};
char *PlmDmlSuff 		= NULL;
char *PlmDmlSuffOrig 		= NULL;
char *meas_unit		= NULL;

struct node
{
char part[15];
int dupind;
struct node *next;
};

struct node_mis
{
	char sr_no[5];
	char *part;
	char *qty;
	char *BomNo;
	struct node_mis *next;
};

struct node_mis *start_sap = NULL;
struct node_mis *start_plm = NULL;

struct node_mis *p_sap = NULL;
struct node_mis *q_sap = NULL;

struct node_mis *p_plm = NULL;
struct node_mis *q_plm = NULL;

char *ChildPart = NULL;
char *ChildPartVal = NULL;
char *Quantity = NULL;
char *QuantityVal = NULL;
char *BomNo = NULL;
char *BomNoVal = NULL;

static int expansionLevel = 2;
int Parentlevel = 0;
char	*plantcode			= NULL;
char	*bl_mkbuy_string	= NULL;
char	*date_time_string	= NULL;

struct node *start		= NULL;
struct node *start1		= NULL;
struct node *p			= NULL;
struct node *p1			= NULL;
struct node *q			= NULL;
struct node *q1			= NULL;


tag_t MypartObjs		= NULLTAG;
char DMLDescription[100];

char *dml_numAP			= NULL;
char *dml_numAP1 		= NULL;
static char projectcode[5]={0};

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);
void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str);
void my_free(struct node* start);
void  rfc_error(char *operation);
RFC_HANDLE BapiLogon(void);
void Expand_SAP_SVR_BOM(char *assy_noDup);
RFC_RC UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2(RFC_HANDLE	hRfc, MARA_MATNR *eMARA_MATNR, MARC_WERKS *eMARC_WERKS, STZU_STLAN *eSTZU_STLAN, STKO_STLAL *eSTKO_STLAL, TC04_CAPID *eTC04_CAPID, STKO_DATUV *eSTKO_DATUV, ITAB_H thSTB, ITAB_H thMATCAT, char *xException );
void compare(struct node_mis *p1,struct node_mis *p2,char *AssyNo,char* plantcode);
void trimString(char * str);
int tm_fnd_DML_PART(char	*PLT_CODE,tag_t t_currentRevision, tag_t* t_DMLRevision);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);
static int ExpandMultiLevelBom (tag_t bom_line_tag, tag_t line1, int depth , tag_t ParentBomLine , tag_t *parent_bom , int noOfChildinParent);
struct node_mis* createnode_mis(char sr_no[5],char *part,char* qty,char *BomNo);
void my_free_mis(struct node_mis** start);

void trimString(char * str)
{
	int i = 0;
    for (i = 0; i < tc_strlen(str); i++)
	{
		//printf("\n%d %c",i,str[i]);
		if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
		{
			str[i] = '\0';
		}     
	}
}
;

struct node_mis* createnode_mis(char sr_no[5],char *part,char *qty,char *BomNo)
{
	struct node_mis* p = NULL;

	p = (struct node_mis*)malloc(sizeof(struct node_mis));
	tc_strcpy(p->sr_no,sr_no);

	p->part = (char *) MEM_alloc(19 * sizeof(char ));
	tc_strcpy(p->part,part);

	p->qty = (char *) MEM_alloc(19 * sizeof(char ));
	if ( strcmp(qty,"") != 0 )
	{
		tc_strcpy(p->qty,qty);
	}
	else
	{
		tc_strcpy(p->qty,"0.000");
	}

	p->BomNo = (char *) MEM_alloc(41 * sizeof(char ));
	if ( strcmp(BomNo,"") != 0 )
	{
		tc_strcpy(p->BomNo,BomNo);
	}
	else
	{
		tc_strcpy(p->BomNo,"NA");
	}

	p->next = NULL;
	return p;
}

void display_bom(struct node_mis *head)
{
	struct node_mis *p2=NULL;
	for(p2=head; p2!=NULL; p2 = p2->next)
	{
		printf("\n[%s][%s][%s][%s]",p2->sr_no,p2->part,p2->qty,p2->BomNo);fflush(stdout);
	}
}

void my_free_mis(struct node_mis** start)
{
	struct node_mis* current = *start;
	struct node_mis* ptr;
	printf("\n");
	while (current != NULL)
	{
		printf("#");
		ptr = current->next;
		free(current);
		current = ptr;
	}
	*start = NULL;
	printf("SUCCESSFULLY DELETED ALL NODES OF LINKED LIST\n");
}


void compare(struct node_mis *p1,struct node_mis *p2,char *AssyNo,char* plantcode)
{

	int	found = 1;
	struct node_mis *s1 = NULL;
	struct node_mis *s2 = NULL;
	int iMisCnt = 0;
	printf("\nIn compare");fflush(stdout);

	fprintf(fMisReport,"\n<SVR_NUMBER>");
	fprintf(fMisReport,AssyNo);
	fprintf(fMisReport,"</SVR_NUMBER>");

	fprintf(fMisReport,"\n<PLANT_CODE>");
	fprintf(fMisReport,plantcode);
	fprintf(fMisReport,"</PLANT_CODE>");

	fprintf(fMisReport,"\n<DATE_TIME>");
	fprintf(fMisReport,date_time_string);
	fprintf(fMisReport,"</DATE_TIME>");

	//fprintf(fMisReport,"\n\nMODULE NUMBER\t MODULE UID\t PLM STATUS\t SAP STATUS\t");

	s1 = p1;
	s2 = p2;
	while(s1!=NULL)
	{
		s2=p2;

		while(s2!=NULL)
		{
			if((strcmp(s2->part,s1->part)==0) && (strcmp(s2->BomNo,s1->BomNo)==0))
			{
				found = 0;
				fprintf(fMisReport,"<logo>\n");

				fprintf(fMisReport,"<field key =\"MODULE_NUMBER\">");
				fprintf(fMisReport,"%s",s1->part);
				fprintf(fMisReport,"</field>\n");

				fprintf(fMisReport,"<field key =\"MODULE_UID\">");
				fprintf(fMisReport,"%s",s1->BomNo);
				fprintf(fMisReport,"</field>\n");

				fprintf(fMisReport,"<field key =\"PLM_STATUS\">");
				fprintf(fMisReport,"PRESENT");
				fprintf(fMisReport,"</field>\n");

				fprintf(fMisReport,"<field key =\"SAP_STATUS\">");
				fprintf(fMisReport,"PRESENT");
				fprintf(fMisReport,"</field>\n");
				
				fprintf(fMisReport,"</logo>\n");

				//fprintf(fMisReport,"\n%s\t %s\t PRESENT\t PRESENT\t",s1->part,s1->BomNo);
				break;
			}
			else
			{
				found = 1;
			}
			s2=s2->next;
		}
		if(found == 1)
		{
			iMisCnt = iMisCnt + 1;

				fprintf(fMisReport,"<logo>\n");

				fprintf(fMisReport,"<field key =\"MODULE_NUMBER\">");
				fprintf(fMisReport,"%s",s1->part);
				fprintf(fMisReport,"</field>\n");

				fprintf(fMisReport,"<field key =\"MODULE_UID\">");
				fprintf(fMisReport,"%s",s1->BomNo);
				fprintf(fMisReport,"</field>\n");

				fprintf(fMisReport,"<field key =\"PLM_STATUS\">");
				fprintf(fMisReport,"PRESENT");
				fprintf(fMisReport,"</field>\n");

				fprintf(fMisReport,"<field key =\"SAP_STATUS\">");
				fprintf(fMisReport,"NOT PRESENT");
				fprintf(fMisReport,"</field>\n");
				
				fprintf(fMisReport,"</logo>\n");

			//fprintf(fMisReport,"\n%s\t %s\t PRESENT\t NOT PRESENT\t",s1->part,s1->BomNo);
			printf("\n%s Part present in PLM not in SAP %s BomNo[%s] for plant [%s]",AssyNo,s1->part,s1->BomNo,plantcode);fflush(stdout);
			//fprintf(fsuccess,"\n%s Part present in PLM not in SAP %s BomNo[%s] for plant [%s]",AssyNo,s1->part,s1->BomNo,plantcode);fflush(stdout);
		}

		s1=s1->next;
	}


	s1 = p1;
	s2 = p2;
	while(s2!=NULL)
	{
		s1=p1;

		while(s1!=NULL)
		{
			if ( (strcmp(s1->part,s2->part)==0) && (strcmp(s1->BomNo,s2->BomNo)==0))
			{
				found = 0;
				break;
			}
			else
			{
				found = 1;
			}
			s1=s1->next;
		}
		if(found == 1)
		{
			iMisCnt = iMisCnt + 1;

				fprintf(fMisReport,"<logo>\n");

				fprintf(fMisReport,"<field key =\"MODULE_NUMBER\">");
				fprintf(fMisReport,"%s",s2->part);
				fprintf(fMisReport,"</field>\n");

				fprintf(fMisReport,"<field key =\"MODULE_UID\">");
				fprintf(fMisReport,"%s",s2->BomNo);
				fprintf(fMisReport,"</field>\n");

				fprintf(fMisReport,"<field key =\"PLM_STATUS\">");
				fprintf(fMisReport,"NOT PRESENT");
				fprintf(fMisReport,"</field>\n");

				fprintf(fMisReport,"<field key =\"SAP_STATUS\">");
				fprintf(fMisReport,"PRESENT");
				fprintf(fMisReport,"</field>\n");
				
				fprintf(fMisReport,"</logo>\n");

			//fprintf(fMisReport,"\n%s\t %s\t NOT PRESENT\t PRESENT\t",s2->part,s2->BomNo);
			printf("\n%s Part present in SAP not in PLM %s BomNo[%s] for plant [%s] Item No [%s]",AssyNo,s2->part,s2->BomNo,plantcode,s2->sr_no);fflush(stdout);
			//fprintf(fsuccess,"\n%s Part present in SAP not in PLM %s BomNo[%s] for plant [%s] Item No [%s]",AssyNo,s2->part,s2->BomNo,plantcode,s2->sr_no);fflush(stdout);
		}

		s2=s2->next;
	}

	if ( iMisCnt > 0 )
	{
		printf("\nMismatch found for SVR BOM : %s",AssyNo);

		fprintf(fMisReport,"\n<MISMATCH_STAT>");
		fprintf(fMisReport,"Mismatch found for SVR BOM %s",AssyNo);
		fprintf(fMisReport,"</MISMATCH_STAT>");

		//fprintf(fsuccess,"\nMismatch found for SVR BOM : %s",AssyNo);
		//fprintf(fMisReport,"\nMismatch found for SVR BOM : %s",AssyNo);

	}
	else
	{
	 	printf("\nNo mismatch found for SVR BOM : %s",AssyNo);

		fprintf(fMisReport,"\n<MISMATCH_STAT>");
		fprintf(fMisReport,"No mismatch found for SVR BOM %s",AssyNo);
		fprintf(fMisReport,"</MISMATCH_STAT>");

        //fprintf(fsuccess,"\nNo mismatch found for SVR BOM : %s",AssyNo);
        //fprintf(fMisReport,"\nNo mismatch found for SVR BOM : %s",AssyNo);
	}
	
}

int tm_fnd_DML_PART(char *PLT_CODE,tag_t t_currentRevision,tag_t* t_DMLRevision)
{
	int     status;
	int     ifail;
	int		count_tsk				=	0;
	int		count_DML				=	0;
	int		iPPPM					=	0;
	int		itsk					=	0;
	int		idml					=	0;
	int		iDMLFnd					=	0;

	char	*c_PartNumber			=	NULL;
	char	*Part_Rev				=	NULL;
	char	*object_type			=	NULL;
	char	*type_name				=	NULL;
	char	*type_dml_name			=	NULL;
	char	*task_name				=	NULL;
	char	*DML_name				=	NULL;
	char	*DML_Owner				= NULL;
	char	*DMLRelStatus			= NULL;
	char	*DateStr				= NULL;
	char	*STDRelDateStr			= NULL;

	date_t STDRelDate;

	tag_t	tsk_part_sol_rel_type	=	NULLTAG;
	tag_t	dml_task_rel_type		=	NULLTAG;
	tag_t	*TaskRevision			=	NULLTAG;
	tag_t	*DMLRevision			=	NULLTAG;
	tag_t	TaskRevTag				=	NULLTAG;
	tag_t	DMLRevTag				=	NULLTAG;
	tag_t	objTaskTypeTag			=	NULLTAG;
	tag_t	objDMLTypeTag			=	NULLTAG;

	printf("\nInside tm_fnd_DML_PART %s",PLT_CODE);fflush(stdout);

	AOM_ask_value_string(t_currentRevision,"current_id",&c_PartNumber);
	printf("\nPart_Number: %s\n",c_PartNumber);fflush(stdout);

	AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev);
	printf("\nPart_Rev: %s\n",Part_Rev);fflush(stdout);

	AOM_ask_value_string(t_currentRevision,"object_type",&object_type);
	printf("\nobject_type : %s",object_type);fflush(stdout);

	GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);

	if(tsk_part_sol_rel_type!=NULLTAG)
	{
		GRM_list_primary_objects_only(t_currentRevision,tsk_part_sol_rel_type,&count_tsk,&TaskRevision);
		printf("\n\n\t\t APL DML Cre:ERC DML  : %d",count_tsk);fflush(stdout);

		if(count_tsk>0)
		{
			for(itsk=0;itsk<count_tsk;itsk++)
			{
				iDMLFnd		=	0;
				TaskRevTag	=	NULLTAG;
				TaskRevTag	=	TaskRevision[itsk];

				if(TCTYPE_ask_object_type(TaskRevTag,&objTaskTypeTag));
				if(TCTYPE_ask_name2(objTaskTypeTag,&type_name));
				printf("\n     type_name_erc changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

				if(tc_strcmp(type_name,"T5_APLTaskRevision")==0)
				{
					//item_id
					AOM_ask_value_string(TaskRevTag,"item_id",&task_name);
					printf("\n\n\t\t object_type is :%s",task_name);fflush(stdout);

					if(tc_strstr(task_name,"PP")!=NULL || tc_strstr(task_name,"PM")!=NULL || tc_strstr(task_name,"AM")!=NULL || tc_strstr(task_name,"MC")!=NULL)
					{
						printf("\nPP Task found for DML.");fflush(stdout);
						iPPPM	=	1;
						if(strstr(task_name,PLT_CODE))
						{
							printf("\nMatch found...!!!");fflush(stdout);

							if (tc_strstr(task_name,"PR")!=NULL)
							{
								AOM_ask_value_string(TaskRevTag,"item_id",&DML_name);
								printf("\nDML_name founc : %s",DML_name);fflush(stdout);
								AOM_UIF_ask_value(TaskRevTag,"owning_user",&DML_Owner);
								AOM_UIF_ask_value(TaskRevTag,"release_status_list",&DMLRelStatus);

								AOM_ask_value_date(TaskRevTag,"date_released",&STDRelDate);
								DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr);
								
								ITK_date_to_string(STDRelDate,&DateStr);
								
								if(tc_strstr(DML_Owner,"APLloader")!=NULL || tc_strstr(DML_Owner,"aplloader")!=NULL)
								{
									printf("\nAssy [%s/%s] DML [%s] as DML Owner [%s]",c_PartNumber,Part_Rev,DML_name,DML_Owner);
									//fprintf(fsuccess,"\nSkiping DML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
									continue;
								}

								if(tc_strstr(DMLRelStatus,"STDSIC Released")==NULL)
								{
									printf("\nAssy [%s/%s] DML Number [%s] Release Status [%s] DML Not STDSIC Released...\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
									//fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] Not STDSIC Released...\n",DMLNum,DMLRelStatus);fflush(stdout);
									continue;
								}

								if (tc_strlen(DateStr)==0)
								{
									printf("\nAssy [%s/%s] DML Number [%s] STD Release Date is NULL..Exiting!\n",c_PartNumber,Part_Rev,DML_name,tc_strlen(DateStr));
									//fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DML_name,tc_strlen(DateStr));
									continue;
								}

								if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL && tc_strlen(DateStr)!=0)
								{
									iDMLFnd	=	1;
									printf("\nAssy [%s/%s] Found DML Number [%s] Release Status [%s] STD Released Date [%s]\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus,STDRelDateStr);fflush(stdout);
									break;
								}

							}
							else
							{
								GRM_find_relation_type("T5_DMLTaskRelation",&dml_task_rel_type);
								if(dml_task_rel_type!=NULLTAG)
								{
									GRM_list_primary_objects_only(TaskRevTag,dml_task_rel_type,&count_DML,&DMLRevision);
									printf("\n\n\t\t No OF DML FOUND  : %d",count_DML);fflush(stdout);
									if(count_DML>0)
									{
										for(idml=0;idml<count_DML;idml++)
										{
											DMLRevTag	=	NULLTAG;
											DMLRevTag	=	DMLRevision[idml];
											
											if(TCTYPE_ask_object_type(DMLRevTag,&objDMLTypeTag));
											if(TCTYPE_ask_name2(objDMLTypeTag,&type_dml_name));
											printf("\ntype_dml_name : %s",type_dml_name);fflush(stdout);

											if (tc_strcmp(type_dml_name,"T5_APLDMLRevision")==0)
											{
												
												AOM_ask_value_string(DMLRevTag,"item_id",&DML_name);
												printf("\nDML_name founc : %s",DML_name);fflush(stdout);
												AOM_UIF_ask_value(DMLRevTag,"owning_user",&DML_Owner);
												AOM_UIF_ask_value(DMLRevTag,"release_status_list",&DMLRelStatus);

												AOM_ask_value_date(DMLRevTag,"date_released",&STDRelDate);
												DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr);
												
												ITK_date_to_string(STDRelDate,&DateStr);
												
												if(tc_strstr(DML_Owner,"APLloader")!=NULL || tc_strstr(DML_Owner,"aplloader")!=NULL)
												{
													printf("\nAssy [%s/%s] DML [%s] as DML Owner [%s]",c_PartNumber,Part_Rev,DML_name,DML_Owner);
													//fprintf(fsuccess,"\nSkiping DML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
													continue;
												}

												if(tc_strstr(DMLRelStatus,"STDSIC Released")==NULL)
												{
													printf("\nAssy [%s/%s] DML Number [%s] Release Status [%s] DML Not STDSIC Released...\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
													//fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] Not STDSIC Released...\n",DMLNum,DMLRelStatus);fflush(stdout);
													continue;
												}

												if (tc_strlen(DateStr)==0)
												{
													printf("\nAssy [%s/%s] DML Number [%s] STD Release Date is NULL..Exiting!\n",c_PartNumber,Part_Rev,DML_name,tc_strlen(DateStr));
													//fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DML_name,tc_strlen(DateStr));
													continue;
												}

												if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL && tc_strlen(DateStr)!=0)
												{
													iDMLFnd	=	1;
													*t_DMLRevision	=	DMLRevTag;
													printf("\nAssy [%s/%s] Found DML Number [%s] Release Status [%s] STD Released Date [%s]\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus,STDRelDateStr);fflush(stdout);
													break;
												}
											}
										}
									}
									else
									{
										printf("\nNo DML found...!!!");fflush(stdout);
									}
								}
							}
						}
					}
				}
				if(iDMLFnd==1)
				{
					printf("\nTask Loop break...!!!");fflush(stdout);
					break;
				}
				else
				{
					printf("\nChecking Next Task...!!!");fflush(stdout);
					continue;
				}
			}

		}
		else
		{
			printf("\nNo task found");fflush(stdout);
		}
	}

	return iDMLFnd;

}

static int sr_no1 		= 0;

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

void Expand_SAP_SVR_BOM(char *assy_noDup)
{
	struct usgProbnode *startUsg=NULLTAG, *p=NULLTAG, *t=NULLTAG;
	int		ret = 0;
	float usgPrbFloat = 0.000f;
	//float sumUsgProb = 0.000f;

	char xException[256];
	char s[1024]={0};
	char comp_part_sap[18];
	int i_sap=0,j_sap=0,k_sap=0,m_sap=0;

	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc3;

	MARA_MATNR	eMARA_MATNR;
	MARC_WERKS	eMARC_WERKS;
	STZU_STLAN	eSTZU_STLAN;
	STKO_STLAL	eSTKO_STLAL;
	TC04_CAPID	eTC04_CAPID;
	STKO_DATUV	eSTKO_DATUV;

	ITAB_H thMATCAT = ITAB_NULL;
	ITAB_H thSTB  = ITAB_NULL;
	STB *tSTB;

	unsigned crow;

	char *cUsgProbStr = NULL;
	char *sumStr = NULL;
	char *cUsgProbChildP = NULL;
	char *cItemNoSap = NULL;
	char *BomL1 = NULL;
	char *date  = NULL;
	char *year  = NULL;
	char *month = NULL;
	char *daydt = NULL;
	char *sapIpDt = NULL;
	char* CCVC_Number = NULL;
	char* SAPChildPart = NULL;
	char* ChildQty = NULL;
	char* ChildQtyStr = NULL;
	char* timestamp = NULL;

	struct node_mis *p_sap = NULL;
	struct node_mis *q_sap = NULL;
	p_sap = NULL;
	q_sap = NULL;

	time_t NowTime;
	struct tm *timeinfo;

	timestamp		= (char *) MEM_alloc(20 * sizeof(char));
	sapIpDt			= (char *) MEM_alloc(11 * sizeof(char));
	cItemNoSap		= (char *) MEM_alloc(5 * sizeof(char));
	cUsgProbChildP	= (char *) MEM_alloc(15 * sizeof(char));
	ChildQty		= (char *) MEM_alloc(19 * sizeof(char));
	BomL1			= (char *) MEM_alloc(20 * sizeof(char));

	//printf("\n Before calling cUsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2 .for.[%s]:[%s].\n",assy_noDup,plantcode);

	hRfc = BapiLogon();
	
	time(&NowTime);
	timeinfo = localtime(&NowTime);
	strftime(timestamp, 20, "%Y-%m-%d-%H_%M_%S", timeinfo);
	printf("\ntimestamp %s",timestamp);
	tc_strdup(timestamp,&date_time_string);

	year = strtok ( timestamp, "-" );
	month = strtok ( NULL, "-" );
	daydt = strtok ( NULL, "-" );

	tc_strcpy(sapIpDt,"");
	tc_strcpy(sapIpDt,year);
	tc_strcat(sapIpDt,month);
	tc_strcat(sapIpDt,daydt);

	printf("\n eSTKO_DATUV:[%s] \n",sapIpDt); fflush(stdout);
	CCVC_Number = strtok ( assy_noDup, "_" );

	SETCHAR(eMARA_MATNR,CCVC_Number);
	SETCHAR(eMARC_WERKS,plantcode);
	SETCHAR(eSTZU_STLAN,"1");
	SETCHAR(eSTKO_STLAL,"01");
	SETCHAR(eTC04_CAPID,"PP01");
	SETCHAR(eSTKO_DATUV,sapIpDt);
	thSTB = ITAB_NULL;

	if (thSTB==ITAB_NULL)
	{
		thSTB = ItCreate("STB",sizeof(STB),0,0);
		if (thSTB==ITAB_NULL)
			rfc_error("ItCreate STB");
	}
	else if (ItFree(thSTB) != 0)
	{
		rfc_error("ItFree STB");
	}

	thMATCAT = ITAB_NULL;

	if (thMATCAT==ITAB_NULL)
	{
		thMATCAT = ItCreate("MATCAT",sizeof(MATCAT),0,0);
		if (thMATCAT==ITAB_NULL)
			rfc_error("ItCreate MATCAT");
	}
	else if (ItFree(thMATCAT) != 0)
	{
		rfc_error("ItFree MATCAT");
	}

	//sumUsgProb = 0.000f;
	RfcRc3 = UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2(	hRfc,
												&eMARA_MATNR,
												&eMARC_WERKS,
												&eSTZU_STLAN,
												&eSTKO_STLAL,
												&eTC04_CAPID,
												&eSTKO_DATUV,
												thSTB,
												thMATCAT,
												xException
											  );

	printf("\nno of childs fetched for [%s,%s][%d]\n",assy_noDup,plantcode,ItFill(thSTB));
	if (ItFill(thSTB)>0)
	{
		startUsg = NULL;
		p = NULL;
		t = NULL;
		ret = 0;

		switch (RfcRc3)
		{
			case RFC_OK :
				printf("\nIn RFC_OK case of ZPPRFC_CS_BOM_EXPL_MAT_V2");

				for (crow = 1;crow <= ItFill(thSTB); crow++)
				{
					tSTB = ItGetLine(thSTB,crow);
					if (tSTB == NULL)
					{
						rfc_error("ItGetLineBOM_ITEM");
					}

					//printf("\ncrow :[%d]",crow );
					GETCHAR(tSTB->POSNR, cItemNoSap	);
					GETCHAR(tSTB->POTX1, BomL1);

					GETCHAR(tSTB->IDNRK, cUsgProbChildP	);
					GETCHAR(tSTB->MENGE, ChildQty);
					
					SAPChildPart = (char *) stripBlanks(cUsgProbChildP);
					ChildQtyStr = (char *) stripBlanks(ChildQty);
					BomNoVal = (char *) stripBlanks(BomL1);

					//printf("\n%s\t%s\t%s",cItemNoSap,cUsgProbChildP,BomL1);

					if(p_sap == NULL)
					{
						p_sap = createnode_mis(cItemNoSap,SAPChildPart,ChildQtyStr,BomNoVal);
						start_sap = p_sap;
					}
					else
					{
						q_sap = start_sap;
						while(q_sap->next != NULL)
						{
							 q_sap = q_sap->next;
						}
						q_sap->next = createnode_mis(cItemNoSap,SAPChildPart,ChildQtyStr,BomNoVal);

					}
				}
				
				break;
			case RFC_EXCEPTION :
				printf("\nRFC_EXCEPTION"); fflush(stdout);
				break;
			case RFC_SYS_EXCEPTION :
				printf("\nRFC_SYS_EXCEPTION"); fflush(stdout);
				break;
			case RFC_FAILURE :
				printf("\nfailure"); fflush(stdout);
				break;
			default :
				printf("\nother failure"); fflush(stdout);
				break;
		}

		if (ItDelete(thSTB) != 0)
		rfc_error("ItDelete STB");
		if (ItDelete(thMATCAT) != 0)
		rfc_error("ItDelete MATCAT");

	}

	RfcClose(hRfc);
}

RFC_RC UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2(RFC_HANDLE	hRfc, MARA_MATNR *eMARA_MATNR, MARC_WERKS *eMARC_WERKS, STZU_STLAN *eSTZU_STLAN, STKO_STLAL *eSTKO_STLAL, TC04_CAPID *eTC04_CAPID, STKO_DATUV *eSTKO_DATUV,ITAB_H  thSTB, ITAB_H  thMATCAT, char *xException )
{

	static RFC_RC RfcRc;

	RFC_PARAMETER Exporting[7];
	RFC_PARAMETER Importing[1];
	RFC_TABLE Tables[3];
	char *RfcException = NULLTAG;

	Exporting[0].name = "MTNRV";		//Material/Partno
	Exporting[0].nlen = 5;
	Exporting[0].type = TYPC;
	Exporting[0].leng = sizeof(MARA_MATNR);
	Exporting[0].addr = eMARA_MATNR;

	Exporting[1].name = "WERKS";		//Material Plant input
	Exporting[1].nlen = 5;
	Exporting[1].type = TYPC;
	Exporting[1].leng = sizeof(MARC_WERKS);
	Exporting[1].addr = eMARC_WERKS;

	Exporting[2].name = "STLAN";		//BOM Usage input
	Exporting[2].nlen = 5;
	Exporting[2].type = TYPC;
	Exporting[2].leng = sizeof(STZU_STLAN);
	Exporting[2].addr = eSTZU_STLAN;

	Exporting[3].name = "STLAL";		//Alternative BOM
	Exporting[3].nlen = 5;
	Exporting[3].type = TYPC;
	Exporting[3].leng = sizeof(STKO_STLAL);
	Exporting[3].addr = eSTKO_STLAL;

	Exporting[4].name = "CAPID";		//Application identifier PP01
	Exporting[4].nlen = 5;
	Exporting[4].type = TYPC;
	Exporting[4].leng = sizeof(TC04_CAPID);
	Exporting[4].addr = eTC04_CAPID;

	Exporting[5].name = "DATUV";		//Valid from date [dd.mm.yyyy][e.g. 06.07.2013]
	Exporting[5].nlen = 5;
	Exporting[5].type = TYPC;
	Exporting[5].leng = sizeof(STKO_DATUV);
	Exporting[5].addr = eSTKO_DATUV;

	Exporting[6].name = NULLTAG;


	Tables[0].name     = "STB";
	Tables[0].nlen     = 3;
	Tables[0].type     = handleOfSTB;
	Tables[0].ithandle = thSTB;

	Tables[1].name     = "MATCAT";
	Tables[1].nlen     = 6;
	Tables[1].type     = handleOfMATCAT;
	Tables[1].ithandle = thMATCAT;

	Tables[2].name     = NULLTAG;

	printf("\nBefore1 ZPPRFC_CS_BOM_EXPL_MAT_V2\n");

	RfcRc = RfcCall(hRfc,"ZPPRFC_CS_BOM_EXPL_MAT_V2",Exporting,Tables);
	//RfcRc = RfcCall(hRfc,"CS_BOM_EXPL_MAT_V2",Exporting,Tables);

	switch (RfcRc)
	{

		case RFC_OK :

			Importing[0].name = NULLTAG;
			printf("\nAfter1 ZPPRFC_CS_BOM_EXPL_MAT_V2 RFC_OK\n");
			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION :
					strcpy(xException,RfcException);
					printf ("exception1 %s",xException);  fflush(stdout);
				break;
				case RFC_EXCEPTION :
					strcpy(xException,RfcException);
					printf ("exception2 %s",xException);  fflush(stdout);
				break;
				default:;
			}
		break;
		default:
			printf("\ndefault case"); fflush(stdout);
		break;
	}
	return RfcRc;
}


static int ExpandMultiLevelBom (tag_t bom_line_tag, tag_t line1, int depth , tag_t ParentBomLine , tag_t *parent_bom , int noOfChildinParent)
{
	int status;
	int ifail;
	int i, no_bom_lines , j ,jr, k=0;
	int n_tags_found= 0;
	int iChildItemTag;
	int level0=0;
	int m = 0;
	int group_child_flag = 0;
	int status_count=0;
	int n_entries = 2;
	int resultCount = 2;
	int CompCodeCtrlCount = 0;
	int skipFlag=0;
	float floatQty= 0.000;

	int Item_ID=0,Item_UoM=0,Item_Owner=0;

	char *name, *sequence_no;
	char *word=NULL;
	char *Item_id_par=NULL;
	char *ItemRevSeq=NULL;
	char *ItemRevSeqTemp=NULL;
	char *ItemRevStr=NULL;
	char *ItemRev=NULL;
	char *itemRevSeqStr=NULL;
	char *ItemSeq=NULL;
	char *Parent_name=NULL;
	char *t5InternalSchme=NULL;
	char *Category=NULL;

	tag_t *child_bom_lines;
	tag_t *tags_found = NULL;
	tag_t *rev=NULLTAG;
	tag_t *compCodeCtrl_tags=NULLTAG;
	
	tag_t item=NULLTAG;
	tag_t reva=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	tag_t dataset = NULLTAG;
	tag_t refobject = NULLTAG;
	tag_t refobjectG = NULLTAG;
	tag_t datasetG = NULLTAG;
	tag_t CreoGenRev = NULLTAG;
	tag_t child_tag = NULLTAG;
	tag_t CompCodeQryTag = NULLTAG;
	tag_t ArchBomLineTag = bom_line_tag;

	char	*ArchName			= NULL;
	char	*ArchId				= NULL;
	char	*ArchType			= NULL;
	char	*rev_release_statuses	= NULL;
	char	*ChildRevName		= NULL;
	char	*ChildOwnName		= NULL;
	char	*ChildPrtType		= NULL;
	char	*ChildPrtQty		= NULL;
	char	*ChildQtyDup		= NULL;
	char	*ChildPrtUoM		= NULL;
	char	*ChildRelStatus		= NULL;
	char	*uid				= NULL;
	char	*aPotx1				= NULL;
	char	*mat_prov_ind	= NULL;
	char	*meas_unit		= NULL;
	char	*sr_no			= NULL;
	char	*tempcsrel		= NULL;
	char	*make_buy_ind 		= NULL;
	char	*make_buy_indDup 	= NULL;
	char	*ChildPartType		= NULL;
	char	*unit 				= NULL;
	char	*unitDup 			= NULL;
	char	*part_noDup 		= NULL;
	char	*part_noDup1	= NULL;
	int		ret = 0;
	logical bl_config_log = false;

	char		**attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char		**values = (char **) MEM_alloc(1 * sizeof(char *));
	meas_unit	= (char *) malloc(500 * sizeof(char));
	sr_no		= (char *) malloc(500 * sizeof(char));

	char **valuesCompCode = (char **) MEM_alloc(1 * sizeof(char *));
	
	depth ++;

	//printf("In ExpandMultiLevelBom Function....................\n");

	if (ParentBomLine != NULLTAG)
	{
		if( AOM_ask_value_string(ParentBomLine,"bl_item_item_id",&Parent_name)!=ITK_ok);
	}
	else
	{
		Parent_name =(char *) MEM_alloc(10);
		tc_strcpy(Parent_name,"-");
	}
	//printf("\nParent_name:[%s] \n",Parent_name); fflush(stdout);
	
	skipFlag=0;

	ITK_CALL(AOM_ask_value_int(bom_line_tag,"bl_level_starting_0",&level0));
	ITK_CALL(AOM_ask_value_string(bom_line_tag,"object_string",&ArchName));
	ITK_CALL(AOM_ask_value_string(bom_line_tag,"bl_child_id",&ArchId));
	ITK_CALL(AOM_ask_value_string(bom_line_tag,"bl_item_object_type",&ArchType));
	
	//printf("\nArchitecture Node %s,%s,%s",ArchName,ArchId,ArchType);fflush(stdout);
	
	if (tc_strcmp(ArchType, "T5_ArchModule") != 0 && tc_strcmp(ArchType, "T5_Platform") != 0)
	{
		BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID);
		BOM_line_ask_attribute_string(bom_line_tag, Item_ID, &ChildRevName);
		
		BOM_line_look_up_attribute ("bl_item_uom_tag",&Item_UoM);
		BOM_line_ask_attribute_string(bom_line_tag,Item_UoM,&ChildPrtUoM);

		BOM_line_look_up_attribute ("awb0RevisionOwningUser",&Item_Owner);
		BOM_line_ask_attribute_string(bom_line_tag,Item_Owner,&ChildOwnName);

		ITK_CALL(AOM_UIF_ask_value(bom_line_tag,"bl_rev_release_status_list",&ChildRelStatus));

		AOM_ask_value_string(bom_line_tag,"bl_quantity",&ChildPrtQty);
		tc_strdup(ChildPrtQty,&ChildQtyDup);

		AOM_ask_value_string(bom_line_tag,"bl_Design Revision_t5_PartType",&ChildPartType);
		AOM_ask_value_string(bom_line_tag,bl_mkbuy_string,&make_buy_ind);

	
		ITK_CALL(BOM_line_look_up_attribute ("bl_is_occ_configured",&Item_ID));
		ITK_CALL(BOM_line_ask_attribute_logical(bom_line_tag,Item_ID, &bl_config_log));

		ITK_CALL(AOM_ask_value_string(bom_line_tag,"bl_occ_t5_uidsap",&uid));
		tc_strdup(uid,&aPotx1);
		//printf("\nbl_config_log ChildRevName %s= [%d]",ChildRevName,bl_config_log);

		if(tc_strstr(ChildRelStatus,"STDSIC Released")==NULL)
		{
			printf("\nSkipping Child Part %s ChildRelStatus: %s Part not STDSIC Released",ChildRevName,ChildRelStatus);
			//fprintf(fsuccess,"\nSkipping Child Part %s ChildRelStatus: %s Part not STDSIC Released",ChildRevName,ChildRelStatus);
			skipFlag=1;
		}

		//printf("\nChild Part Number [%s] Part Qty [%s]	UoM [%s]	Owner [%s]",ChildRevName,ChildPrtQty,ChildPrtUoM,ChildOwnName);
		
		if(tc_strcmp(ChildPrtQty, "") == 0 || tc_strcmp(ChildPrtQty,"0") == 0)
		{
			printf("\nChild Part Number [%s] Part Qty [%s] hence skipping",ChildRevName,ChildPrtQty);
			skipFlag=1;
		}

		if (
			tc_strcmp(ChildPartType,"D")==0 ||
			tc_strcmp(ChildPartType,"DA")==0 ||
			tc_strcmp(ChildPartType,"DC")==0 ||
			tc_strcmp(ChildPartType,"IFD")==0 ||
			tc_strcmp(ChildPartType,"IM")==0 ||
			tc_strcmp(ChildPartType,"CP")==0 ||
			tc_strstr(ChildRevName,"_") !=NULL
			)
		{
			printf("\nSkipping Child Part [%s] as Part Type [%s]",ChildRevName,ChildPartType);
			skipFlag=1;
		}

		tc_strdup(make_buy_ind,&make_buy_indDup);

		if(tc_strlen(make_buy_ind)==0 || tc_strcmp(make_buy_ind,"NA")==0)
		{
			printf("\nSkipping Child Part [%s] as Plant Make/Buy is NULL or NA",ChildRevName);
			skipFlag=1;
		}

		if(tc_strlen(make_buy_ind)>0)
		{
			tc_strdup(make_buy_ind,&make_buy_indDup);

			if(tc_strcmp(make_buy_indDup,"F18") == 0)
			{
				tc_strdup("L",&mat_prov_ind);
				tc_strdup("1",&tempcsrel);
			}
			else
			{
				tc_strdup("",&mat_prov_ind);
				tc_strdup("X",&tempcsrel);
			}
		}
	
		if(tc_strlen(ChildPrtUoM)>0)
		{
			tc_strdup(ChildPrtUoM,&unitDup);
			if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
			else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
			else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
			else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
			else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
			else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
			else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
			else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
			else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
			else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
			else
			{
				tc_strdup("EA",&unitDup);
				tc_strcpy(meas_unit,"EA");
			}
		}
		else tc_strcpy(meas_unit,"EA");
			
		tc_strdup(ChildRevName,&part_noDup);
		floatQty = atof(ChildQtyDup);

		if (skipFlag==0)
		{
			printf("\nFinal Node [%s][%7.3f][%s][%s][%s]",part_noDup,floatQty,meas_unit,make_buy_indDup,aPotx1);
			
			tc_strcpy(sr_no,"");
			if(p_plm == NULL)
			{
				sr_no1 = 1 ;
				p_plm = createnode_mis(sr_no,part_noDup,ChildQtyDup,aPotx1);
				start_plm = p_plm;
			}
			else
			{
				q_plm = start_plm;
				while(q_plm->next != NULL)
				{
					 q_plm = q_plm->next;
				}
				sr_no1 = sr_no1 + 1 ;
				q_plm->next = createnode_mis(sr_no,part_noDup,ChildQtyDup,aPotx1);

			}
		}

	}

	ifail = BOM_line_ask_child_lines (bom_line_tag, &no_bom_lines, &child_bom_lines);

	//printf("\nNo_bom_lines: %d ",no_bom_lines);

	fflush(stdout);

	if (no_bom_lines > 0)
	{
		Parentlevel = level0;
		ParentBomLine = bom_line_tag;

		parent_bom = child_bom_lines;
		noOfChildinParent = no_bom_lines;

		//printf("\n	Parent Item_id_par: %s ",Item_id_par);
		fflush(stdout);
	}

	if (depth <= expansionLevel)
	{
		for (j = 0; j < no_bom_lines; j++)
		{
			ExpandMultiLevelBom (child_bom_lines[j], bom_line_tag, depth,ParentBomLine,parent_bom,noOfChildinParent);
		}

		if (no_bom_lines > 0)
		{
			MEM_free (child_bom_lines);
		}
	}

	return status;
}

extern int ITK_user_main (int argc, char ** argv )
{
    int status;
	struct usgProbnode *pUP = NULLTAG;

	char my_denis[14] = {0};

	tag_t ChildOPtr		= NULLTAG;
	tag_t ChildOPtrCpy	= NULLTAG;
	tag_t PartOPtr		= NULLTAG;
	tag_t *partObjs		= NULLTAG;

	char *sUserName		= NULL;
	char *sPassword 	= NULL;
	char *UsrGroup 		= NULL;
	char *AssyNo		= NULL;
	char *iPlatForm		= NULL;
	char *iSvrNumber	= NULL;
	char *sRevision		= NULL;
	char *sSequence		= NULL;

	int ci			= 0;
	int ei			= 0;
	int grind		= 0;
	int iPartIndex;
	int ret;
	int failflag		= 0;
	int i				= 0;
	int noOfChilds		= 0;
	int stat			= 0;
	int taskCount		= 0;
	int ia=0;
	int ja=0;
	int ka=0;
	int la=0;
	int ret1=0;

	char *AssyPrttype 		= NULL;
	char *AssyPrttypeDup 	= NULL;
	char *Revision 			= NULL;
	char *RevisionDup 		= NULL;
	char *assy_no 			= NULL;
	char *assy_noDup 		= NULL;
	char *date_updated 		= NULL;
	char *date_updatedDup 	= NULL;
	char *epaowner 			= NULL;
	char *epaownerDup 		= NULL;
	char *eparelzstate 		= NULL;
	char *eparelzstateDup 	= NULL;
	char *epataskId 		= NULL;
	char *epataskIdDup 		= NULL;
	char *part_no 			= NULL;
	char *taskId 			= NULL;
	char *taskIdDup 		= NULL;
	char *DispName 			= NULL;
	char *DispNameDup 		= NULL;
	char *PrtCls 			= NULL;
	char *PrtClsDup 		= NULL;
	char *cPrtCls			= NULL;
	char *owner				= NULL;
	char *ownerDup			= NULL;
	char *prjcode			= NULL;
	char *prjcodeDup 		= NULL;
	char *prtType 			= NULL;
	char *prtTypeDup 		= NULL;
	char *qty 				= NULL;
	char *qtyDup 			= NULL;
	char *qty_req_info 		= NULL;
	char *qty_req_infoDup 	= NULL;
	char *relzstate 		= NULL;
	char *relzstateDup 		= NULL;


	char *iOrganizationID	= NULL;
	char *StdDate			= NULL;
	char *MonYear			= NULL;
	char *inputDmlNumber	= NULL;
	char *inputPlantCode	= NULL;
	char *my_comp_part_sap	= NULL;

	int cnt = 0 ;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};


	char *AssemblyRevision 		= NULL;
	char *AssemblyRevisionDup 	= NULL;
	char *SequenceRevision 		= NULL;
	char *SequenceRevisionDup 	= NULL;
	
	int n_entries			= 0;
	int resultCount 		= 0;
	int CntChildP 			= 0;
	int ChildItemTag 		= 0;
	int n_closure_tags 		= 0;

	char		*LatRevName			= NULL;
	char		*Plant_MakeBuy		= NULL;
	char		*POwnerName			= NULL;
	char		*POwnerNameDup		= NULL;
	char		*InpRevSeq			= NULL;
	char		*PartRelStatus		= NULL;
	char		*PartRevSeq			= NULL;
	char		*PlantSuffix		= NULL;
	char		*RevisionRule	= NULL;
	char		*ClosureRule	= NULL;

	tag_t		VarientQryTag	= NULLTAG;
	tag_t		LatestPRev		= NULLTAG;
	tag_t		window			= NULLTAG;
	tag_t		ArchWindow		= NULLTAG;
	tag_t		rule			= NULLTAG;
	tag_t		*closure_tags	= NULLTAG;
	tag_t		closure_tag		= NULLTAG;
	tag_t		t_DMLRevision	= NULLTAG;

	tag_t		*outTag = NULLTAG;
	tag_t		PerentLine = NULLTAG;
	tag_t		ArchPerentLine = NULLTAG;
	tag_t		*ChildPartLine = NULLTAG;
	tag_t		ChildItemRevTag = NULLTAG;
	tag_t		*ChildArchLine = NULLTAG;
	tag_t		ArchBomLine_Tag = NULLTAG;
	tag_t		ArchMod_Tag		= NULLTAG;
	tag_t		*RwPartItemMst		= NULLTAG;
	tag_t		RwPartMstTag		= NULLTAG;
	tag_t		RwPartRel			= NULLTAG;
	tag_t		RawPartRelTag		= NULLTAG;

	tag_t		node_tag			= NULLTAG;
	tag_t		latestrev			= NULLTAG;
	tag_t		platformrev			= NULLTAG;
	tag_t		SVR_Rev_Tag			= NULLTAG;
	
	tag_t	*bom_variant_config		= NULLTAG;
	tag_t	*SVR_VCTags				= NULLTAG;
	tag_t	*tags_found				= NULLTAG;
	tag_t	*SVR_Tags				= NULLTAG;
	tag_t	ParentBomLineTag	= NULLTAG;
	tag_t	*ParentBom			= NULLTAG;

	tag_t	msExcelDS		= NULLTAG;
	tag_t	excelDataset	= NULLTAG;
	tag_t	excelDS_t		= NULLTAG;

	char	*item_type			= NULL;
	char	*curentname			= NULL;
	char	*pltfrm_str			= NULL;

	int		n_tags_found = 0,VcCount = 0,CntChildArch=0,a=0;
	logical modB = false;

	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **attrs1 = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	char **values1 = (char **) MEM_alloc(1 * sizeof(char *));

	int				ifail 						= ITK_ok;
	
	//fsuccess_name = (char *) MEM_alloc (sizeof (char) * 10000);
	ReportName = (char *) MEM_alloc (sizeof (char) * 10000);

	//ifail = ITK_init_module("ercpsup","ERCpsup2019","Engineering");
	//ifail = ITK_init_module("ercpsup","XYT1ESA","dba");

	ifail = ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	ifail = ITK_auto_login(TRUE);
    ifail = ITK_set_journalling(TRUE);

	sUserName		= ITK_ask_cli_argument("-u=loader");
	//sUserName		= ITK_ask_cli_argument("-u=infodba");
	//sPassword		= ITK_ask_cli_argument("-pf=/home/cmitest/shells/Admin/loaderpwffile.pwf");
	sPassword		= ITK_ask_cli_argument("-pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf");
	//sPassword		= ITK_ask_cli_argument("-pf=/user/uaprod/shells/Admin/infodbapassfile.pwf");
	UsrGroup		= ITK_ask_cli_argument("-g=dba");
	iPlatForm		= ITK_ask_cli_argument("-f=");
	iSvrNumber		= ITK_ask_cli_argument("-s=");
	plantcode		= ITK_ask_cli_argument("-t=");
	iSapServer		= ITK_ask_cli_argument("-c=");

	printf("\n%s\t%s\n",sUserName,sPassword);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
	}

	printf("\nInput Platform [%s] SVR [%s]	plantcode [%s]\n", iPlatForm,iSvrNumber,plantcode);

	tc_strdup(sRevision,&AssemblyRevisionDup);
	tc_strdup(sSequence,&SequenceRevisionDup);

	//sprintf(fsuccess_name,"/tmp/TCUA_SVR_BOM_Mismatch_%s.log",iSvrNumber);
	//sprintf(fsuccess_name,"/tmp/TCUA_SVR_BOM_Mismatch.log");
	//tc_strcpy(fsuccess_name,"/tmp/");
	//tc_strcpy(fsuccess_name,"/user/testcmi/devgroups/Amol/TCUA_SVR_BOM_Mismatch.log");

	/*fsuccess = fopen(fsuccess_name,"w");
	if(fsuccess == NULL)
	{
		printf("\nUnable To open Or Create Log  file\n");
		goto CLEANUP;
	}*/

	//sprintf(ReportName,"/tmp/SVR_UA_SAP_BOM_Compare_%s.csv",iSvrNumber);
	//sprintf(ReportName,"/tmp/SVR_UA_SAP_BOM_Compare.csv");

	fMisReport=fopen("/tmp/SVR_BOM_Compare_SAP.xml","w");

	//fMisReport = fopen(ReportName,"w");
	if(fMisReport == NULL)
	{
		printf("\nUnable To open Or Create csv  file");
		goto CLEANUP;
	}

	fprintf(fMisReport,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
	fprintf(fMisReport,"\n<Top>\n");

	char *qry_entries[1] = {"Name"};
	int one_entries = 1;

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	qry_values[0] = iSvrNumber;

	ITK_CALL(ITEM_find_item(iPlatForm, &node_tag));
	if (node_tag != NULLTAG)
	{
		//printf("PlatForm : %s Found\n",AssyNo);fflush(stdout);
		OUTS("PlatForm",10,30,iPlatForm);
		ITK_CALL(ITEM_ask_type2 (node_tag, &item_type));
		//printf("Main item_typeS [%s]\n",item_type);  fflush(stdout);
		OUTS("Main item_type",10,30,item_type);
	}
	else
	{
		//printf("PlatForm %s not found in TCUA\n",AssyNo);
		OUTS("PlatForm not found in TCUA",10,30,iPlatForm);
		goto CLEANUP;
	}

	if(tc_strcmp(item_type, "T5_Platform") == 0)	//Expanding Module BOM to TPL
	{
		attrs[0] = "item_id";
		values[0] = (char *)iPlatForm;

		ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

		ITK_CALL(ITEM_ask_latest_rev(node_tag,&latestrev));

		if (latestrev!=NULLTAG)
		{
			ITK_CALL( AOM_ask_value_string(latestrev,"object_string",&curentname));
			//printf("latest revision---------------> %s\n",curentname);fflush(stdout);
			OUTS("T5_Platform latest revision",10,30,curentname);
		}

	}

	MEM_free(attrs);
	MEM_free(values);
	if (n_tags_found == 0)
	{
		//printf("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", AssyNo);
		OUTS("ITEM_find_items_by_key_attributes returns success,  but didn't find",10,30,iPlatForm);
		goto CLEANUP;
	}
	else if (n_tags_found > 1)
	{
		MEM_free(tags_found);
		//printf( "More than one items matched with id %s\n", AssyNo);
		OUTS("More than one items matched with id",10,30,iPlatForm);
		goto CLEANUP;
	}

	ITK_CALL(ITEM_ask_item_of_rev(latestrev, &platformrev));
	ITK_CALL(AOM_ask_value_string(platformrev,"item_id",&pltfrm_str));
	//printf("pltfrm_str String Type is :%s\n",pltfrm_str); fflush(stdout);
	OUTS("pltfrm_str String Type",10,30,pltfrm_str);


	if(QRY_find("VariantRule", &VarientQryTag));
	ITK_CALL(QRY_execute(VarientQryTag, one_entries, qry_entries, qry_values, &resultCount, &SVR_Tags));

	printf("\nSVR Tag Found resultCount :%d:\n",resultCount);fflush(stdout);

	if (tc_strcmp(plantcode,"1100")==0)
	{
		tc_strdup("t5_CarMakeBuyIndicator",&Plant_MakeBuy);
		tc_strdup("bl_Design Revision_t5_CarMakeBuyIndicator",&bl_mkbuy_string);
		tc_strdup("STDC Released and Above",&RevisionRule);
		tc_strdup("BOMViewClosureRuleSTDC",&ClosureRule);
		tc_strdup("APLC",&PlantSuffix);
	}

	if(resultCount>0)
	{
		printf("\nSVR Found : %s Query Executed Succesfully",iSvrNumber);fflush(stdout);
		SVR_Rev_Tag = SVR_Tags[0];

		for (cnt=0;cnt< resultCount;cnt++ )
		{
			PartOPtr = SVR_Tags[0];

			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"object_string",&LatRevName));
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"owning_user",&POwnerName));
			tc_strdup(POwnerName,&POwnerNameDup);
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"release_status_list",&PartRelStatus));
			ITK_CALL(AOM_ask_value_string(PartOPtr,"object_type",&prtType));
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"current_name",&assy_no));
			ITK_CALL(AOM_ask_value_tags(PartOPtr,"T5_SVRDerivesCCV",&VcCount,&SVR_VCTags));
			tc_strdup(prtType,&prtTypeDup);
			tc_strdup(assy_no,&assy_noDup);

			printf("\nSVR Number: %s",iSvrNumber);fflush(stdout);


			//if(tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)
			if(tc_strstr(PartRelStatus,"ERC Released")!=NULL)
			{
				printf("\nSVRName: %s	ReleaseStatus: %s",LatRevName,PartRelStatus);fflush(stdout);
				//fprintf(fsuccess,"\nSVRName: %s	ReleaseStatus: %s",LatRevName,PartRelStatus);fflush(stdout);
			}
			else
			{
				printf("\nSVRName %s RelStatus: %s Part not Released...\n",LatRevName,PartRelStatus);
				//fprintf(fsuccess,"\nSVRName %s RelStatus: %s Part not Released...\n",LatRevName,PartRelStatus);
				//fprintf(fMisReport,"\nSVRName %s RelStatus: %s Part not Released...\n",LatRevName,PartRelStatus);
				//goto CLEANUP;
				//continue;
			}


			//Checking plant DML released
			/*if (tm_fnd_DML_PART(PlantSuffix,SVR_VCTags[0], &t_DMLRevision)!=1)
			{
				printf("\nValid Released DML not found for %s/%s, Checking Previous Revision\n",assy_no);
				continue;
			}*/

			if(tc_strcmp(prtTypeDup, "VariantRule") == 0)
			{
				printf("\nExpanding SVR BOM %s",assy_no);

				BOM_create_window (&window);		
				CFM_find(RevisionRule, &rule );
				printf("\nSetting RevisionRule : %s",RevisionRule);
				BOM_set_window_config_rule( window, rule );	
				//Setting Closure Rule Start
				printf("\nSetting ClosureRule : %s",ClosureRule);
				ITK_CALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &n_closure_tags, &closure_tags ));
				printf("\nn_closure_tags found %d",n_closure_tags);fflush(stdout);
				if(n_closure_tags > 0)
				{
					closure_tag=closure_tags[0];
					ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
				}
				else
				{
					goto CLEANUP;
				}
				//Setting Closure Rule End

				BOM_set_window_pack_all (window, false);
				BOM_set_window_top_line (window, NULLTAG, latestrev, NULLTAG, &PerentLine);
				BOM_line_ask_child_lines(PerentLine, &CntChildArch, &ChildArchLine);
				
				printf("\nBefore SVR No of Child Arch Modules %d\n",CntChildArch);

				//Applying SVR
				ITK_CALL(BOM_window_hide_unconfigured(window));
				ITK_CALL(BOM_window_show_variants(window));
				ITK_CALL(BOM_create_window_variant_config(window,1,&bom_variant_config));
				ITK_CALL(BOM_variant_config_apply (bom_variant_config));
				ITK_CALL(BOM_window_apply_variant_configuration(window,1,&SVR_Rev_Tag));
				ITK_CALL(BOM_window_hide_variants(window));
				ITK_CALL(BOM_window_ask_is_modified(window,&modB));
				ITK_CALL(BOM_line_ask_child_lines(PerentLine, &CntChildArch, &ChildArchLine));

				printf("\nAfter SVR No of Child Arch Modules %d\n",CntChildArch);

				ExpandMultiLevelBom (PerentLine, NULLTAG, 0 , ParentBomLineTag , ParentBom , 0);
				
				MEM_free (ChildArchLine);

				if(sr_no1 < 1)
				{
					printf("\nAssembly %s do not have structure in PLM",assy_no);fflush(stdout);
					fprintf(fMisReport,"\n<MISMATCH_STAT>");
					fprintf(fMisReport,"Assembly do not have structure in PLM %s",assy_no);
					fprintf(fMisReport,"</MISMATCH_STAT>");
					//fprintf(fMisReport,"\nAssembly %s do not have structure in PLM",assy_no);fflush(stdout);
					//goto CLEANUP;
				}
				else
				{
					Expand_SAP_SVR_BOM(assy_noDup);


					printf("\n\nPLM DATA..............\n");fflush(stdout);
					//fprintf(fsuccess,"\n\nPLM DATA..............\n");fflush(stdout);
					display_bom(start_plm);
					printf("\n\nSAP DATA..............\n");fflush(stdout);
					//fprintf(fsuccess,"\n\nSAP DATA..............\n");fflush(stdout);
					display_bom(start_sap);
					printf("\nMismatch Report.........\n");fflush(stdout);
					//fprintf(fsuccess,"\nMismatch Report.........\n");fflush(stdout);
					compare(start_plm,start_sap,iSvrNumber,plantcode);
					printf("\n.....................................\n");fflush(stdout);
					//fprintf(fsuccess,"\n.....................................\n");fflush(stdout);

					my_free_mis(&start_plm);
					my_free_mis(&start_sap);
				}

			}//If Module
			else
			{
				printf("\nDesign Revision [%s] has PartType %s Exiting...",assy_no,prtType);
				goto CLEANUP;
			}

		}//part objects for loop

	}
	else
	{ 
		printf ("\nSVR not found [%s]\n", iSvrNumber); fflush(stdout);
		fprintf(fMisReport,"\n<MISMATCH_STAT>");
		fprintf(fMisReport,"SVR not found %s",iSvrNumber);
		fprintf(fMisReport,"</MISMATCH_STAT>");
	}
	
	fprintf(fMisReport,"</Top>\n");
	fclose(fMisReport);

	/*ITK_CALL(AE_find_datasettype2("MSExcel",&msExcelDS)!=ITK_ok);
	if(msExcelDS == NULLTAG)
	{
		printf("\n Could not find Dataset\n");fflush(stdout);
		goto CLEANUP;
	}

	ITK_CALL(AE_create_dataset_with_id(msExcelDS,assy_no,"SVR_UA_SAP_BOM_Compare_Report","","",&excelDataset));
	ITK_CALL(AE_save_myself(excelDataset));
	//if(GRM_create_relation(Lat_Item_Tag,wordDataset,Iman_Ref_Rel_Tg,NULLTAG,&Part_Ref_Rel_t)!=ITK_ok)PrintErrorStack();
	//if(AOM_load(Part_Ref_Rel_t)!=ITK_ok)PrintErrorStack();
	//if(GRM_save_relation(Part_Ref_Rel_t)!=ITK_ok)PrintErrorStack();
	ITK_CALL(AE_ask_dataset_latest_rev(excelDataset,&excelDS_t));
	ITK_CALL(AOM_refresh(excelDS_t,TRUE));
	//if(AE_import_named_ref(wordLatestDat_t,"word",FileDown,NULL,SS_BINARY)!=ITK_ok)PrintErrorStack();
	ITK_CALL(AE_import_named_ref(excelDS_t,"excel",ReportName,NULL,SS_BINARY));
	//if(AE_import_named_ref(wordLatestDat_t,"Text",FileDown,NULL,SS_TEXT)!=ITK_ok)PrintErrorStack();
	ITK_CALL(AOM_load(excelDS_t));
	ITK_CALL(AE_save_myself(excelDS_t));
	//if(AOM_unlock(DMLRevTg)!=ITK_ok)PrintErrorStack();
	//if(AOM_refresh(Lat_Item_Tag,TRUE)!=ITK_ok)PrintErrorStack();
	
	remove(ReportName);
	if(ReportName) MEM_free(ReportName);*/

	CLEANUP:
	printf("\nCLEANUP...\n"); fflush(stdout);
	//fclose(fsuccess);
	ITK_CALL(POM_logout(false));
    ITK_exit_module(true);
}
;