#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>
#include <user_exits/user_exits.h>
#include "wmhelpe.h"
#include "bapi.h"
#include "bom_del.h"

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define GETINT(var,str) sprintf(str,"%ld",var);
#define GETINT2(var,str) sprintf(str,"%d",var);
#define NL printf("\n")

#define CONNECT_FAIL (EMH_USER_error_base + 2)

#define OUT(text,pos) printf("%*.0s",pos,text); printf("%s\n",text);

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{

  printf("%*.0s",pos,text); printf("%-*s : %s\n",len,text,str);
  //if (outfile!=NULL) fprintf(outfile,"=%s\n>%s\n",text,str);
  return;
}


void rfc_error(char *operation)
{
#ifdef SAPonNT
  char s[16];
#endif
  RFC_ERROR_INFO RfcErrorInfo;
  OUT("RFC error",0);
  OUTS("operation/code",0,15,operation);
  memset(&RfcErrorInfo,0,sizeof(RfcErrorInfo));
  RfcLastError(&RfcErrorInfo);
  OUTS("key",0,15,RfcErrorInfo.key);
  OUTS("status",0,15,RfcErrorInfo.status);
  OUTS("message",0,15,RfcErrorInfo.message);
  OUTS("internal status",0,15,RfcErrorInfo.intstat); NL;
  RfcClose (RFC_HANDLE_NULL);
#ifdef SAPonNT
  INS("","","Quit? [y]",4,24,s);
#endif
  exit(1);
}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

char *iSapServer = NULL;

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}



RFC_RC ZPPRFC_BDC_CS02
(
	RFC_HANDLE hRfc,
	MATERIAL_HEADER *eMATERIAL_HEADER,
	PLANT *ePLANT,
	BOM_USAGE *eBOM_USAGE,
	STLAL *eSTLAL,
	CHANGE_NO *eCHANGE_NO,
	SUBRC *iSUBRC,
	BAPIRET2 *iReturn,
	ITAB_H thZPP_RFC_BDC,
	char* xException
)
{
	RFC_PARAMETER Exporting[6];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[2];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL_HEADER";
	Exporting[0].nlen = tc_strlen("MATERIAL_HEADER");
	Exporting[0].type = handleOfMATERIAL_HEADER;
	Exporting[0].leng = sizeof(MATERIAL_HEADER);
	Exporting[0].addr = eMATERIAL_HEADER;

	Exporting[1].name = "PLANT";
	Exporting[1].nlen = tc_strlen("PLANT");
	Exporting[1].type = handleOfPLANT;
	Exporting[1].leng = sizeof(PLANT);
	Exporting[1].addr = ePLANT;

	Exporting[2].name = "BOM_USAGE";
	Exporting[2].nlen = tc_strlen("BOM_USAGE");
	Exporting[2].type = handleOfBOM_USAGE;
	Exporting[2].leng = sizeof(BOM_USAGE);
	Exporting[2].addr = eBOM_USAGE;

	Exporting[3].name = "STLAL";
	Exporting[3].nlen = tc_strlen("STLAL");
	Exporting[3].type = handleOfSTLAL;
	Exporting[3].leng = sizeof(STLAL);
	Exporting[3].addr = eSTLAL;

	Exporting[4].name = "CHANGE_NO";
	Exporting[4].nlen = tc_strlen("CHANGE_NO");
	Exporting[4].type = handleOfCHANGE_NO;
	Exporting[4].leng = sizeof(CHANGE_NO);
	Exporting[4].addr = eCHANGE_NO;
	
	Exporting[5].name = NULL;

	Tables[0].name     = "TABLE";
	Tables[0].nlen     = 5;
	Tables[0].type     = handleOfZPP_RFC_BDC;
	Tables[0].ithandle = thZPP_RFC_BDC;
	
	Tables[1].name = NULL;

	//Tables[0].name = NULL;

	RfcRc = RfcCall( hRfc, "ZPPRFC_BDC_CS02", Exporting, Tables ) ;

	switch (RfcRc)
	{
	  	case RFC_OK :
			
			Importing[0].name = "RETVAL";
			Importing[0].nlen = tc_strlen("RETVAL");
			Importing[0].type = handleOfSUBRC;
			Importing[0].leng = sizeof(SUBRC);
			Importing[0].addr = iSUBRC;


			/*Importing[1].name = "BAPIRET2";
			Importing[1].nlen = tc_strlen("BAPIRET2");
			Importing[1].type = handleOfBAPIRET2;
			Importing[1].leng = sizeof(BAPIRET2);
			Importing[1].addr = iBAPIRET2;*/

			Importing[0].name = "MESSG";
			Importing[0].nlen = 5;
			Importing[0].type = handleOfBAPIRET2;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = iReturn;

			
			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
	  			case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				default:
					break;
			}
		default:
			break;
	}
	return RfcRc;
}

void Delete_Child ( char *PlatForm, char* plantcode, char *dml_no_arg, char *itemid, char *ChildNo )
{
	RFC_HANDLE hRfc;
	RFC_RC RfcRc;
	char xException[1024] = { 0 };

	

	MATERIAL_HEADER eMATERIAL_HEADER;
	PLANT ePLANT;
	BOM_USAGE eBOM_USAGE;
	STLAL eSTLAL;
	CHANGE_NO eCHANGE_NO;
	SUBRC iSUBRC;
	BAPIRET2 iReturn;
	char sMessage[1024] = { 0 };
	char s[1024] = { 0 };
	int crow = 0;

	ZPP_RFC_BDC *tZPP_RFC_BDC;
	ITAB_H thZPP_RFC_BDC = ITAB_NULL;


	printf("PlatForm:%s,plantcode:%s,dml_no_arg:%s,itemid:%s,ChildNo:%s",PlatForm,plantcode,dml_no_arg,itemid,ChildNo);

	hRfc = BapiLogon ( );
	if ( hRfc == 0 )
	{
		printf ("\nRFC connection is not present.");
		return ;
	}

	SETCHAR(eMATERIAL_HEADER.MATNR,PlatForm);
	SETCHAR(ePLANT.WERKS,plantcode);
	//SETCHAR(ePLANT.WERKS,"1100");
	//SETCHAR(ePLANT.WERKS,"1001");
	SETCHAR(eBOM_USAGE.STLAN,"1");
	SETCHAR(eSTLAL.ALTNR,"01");
	//SETCHAR(eCHANGE_NO.AENNR,"ECNPP3216991");
	SETCHAR(eCHANGE_NO.AENNR,dml_no_arg);

	thZPP_RFC_BDC = ITAB_NULL;

	if ( thZPP_RFC_BDC == ITAB_NULL )
	{
		thZPP_RFC_BDC = ItCreate ( "TABLE", sizeof ( ZPP_RFC_BDC ), 0, 0 ) ;
		if ( thZPP_RFC_BDC == ITAB_NULL ) 
		{
			rfc_error ( "ItCreate TABLE" ) ;
		}
		else
		{
			printf("\nTABLE created");
		}
	}
	else if ( ItFree ( thZPP_RFC_BDC ) != 0 ) 
	{
		rfc_error ( "ItCreate TABLE" ) ;
	}

	tZPP_RFC_BDC = ItAppLine ( thZPP_RFC_BDC ) ;

	SETCHAR(tZPP_RFC_BDC->Item_No,itemid);
	SETCHAR(tZPP_RFC_BDC->Material_No,ChildNo);

	RfcRc = ZPPRFC_BDC_CS02
			(
				hRfc,
				&eMATERIAL_HEADER,
				&ePLANT,
				&eBOM_USAGE,
				&eSTLAL,
				&eCHANGE_NO,
				&iSUBRC,
				&iReturn,
				thZPP_RFC_BDC,
				xException
			);
	switch ( RfcRc )
	{
		case RFC_OK:
			//printf("\nOK %s",xException);
			NL;NL;
			for (crow = 1;crow <= ItFill(thZPP_RFC_BDC); crow++)
			{
				tZPP_RFC_BDC = ItGetLine(thZPP_RFC_BDC,crow);
				if (tZPP_RFC_BDC == NULL)
				{
					printf("\nItGetLineT_DEP_SOURCE\n");fflush(stdout);
				}
				GETCHAR(tZPP_RFC_BDC->Item_No,sMessage);
				OUTS("Item_No",10,30,sMessage);

				GETCHAR(tZPP_RFC_BDC->Material_No,sMessage);
				OUTS("Material_No",10,30,sMessage);
			}
			NL;NL;
			GETINT(iSUBRC.SUBRC,sMessage);
			OUTS("SUBRC",10,30,sMessage);
			NL;NL;
			
			//GETCHAR(iReturn.Message,s);
			//printf("\nMessage:[%s]",s);

			GETCHAR(iReturn.Type,s);
            OUTS("TYPE",10,30,s);
            GETCHAR(iReturn.Id,s);
            OUTS("ID",10,30,s);
            GETNUM(iReturn.Number,s);
            OUTS("NUMBER",10,30,s);
            GETCHAR(iReturn.Message,s);
            OUTS("MESSAGE",10,30,s);
            GETCHAR(iReturn.Log_No,s);
            OUTS("LOG_NO",10,30,s);
            GETNUM(iReturn.Log_Msg_No,s);
            OUTS("LOG_MSG_NO",10,30,s);
            GETCHAR(iReturn.Message_V1,s);
            OUTS("MESSAGE_V1",10,30,s);
            GETCHAR(iReturn.Message_V2,s);
            OUTS("MESSAGE_V2",10,30,s);
            GETCHAR(iReturn.Message_V3,s);
            OUTS("MESSAGE_V3",10,30,s);
            GETCHAR(iReturn.Message_V4,s);
            OUTS("MESSAGE_V4",10,30,s);
            GETCHAR(iReturn.Parameter,s);
            OUTS("PARAMETER",10,30,s);
            GETINT2(iReturn.Row,s);
            OUTS("ROW",10,30,s);
            GETCHAR(iReturn.Field,s);
            OUTS("FIELD",10,30,s);
            GETCHAR(iReturn.System,s);
            OUTS("SYSTEM",10,30,s);
            OUT("RETURN",8); NL;

		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
		break;
		default:
			printf("\nOther Failure!");
	}
	if ( ItDelete ( thZPP_RFC_BDC ) != 0 )	
	{
		rfc_error ( "ItDelete thZPP_RFC_BDC" ) ;
	}
	RfcClose ( hRfc ) ;
	printf("\nRFC connection is closed");
}
extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	char *sUserName = NULL;
	char *sPassword = NULL;
	char *inputPart = NULL;
	char *RevSeq = NULL;
	char *plantcode = NULL;
	char *dml_no_arg = NULL;
	char *ChildNo = NULL;
	char *itemid = NULL;
	char *PlatForm = NULL;
	/*ITK_CALL( ITK_initialize_text_services ( ITK_BATCH_TEXT_MODE ) );
	ITK_CALL( ITK_auto_login ( ) );
	ITK_CALL( ITK_set_journalling ( TRUE ) );*/

	/*sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	inputPart = ITK_ask_cli_argument("-d=");
	RevSeq = ITK_ask_cli_argument("-r=");
	plantcode = ITK_ask_cli_argument("-c=");
	dml_no_arg = ITK_ask_cli_argument("-w=");*/


	PlatForm = ITK_ask_cli_argument("-f=");
	plantcode = ITK_ask_cli_argument("-l=");
	dml_no_arg = ITK_ask_cli_argument("-d=");
	itemid = ITK_ask_cli_argument("-i=");
	ChildNo = ITK_ask_cli_argument("-c=");
	iSapServer = ITK_ask_cli_argument("-s=");
	
	
	
	Delete_Child(PlatForm,plantcode,dml_no_arg,itemid,ChildNo);

	ITK_CALL(POM_logout(false));
	return status;

}