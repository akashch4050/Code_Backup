#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"
#include "GetUpdCharVal.h"

#include <sa/sa.h>
#include <unidefs.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <stdarg.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <unidefs.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#include <pie/pie.h>

char *iSapServer = NULL;

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

RFC_HANDLE hRfc;
RFC_RC RfcRc;

struct OptionValue
{
	char Optname[50];
	char Optvalue[50];
	struct OptionValue *next;
};

void my_free(struct OptionValue* start)
{
	struct OptionValue* prev;
	struct OptionValue* ptr;
	printf("\nErazing Linklist Started...\n");
	for(prev = start, ptr = start; ptr != NULL, prev = ptr; ptr = ptr->next)
	{
		printf("#");
		free(prev);
	}
	start = NULL;
	printf("\nErazing Linklist Completed.\n");
	
}

struct OptionValue* createnode ( char Optname[50],char Optvalue[50] )
{
	struct OptionValue* p = NULL;
	p = ( struct OptionValue * ) malloc ( sizeof (struct OptionValue ) );
	tc_strcpy ( p->Optname , Optname );
	tc_strcpy ( p->Optvalue , Optvalue );
	p->next = NULL;
	return p;
}
int search(struct OptionValue* start,char *Optvalue)
{
	struct OptionValue* p;
	int found = 1 ;

	p = start;
	while ( p != NULL )
	{
		if ( tc_strcmp ( p->Optvalue , Optvalue) == 0 )
		{
			found = 0;
			break;
		}
		else
		{
			p = p->next;
			found = 1 ;
		}
	}
	return found;
}


void getTodayDateCal(char sTodaysDate[9])
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;

	time_t Tval = 0;
	Tval = time(0);
	Sys_T = localtime(&Tval);
	
	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;

	sprintf(sTodaysDate,"%04d%02d%02d",Year,Month,Day);
	
}


void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{

  printf("%*.0s",pos,text); printf("%-*s : %s\n",len,text,str);
  //if (outfile!=NULL) fprintf(outfile,"=%s\n>%s\n",text,str);
  return;
}

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

void  rfc_error(char *operation)
{
#ifdef SAPonNT
  char s[16];
#endif
  RFC_ERROR_INFO RfcErrorInfo;
  printf("\nRFC error");
  printf("\noperation/code: %s",operation);
  memset(&RfcErrorInfo,0,sizeof(RfcErrorInfo));
  RfcLastError(&RfcErrorInfo);
  printf("\nkey				%s",RfcErrorInfo.key);
  printf("\nstatus			%s",RfcErrorInfo.status);
  printf("\nmessage			%s",RfcErrorInfo.message);
  printf("\ninternal status %s",RfcErrorInfo.intstat);
  RfcClose (RFC_HANDLE_NULL);
  exit(1);
}
RFC_RC BAPI_OBJCL_GETDETAIL(RFC_HANDLE hRfc
				,BAPI1003_KEY_OBJECT *eBAPI1003_KEY_OBJECT
				,BAPI1003_KEY_OBJECTTABLE *eBAPI1003_KEY_OBJECTTABLE
				,BAPI1003_KEY_CLASSNUM *eBAPI1003_KEY_CLASSNUM
				,BAPI1003_KEY_CLASSTYPE *eBAPI1003_KEY_CLASSTYPE
				,BAPI1003_KEY_KEYDATE *eBAPI1003_KEY_KEYDATE
				,FLAG *eFLAG
				,BAPIFIELDSCACL_BAPILANGUA *eBAPIFIELDSCACL_BAPILANGUA

				,STATUS *iSTATUS
				,STANDARDCLASS *iSTANDARDCLASS
				,ITAB_H thALLOCVALUESNUM
				,ITAB_H thALLOCVALUESCHAR
				,ITAB_H thALLOCVALUESCURR
				,ITAB_H thRETURN
				,char *xException)
{
	RFC_PARAMETER Exporting[8];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[5];
	//RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "OBJECTKEY";
	Exporting[0].nlen = strlen("OBJECTKEY");
	Exporting[0].type = TYPC;
	Exporting[0].leng = sizeof(BAPI1003_KEY_OBJECT);
	Exporting[0].addr = eBAPI1003_KEY_OBJECT;

	Exporting[1].name = "OBJECTTABLE";
	Exporting[1].nlen = strlen("OBJECTTABLE");
	Exporting[1].type = TYPC;
	Exporting[1].leng = sizeof(BAPI1003_KEY_OBJECTTABLE);
	Exporting[1].addr = eBAPI1003_KEY_OBJECTTABLE;

	Exporting[2].name = "CLASSNUM";
	Exporting[2].nlen = strlen("CLASSNUM");
	Exporting[2].type = TYPC;
	Exporting[2].leng = sizeof(BAPI1003_KEY_CLASSNUM);
	Exporting[2].addr = eBAPI1003_KEY_CLASSNUM;

	Exporting[3].name = "CLASSTYPE";
	Exporting[3].nlen = strlen("CLASSTYPE");
	Exporting[3].type = TYPC;
	Exporting[3].leng = sizeof(BAPI1003_KEY_CLASSTYPE);
	Exporting[3].addr = eBAPI1003_KEY_CLASSTYPE;

	Exporting[4].name = "KEYDATE";
	Exporting[4].nlen = strlen("KEYDATE");
	Exporting[4].type = TYPDATE;
	Exporting[4].leng = sizeof(BAPI1003_KEY_KEYDATE);
	Exporting[4].addr = eBAPI1003_KEY_KEYDATE;

	Exporting[5].name = "UNVALUATED_CHARS";
	Exporting[5].nlen = strlen("UNVALUATED_CHARS");
	Exporting[5].type = TYPC;
	Exporting[5].leng = sizeof(FLAG);
	Exporting[5].addr = eFLAG;

	Exporting[6].name = "LANGUAGE";
	Exporting[6].nlen = strlen("LANGUAGE");
	Exporting[6].type = TYPC;
	Exporting[6].leng = sizeof(BAPIFIELDSCACL_BAPILANGUA);
	Exporting[6].addr = eBAPIFIELDSCACL_BAPILANGUA;

	Exporting[7].name = NULL;


	Tables[0].name     = "ALLOCVALUESNUM";
	Tables[0].nlen     = strlen("ALLOCVALUESNUM");
	Tables[0].type     = handleOfALLOCVALUESNUM;
	Tables[0].ithandle = thALLOCVALUESNUM;

	Tables[1].name     = "ALLOCVALUESCHAR";
	Tables[1].nlen     = strlen("ALLOCVALUESCHAR");
	Tables[1].type     = handleOfALLOCVALUESCHAR;
	Tables[1].ithandle = thALLOCVALUESCHAR;

	Tables[2].name     = "ALLOCVALUESCURR";
	Tables[2].nlen     = strlen("ALLOCVALUESCURR");
	Tables[2].type     = handleOfALLOCVALUESCURR;
	Tables[2].ithandle = thALLOCVALUESCURR;

	Tables[3].name     = "RETURN";
	Tables[3].nlen     = strlen("RETURN");
	Tables[3].type     = handleOfRETURN;
	Tables[3].ithandle = thRETURN;

	Tables[4].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_OBJCL_GETDETAIL",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			Importing[0].name = "STATUS";
			Importing[0].nlen = strlen("STATUS");
			Importing[0].type = handleOfSTATUS;
			Importing[0].leng = sizeof(STATUS);
			Importing[0].addr = iSTATUS;

			Importing[1].name = "STANDARDCLASS";
			Importing[1].nlen = strlen("STANDARDCLASS");
			Importing[1].type = handleOfSTANDARDCLASS;
			Importing[1].leng = sizeof(STANDARDCLASS);
			Importing[1].addr = iSTATUS;

			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			//printf("\nRfcException:%s",RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
		break;
	}
	return RfcRc;
}
RFC_RC BAPI_OBJCL_CHANGE(RFC_HANDLE hRfc
				,BAPI1003_KEY_OBJECT *eBAPI1003_KEY_OBJECT
				,BAPI1003_KEY_OBJECTTABLE *eBAPI1003_KEY_OBJECTTABLE
				,BAPI1003_KEY_CLASSNUM *eBAPI1003_KEY_CLASSNUM
				,BAPI1003_KEY_CLASSTYPE *eBAPI1003_KEY_CLASSTYPE
				//,STATUS *eSTATUS
				//,STANDARDCLASS *eSTANDARDCLASS
				,BAPI1003_KEY_STATUS_1* eBAPI1003_KEY_STATUS
				,BAPI1003_KEY_STDCLASS_1* eBAPI1003_KEY_STDCLASS
				,BAPI1003_KEY_CHANGENUMBER *eBAPI1003_KEY_CHANGENUMBER
				,BAPI1003_KEY_KEYDATE *eBAPI1003_KEY_KEYDATE
				,BAPI1003_KEY_FLAG *eNO_DEFAULT_VALUES
				,BAPI1003_KEY_FLAG *eKEEP_SAME_DEFAULTS
				,BAPI1003_KEY_STATUS *iBAPI1003_KEY_STATUS
				,ITAB_H thALLOCVALUESNUM
				,ITAB_H thALLOCVALUESCHAR
				,ITAB_H thALLOCVALUESCURR
				,ITAB_H thRETURN
				,char *xException)
{
	RFC_PARAMETER Exporting[11];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[5];
//	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "OBJECTKEY";
	Exporting[0].nlen = strlen("OBJECTKEY");
	Exporting[0].type = TYPC;
	Exporting[0].leng = sizeof(BAPI1003_KEY_OBJECT);
	Exporting[0].addr = eBAPI1003_KEY_OBJECT;

	Exporting[1].name = "OBJECTTABLE";
	Exporting[1].nlen = strlen("OBJECTTABLE");
	Exporting[1].type = TYPC;
	Exporting[1].leng = sizeof(BAPI1003_KEY_OBJECTTABLE);
	Exporting[1].addr = eBAPI1003_KEY_OBJECTTABLE;

	Exporting[2].name = "CLASSNUM";
	Exporting[2].nlen = strlen("CLASSNUM");
	Exporting[2].type = TYPC;
	Exporting[2].leng = sizeof(BAPI1003_KEY_CLASSNUM);
	Exporting[2].addr = eBAPI1003_KEY_CLASSNUM;

	Exporting[3].name = "CLASSTYPE";
	Exporting[3].nlen = strlen("CLASSTYPE");
	Exporting[3].type = TYPC;
	Exporting[3].leng = sizeof(BAPI1003_KEY_CLASSTYPE);
	Exporting[3].addr = eBAPI1003_KEY_CLASSTYPE;

	Exporting[4].name = "STATUS";
	Exporting[4].nlen = strlen("STATUS");
	Exporting[4].type = TYPC;
	Exporting[4].leng = sizeof(BAPI1003_KEY_STATUS_1);
	Exporting[4].addr = eBAPI1003_KEY_STATUS;

	Exporting[5].name = "STANDARDCLASS";
	Exporting[5].nlen = strlen("STANDARDCLASS");
	Exporting[5].type = TYPC;
	Exporting[5].leng = sizeof(BAPI1003_KEY_STDCLASS_1);
	Exporting[5].addr = eBAPI1003_KEY_STDCLASS;

	Exporting[6].name = "CHANGENUMBER";
	Exporting[6].nlen = strlen("CHANGENUMBER");
	Exporting[6].type = TYPC;
	Exporting[6].leng = sizeof(BAPI1003_KEY_CHANGENUMBER);
	Exporting[6].addr = eBAPI1003_KEY_CHANGENUMBER;


	Exporting[7].name = "KEYDATE";
	Exporting[7].nlen = strlen("KEYDATE");
	Exporting[7].type = TYPDATE;
	Exporting[7].leng = sizeof(BAPI1003_KEY_KEYDATE);
	Exporting[7].addr = eBAPI1003_KEY_KEYDATE;

	Exporting[8].name = "NO_DEFAULT_VALUES";
	Exporting[8].nlen = strlen("NO_DEFAULT_VALUES");
	Exporting[8].type = TYPC;
	Exporting[8].leng = sizeof(BAPI1003_KEY_FLAG);
	Exporting[8].addr = eNO_DEFAULT_VALUES;

	Exporting[9].name = "KEEP_SAME_DEFAULTS";
	Exporting[9].nlen = strlen("KEEP_SAME_DEFAULTS");
	Exporting[9].type = TYPC;
	Exporting[9].leng = sizeof(BAPI1003_KEY_FLAG);
	Exporting[9].addr = eKEEP_SAME_DEFAULTS;

	Exporting[10].name = NULL;


	Tables[0].name     = "ALLOCVALUESNUMNEW";
	Tables[0].nlen     = strlen("ALLOCVALUESNUMNEW");
	Tables[0].type     = handleOfALLOCVALUESNUM;
	Tables[0].ithandle = thALLOCVALUESNUM;

	Tables[1].name     = "ALLOCVALUESCHARNEW";
	Tables[1].nlen     = strlen("ALLOCVALUESCHARNEW");
	Tables[1].type     = handleOfALLOCVALUESCHAR;
	Tables[1].ithandle = thALLOCVALUESCHAR;

	Tables[2].name     = "ALLOCVALUESCURRNEW";
	Tables[2].nlen     = strlen("ALLOCVALUESCURRNEW");
	Tables[2].type     = handleOfALLOCVALUESCURR;
	Tables[2].ithandle = thALLOCVALUESCURR;

	Tables[3].name     = "RETURN";
	Tables[3].nlen     = strlen("RETURN");
	Tables[3].type     = handleOfRETURN;
	Tables[3].ithandle = thRETURN;

	Tables[4].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_OBJCL_CHANGE",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:


			Importing[0].name = "CLASSIF_STATUS";
			Importing[0].nlen = strlen("CLASSIF_STATUS");
			Importing[0].type = handleOfBAPI1003_KEY_STATUS;
			Importing[0].leng = sizeof(BAPI1003_KEY_STATUS);
			Importing[0].addr = iBAPI1003_KEY_STATUS;


			Importing[1].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			//printf("\nRfcException2:%s",RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
		break;
	}
	//printf("\nhi");
	return RfcRc;
}
RFC_RC BAPI_TRANSACTION_COMMIT(RFC_HANDLE hRfc,
		BAPITA_WAIT *eBAPITA_WAIT,
		RETURN *iRETURN,
		char* xException)
{
	RFC_PARAMETER Exporting[2];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[1];
//	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "BAPITA_WAIT";
	Exporting[0].nlen = strlen("BAPITA_WAIT");
	Exporting[0].type = TYPC;
	Exporting[0].leng = sizeof(BAPITA_WAIT);
	Exporting[0].addr = eBAPITA_WAIT;

	Exporting[1].name = NULL;

	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_TRANSACTION_COMMIT",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:


			Importing[0].name = "RETURN";
			Importing[0].nlen = strlen("RETURN");
			Importing[0].type = handleOfRETURN;
			Importing[0].leng = sizeof(RETURN);
			Importing[0].addr = iRETURN;

			Importing[1].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			//printf("\nRfcException3:%s",RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
		break;
	}
	return RfcRc;

}
/*cll_BAPI_TRANSACTION_COMMIT(RFC_RC RfcRc)
{
	char *xException = NULL;
	BAPITA_WAIT eBAPITA_WAIT;
	RETURN iRETURN;

	SETCHAR(eBAPITA_WAIT,"X");

	RfcRc = BAPI_TRANSACTION_COMMIT(hRfc,
				&eBAPITA_WAIT,
				&iRETURN,
				xException
			);
	switch (RfcRc)
	{
		case RFC_OK:
			printf("\nCommitted...");
			break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			exit(0);
		break;
		default:
			printf("\nOther Failure!");
			exit(0);
	}
}*/
cll_BAPI_OBJCL_CHANGE ( char *KmatPartNo, char *OptionMastr, struct OptionValue *start )
{
//	RFC_HANDLE hRfc;
//	RFC_RC RfcRc;
//	RFC_RC RfcRc2;
	struct OptionValue *p = NULL;
	BAPI1003_KEY_OBJECT eBAPI1003_KEY_OBJECT;
	BAPI1003_KEY_OBJECTTABLE eBAPI1003_KEY_OBJECTTABLE;
	BAPI1003_KEY_CLASSNUM eBAPI1003_KEY_CLASSNUM;
	BAPI1003_KEY_CLASSTYPE eBAPI1003_KEY_CLASSTYPE;
	//STATUS eSTATUS;
	//STANDARDCLASS eSTANDARDCLASS;

	BAPI1003_KEY_STATUS_1 eBAPI1003_KEY_STATUS;
	BAPI1003_KEY_STDCLASS_1 eBAPI1003_KEY_STDCLASS;


	BAPI1003_KEY_CHANGENUMBER eBAPI1003_KEY_CHANGENUMBER;
	BAPI1003_KEY_KEYDATE eBAPI1003_KEY_KEYDATE;
	BAPI1003_KEY_FLAG eNO_DEFAULT_VALUES;
	BAPI1003_KEY_FLAG eKEEP_SAME_DEFAULTS;

	BAPI1003_KEY_STATUS iBAPI1003_KEY_STATUS;

	char xException[1024] = { 0 };
	char s[1024] = { 0 };
	char s1[1024] = { 0 };
	char s2[1024] = { 0 };
	char s3[1024] = { 0 };
	int crow = 0;
	char sTodaysDate[9] = { 0 };

	ALLOCVALUESNUM *tALLOCVALUESNUM;
	ITAB_H thALLOCVALUESNUM = ITAB_NULL;

	ALLOCVALUESCHAR *tALLOCVALUESCHAR;
	ITAB_H thALLOCVALUESCHAR = ITAB_NULL;

	ALLOCVALUESCURR *tALLOCVALUESCURR;
	ITAB_H thALLOCVALUESCURR = ITAB_NULL;

	RETURN *tRETURN;
	ITAB_H thRETURN = ITAB_NULL;

	//----------------------------
	//char *xException = NULL;
	BAPITA_WAIT eBAPITA_WAIT;
	RETURN iRETURN;

	//----------------------------

	getTodayDateCal(sTodaysDate);

	//SETCHAR(eBAPI1003_KEY_OBJECT,"X4_SAP1");
	SETCHAR(eBAPI1003_KEY_OBJECT,KmatPartNo);	//kmat
	SETCHAR(eBAPI1003_KEY_OBJECTTABLE,"MARA");
	SETCHAR(eBAPI1003_KEY_CLASSNUM,OptionMastr);	//option val class
	SETCHAR(eBAPI1003_KEY_CLASSTYPE,"300");
	SETCHAR(eBAPI1003_KEY_STATUS,"1");
	SETCHAR(eBAPI1003_KEY_STDCLASS,"");
	SETCHAR(eBAPI1003_KEY_CHANGENUMBER,"");
	SETDATE(eBAPI1003_KEY_KEYDATE,sTodaysDate);
	SETCHAR(eNO_DEFAULT_VALUES,"");
	SETCHAR(eKEEP_SAME_DEFAULTS,"");


	thALLOCVALUESNUM = ITAB_NULL;
	if (thALLOCVALUESNUM==ITAB_NULL)
	{
		thALLOCVALUESNUM = ItCreate("ALLOCVALUESNUMNEW",sizeof(ALLOCVALUESNUM),0,0);
		if (thALLOCVALUESNUM==ITAB_NULL)
				rfc_error("ItCreate ALLOCVALUESNUMNEW");
	}
	else
	{
		if (ItFree(thALLOCVALUESNUM) != 0)
			rfc_error("ItFree ALLOCVALUESNUM");
	}

	thALLOCVALUESCHAR = ITAB_NULL;
	if (thALLOCVALUESCHAR==ITAB_NULL)
	{
		thALLOCVALUESCHAR = ItCreate("ALLOCVALUESCHARNEW",sizeof(ALLOCVALUESCHAR),0,0);
		if (thALLOCVALUESCHAR==ITAB_NULL)
				rfc_error("ItCreate ALLOCVALUESCHARNEW");
	}
	else
	{
		if (ItFree(thALLOCVALUESCHAR) != 0)
			rfc_error("ItFree ALLOCVALUESCHAR");
	}

	thALLOCVALUESCURR = ITAB_NULL;
	if (thALLOCVALUESCURR==ITAB_NULL)
	{
		thALLOCVALUESCURR = ItCreate("ALLOCVALUESCURRNEW",sizeof(ALLOCVALUESCURR),0,0);
		if (thALLOCVALUESCURR==ITAB_NULL)
				rfc_error("ItCreate ALLOCVALUESCURRNEW");
	}
	else
	{
		if (ItFree(thALLOCVALUESCURR) != 0)
			rfc_error("ItFree ALLOCVALUESCURR");
	}

	thRETURN = ITAB_NULL;
	if (thRETURN==ITAB_NULL)
	{
		thRETURN = ItCreate("RETURN",sizeof(RETURN),0,0);
		if (thRETURN==ITAB_NULL)
				rfc_error("ItCreate RETURN");
	}
	else
	{
		if (ItFree(thRETURN) != 0)
			rfc_error("ItFree RETURN");
	}
	
	for(p = start; p != NULL; p = p -> next)
	{
		OUTS ( p->Optname , 10 ,60 , p->Optvalue ) ;

		tALLOCVALUESCHAR = ItAppLine ( thALLOCVALUESCHAR ) ;

		if (tALLOCVALUESCHAR == NULL)
			printf("ItAppLine ALLOCVALUESCHAR");
		SETCHAR(tALLOCVALUESCHAR->CHARACT,p->Optname);
		SETCHAR(tALLOCVALUESCHAR->VALUE_CHAR,p->Optvalue);
		SETCHAR(tALLOCVALUESCHAR->INHERITED,"");
		SETCHAR(tALLOCVALUESCHAR->INSTANCE,"000");
		SETCHAR(tALLOCVALUESCHAR->VALUE_NEUTRA,"");
		SETCHAR(tALLOCVALUESCHAR->CHARACT_DESCR,"");
	}

	/*tALLOCVALUESCHAR = ItAppLine ( thALLOCVALUESCHAR ) ;
	if (tALLOCVALUESCHAR == NULL)
		printf("ItAppLine ALLOCVALUESCHAR");
	SETCHAR(tALLOCVALUESCHAR->CHARACT,"N_COLOR");
	SETCHAR(tALLOCVALUESCHAR->VALUE_CHAR,"RED");
	SETCHAR(tALLOCVALUESCHAR->INHERITED,"");
	SETCHAR(tALLOCVALUESCHAR->INSTANCE,"000");
	SETCHAR(tALLOCVALUESCHAR->VALUE_NEUTRA,"");
	SETCHAR(tALLOCVALUESCHAR->CHARACT_DESCR,"");

	tALLOCVALUESCHAR = ItAppLine ( thALLOCVALUESCHAR ) ;
	if (tALLOCVALUESCHAR == NULL)
		printf("ItAppLine ALLOCVALUESCHAR");
	SETCHAR(tALLOCVALUESCHAR->CHARACT,"N_COLOR");
	SETCHAR(tALLOCVALUESCHAR->VALUE_CHAR,"BLACK");
	SETCHAR(tALLOCVALUESCHAR->INHERITED,"");
	SETCHAR(tALLOCVALUESCHAR->INSTANCE,"000");
	SETCHAR(tALLOCVALUESCHAR->VALUE_NEUTRA,"");
	SETCHAR(tALLOCVALUESCHAR->CHARACT_DESCR,"");

	tALLOCVALUESCHAR = ItAppLine ( thALLOCVALUESCHAR ) ;
	if (tALLOCVALUESCHAR == NULL)
		printf("ItAppLine ALLOCVALUESCHAR");
	SETCHAR(tALLOCVALUESCHAR->CHARACT,"N_COLOR");
	SETCHAR(tALLOCVALUESCHAR->VALUE_CHAR,"WHITE");
	SETCHAR(tALLOCVALUESCHAR->INHERITED,"");
	SETCHAR(tALLOCVALUESCHAR->INSTANCE,"000");
	SETCHAR(tALLOCVALUESCHAR->VALUE_NEUTRA,"");
	SETCHAR(tALLOCVALUESCHAR->CHARACT_DESCR,"");

	tALLOCVALUESCHAR = ItAppLine ( thALLOCVALUESCHAR ) ;
	if (tALLOCVALUESCHAR == NULL)
		printf("ItAppLine ALLOCVALUESCHAR");
	SETCHAR(tALLOCVALUESCHAR->CHARACT,"N_COLOR");
	SETCHAR(tALLOCVALUESCHAR->VALUE_CHAR,"RED1");
	SETCHAR(tALLOCVALUESCHAR->INHERITED,"");
	SETCHAR(tALLOCVALUESCHAR->INSTANCE,"000");
	SETCHAR(tALLOCVALUESCHAR->VALUE_NEUTRA,"");
	SETCHAR(tALLOCVALUESCHAR->CHARACT_DESCR,"");

	tALLOCVALUESCHAR = ItAppLine ( thALLOCVALUESCHAR ) ;
	if (tALLOCVALUESCHAR == NULL)
		printf("ItAppLine ALLOCVALUESCHAR");
	SETCHAR(tALLOCVALUESCHAR->CHARACT,"N_COLOR");
	SETCHAR(tALLOCVALUESCHAR->VALUE_CHAR,"WHITE1");
	SETCHAR(tALLOCVALUESCHAR->INHERITED,"");
	SETCHAR(tALLOCVALUESCHAR->INSTANCE,"000");
	SETCHAR(tALLOCVALUESCHAR->VALUE_NEUTRA,"");
	SETCHAR(tALLOCVALUESCHAR->CHARACT_DESCR,"");

	tALLOCVALUESCHAR = ItAppLine ( thALLOCVALUESCHAR ) ;
	if (tALLOCVALUESCHAR == NULL)
		printf("ItAppLine ALLOCVALUESCHAR");
	SETCHAR(tALLOCVALUESCHAR->CHARACT,"N_COLOR");
	SETCHAR(tALLOCVALUESCHAR->VALUE_CHAR,"RED2");
	SETCHAR(tALLOCVALUESCHAR->INHERITED,"");
	SETCHAR(tALLOCVALUESCHAR->INSTANCE,"000");
	SETCHAR(tALLOCVALUESCHAR->VALUE_NEUTRA,"");
	SETCHAR(tALLOCVALUESCHAR->CHARACT_DESCR,"");*/

	hRfc = BapiLogon();

	printf("\nbefore ItFill(thALLOCVALUESCHAR) : %d",ItFill(thALLOCVALUESCHAR));

	RfcRc = BAPI_OBJCL_CHANGE(hRfc
				,&eBAPI1003_KEY_OBJECT
				,&eBAPI1003_KEY_OBJECTTABLE
				,&eBAPI1003_KEY_CLASSNUM
				,&eBAPI1003_KEY_CLASSTYPE
				,&eBAPI1003_KEY_STATUS
				,&eBAPI1003_KEY_STDCLASS
				,&eBAPI1003_KEY_CHANGENUMBER
				,&eBAPI1003_KEY_KEYDATE
				,&eNO_DEFAULT_VALUES
				,&eKEEP_SAME_DEFAULTS
				,&iBAPI1003_KEY_STATUS
				,thALLOCVALUESNUM
				,thALLOCVALUESCHAR
				,thALLOCVALUESCURR
				,thRETURN
				,xException);
	//printf("\nafter call");
	switch (RfcRc)
	{
		case RFC_OK:
			GETCHAR(iBAPI1003_KEY_STATUS.CLASSIF_STATUS,s);
			printf("\niBAPI1003_KEY_STATUS : %s",s);

			printf("\nItFill(thALLOCVALUESNUM) : %d",ItFill(thALLOCVALUESNUM));
			printf("\nItFill(thALLOCVALUESCHAR) : %d",ItFill(thALLOCVALUESCHAR));
			printf("\nItFill(thALLOCVALUESCURR) : %d",ItFill(thALLOCVALUESCURR));
			printf("\nItFill(thRETURN) : %d",ItFill(thRETURN));
			printf("\n");

			for (crow = 1;crow <= ItFill(thALLOCVALUESCHAR); crow++)
			{
				tALLOCVALUESCHAR = ItGetLine(thALLOCVALUESCHAR,crow);
				if (tALLOCVALUESCHAR == NULL)
				{
					printf("\nItGetLine ALLOCVALUESCHAR\n");fflush(stdout);
				}
				NL;
				GETCHAR(tALLOCVALUESCHAR->CHARACT,s);
				OUTS("CHARACT",10,30,s);

				GETCHAR(tALLOCVALUESCHAR->VALUE_CHAR,s);
				OUTS("VALUE_CHAR",10,30,s);

				GETCHAR(tALLOCVALUESCHAR->INHERITED,s);
				OUTS("INHERITED",10,30,s);

				GETCHAR(tALLOCVALUESCHAR->INSTANCE,s);
				OUTS("INSTANCE",10,30,s);

				GETCHAR(tALLOCVALUESCHAR->VALUE_NEUTRA,s);
				OUTS("VALUE_NEUTRA",10,30,s);

				GETCHAR(tALLOCVALUESCHAR->CHARACT_DESCR,s);
				OUTS("CHARACT_DESCR",10,30,s);
			}
			NL;NL;
			for (crow = 1;crow <= ItFill(thRETURN); crow++)
			{
				tRETURN = ItGetLine(thRETURN,crow);
				if (tRETURN == NULL)
				{
					printf("\nItGetLine RETURN\n");fflush(stdout);
				}

				GETCHAR(tRETURN->TYPE,s);
				OUTS("TYPE",10,30,s);
				GETCHAR(tRETURN->ID,s);
				OUTS("ID",10,30,s);
				GETNUM(tRETURN->NUMBER,s);
				OUTS("NUMBER",10,30,s);
				GETCHAR(tRETURN->MESSAGE,s);
				OUTS("MESSAGE",10,30,s);
				GETCHAR(tRETURN->LOG_NO,s);
				OUTS("LOG_NO",10,30,s);
				GETNUM(tRETURN->LOG_MSG_NO,s);
				OUTS("LOG_MSG_NO",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V1,s);
				OUTS("MESSAGE_V1",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V2,s);
				OUTS("MESSAGE_V2",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V3,s);
				OUTS("MESSAGE_V3",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V4,s);
				OUTS("MESSAGE_V4",10,30,s);
				GETCHAR(tRETURN->PARAMETER,s);
				OUTS("PARAMETER",10,30,s);
				GETINT2(tRETURN->ROW,s);
				OUTS("ROW",10,30,s);
				GETCHAR(tRETURN->FIELD,s);
				OUTS("FIELD",10,30,s);
				GETCHAR(tRETURN->SYSTEM,s);
				OUTS("SYSTEM",10,30,s);
			}
		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			exit(0);
		break;
		default:
			printf("\nOther Failure!");
			exit(0);
	}
	

	//cll_BAPI_TRANSACTION_COMMIT(RfcRc);
	//--------------------commit called

	
	SETCHAR(eBAPITA_WAIT," ");

	RfcRc = BAPI_TRANSACTION_COMMIT(hRfc,
				&eBAPITA_WAIT,
				&iRETURN,
				xException
			);
	switch (RfcRc)
	{
		case RFC_OK:
			NL;NL;
			GETCHAR(iRETURN.TYPE,s);
			OUTS("TYPE",10,30,s);
			GETCHAR(iRETURN.ID,s);
			OUTS("ID",10,30,s);
			GETNUM(iRETURN.NUMBER,s);
			OUTS("NUMBER",10,30,s);
			GETCHAR(iRETURN.MESSAGE,s);
			OUTS("MESSAGE",10,30,s);
			GETCHAR(iRETURN.LOG_NO,s);
			OUTS("LOG_NO",10,30,s);
			GETNUM(iRETURN.LOG_MSG_NO,s);
			OUTS("LOG_MSG_NO",10,30,s);
			GETCHAR(iRETURN.MESSAGE_V1,s);
			OUTS("MESSAGE_V1",10,30,s);
			GETCHAR(iRETURN.MESSAGE_V2,s);
			OUTS("MESSAGE_V2",10,30,s);
			GETCHAR(iRETURN.MESSAGE_V3,s);
			OUTS("MESSAGE_V3",10,30,s);
			GETCHAR(iRETURN.MESSAGE_V4,s);
			OUTS("MESSAGE_V4",10,30,s);
			GETCHAR(iRETURN.PARAMETER,s);
			OUTS("PARAMETER",10,30,s);
			GETINT2(iRETURN.ROW,s);
			OUTS("ROW",10,30,s);
			GETCHAR(iRETURN.FIELD,s);
			OUTS("FIELD",10,30,s);
			GETCHAR(iRETURN.SYSTEM,s);
			OUTS("SYSTEM",10,30,s);
			printf("\nCommitted...");
			break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			exit(0);
		break;
		default:
			printf("\nOther Failure!");
			exit(0);
	}

	if ( ItDelete ( thALLOCVALUESNUM ) != 0 )
	{
		rfc_error ( "ItDelete thALLOCVALUESNUM" ) ;
	}

	if ( ItDelete ( thALLOCVALUESCHAR ) != 0 )
	{
		rfc_error ( "ItDelete thALLOCVALUESCHAR" ) ;
	}

	if ( ItDelete ( thALLOCVALUESCURR ) != 0 )
	{
		rfc_error ( "ItDelete thALLOCVALUESCURR" ) ;
	}

	if ( ItDelete ( thRETURN ) != 0 )
	{
		rfc_error ( "ItDelete thRETURN" ) ;
	}

	RfcClose(hRfc);
}
cll_BAPI_OBJCL_GETDETAIL(char *KmatPartNo, char *OptionMastr)
{
//	RFC_HANDLE hRfc;
//	RFC_RC RfcRc;

	BAPI1003_KEY_OBJECT eBAPI1003_KEY_OBJECT;
	BAPI1003_KEY_OBJECTTABLE eBAPI1003_KEY_OBJECTTABLE;
	BAPI1003_KEY_CLASSNUM eBAPI1003_KEY_CLASSNUM;
	BAPI1003_KEY_CLASSTYPE eBAPI1003_KEY_CLASSTYPE;
	BAPI1003_KEY_KEYDATE eBAPI1003_KEY_KEYDATE;
	FLAG eFLAG;
	BAPIFIELDSCACL_BAPILANGUA eBAPIFIELDSCACL_BAPILANGUA;

	char xException[1024] = { 0 };
	char s[1024] = { 0 };
	char s1[1024] = { 0 };
	char s2[1024] = { 0 };
	char s3[1024] = { 0 };
	STATUS iSTATUS;
	STANDARDCLASS iSTANDARDCLASS;
	int crow = 0;
	char sTodaysDate[9] = { 0 };


	ALLOCVALUESNUM *tALLOCVALUESNUM;
	ITAB_H thALLOCVALUESNUM = ITAB_NULL;

	ALLOCVALUESCHAR *tALLOCVALUESCHAR;
	ITAB_H thALLOCVALUESCHAR = ITAB_NULL;

	ALLOCVALUESCURR *tALLOCVALUESCURR;
	ITAB_H thALLOCVALUESCURR = ITAB_NULL;

	RETURN *tRETURN;
	ITAB_H thRETURN = ITAB_NULL;

	getTodayDateCal(sTodaysDate);

	SETCHAR(eBAPI1003_KEY_OBJECT,KmatPartNo);
	SETCHAR(eBAPI1003_KEY_OBJECTTABLE,"MARA");
	SETCHAR(eBAPI1003_KEY_CLASSNUM,OptionMastr);
	SETCHAR(eBAPI1003_KEY_CLASSTYPE,"300");
	//SETDATE(eBAPI1003_KEY_KEYDATE,"20190410");//10.04.2019
	SETDATE(eBAPI1003_KEY_KEYDATE,sTodaysDate);
	SETCHAR(eFLAG," ");
	SETCHAR(eBAPIFIELDSCACL_BAPILANGUA,"E");



	thALLOCVALUESNUM = ITAB_NULL;
	if (thALLOCVALUESNUM==ITAB_NULL)
	{
		thALLOCVALUESNUM = ItCreate("ALLOCVALUESNUM",sizeof(ALLOCVALUESNUM),0,0);
		if (thALLOCVALUESNUM==ITAB_NULL)
				rfc_error("ItCreate ALLOCVALUESNUM");
	}
	else
	{
		if (ItFree(thALLOCVALUESNUM) != 0)
			rfc_error("ItFree ALLOCVALUESNUM");
	}

	thALLOCVALUESCHAR = ITAB_NULL;
	if (thALLOCVALUESCHAR==ITAB_NULL)
	{
		thALLOCVALUESCHAR = ItCreate("ALLOCVALUESCHAR",sizeof(ALLOCVALUESCHAR),0,0);
		if (thALLOCVALUESCHAR==ITAB_NULL)
				rfc_error("ItCreate ALLOCVALUESCHAR");
	}
	else
	{
		if (ItFree(thALLOCVALUESCHAR) != 0)
			rfc_error("ItFree ALLOCVALUESCHAR");
	}

	thALLOCVALUESCURR = ITAB_NULL;
	if (thALLOCVALUESCURR==ITAB_NULL)
	{
		thALLOCVALUESCURR = ItCreate("ALLOCVALUESCURR",sizeof(ALLOCVALUESCURR),0,0);
		if (thALLOCVALUESCURR==ITAB_NULL)
				rfc_error("ItCreate ALLOCVALUESCURR");
	}
	else
	{
		if (ItFree(thALLOCVALUESCURR) != 0)
			rfc_error("ItFree ALLOCVALUESCURR");
	}

	thRETURN = ITAB_NULL;
	if (thRETURN==ITAB_NULL)
	{
		thRETURN = ItCreate("RETURN",sizeof(RETURN),0,0);
		if (thRETURN==ITAB_NULL)
				rfc_error("ItCreate RETURN");
	}
	else
	{
		if (ItFree(thRETURN) != 0)
			rfc_error("ItFree RETURN");
	}

	hRfc = BapiLogon();

	RfcRc = BAPI_OBJCL_GETDETAIL(hRfc
				,&eBAPI1003_KEY_OBJECT
				,&eBAPI1003_KEY_OBJECTTABLE
				,&eBAPI1003_KEY_CLASSNUM
				,&eBAPI1003_KEY_CLASSTYPE
				,&eBAPI1003_KEY_KEYDATE
				,&eFLAG
				,&eBAPIFIELDSCACL_BAPILANGUA
				,&iSTATUS
				,&iSTANDARDCLASS
				,thALLOCVALUESNUM
				,thALLOCVALUESCHAR
				,thALLOCVALUESCURR
				,thRETURN
				,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			GETCHAR(iSTATUS.STATUS,s);
			printf("\niSTATUS : %s",s);
			GETCHAR(iSTANDARDCLASS.STANDARDCLASS,s);
			printf("\niSTANDARDCLASS : %s",s);

			printf("\nItFill(thALLOCVALUESNUM) : %d",ItFill(thALLOCVALUESNUM));
			printf("\nItFill(thALLOCVALUESCHAR) : %d",ItFill(thALLOCVALUESCHAR));
			printf("\nItFill(thALLOCVALUESCURR) : %d",ItFill(thALLOCVALUESCURR));
			printf("\nItFill(thRETURN) : %d",ItFill(thRETURN));
			printf("\n");

			for (crow = 1;crow <= ItFill(thALLOCVALUESCHAR); crow++)
			{
				tALLOCVALUESCHAR = ItGetLine(thALLOCVALUESCHAR,crow);
				if (tALLOCVALUESCHAR == NULL)
				{
					printf("\nItGetLine ALLOCVALUESCHAR\n");fflush(stdout);
				}
				NL;
				GETCHAR(tALLOCVALUESCHAR->CHARACT,s);
				OUTS("CHARACT",10,30,s);

				GETCHAR(tALLOCVALUESCHAR->VALUE_CHAR,s);
				OUTS("VALUE_CHAR",10,30,s);

				GETCHAR(tALLOCVALUESCHAR->INHERITED,s);
				OUTS("INHERITED",10,30,s);

				GETCHAR(tALLOCVALUESCHAR->INSTANCE,s);
				OUTS("INSTANCE",10,30,s);

				GETCHAR(tALLOCVALUESCHAR->VALUE_NEUTRA,s);
				OUTS("VALUE_NEUTRA",10,30,s);

				GETCHAR(tALLOCVALUESCHAR->CHARACT_DESCR,s);
				OUTS("CHARACT_DESCR",10,30,s);





			}
			NL;NL;
			for (crow = 1;crow <= ItFill(thRETURN); crow++)
			{
				tRETURN = ItGetLine(thRETURN,crow);
				if (tRETURN == NULL)
				{
					printf("\nItGetLine RETURN\n");fflush(stdout);
				}

				GETCHAR(tRETURN->TYPE,s);
				OUTS("TYPE",10,30,s);
				GETCHAR(tRETURN->ID,s);
				OUTS("ID",10,30,s);
				GETNUM(tRETURN->NUMBER,s);
				OUTS("NUMBER",10,30,s);
				GETCHAR(tRETURN->MESSAGE,s);
				OUTS("MESSAGE",10,30,s);
				GETCHAR(tRETURN->LOG_NO,s);
				OUTS("LOG_NO",10,30,s);
				GETNUM(tRETURN->LOG_MSG_NO,s);
				OUTS("LOG_MSG_NO",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V1,s);
				OUTS("MESSAGE_V1",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V2,s);
				OUTS("MESSAGE_V2",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V3,s);
				OUTS("MESSAGE_V3",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V4,s);
				OUTS("MESSAGE_V4",10,30,s);
				GETCHAR(tRETURN->PARAMETER,s);
				OUTS("PARAMETER",10,30,s);
				GETINT2(tRETURN->ROW,s);
				OUTS("ROW",10,30,s);
				GETCHAR(tRETURN->FIELD,s);
				OUTS("FIELD",10,30,s);
				GETCHAR(tRETURN->SYSTEM,s);
				OUTS("SYSTEM",10,30,s);

			}

		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			exit(0);
		break;
		default:
			printf("\nOther Failure!");
			exit(0);
	}
	if ( ItDelete ( thALLOCVALUESNUM ) != 0 )
	{
		rfc_error ( "ItDelete thALLOCVALUESNUM" ) ;
	}

	if ( ItDelete ( thALLOCVALUESCHAR ) != 0 )
	{
		rfc_error ( "ItDelete thALLOCVALUESCHAR" ) ;
	}

	if ( ItDelete ( thALLOCVALUESCURR ) != 0 )
	{
		rfc_error ( "ItDelete thALLOCVALUESCURR" ) ;
	}

	if ( ItDelete ( thRETURN ) != 0 )
	{
		rfc_error ( "ItDelete thRETURN" ) ;
	}

	RfcClose(hRfc);

}
extern int ITK_user_main(int argc, char ** argv )
{


	int status = ITK_ok;

	char *sUserName = NULL;
	char *sPassword = NULL;
	char *KmatPartNo = NULL;
	char *OptionMastr = NULL;

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	//sUserName = ITK_ask_cli_argument("-u=");
	//sPassword = ITK_ask_cli_argument("-p=");
	KmatPartNo = ITK_ask_cli_argument("-k=");
	OptionMastr = ITK_ask_cli_argument("-o=");
	iSapServer = ITK_ask_cli_argument("-s=");

	//---------
	
	Get_plm_Attr_and_Val ( KmatPartNo ,OptionMastr );

	//cll_BAPI_OBJCL_GETDETAIL(KmatPartNo,OptionMastr);	//to get all char of input class and kmat

	//cll_BAPI_OBJCL_CHANGE( KmatPartNo, OptionMastr, start );		//change char of input class and kmat


	ITK_CALL(POM_logout(false));
	return status;
}

Get_plm_Attr_and_Val ( char *KmatPartNo , char *OptionMastr )
{
	tag_t platfrm_tag = NULLTAG;
	char *item_type = NULL;
	tag_t relation_dep = NULLTAG;
	int countConfigCtx = 0;
	tag_t *ConfigCtxSecObject = NULLTAG;
	char *SmCrIDContext = NULL;
	int j1 = 0;
	tag_t Optfmly_tag = NULLTAG;
	char *OptfmlyDesc = NULL;
	char *OptfmlyName = NULL;
	char **qry_valuesOptFamVal = ( char ** ) MEM_alloc ( 10 * sizeof ( char * ) );
	char *Context_Str = NULL;
	tag_t ConfigCtx = NULLTAG;

	tag_t queryTag = NULLTAG;
	int n_entries = 1;
	char *qry_entries[1] = { "ID" }; 
	char **qry_values = ( char ** ) MEM_alloc ( 10 * sizeof ( char * ) );
	int resultCount = 0; 
	tag_t *familtopttag = NULLTAG;

	tag_t queryTagOptFamVal = NULLTAG;
	int n_entriesOptFamVal = 2;
	char *qry_entriesOptFamVal[] = { "Thread ID" , "ID" };
	int resultCountOptFamVal = 0;
	tag_t *revOptFamVal = NULLTAG;
	int i = 0;
	
	tag_t OptfmlyVal_tag = NULLTAG;
	char *OptValName = NULL;
	char *OptValDesc = NULL;
	struct OptionValue *start = NULL;
	struct OptionValue *p = NULL;
	struct OptionValue *q = NULL;
	char *Optfmly_type = NULL;
	start = NULL;
	p = NULL;
	q = NULL;
//	ret = 0;

	OptValName = ( char * ) malloc ( 50 * sizeof ( char ) ) ;
	OptValDesc = ( char * ) malloc ( 50 * sizeof ( char ) ) ;

	ITK_CALL( ITEM_find_item ( KmatPartNo, &platfrm_tag ) );
	if ( platfrm_tag != NULLTAG )
	{
		ITK_CALL ( ITEM_ask_type2 ( platfrm_tag, &item_type ) );
		printf("\nitem_type:%s",item_type);
	}
	else
	{
		return ;
	}
	if ( tc_strcmp( item_type ,"T5_Platform" ) == 0 )
	{
		

		OptfmlyDesc = ( char * ) malloc ( 50 * sizeof ( char ) ) ;
		OptfmlyName = ( char * ) malloc ( 50 * sizeof ( char ) ) ;

		ITK_CALL(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
		if(relation_dep != NULLTAG)
		{
			printf("\nVariant ConfigContext relation found......");
		}
		
		ITK_CALL(GRM_list_secondary_objects_only(platfrm_tag,relation_dep,&countConfigCtx,&ConfigCtxSecObject));

		if ( countConfigCtx > 0 )
		{

			ConfigCtx = ConfigCtxSecObject [ 0 ] ;

			ITK_CALL(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
			printf("\nSmCrIDContext Object String Type is :%s",SmCrIDContext);

			ITK_CALL(AOM_ask_value_string(ConfigCtx,"item_id",&Context_Str));
			printf("\nContext_Str :%s",Context_Str);	fflush(stdout);

			qry_values[0] = SmCrIDContext;
			
			if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
			//printf("\nAfter Cfg0OptionFamiliesFromIDs : QRY_find");
			if (queryTag)
			{
				//printf("\n\tFound Query");
			}
			else
			{
				printf("\nNot Found Query");
			}	
			
			ITK_CALL( QRY_execute ( queryTag, n_entries, qry_entries, qry_values, &resultCount, &familtopttag ) );

			for ( j1 = 0; j1 < resultCount; j1++ )
			{			  
				
				Optfmly_tag = familtopttag[j1];
				ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyDesc));
				ITK_CALL(AOM_ask_value_string(Optfmly_tag,"current_desc",&OptfmlyName));
				//printf("\nContextobjName Object String Type is %s:%s [%d]",OptfmlyDesc,OptfmlyName,tc_strlen(OptfmlyName));

				ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_type",&Optfmly_type));
				printf("\tOptfmly type:[%-30s]",Optfmly_type);  fflush(stdout);

				if ( tc_strcmp(Optfmly_type, "Cfg0PackageOptionFamily" ) == 0 )
				{
					printf("\tSkipping"); fflush(stdout);
					continue;
				}

				if(tc_strlen(OptfmlyName) == 0)
				{
					printf("\nError:object_desc is null for object_name:%s raise error with BOM process team",OptfmlyDesc);
					continue;
				}

				if ( tc_strlen ( OptfmlyName ) > 30 )
				{
					printf("\nError:Can not create characteristic for option name [%s] length is more than 30 character contact BOM process team length:%d",OptfmlyName,tc_strlen ( OptfmlyName ));
					exit ( 0 ); //it should show error and come out
					//continue;
				}


				qry_valuesOptFamVal[0]= OptfmlyDesc;
				qry_valuesOptFamVal[1]= Context_Str;
				if(QRY_find("__Cfg0OptionValuesFromOptionFamilyIDs", &queryTagOptFamVal));
				//printf("\nAfter __Cfg0OptionValuesFromOptionFamilyIDs: QRY_find");
				if (queryTagOptFamVal)
				{
					//printf("\nFound Query");
				}
				else
				{
					printf("\nNot Found Query");
				}
				ITK_CALL ( QRY_execute ( queryTagOptFamVal, n_entriesOptFamVal, qry_entriesOptFamVal, qry_valuesOptFamVal, &resultCountOptFamVal, &revOptFamVal ) ) ;
				//printf("\nresultCountOptFamVal:%d",resultCountOptFamVal);
				for ( i = 0; i < resultCountOptFamVal ; i++ )
				{
					OptfmlyVal_tag = revOptFamVal[i];
					ITK_CALL(AOM_ask_value_string(OptfmlyVal_tag,"object_name",&OptValName));
					ITK_CALL(AOM_ask_value_string(OptfmlyVal_tag,"current_name",&OptValDesc));
					//printf("\nValue Object String  is :%s",OptValName);	
					if ( p == NULL )
					{
						p = createnode ( OptfmlyName, OptValName ) ;
						start = p;
					}
					else
					{
						q = start;
						while ( q->next != NULL )
						{
							q = q->next;
						}
						q->next = createnode ( OptfmlyName, OptValName ) ;
					}
				}//get option value
			}//get option descr
			/*NL;NL;
			for(p = start; p != NULL; p = p -> next)
			{
				OUTS ( p->Optname , 10 ,60 , p->Optvalue ) ;
			}
			my_free(start);*/
			cll_BAPI_OBJCL_CHANGE( KmatPartNo, OptionMastr, start );
			my_free(start);
		}
	}
}