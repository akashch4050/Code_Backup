/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : SAPBomCreateChangeUA.c
* Created By                   : Amol Narke
* Created On                   : 11/05/2020
* Project                      : Tata Motors TCUA-SAP Interface
* Methods Defined              :
* Description                  : TCUA - SAP DML Wise BOM Transfer
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <tccore/tctype.h>

#include "wmhelpe.h"
#include "bapi.h"

//#include "t.h"
//#include "ppe.h"
//#include "saprfc.h"
//#include "sapitab.h"

struct node
{
	char sr_no[5];
	char *part;
	float qty;
	char uq[4];
	char tempcsrel[2];
	char mat_prov_ind[2];
	char * make_buy_indDup;
	float usgProb;
	struct node *next;
};
struct usgProbnode
{
	char sr_no[5];
	char *part;
	float usgProb;
	struct usgProbnode *next;
};

int FetchPlantSpecificData(char* DMLNumber,char* ProjCode);
void displaying_objects(void);
RFC_RC cll_ccap_ecn_create(RFC_HANDLE);
RFC_RC ccap_ecn_create(RFC_HANDLE hRfc,AENR_API01 *,CSDATA_XFELD *,CSDATA_XFELD *,CSDATA_XFELD *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AEEF_API01 *,AENRB_AENNR *,ITAB_H,ITAB_H,ITAB_H,ITAB_H,ITAB_H,char *);
struct node* createnode(char sr_no[5],char *part,float* qty,char uq[4],char tempcsrel[2],char mat_prov_ind[2],char *make_buy_indDup);
int search(struct node* start,char *part,float* qty);
void SapBomCreate(struct node *head,char *assy_noDup,char *AssemblyRevisionDup,char *SequenceRevisionDup,char *OrganizationIDDup);
void SapBomChange(struct node *head,char *assy_noDup,char *AssemblyRevisionDup,char *SequenceRevisionDup,char *OrganizationIDDup);
RFC_RC cad_create_bom_with_sub_items(RFC_HANDLE hRfc, DRAW_LOEDK *eIAutoPosnr, CAD_BICSK *eIBomHeader, CAD_BICSK *iEBomHeader, MESSAGE_MSGTX *iEMessage, CAD_RETURN_MESSAGE_LEN *iEMessageLen, CAD_RETURN_VALUE *iEReturn, ITAB_H thBomItem, char *xException);
RFC_RC zcad_change_bom_with_sub_items(RFC_HANDLE hRfc,CAD_BICSK *eIBomHeader,CAD_RETURN_VALUE *iEReturn,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_BICSK *iEBomHeader,ITAB_H thBomItem,char *xException);
RFC_RC UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2(RFC_HANDLE	hRfc, MARA_MATNR *eMARA_MATNR, MARC_WERKS *eMARC_WERKS, STZU_STLAN *eSTZU_STLAN, STKO_STLAL *eSTKO_STLAL, TC04_CAPID *eTC04_CAPID, STKO_DATUV *eSTKO_DATUV, ITAB_H thSTB, ITAB_H thMATCAT, char *xException );

struct usgProbnode* createnode2(char sr_no[5],char *part,float* usgProb);
struct usgProbnode* GetUsageProb(char *assy_noDup);
void my_free2(struct usgProbnode* start);
void compareUsage(struct usgProbnode *pUP,struct node *start);
void display1(struct node *head,char *assy_noDup);
void display2(struct usgProbnode *head,char *assy_noDup);
void my_free(struct node* start);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);

int findNextRelRev(tag_t CurRevTag);
int ExpandBomForCreate(tag_t LatestRev,char *DML_Numb);

FILE* fsuccess;
FILE* fp=NULL;
FILE* finsp;
FILE* fval;

char fsuccess_name[200];
char fisa_name[200];
char fvac_name[200];

WERKS_D eWerks;
static MATNR eMatnr;

tag_t		*TaskRevision			= NULLTAG;
tag_t		TaskRevTag			= NULLTAG;
tag_t		*PartTags			= NULLTAG;

int tcount=0,pcount=0,TaskCnt=0,PartCnt=0;

char *iSapServer=NULL;
char *projectcode=NULL;
char *assy_noDup=NULL;
char *make_buy_indDup=NULL;
char *make_buy_ind=NULL;
char *blk_ind = NULL;
char *plantcode=NULL;
char *Plant_MakeBuy=NULL;
char *Plant_StoreLoc=NULL;
char *bl_mkbuy_string	= NULL;
char *profit_centre2=NULL;
char *plan_calendar2=NULL;
char *overhd_grp2=NULL;
char *origin_group2=NULL;
char *profit_centre_sap = NULL;
char *plan_calendar = NULL;
char *overhd_grp = NULL;
char *origin_group=NULL;
char *DMLDescription=NULL;
char *apl_release_date=NULL;
char *PrtRev=NULL;
char *PrtRevDup=NULL;
char *PrtSeqDup=NULL;
char *OwnerNameDup=NULL;
char *OwnerName=NULL;
char *SAPpstat=NULL;
char *MRPpstat=NULL;
char *PlantSuffix	= NULL;

char	pstat;
char	pstat_mrp;
char	pstat_acc;
char dml_no_arg[14]={0};
char dml_numAP1[14]={0};

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
void rfc_error(char *);

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

void trimString(char * str)
{
	int i = 0;
    for (i = 0; i < tc_strlen(str); i++)
	{
		//printf("\n%d %c",i,str[i]);
		if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
		{
			str[i] = '\0';
		}
	}
}

void my_free(struct node* start)
{
	struct node* prev;
	struct node* ptr;
	printf("\nErazing Linklist Started...\n");
	fprintf(fsuccess,"\nErazing Linklist Started...\n");
	//for(prev = start, ptr = start; ptr != NULL, prev = ptr;ptr = ptr->next)
	for(prev = start, ptr = start; ptr != NULL, prev = ptr;ptr = ptr->next)
	{
		printf("#");
		fprintf(fsuccess,"#");
		free(prev);
	}
	start = NULL;
	printf("\nErazing Linklist Completed.\n");
	fprintf(fsuccess,"\nErazing Linklist Completed.\n");

}

void my_free2(struct usgProbnode* start)
{
	struct usgProbnode* prev;
	struct usgProbnode* ptr;
	printf("\nErazing Linklist Started...\n");
	fprintf(fsuccess,"\nErazing Linklist Started...\n");
	for(prev = start, ptr = start; ptr != NULLTAG, prev = ptr;ptr = ptr->next)
	{
		printf("#");
		fprintf(fsuccess,"#");
		free(prev);
	}
	start = NULLTAG;
	printf("\nErazing Linklist Completed.\n");
	fprintf(fsuccess,"\nErazing Linklist Completed.\n");

}
struct usgProbnode* createnode2(char sr_no[5],char *part,float* usgProb)
{
	struct usgProbnode* q=NULL;
	//printf("In createnode2 Function....\n");
	q=(struct usgProbnode*)malloc(sizeof(struct usgProbnode));
	q->part=part;
	strcpy(q->sr_no,sr_no);
	q->usgProb = *usgProb;
	q->next=NULL;
	return q;
}

int search(struct node* start,char *part,float* qty)
{
	struct node* p;
	int found = 1 ;

	p=start;
	/*while(p->next!=NULL)*/
	while(p!=NULL)
	{
			if(strcmp(p->part,part)==0)
			{
					//found;
					p->qty = p->qty + *qty;
					found = 0;
					break;
			}
			else
			{
				p=p->next;
				found = 1 ;
			}

		}
	return found;
}

struct node* createnode(char sr_no[5],char *part,float* qty,char uq[4],char tempcsrel[2],char mat_prov_ind[2],char *make_buy_indDup)
{
	struct node* p = NULL;

	p = (struct node*)malloc(sizeof(struct node));
	//strcpy(p->part,part);
	p->part = part;
	tc_strcpy(p->sr_no,sr_no);
	tc_strcpy(p->uq,uq);
	tc_strcpy(p->mat_prov_ind,mat_prov_ind);
	tc_strcpy(p->tempcsrel,tempcsrel);
	p->make_buy_indDup = make_buy_indDup;
	p->qty = *qty;
	p->usgProb = 0.000f;
	p->next = NULL;
	return p;
}

void displaying_objects(void)
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;

	hRfc = BapiLogon();
	printf("\ncalling the change no creation function");
	RfcRc = cll_ccap_ecn_create(hRfc);
	RfcClose(hRfc);
}

void display1(struct node *head,char *assy_noDup)
{
	struct node *p=NULL;
	//fprintf(fp,"\n%15s", assy_noDup);
	for(p = head; p != NULL; p = p -> next)
	{
		printf("\n\t %s %-15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel);
		fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel);
		//fprintf(fp,"\n%15s", p -> part);
	}

}

void SapBomCreate(struct node *head,char *assy_noDup,char *AssemblyRevisionDup,char *SequenceRevisionDup,char *OrganizationIDDup)
{
	struct node *p=NULL;
	char sap_qty[18];
	char s[1024] = {0};
	char ReturnValue[2]={0};
	char ReturnMessage[1024] = {0};
    int plantflg=0;
	char xException[256];
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;

	CAD_BICSK eIBomHeader;
	DRAW_LOEDK eIAutoPosnr;
	CAD_BICSK iEBomHeader;
	MESSAGE_MSGTX iEMessage;
	CAD_RETURN_MESSAGE_LEN iEMessageLen;
	CAD_RETURN_VALUE iEReturn;
	ITAB_H thBomItem = ITAB_NULL;
	CAD_BOM_ITEM *tBomItem;

	hRfc = BapiLogon();
	thBomItem = ITAB_NULL;
	if (thBomItem==ITAB_NULL)
	{
		thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
		if (thBomItem==ITAB_NULL)
				rfc_error("ItCreateBOM_ITEM");
	}
	else
	{
		if (ItFree(thBomItem) != 0)
			rfc_error("ItFreeBOM_ITEM");
	}

	printf("\nAssembly:[%s]",assy_noDup);
	printf("\nChange No:[%s]",dml_no_arg);
	printf("\nPlant:[%s]",plantcode);

	printf("\nAssembly:[%s,%s,%s]",assy_noDup,dml_no_arg,plantcode);
	fprintf(fsuccess,"\nAssembly:[%s,%s,%s]",assy_noDup,dml_no_arg,plantcode);


	SETCHAR(eIAutoPosnr,"");
	SETCHAR(eIBomHeader.Matnr,assy_noDup);
	SETCHAR(eIBomHeader.Werks,plantcode);
	SETCHAR(eIBomHeader.Stlan,"1");
	SETCHAR(eIBomHeader.Stlal,"01");
	SETCHAR(eIBomHeader.Aennr,dml_no_arg);
	SETCHAR(eIBomHeader.Datuv,"");
	SETCHAR(eIBomHeader.Stype,"");
	SETCHAR(eIBomHeader.Tcode,"");
	SETCHAR(eIBomHeader.Bmein,"");
	SETCHAR(eIBomHeader.Bmeng,"");
	SETCHAR(eIBomHeader.Cadkz,"");
	SETCHAR(eIBomHeader.Datub,"");
	SETCHAR(eIBomHeader.Emeng,"");
	SETCHAR(eIBomHeader.Equnr,"");
	SETCHAR(eIBomHeader.Exstl,"");
	SETCHAR(eIBomHeader.Labor,"");
	SETCHAR(eIBomHeader.Loekz,"");
	SETCHAR(eIBomHeader.Losbs,"");
	SETCHAR(eIBomHeader.Losvn,"");
	SETCHAR(eIBomHeader.Selal,"");
	SETCHAR(eIBomHeader.Serge,"");
	SETCHAR(eIBomHeader.Stktx,"");
	SETCHAR(eIBomHeader.Stlbe,"");
	SETCHAR(eIBomHeader.Stlst,"");
	SETCHAR(eIBomHeader.Vmtnr,"");
	SETCHAR(eIBomHeader.Ztext,"");
	SETCHAR(eIBomHeader.Revlv,"");
	SETCHAR(eIBomHeader.Tplnr,"");
	SETCHAR(eIBomHeader.Dokar,"");
	SETCHAR(eIBomHeader.Doknr,"");
	SETCHAR(eIBomHeader.Doktl,"");
	SETCHAR(eIBomHeader.Dokvr,"");
	SETCHAR(eIBomHeader.Vbeln,"");
	SETNUM(eIBomHeader.Vbpos,"000000");
	SETCHAR(eIBomHeader.Stobj,"");
	SETCHAR(eIBomHeader.Vdknr,"");
	SETCHAR(eIBomHeader.Vdkar,"");
	SETCHAR(eIBomHeader.Vdktl,"");
	SETCHAR(eIBomHeader.Vdkvr,"");
	SETCHAR(eIBomHeader.Veqnr,"");
	SETCHAR(eIBomHeader.Vtpnr,"");
	SETCHAR(eIBomHeader.Pspnr,"");
	SETCHAR(eIBomHeader.Oitxt,"");
	SETCHAR(eIBomHeader.MatnrLong,"");



	for(p = head; p != NULL; p = p -> next)
	{
		sprintf(sap_qty,"%7.3f", p->qty);
		printf("\n\t %s %-15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel);
		fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel);

		tBomItem = ItAppLine(thBomItem);
		if (tBomItem == NULL)
		printf("ItAppLineBOM_ITEM");

		SETCHAR(tBomItem->Idnrk,p->part);
		SETCHAR(tBomItem->Menge,sap_qty);
		SETCHAR(tBomItem->Postp,"L");
		SETCHAR(tBomItem->Posnr,p->sr_no);
	
		if(*assy_noDup=='G')
		{
			SETCHAR(tBomItem->Alpgr,"a1");
			SETNUM(tBomItem->Alprf,"1");
			//SETCHAR(tBomItem->Ewahr,"000");
			//plantflg=PlantChk(plantcode);

			if(tc_strcmp(p->sr_no,"0001")==0)
			{
				SETCHAR(tBomItem->Ewahr,"100");
			}
			else
			{
			   SETCHAR(tBomItem->Ewahr,"000");
			}
			
			SETCHAR(tBomItem->Alpst,"1");
		}
		else
		{
			SETCHAR(tBomItem->Alpgr,"");
			SETNUM(tBomItem->Alprf,"");
			SETCHAR(tBomItem->Ewahr,"");
			SETCHAR(tBomItem->Alpst,"");
		}
		SETCHAR(tBomItem->Verti,"");
		SETCHAR(tBomItem->Sanka,p->tempcsrel);
		SETCHAR(tBomItem->Sanfe,"");
		SETCHAR(tBomItem->Beikz,p->mat_prov_ind);
		SETCHAR(tBomItem->Selsb,"");
		SETCHAR(tBomItem->Schgt,"");
		SETCHAR(tBomItem->Meins,p->uq);
		SETCHAR(tBomItem->Potx1,"");
		SETCHAR(tBomItem->Dspst,"");
		SETCHAR(tBomItem->Lgort,"");
		SETCHAR(tBomItem->Sortf,"");
		SETCHAR(tBomItem->Potx2,"");
		SETCHAR(tBomItem->Upskz,"");
		SETCHAR(tBomItem->Auskz,"");
		SETCHAR(tBomItem->Alpos,"");
		SETCHAR(tBomItem->Ausch,"0.00");
		SETCHAR(tBomItem->Avoau,"0.00");
		SETCHAR(tBomItem->Cadpo,"");
		SETCHAR(tBomItem->Ekgrp,"");
		SETCHAR(tBomItem->Erskz,"");
		SETCHAR(tBomItem->Fmeng,"");
		SETCHAR(tBomItem->Lifnr,"");
		SETCHAR(tBomItem->Lifzt,"");
		SETCHAR(tBomItem->Matkl,"");
		SETCHAR(tBomItem->Netau,"");
		SETCHAR(tBomItem->Nfmat,"");
		SETCHAR(tBomItem->Nlfzt,"");
		SETCHAR(tBomItem->Peinh,"");
		SETCHAR(tBomItem->Preis,"");
		SETCHAR(tBomItem->Pswrk,"");
		SETCHAR(tBomItem->Rekrs,"");
		SETCHAR(tBomItem->Rform,"");
		SETCHAR(tBomItem->Roanz,"");
		SETCHAR(tBomItem->Roame,"");
		SETCHAR(tBomItem->Rokme,"");
		SETCHAR(tBomItem->Romei,"");
		SETCHAR(tBomItem->Romen,"");
		SETCHAR(tBomItem->Roms1,"");
		SETCHAR(tBomItem->Roms2,"");
		SETCHAR(tBomItem->Roms3,"");
		SETCHAR(tBomItem->Rvrel,"");
		SETCHAR(tBomItem->Sakto,"");
		SETCHAR(tBomItem->Sanin,"");
		SETCHAR(tBomItem->Sanko,"");
		SETCHAR(tBomItem->Sanvs,"");
		SETCHAR(tBomItem->Selal,"");
		SETCHAR(tBomItem->Selid,"");
		SETCHAR(tBomItem->Selpo,"");
		SETCHAR(tBomItem->Stkkz,"");
		SETCHAR(tBomItem->Stktx,"");
		SETCHAR(tBomItem->Stlal,"");
		SETCHAR(tBomItem->Stlkz,"");
		SETCHAR(tBomItem->Webaz,"");
		SETCHAR(tBomItem->Waers,"");
		SETCHAR(tBomItem->Dokar,"");
		SETCHAR(tBomItem->Doknr,"");
		SETCHAR(tBomItem->Dokvr,"");
		SETCHAR(tBomItem->Doktl,"");
		SETCHAR(tBomItem->Ekorg,"");
		SETCHAR(tBomItem->Class,"");
		SETCHAR(tBomItem->Klart,"");
		SETCHAR(tBomItem->Potpr,"");
		SETCHAR(tBomItem->Prvbe,"");
		SETCHAR(tBomItem->Nfeag,"");
		SETCHAR(tBomItem->Nfgrp,"");
		SETCHAR(tBomItem->Kzkup,"");
		SETCHAR(tBomItem->Intrm,"");
		SETCHAR(tBomItem->Kzclb,"");
		SETCHAR(tBomItem->Nlfzv,"");
		SETCHAR(tBomItem->Nlfmv,"");
		SETCHAR(tBomItem->Rfpnt,"");
		SETCHAR(tBomItem->MatnrLong,"");
	}

	RfcRc = cad_create_bom_with_sub_items(hRfc,&eIAutoPosnr,&eIBomHeader,&iEBomHeader,&iEMessage,&iEMessageLen,&iEReturn,thBomItem,xException);
	 switch (RfcRc)
	  {
	     case RFC_OK :
							/*for (crow = 1;crow <= ItFill(thBomItem); crow++)
							{
							    tBomItem = ItGetLine(thBomItem,crow);
							    if (tBomItem == NULL)
									printf("ItGetLineBOM_ITEM");
								strcpy(comp_sap,"");
							    strncpy(comp_sap,tBomItem->Idnrk,15);
							    printf("\nBomItem:%04d %15s",crow,comp_sap);
							    fprintf(fsuccess,"\nBomItem:%04d %15s",crow,comp_sap);
							}*/
							printf("\nMESSAGE FOR BOM %s CREATE:%s",assy_noDup,iEMessage);
							fprintf(fsuccess,"\nMSG RCVD:MESSAGE FOR BOM %s CREATE:%s",assy_noDup,iEMessage);
							GETCHAR(iEReturn,s);F_OUTK("iEReturn",00,20,s);
							GETCHAR(iEMessage,s);F_OUTK("iEMessage",00,20,s);
							strcpy(ReturnValue,"");
							//printf("\nReturn Value [%s]\n",iEReturn);
							GETCHAR(iEReturn,ReturnValue);

							printf("\nReturn Value [%s]\n",ReturnValue);
							if(tc_strcmp(ReturnValue,"D")==0)
							{
								printf("Assy or comp Makred for ZI %s,%s\n",plantcode,assy_noDup);
								//fprintf(fpDelFile,"%s,%s,%s\n",dmlnost,plantcode,cAssemblyNo);
							}
							strcpy(ReturnMessage,"");
							GETCHAR(iEMessage,ReturnMessage);

							printf("\nReturn Message [%s]\n",ReturnMessage);
							if(tc_strlen(ReturnMessage)>0)
							if(tc_strstr(ReturnMessage,"BOM item due to material status ZI 'Inactive Material Block '"))
							{
								printf("Assy or comp Makred for ZI %s,%s\n",plantcode,assy_noDup);
								//fprintf(fpDelFile,"%s,%s,%s\n",dmlnost,plantcode,cAssemblyNo);
							}
							
							break;
	     case RFC_EXCEPTION :
							printf("\nexception");
							fprintf(fsuccess,"\nexception");
							break;
	     case RFC_SYS_EXCEPTION :
							printf("\nsystem exception raised");
							fprintf(fsuccess,"\nsystem exception raised");
							break;
	     case RFC_FAILURE :
							printf("\nfailure");
							fprintf(fsuccess,"\nfailure");
							break;
	     default :
							printf("\nother failure");
							fprintf(fsuccess,"\nother failure");
							break;
	   }
	 if (ItDelete(thBomItem) != 0)
	   rfc_error("ItDelete BOM_ITEM");
	 RfcClose(hRfc);
	//fclose(fpDelFile);
}

RFC_RC  cad_create_bom_with_sub_items(RFC_HANDLE hRfc, DRAW_LOEDK *eIAutoPosnr, CAD_BICSK *eIBomHeader, CAD_BICSK *iEBomHeader, MESSAGE_MSGTX *iEMessage, CAD_RETURN_MESSAGE_LEN *iEMessageLen, CAD_RETURN_VALUE *iEReturn, ITAB_H thBomItem, char *xException)
{
  // RFC variables
  RFC_PARAMETER Exporting[3];
  RFC_PARAMETER Importing[5];
  RFC_TABLE Tables[2];
  RFC_RC RfcRc;
  char *RfcException = NULLTAG;
  // define export params
  Exporting[0].name = "I_AUTO_POSNR";
  Exporting[0].nlen = 12;
  Exporting[0].type = TYPC;
  Exporting[0].leng = sizeof(DRAW_LOEDK);
  Exporting[0].addr = eIAutoPosnr;

  Exporting[1].name = "I_BOM_HEADER";
  Exporting[1].nlen = 12;
  Exporting[1].type = handleOfCAD_BICSK;
  Exporting[1].leng = sizeof(CAD_BICSK);
  Exporting[1].addr = eIBomHeader;

  Exporting[2].name = NULLTAG;

  Tables[0].name     = "BOM_ITEM";
  Tables[0].nlen     = 8;
  Tables[0].type     = handleOfCAD_BOM_ITEM;
  Tables[0].ithandle = thBomItem;

  Tables[1].name = NULLTAG;

  RfcRc = RfcCall(hRfc,"CAD_CREATE_BOM_WITH_SUB_ITEMS",Exporting,Tables);
  switch (RfcRc)
  {
    case RFC_OK :

		  Importing[0].name = "E_BOM_HEADER";
		  Importing[0].nlen = 12;
		  Importing[0].type = handleOfCAD_BICSK;
		  Importing[0].leng = sizeof(CAD_BICSK);
		  Importing[0].addr = iEBomHeader;

		  Importing[1].name = "E_MESSAGE";
		  Importing[1].nlen = 9;
		  Importing[1].type = TYPC;
		  Importing[1].leng = sizeof(MESSAGE_MSGTX);
		  Importing[1].addr = iEMessage;

		  Importing[2].name = "E_MESSAGE_LEN";
		  Importing[2].nlen = 13;
		  Importing[2].type = TYPC;
		  Importing[2].leng = sizeof(CAD_RETURN_MESSAGE_LEN);
		  Importing[2].addr = iEMessageLen;

		  Importing[3].name = "E_RETURN";
		  Importing[3].nlen = 8;
		  Importing[3].type = TYPC;
		  Importing[3].leng = sizeof(CAD_RETURN_VALUE);
		  Importing[3].addr = iEReturn;

		  Importing[4].name = NULLTAG;

		  RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
		  // printf("\nMessage Received:%s",RfcException);

	switch (RfcRc)
	{
		case RFC_SYS_EXCEPTION :
			strcpy(xException,RfcException);
			printf("\nRFC_SYS_EXCEPTION: %s",xException);
			break;
		case RFC_EXCEPTION :
			strcpy(xException,RfcException);
			printf("\nRFC_EXCEPTION    : %s",xException);
			break;
			default:;
	}
	break;
	default:
			printf("\nNot ok");

  }
  return RfcRc;
}

void SapBomChange(struct node *head,char *assy_noDup,char *AssemblyRevisionDup,char *SequenceRevisionDup,char *OrganizationIDDup)
{
	struct node *p=NULL;
	char sap_qty[18];
	char s[1024];
	char xException[256];
	char ReturnMessage[1024] = {0};
	char ReturnValue[2]={0};

	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;
	CAD_BICSK eIBomHeader;
	//DRAW_LOEDK eIAutoPosnr;
	CAD_BICSK iEBomHeader;
	MESSAGE_MSGTX iEMessage;
	CAD_RETURN_MESSAGE_LEN iEMessageLen;
	CAD_RETURN_VALUE iEReturn;
	ITAB_H thBomItem = ITAB_NULL;
	CAD_BOM_ITEM *tBomItem;
	float sumUsgProb = 0.000f;
	char NCUsgFileName[200]={0};
	FILE* fpUsgProb = NULL;
	char strUP[11]={0};
	char todayDate[11]={0};

	getTodayDate(todayDate);
	//sprintf(NCUsgFileName,"%s/PLMSAP/UsgProbGrp_%s.txt",getenv("ONLREP"),todayDate);
	//sprintf(NCUsgFileName,"%s/PLMSAP/PLM_SAP_LOG/UsgProbGrp_%s_%s.txt",getenv("ONLREP"),plantcode,todayDate);

	sprintf(NCUsgFileName,"UsgProbGrp_%s_%s.txt",plantcode,todayDate);

	//sprintf(NCUsgFileName,"UsgProbGrp_%s_%s.txt",plantcode,todayDate);
	fpUsgProb = fopen(NCUsgFileName,"a");

	hRfc = BapiLogon();
	thBomItem = ITAB_NULL;
	if (thBomItem==ITAB_NULL)
	{
		thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
		if (thBomItem==ITAB_NULL)
				rfc_error("ItCreateBOM_ITEM");
	}
	else
	{
		if (ItFree(thBomItem) != 0)
			rfc_error("ItFreeBOM_ITEM");
	}

	printf("\nAssembly:[%s]",assy_noDup);
	printf("\nAssembly:[%s]",dml_no_arg);
	printf("\nAssembly:[%s]",plantcode);

	printf("\nAssembly:[%s,%s,%s]",assy_noDup,dml_no_arg,plantcode);

	fprintf(fsuccess,"\nAssembly:[%s,%s,%s]",assy_noDup,dml_no_arg,plantcode);

	SETCHAR(eIBomHeader.Matnr,assy_noDup);			/*assembly*/
	SETCHAR(eIBomHeader.Werks,plantcode);			/*Plant*/
	SETCHAR(eIBomHeader.Stlan,"1");					/*usage*/
	SETCHAR(eIBomHeader.Stlal,"01");				/*alternative*/
	SETCHAR(eIBomHeader.Aennr,dml_no_arg);			/*dml_no_arg DMLNO with ST */
	SETCHAR(eIBomHeader.Datuv,"");					/*FROM date*/
	SETCHAR(eIBomHeader.Datub,"31.12.9999");		/*TO date*/
	SETCHAR(eIBomHeader.Stype,"");
	SETCHAR(eIBomHeader.Tcode,"");
	SETCHAR(eIBomHeader.Bmein,"");
	SETCHAR(eIBomHeader.Bmeng,"");
	SETCHAR(eIBomHeader.Cadkz,"");
	SETCHAR(eIBomHeader.Emeng,"");
	SETCHAR(eIBomHeader.Equnr,"");
	SETCHAR(eIBomHeader.Exstl,"");
	SETCHAR(eIBomHeader.Labor,"");
	SETCHAR(eIBomHeader.Loekz,"");
	SETCHAR(eIBomHeader.Losbs,"");
	SETCHAR(eIBomHeader.Losvn,"");
	SETCHAR(eIBomHeader.Selal,"");
	SETCHAR(eIBomHeader.Serge,"");
	SETCHAR(eIBomHeader.Stktx,"");
	SETCHAR(eIBomHeader.Stlbe,"");
	SETCHAR(eIBomHeader.Stlst,"");
	SETCHAR(eIBomHeader.Vmtnr,"");
	SETCHAR(eIBomHeader.Ztext,"");
	SETCHAR(eIBomHeader.Revlv,"");
	SETCHAR(eIBomHeader.Tplnr,"");
	SETCHAR(eIBomHeader.Dokar,"");
	SETCHAR(eIBomHeader.Doknr,"");
	SETCHAR(eIBomHeader.Doktl,"");
	SETCHAR(eIBomHeader.Dokvr,"");
	SETCHAR(eIBomHeader.Vbeln,"");
	SETNUM(eIBomHeader.Vbpos,"000000");
	SETCHAR(eIBomHeader.Stobj,"");
	SETCHAR(eIBomHeader.Vdknr,"");
	SETCHAR(eIBomHeader.Vdkar,"");
	SETCHAR(eIBomHeader.Vdktl,"");
	SETCHAR(eIBomHeader.Vdkvr,"");
	SETCHAR(eIBomHeader.Veqnr,"");
	SETCHAR(eIBomHeader.Vtpnr,"");
	SETCHAR(eIBomHeader.Pspnr,"");
	SETCHAR(eIBomHeader.Oitxt,"");
	SETCHAR(eIBomHeader.MatnrLong,"");

	sumUsgProb = 0.000f;

	for(p = head; p != NULL; p = p -> next)
	{
		sprintf(sap_qty,"%7.3f", p->qty);

		tBomItem = ItAppLine(thBomItem);
		if (tBomItem == NULL)
		printf("ItAppLineBOM_ITEM");

		SETCHAR(tBomItem->Idnrk,p->part);
		SETCHAR(tBomItem->Menge,sap_qty);
		SETCHAR(tBomItem->Postp,"L");
		SETCHAR(tBomItem->Posnr,p->sr_no);
		
		if(*assy_noDup=='G')
		{
			SETCHAR(tBomItem->Alpgr,"a1");
			SETNUM(tBomItem->Alprf,"1");
			SETCHAR(tBomItem->Alpst,"1");

			sprintf(strUP,"%7.3f", p->usgProb);
			if(tc_strcmp(strUP,"")!=0)
			{
				SETCHAR(tBomItem->Ewahr,strUP);		// Group's child Usage Probability Added on dated 26.09.2013
			}
			else
			{
				SETCHAR(tBomItem->Ewahr,"");
			}

			sumUsgProb = sumUsgProb + (p->usgProb);

			printf("\n\t%15s %4s 1 01 %12s %s %-15s %7.3f %3s %3s %3s a1 1  1 	%7.3f",assy_noDup,plantcode,dml_no_arg,p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel,p->usgProb);
			fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s  %7.3f",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel,p->usgProb);

		}
		else
		{
			printf("\n\t%15s %4s 1 01 %12s %s %-15s %7.3f %3s %3s %3s  %7.3f",assy_noDup,plantcode,dml_no_arg,p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel,p->usgProb);
			fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s  %7.3f",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel,p->usgProb);

			SETCHAR(tBomItem->Alpgr,"");
			SETNUM(tBomItem->Alprf,"");
			SETCHAR(tBomItem->Ewahr,"");
			SETCHAR(tBomItem->Alpst,"");
		}
		SETCHAR(tBomItem->Verti,"");
		SETCHAR(tBomItem->Beikz,p->mat_prov_ind);
		SETCHAR(tBomItem->Selsb,"");
		if (tc_strcmp(sap_qty,"99") != 0)
		{
			//strcpy(blk_ind,"");
			SETCHAR(tBomItem->Schgt,"");//blk_ind
		}
		else
		{
			//strcpy(blk_ind,"");
			strcpy(p->tempcsrel,"1");
			SETCHAR(tBomItem->Schgt,"");//blk_ind
		}
		SETCHAR(tBomItem->Sanka,p->tempcsrel);
		SETCHAR(tBomItem->Schgt,"");/*blk_ind*/
		SETCHAR(tBomItem->Meins,p->uq);
		SETCHAR(tBomItem->Potx1,"");	//bomtxt
		SETCHAR(tBomItem->Sanfe,"");
		SETCHAR(tBomItem->Dspst,"");
		SETCHAR(tBomItem->Upskz,"");
		SETCHAR(tBomItem->Auskz,"");
		SETCHAR(tBomItem->Alpos,"");
		SETCHAR(tBomItem->Ausch,"");
		SETCHAR(tBomItem->Avoau,"");
		SETCHAR(tBomItem->Cadpo,"");
		SETCHAR(tBomItem->Ekgrp,"");
		SETCHAR(tBomItem->Erskz,"");
		SETCHAR(tBomItem->Fmeng,"");
		SETCHAR(tBomItem->Lifnr,"");
		SETCHAR(tBomItem->Lifzt,"");
		SETCHAR(tBomItem->Matkl,"");
		SETCHAR(tBomItem->Netau,"");
		SETCHAR(tBomItem->Nfmat,"");
		SETCHAR(tBomItem->Nlfzt,"");
		SETCHAR(tBomItem->Peinh,"");
		SETCHAR(tBomItem->Preis,"");
		SETCHAR(tBomItem->Potx2,"");
		SETCHAR(tBomItem->Pswrk,"");
		SETCHAR(tBomItem->Rekrs,"");
		SETCHAR(tBomItem->Rform,"");
		SETCHAR(tBomItem->Roanz,"");
		SETCHAR(tBomItem->Roame,"");
		SETCHAR(tBomItem->Rokme,"");
		SETCHAR(tBomItem->Romei,"");
		SETCHAR(tBomItem->Romen,"");
		SETCHAR(tBomItem->Roms1,"");
		SETCHAR(tBomItem->Roms2,"");
		SETCHAR(tBomItem->Roms3,"");
		SETCHAR(tBomItem->Rvrel,"");
		SETCHAR(tBomItem->Sakto,"");
		SETCHAR(tBomItem->Sanin,"");
		SETCHAR(tBomItem->Sanko,"");
		SETCHAR(tBomItem->Sanvs,"");
		SETCHAR(tBomItem->Selal,"");
		SETCHAR(tBomItem->Selid,"");
		SETCHAR(tBomItem->Selpo,"");
		SETCHAR(tBomItem->Sortf,"");
		SETCHAR(tBomItem->Stkkz,"");
		SETCHAR(tBomItem->Stktx,"");
		SETCHAR(tBomItem->Stlal,"");
		SETCHAR(tBomItem->Stlkz,"");
		SETCHAR(tBomItem->Webaz,"");
		SETCHAR(tBomItem->Waers,"");
		SETCHAR(tBomItem->Dokar,"");
		SETCHAR(tBomItem->Doknr,"");
		SETCHAR(tBomItem->Dokvr,"");
		SETCHAR(tBomItem->Doktl,"");
		SETCHAR(tBomItem->Ekorg,"");
		SETCHAR(tBomItem->Lgort,"");
		SETCHAR(tBomItem->Class,"");
		SETCHAR(tBomItem->Klart,"");
		SETCHAR(tBomItem->Potpr,"");
		SETCHAR(tBomItem->Prvbe,"");
		SETCHAR(tBomItem->Nfeag,"");
		SETCHAR(tBomItem->Nfgrp,"");
		SETCHAR(tBomItem->Kzkup,"");
		SETCHAR(tBomItem->Intrm,"");
		SETCHAR(tBomItem->Kzclb,"");
		SETCHAR(tBomItem->Nlfzv,"");
		SETCHAR(tBomItem->Nlfmv,"");
		SETCHAR(tBomItem->Rfpnt,"");
		SETCHAR(tBomItem->MatnrLong,"");


	}

	if(*assy_noDup=='G')
	{
		printf("\n\nGroup:[%s %s %s] plantcode:[%s] And Usage Probability Sum is:[%7.3f]",assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,plantcode,sumUsgProb);fflush(stdout);
		fprintf(fsuccess,"\n\nGroup:[%s %s %s] plantcode:[%s] And Usage Probability Sum is:[%7.3f]",assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,plantcode,sumUsgProb);fflush(stdout);
		//fprintf(fpUsgProb,"\n\nGroup:[%s %s %s] plantcode:[%s] And Usage Probability Sum is:[%7.3f]",assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,plantcode,sumUsgProb);fflush(stdout);

         
		if (sumUsgProb <100)
		{
			printf("\nUsage Probability Sum [%7.3f] is less than 100 for G-part:[%s %s %s][%s] Project:[%s]\n",sumUsgProb,assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,plantcode,projectcode);fflush(stdout);
			fprintf(fsuccess,"\nUsage Probability Sum [%7.3f] is less than 100 for G-part:[%s %s %s][%s] Project:[%s]\n",sumUsgProb,assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,plantcode,projectcode);fflush(fsuccess);

			for(p = head; p != NULL; p = p -> next)
			{
				fprintf(fpUsgProb,"\n%s,%s,%s,%s,%7.3f,%s,%s,%s",assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,p->part,p->qty,plantcode,p->make_buy_indDup,strUP);fflush(fpUsgProb);
				printf("\nUsage Probability Details:%s,%s,%s,%s,%7.3f,%s,%s,%s",assy_noDup,AssemblyRevisionDup,SequenceRevisionDup,p->part,p->qty,plantcode,p->make_buy_indDup,strUP);fflush(fpUsgProb);fflush(stdout);
			}
			fprintf(fpUsgProb,"\n");
			printf("\n");fflush(stdout);
		}
	}

	RfcRc = zcad_change_bom_with_sub_items(hRfc,&eIBomHeader,&iEReturn,&iEMessage,&iEMessageLen,&iEBomHeader,thBomItem,xException);
	switch (RfcRc)
	{
		case RFC_OK :
	 		/*for (crow = 1;crow <= ItFill(thBomItem); crow++)
			{
				tBomItem = ItGetLine(thBomItem,crow);
				if (tBomItem == NULL)
					rfc_error("ItGetLineBOM_ITEM");
				strncpy(comp_part_sap,tBomItem->Idnrk,15);
				printf("\n\t:%s",comp_part_sap);
				fprintf(fsuccess,"\n\t:%s",comp_part_sap);
			}*/
			strcpy(ReturnValue,"");
			printf("\nReturn Value [%s]\n",iEReturn);
			GETCHAR(iEReturn,ReturnValue);
			//nlsStrTrimTrailWhiteSpace(ReturnValue);
			//nlsStrTrimLeadWhiteSpace(ReturnValue);
			printf("\nReturn Value [%s]\n",ReturnValue);
			if(tc_strcmp(ReturnValue,"D")==0)
			{
				printf("Assy or comp Makred for ZI %s,%s\n",plantcode,assy_noDup);
				//fprintf(fpDelFile,"%s,%s,%s\n",dmlnost,plantcode,cAssemblyNo);
			}
			GETCHAR(iEMessage,ReturnMessage);
			//nlsStrTrimTrailWhiteSpace(ReturnMessage);
			//nlsStrTrimLeadWhiteSpace(ReturnMessage);
			printf("\nReturn Message [%s]\n",ReturnMessage);
			if(tc_strlen(ReturnMessage)>0)
			if(tc_strstr(ReturnMessage,"BOM item due to material status ZI 'Inactive Material Block '"))
			{
				printf("Assy or comp Makred for ZI %s,%s\n",plantcode,assy_noDup);
				//fprintf(fpDelFile,"%s,%s,%s\n",dmlnost,plantcode,cAssemblyNo);
			}
			printf("\nMessage for Bom Change:%s [%s] %s",assy_noDup,iEReturn,iEMessage);
			fprintf(fsuccess,"\nMessage for Bom Change:%s [%s] %s ",assy_noDup,iEReturn,iEMessage);
			NL;NL;
			GETCHAR(iEReturn,s);F_OUTK("iEReturn",00,20,s);
			GETCHAR(iEMessage,s);F_OUTK("iEMessage",00,20,s);

		break;

		case RFC_EXCEPTION :
			 printf("EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION :
			rfc_error("SYSTEM EXCEPTION RAISED");
		break;
		case RFC_FAILURE :
			rfc_error("failure");
		break;
		default :
			rfc_error("other failure");
		break;
	}
	if (ItDelete(thBomItem) != 0)
		rfc_error("ItDelete BOM_ITEM");
	RfcClose(hRfc);
	/*if(fpDelFile)
	fclose(fpDelFile);
	fpDelFile=NULL;*/

	if(fpUsgProb)
	fclose(fpUsgProb);
	fpUsgProb=NULL;

}

RFC_RC  zcad_change_bom_with_sub_items(RFC_HANDLE hRfc,CAD_BICSK *eIBomHeader,CAD_RETURN_VALUE *iEReturn,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_BICSK *iEBomHeader,ITAB_H thBomItem,char *xException)
{
	char *RfcException = NULLTAG;
	RFC_PARAMETER Exporting[2];
	RFC_PARAMETER Importing[5];
	RFC_TABLE Tables[2];
	RFC_RC RfcRc;

	Exporting[0].name = "I_BOM_HEADER";
	Exporting[0].nlen = 12;
	Exporting[0].type = handleOfCAD_BICSK;
	Exporting[0].leng = sizeof(CAD_BICSK);
	Exporting[0].addr = eIBomHeader;

	Exporting[1].name = NULLTAG;

	Tables[0].name     = "BOM_ITEM";
	Tables[0].nlen     = 8;
	Tables[0].type     = handleOfCAD_BOM_ITEM;
	Tables[0].ithandle = thBomItem;

	Tables[1].name = NULLTAG;

	RfcRc = RfcCall(hRfc,"ZCAD_CHANGE_BOM_WITH_SUB_ITEMS",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK :
			Importing[0].name = "E_RETURN";
			Importing[0].nlen = 8;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(CAD_RETURN_VALUE);
			Importing[0].addr = iEReturn;

			Importing[1].name = "E_MESSAGE";
			Importing[1].nlen = 9;
			Importing[1].type = TYPC;
			Importing[1].leng = sizeof(MESSAGE_MSGTX);
			Importing[1].addr = iEMessage;

			Importing[2].name = "E_MESSAGE_LEN";
			Importing[2].nlen = 13;
			Importing[2].type = TYPC;
			Importing[2].leng = sizeof(CAD_RETURN_MESSAGE_LEN);
			Importing[2].addr = iEMessageLen;

			Importing[3].name = "E_BOM_HEADER";
			Importing[3].nlen = 12;
			Importing[3].type = handleOfCAD_BICSK;
			Importing[3].leng = sizeof(CAD_BICSK);
			Importing[3].addr = iEBomHeader;

			Importing[4].name = NULLTAG;


			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION :
					strcpy(xException,RfcException);
					printf("RFC_SYS_EXCEPTION:%s",xException);
				break;
				case RFC_EXCEPTION :
					strcpy(xException,RfcException);
					printf("RFC_EXCEPTION:    %s",xException);
				break;
				default:;
			}
		default:;
	}
	return RfcRc;
}

struct usgProbnode*  GetUsageProb(char *assy_noDup)
{
	struct usgProbnode *startUsg=NULLTAG, *p=NULLTAG, *t=NULLTAG;

	int		ret;
	float usgPrbFloat = 0.000f;
	//float sumUsgProb = 0.000f;

	char xException[256];
	char s[1024]={0};

	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc3;

	MARA_MATNR	eMARA_MATNR;
	MARC_WERKS	eMARC_WERKS;
	STZU_STLAN	eSTZU_STLAN;
	STKO_STLAL	eSTKO_STLAL;
	TC04_CAPID	eTC04_CAPID;
	STKO_DATUV	eSTKO_DATUV;

	ITAB_H thMATCAT = ITAB_NULL;
	ITAB_H thSTB  = ITAB_NULL;
	STB *tSTB;

	unsigned crow;

	char cUsgProbStr[2000];
	char *sumStr = NULL;
	char *cUsgProbChildP = NULL;
	char *GrpChildPart = NULL;
	char *cItemNoSap = NULL;
	//date_t date;
	char *year  = NULL;
	char *month = NULL;
	char *daydt = NULL;
	char *sapIpDt = NULL;
	char* timestamp = NULL;

	time_t NowTime;
	struct tm *timeinfo;
	timestamp = (char *) MEM_alloc(20 * sizeof(char ));
	sapIpDt = (char *) MEM_alloc(9 * sizeof(char ));
	cItemNoSap = (char *) MEM_alloc(20 * sizeof(char ));
	cUsgProbChildP = (char *) MEM_alloc(20 * sizeof(char ));

	//printf("\n Before calling cUsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2 .for.[%s]:[%s].\n",assy_noDup,plantcode);

	hRfc = BapiLogon();

	//date = sysGetDate2();
	time(&NowTime);
	timeinfo = localtime(&NowTime);
	strftime(timestamp, 20, "%Y-%m-%d-%H_%M_%S", timeinfo);
	printf("\ntimestamp %s",timestamp);


	/*year = subString(timestamp,0,4);
	month = subString(timestamp,6,2);
	daydt = subString(timestamp,9,2);*/

	year = strtok ( timestamp, "-" );
	month = strtok ( NULL, "-" );
	daydt = strtok ( NULL, "-" );

	tc_strcpy(sapIpDt,"");
	tc_strcpy(sapIpDt,year);
	tc_strcat(sapIpDt,month);
	tc_strcat(sapIpDt,daydt);
	printf("\n eSTKO_DATUV:[%s] \n",sapIpDt); fflush(stdout);

	SETCHAR(eMARA_MATNR,assy_noDup);
	SETCHAR(eMARC_WERKS,plantcode);
	if (!tc_strcmp(plantcode,"2001"))
	{
		SETCHAR(eSTZU_STLAN,"2");
	}
	else
	{
		SETCHAR(eSTZU_STLAN,"1");
	}
	SETCHAR(eSTKO_STLAL,"01");
	SETCHAR(eTC04_CAPID,"PP01");
	SETCHAR(eSTKO_DATUV,sapIpDt);

	thSTB = ITAB_NULL;

	if (thSTB==ITAB_NULL)
	{
		thSTB = ItCreate("STB",sizeof(STB),0,0);
		if (thSTB==ITAB_NULL)
			rfc_error("ItCreate STB");
	}
	else if (ItFree(thSTB) != 0)
	{
		rfc_error("ItFree STB");
	}

	thMATCAT = ITAB_NULL;

	if (thMATCAT==ITAB_NULL)
	{
		thMATCAT = ItCreate("MATCAT",sizeof(MATCAT),0,0);
		if (thMATCAT==ITAB_NULL)
			rfc_error("ItCreate MATCAT");
	}
	else if (ItFree(thMATCAT) != 0)
	{
		rfc_error("ItFree MATCAT");
	}

	//sumUsgProb = 0.000f;
	RfcRc3 = UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2(	hRfc,
												&eMARA_MATNR,
												&eMARC_WERKS,
												&eSTZU_STLAN,
												&eSTKO_STLAL,
												&eTC04_CAPID,
												&eSTKO_DATUV,
												thSTB,
												thMATCAT,
												xException
											  );

	printf("\nno of childs fetched for G-part::[%s][%d]\n",assy_noDup,ItFill(thSTB));
	if (ItFill(thSTB)>0)
	{
		startUsg = NULL;
		p = NULL;
		t = NULL;
		ret = 0;

		switch (RfcRc3)
		{
			case RFC_OK :
				//printf("\n In RFC_OK case of UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2...");
				printf("\n Previous Revision Bom Details from SAP...Before updation");
				//printf("\nno of row fetched from thSTB:[%d]\n",ItFill(thSTB));
				//strcpy(cUsgProbStr,"");
				for (crow = 1;crow <= ItFill(thSTB); crow++)
				{
					tSTB = ItGetLine(thSTB,crow);
					if (tSTB == NULL)
					{
						rfc_error("ItGetLineBOM_ITEM");
					}

					printf("\n\t crow :[%d]",crow );
					GETCHAR(tSTB->POSNR, cItemNoSap	);		//OUTS(".....POSNR",10,30, cItemNoSap);
					GETCHAR(tSTB->IDNRK, cUsgProbChildP	);	//OUTS(".....IDNRK",10,30, cUsgProbChildP);

					GETBCD	(tSTB->EWAHR,s,0);
					usgPrbFloat = atof(s);
					sprintf(cUsgProbStr,"%1.3f",atof(s));	//OUTS(".....EWAHR",10,30, cUsgProbStr);

					printf("\n...POSNR:%s",cItemNoSap);
					fprintf(fsuccess,"...POSNR:%s",cItemNoSap);
					printf("\n...IDNRK:%s",cUsgProbChildP);
					fprintf(fsuccess,"...IDNRK:%s",cUsgProbChildP);
					printf("\n...EWAHR:%f",usgPrbFloat);
					fprintf(fsuccess,"...EWAHR:%f",usgPrbFloat);
					
					//stripBlanks - itk function
					trimString(cItemNoSap);
					trimString(cUsgProbChildP);
					tc_strdup(cUsgProbChildP,&GrpChildPart);

					if(p==NULL)
					{

						//sr_no1 = 1 ;
						//sprintf(sr_no,"%04d",sr_no1);
						p = createnode2(cItemNoSap,GrpChildPart,&usgPrbFloat);
						startUsg = p;
					}
					else
					{
						//ret = search(startUsg,GrpChildPart,&usgPrbFloat);
						//if(ret == 1)
						//{
							 t=startUsg;
							 while(t->next!=NULL)
							 {
								 t=t->next;
							 }
							 //sr_no1 = sr_no1 + 1 ;
							 //sprintf(cItemNoSap,"%04d",sr_no1);
							 t->next = createnode2(cItemNoSap,GrpChildPart,&usgPrbFloat);
						//}
					}
					//sumUsgProb = sumUsgProb + usgPrbFloat;
				}
				break;
			case RFC_EXCEPTION :
				//printf("\nRFC_EXCEPTION"); fflush(stdout);
				break;
			case RFC_SYS_EXCEPTION :
				//printf("\nRFC_SYS_EXCEPTION"); fflush(stdout);
				break;
			case RFC_FAILURE :
				//printf("\nfailure"); fflush(stdout);
				break;
			default :
				//printf("\nother failure"); fflush(stdout);
				break;
		}

		if (ItDelete(thSTB) != 0)
			rfc_error("ItDelete STB");
		if (ItDelete(thMATCAT) != 0)
			rfc_error("ItDelete MATCAT");
	}

	//display2(startUsg, assy_noDup);

	RfcClose(hRfc);

	return startUsg;
}

RFC_RC UsgProb_ZPPRFC_CS_BOM_EXPL_MAT_V2(RFC_HANDLE	hRfc, MARA_MATNR *eMARA_MATNR, MARC_WERKS *eMARC_WERKS, STZU_STLAN *eSTZU_STLAN, STKO_STLAL *eSTKO_STLAL, TC04_CAPID *eTC04_CAPID, STKO_DATUV *eSTKO_DATUV,ITAB_H  thSTB, ITAB_H  thMATCAT, char *xException )
{

	static RFC_RC RfcRc;

	RFC_PARAMETER Exporting[7];
	RFC_PARAMETER Importing[1];
	RFC_TABLE Tables[3];
	char *RfcException = NULLTAG;

	Exporting[0].name = "MTNRV";		//Material/Partno
	Exporting[0].nlen = 5;
	Exporting[0].type = TYPC;
	Exporting[0].leng = sizeof(MARA_MATNR);
	Exporting[0].addr = eMARA_MATNR;

	Exporting[1].name = "WERKS";		//Material Plant input
	Exporting[1].nlen = 5;
	Exporting[1].type = TYPC;
	Exporting[1].leng = sizeof(MARC_WERKS);
	Exporting[1].addr = eMARC_WERKS;

	Exporting[2].name = "STLAN";		//BOM Usage input
	Exporting[2].nlen = 5;
	Exporting[2].type = TYPC;
	Exporting[2].leng = sizeof(STZU_STLAN);
	Exporting[2].addr = eSTZU_STLAN;

	Exporting[3].name = "STLAL";		//Alternative BOM
	Exporting[3].nlen = 5;
	Exporting[3].type = TYPC;
	Exporting[3].leng = sizeof(STKO_STLAL);
	Exporting[3].addr = eSTKO_STLAL;

	Exporting[4].name = "CAPID";		//Application identifier PP01
	Exporting[4].nlen = 5;
	Exporting[4].type = TYPC;
	Exporting[4].leng = sizeof(TC04_CAPID);
	Exporting[4].addr = eTC04_CAPID;

	Exporting[5].name = "DATUV";		//Valid from date [dd.mm.yyyy][e.g. 06.07.2013]
	Exporting[5].nlen = 5;
	Exporting[5].type = TYPC;
	Exporting[5].leng = sizeof(STKO_DATUV);
	Exporting[5].addr = eSTKO_DATUV;

	Exporting[6].name = NULLTAG;


	Tables[0].name     = "STB";
	Tables[0].nlen     = 3;
	Tables[0].type     = handleOfSTB;
	Tables[0].ithandle = thSTB;

	Tables[1].name     = "MATCAT";
	Tables[1].nlen     = 6;
	Tables[1].type     = handleOfMATCAT;
	Tables[1].ithandle = thMATCAT;

	Tables[2].name     = NULLTAG;

	RfcRc = RfcCall(hRfc,"ZPPRFC_CS_BOM_EXPL_MAT_V2",Exporting,Tables);

	switch (RfcRc)
	{

		case RFC_OK :

			Importing[0].name = NULLTAG;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
			case RFC_SYS_EXCEPTION :
				strcpy(xException,RfcException);
				//printf ("exception1");  fflush(stdout);
			break;
			case RFC_EXCEPTION :
				strcpy(xException,RfcException);
				//printf ("exception2");  fflush(stdout);
			break;
			default:;
			}
		break;
		default:
			printf("\ndefault case"); fflush(stdout);
		break;
	}
	return RfcRc;
}

void compareUsage(struct usgProbnode *pUP,struct node *start)
{
	struct usgProbnode *p = NULL;
	struct node *q = NULL;

	printf("\nSAP Bom List");
	fprintf(fsuccess,"\nSAP Bom List");
	for(p = pUP;p!=NULL;p = p->next)
	{
		printf("\n[%s,%s,%f]",p->sr_no,p->part,p->usgProb);
		fprintf(fsuccess,"\n[%s,%s,%f]",p->sr_no,p->part,p->usgProb);
	}
//	printf("\nPLM");
//	for(q = start;q!=NULL;q = q->next)
//	{
//		printf("\n[%s,%s,%f]",q->sr_no,q->part,q->usgProb);
//	}

	for(q = start;q!=NULL;q = q->next)
	{
		for(p = pUP;p!=NULL;p = p->next)
		{
			//printf("\n[%s,%s]",q->part,p->part);
			if(tc_strcmp(q->part,p->part)==0)
			{
				q->usgProb = p->usgProb;
			}
		}
	}

	printf("\nPLM Bom List");
	fprintf(fsuccess,"\nPLM Bom List");
	for(q = start;q!=NULL;q = q->next)
	{
		printf("\n[%s,%s,%f]",q->sr_no,q->part,q->usgProb);
		fprintf(fsuccess,"\n[%s,%s,%f]",q->sr_no,q->part,q->usgProb);
	}
}

RFC_RC cll_ccap_ecn_create(RFC_HANDLE hRfc)
{
	static RFC_RC RfcRc;
	int status;
	int Cnt=0,pCnt=0;
	char *PartNumC=NULL;
	char *part_typeC=NULL;
	char *taskIdStr=NULL;

	tag_t PartTag1 = NULLTAG;
	tag_t *ChPartTags	= NULLTAG;

	AENR_API01 eChangeHeader;
	CSDATA_XFELD eFlAle;
	CSDATA_XFELD eFlCommitAndWait;
	CSDATA_XFELD eFlNoCommitWork;
	AENV_API01 eObjectBom;
	AENV_API01 eObjectBomCus;
	AENV_API01 eObjectBomDoc;
	AENV_API01 eObjectBomEqui;
	AENV_API01 eObjectBomLoc;
	AENV_API01 eObjectBomMat;
	AENV_API01 eObjectBomPsp;
	AENV_API01 eObjectBomStd;
	AENV_API01 eObjectChar;
	AENV_API01 eObjectCls;
	AENV_API01 eObjectClsMaint;
	AENV_API01 eObjectConfProf;
	AENV_API01 eObjectDep;
	AENV_API01 eObjectDoc;
	AENV_API01 eObjectHazmat;
	AENV_API01 eObjectMat;
	AENV_API01 eObjectPhrase;
	AENV_API01 eObjectPvs;
	AENV_API01 eObjectPvsAlt;
	AENV_API01 eObjectPvsRel;
	AENV_API01 eObjectPvsVar;
	AENV_API01 eObjectSubstance;
	AENV_API01 eObjectTlist;
	AENV_API01 eObjectTlist2;
	AENV_API01 eObjectTlistA;
	AENV_API01 eObjectTlistE;
	AENV_API01 eObjectTlistM;
	AENV_API01 eObjectTlistN;
	AENV_API01 eObjectTlistQ;
	AENV_API01 eObjectTlistR;
	AENV_API01 eObjectTlistS;
	AENV_API01 eObjectTlistT;
	AENV_API01 eObjectValidMatvers;
	AENV_API01 eObjectVarTab;
	AEEF_API01 eValueAssign;
	AENRB_AENNR iChangeNo;
	ITAB_H thAltDates = ITAB_NULL;
	ITAB_H thEffectivity = ITAB_NULL;
	ITAB_H thObjmgrec = ITAB_NULL;
	ITAB_H thTextheader = ITAB_NULL;
	ITAB_H thTextlines = ITAB_NULL;
	char xException[256];

	AEOI_API01 *tObjmgrec;

	//tc_strdup("29.09.2018",&apl_release_date); //Temp Date

	printf("\nChangeNo : %s ",dml_no_arg);
	printf("\nDMLDescription : %s",DMLDescription);
	printf("\nSTD_RELEASE_DATE : %s",apl_release_date);
	
	SETCHAR(eChangeHeader.ChangeNo,dml_no_arg);
	SETNUM(eChangeHeader.Status,"01");
	SETCHAR(eChangeHeader.AuthGroup,"");

	SETCHAR(eChangeHeader.ValidFrom,apl_release_date);
	SETCHAR(eChangeHeader.Descript,DMLDescription);
	SETCHAR(eChangeHeader.ReasonChg,"");
	SETCHAR(eChangeHeader.DeletionMark,"");
	SETCHAR(eChangeHeader.IndateRule,"");
	SETCHAR(eChangeHeader.OutdateRule,"");
	SETCHAR(eChangeHeader.Function,"");
	SETCHAR(eChangeHeader.ChangeLeader,"");
	SETCHAR(eChangeHeader.EffectivityType,"");
	SETCHAR(eChangeHeader.OverridingMark,"");
	SETNUM(eChangeHeader.Rank,"");
	SETNUM(eChangeHeader.ReleaseKey,"");
	SETCHAR(eChangeHeader.StatusProfile,"");
	SETCHAR(eChangeHeader.TechRel,"");
	SETCHAR(eChangeHeader.BasicChange,"");
	SETCHAR(eFlAle,"");
	SETCHAR(eFlCommitAndWait,"X");
	SETCHAR(eFlNoCommitWork,"");
	SETCHAR(eObjectBom.Active,"");
	SETCHAR(eObjectBom.Locked,"");
	SETCHAR(eObjectBom.ObjRequ,"");
	SETCHAR(eObjectBom.MgtrecGen,"");
	SETCHAR(eObjectBom.GenNew,"");
	SETCHAR(eObjectBom.GenDialog,"");
	SETCHAR(eObjectBomCus.Active,"");
	SETCHAR(eObjectBomCus.Locked,"");
	SETCHAR(eObjectBomCus.ObjRequ,"");
	SETCHAR(eObjectBomCus.MgtrecGen,"");
	SETCHAR(eObjectBomCus.GenNew,"");
	SETCHAR(eObjectBomCus.GenDialog,"");
	SETCHAR(eObjectBomDoc.Active,"");
	SETCHAR(eObjectBomDoc.Locked,"");
	SETCHAR(eObjectBomDoc.ObjRequ,"");
	SETCHAR(eObjectBomDoc.MgtrecGen,"");
	SETCHAR(eObjectBomDoc.GenNew,"");
	SETCHAR(eObjectBomDoc.GenDialog,"");
	SETCHAR(eObjectBomEqui.Active,"");
	SETCHAR(eObjectBomEqui.Locked,"");
	SETCHAR(eObjectBomEqui.ObjRequ,"");
	SETCHAR(eObjectBomEqui.MgtrecGen,"");
	SETCHAR(eObjectBomEqui.GenNew,"");
	SETCHAR(eObjectBomEqui.GenDialog,"");
	SETCHAR(eObjectBomLoc.Active,"");
	SETCHAR(eObjectBomLoc.Locked,"");
	SETCHAR(eObjectBomLoc.ObjRequ,"");
	SETCHAR(eObjectBomLoc.MgtrecGen,"");
	SETCHAR(eObjectBomLoc.GenNew,"");
	SETCHAR(eObjectBomLoc.GenDialog,"");
	SETCHAR(eObjectBomMat.Active,"X");
	SETCHAR(eObjectBomMat.Locked,"");
	SETCHAR(eObjectBomMat.ObjRequ,"X");
	SETCHAR(eObjectBomMat.MgtrecGen,"X");
	SETCHAR(eObjectBomMat.GenNew,"");
	SETCHAR(eObjectBomMat.GenDialog,"");
	SETCHAR(eObjectBomPsp.Active,"");
	SETCHAR(eObjectBomPsp.Locked,"");
	SETCHAR(eObjectBomPsp.ObjRequ,"");
	SETCHAR(eObjectBomPsp.MgtrecGen,"");
	SETCHAR(eObjectBomPsp.GenNew,"");
	SETCHAR(eObjectBomPsp.GenDialog,"");
	SETCHAR(eObjectBomStd.Active,"");
	SETCHAR(eObjectBomStd.Locked,"");
	SETCHAR(eObjectBomStd.ObjRequ,"");
	SETCHAR(eObjectBomStd.MgtrecGen,"");
	SETCHAR(eObjectBomStd.GenNew,"");
	SETCHAR(eObjectBomStd.GenDialog,"");
	SETCHAR(eObjectChar.Active,"");
	SETCHAR(eObjectChar.Locked,"");
	SETCHAR(eObjectChar.ObjRequ,"");
	SETCHAR(eObjectChar.MgtrecGen,"");
	SETCHAR(eObjectChar.GenNew,"");
	SETCHAR(eObjectChar.GenDialog,"");
	SETCHAR(eObjectCls.Active,"");
	SETCHAR(eObjectCls.Locked,"");
	SETCHAR(eObjectCls.ObjRequ,"");
	SETCHAR(eObjectCls.MgtrecGen,"");
	SETCHAR(eObjectCls.GenNew,"");
	SETCHAR(eObjectCls.GenDialog,"");
	SETCHAR(eObjectClsMaint.Active,"");
	SETCHAR(eObjectClsMaint.Locked,"");
	SETCHAR(eObjectClsMaint.ObjRequ,"");
	SETCHAR(eObjectClsMaint.MgtrecGen,"");
	SETCHAR(eObjectClsMaint.GenNew,"");
	SETCHAR(eObjectClsMaint.GenDialog,"");
	SETCHAR(eObjectConfProf.Active,"");
	SETCHAR(eObjectConfProf.Locked,"");
	SETCHAR(eObjectConfProf.ObjRequ,"");
	SETCHAR(eObjectConfProf.MgtrecGen,"");
	SETCHAR(eObjectConfProf.GenNew,"");
	SETCHAR(eObjectConfProf.GenDialog,"");
	SETCHAR(eObjectDep.Active,"");
	SETCHAR(eObjectDep.Locked,"");
	SETCHAR(eObjectDep.ObjRequ,"");
	SETCHAR(eObjectDep.MgtrecGen,"");
	SETCHAR(eObjectDep.GenNew,"");
	SETCHAR(eObjectDep.GenDialog,"");
	SETCHAR(eObjectDoc.Active,"X");
	SETCHAR(eObjectDoc.Locked,"");
	SETCHAR(eObjectDoc.ObjRequ,"X");
	SETCHAR(eObjectDoc.MgtrecGen,"X");
	SETCHAR(eObjectDoc.GenNew,"");
	SETCHAR(eObjectDoc.GenDialog,"");
	SETCHAR(eObjectHazmat.Active,"");
	SETCHAR(eObjectHazmat.Locked,"");
	SETCHAR(eObjectHazmat.ObjRequ,"");
	SETCHAR(eObjectHazmat.MgtrecGen,"");
	SETCHAR(eObjectHazmat.GenNew,"");
	SETCHAR(eObjectHazmat.GenDialog,"");
	SETCHAR(eObjectMat.Active,"X");
	SETCHAR(eObjectMat.Locked,"");
	SETCHAR(eObjectMat.ObjRequ,"X");
	SETCHAR(eObjectMat.MgtrecGen,"X");
	SETCHAR(eObjectMat.GenNew,"");
	SETCHAR(eObjectMat.GenDialog,"");
	SETCHAR(eObjectPhrase.Active,"");
	SETCHAR(eObjectPhrase.Locked,"");
	SETCHAR(eObjectPhrase.ObjRequ,"");
	SETCHAR(eObjectPhrase.MgtrecGen,"");
	SETCHAR(eObjectPhrase.GenNew,"");
	SETCHAR(eObjectPhrase.GenDialog,"");
	SETCHAR(eObjectPvs.Active,"");
	SETCHAR(eObjectPvs.Locked,"");
	SETCHAR(eObjectPvs.ObjRequ,"");
	SETCHAR(eObjectPvs.MgtrecGen,"");
	SETCHAR(eObjectPvs.GenNew,"");
	SETCHAR(eObjectPvs.GenDialog,"");
	SETCHAR(eObjectPvsAlt.Active,"");
	SETCHAR(eObjectPvsAlt.Locked,"");
	SETCHAR(eObjectPvsAlt.ObjRequ,"");
	SETCHAR(eObjectPvsAlt.MgtrecGen,"");
	SETCHAR(eObjectPvsAlt.GenNew,"");
	SETCHAR(eObjectPvsAlt.GenDialog,"");
	SETCHAR(eObjectPvsRel.Active,"");
	SETCHAR(eObjectPvsRel.Locked,"");
	SETCHAR(eObjectPvsRel.ObjRequ,"");
	SETCHAR(eObjectPvsRel.MgtrecGen,"");
	SETCHAR(eObjectPvsRel.GenNew,"");
	SETCHAR(eObjectPvsRel.GenDialog,"");
	SETCHAR(eObjectPvsVar.Active,"");
	SETCHAR(eObjectPvsVar.Locked,"");
	SETCHAR(eObjectPvsVar.ObjRequ,"");
	SETCHAR(eObjectPvsVar.MgtrecGen,"");
	SETCHAR(eObjectPvsVar.GenNew,"");
	SETCHAR(eObjectPvsVar.GenDialog,"");
	SETCHAR(eObjectSubstance.Active,"");
	SETCHAR(eObjectSubstance.Locked,"");
	SETCHAR(eObjectSubstance.ObjRequ,"");
	SETCHAR(eObjectSubstance.MgtrecGen,"");
	SETCHAR(eObjectSubstance.GenNew,"");
	SETCHAR(eObjectSubstance.GenDialog,"");
	SETCHAR(eObjectTlist.Active,"");
	SETCHAR(eObjectTlist.Locked,"");
	SETCHAR(eObjectTlist.ObjRequ,"");
	SETCHAR(eObjectTlist.MgtrecGen,"");
	SETCHAR(eObjectTlist.GenNew,"");
	SETCHAR(eObjectTlist.GenDialog,"");
	SETCHAR(eObjectTlist2.Active,"");
	SETCHAR(eObjectTlist2.Locked,"");
	SETCHAR(eObjectTlist2.ObjRequ,"");
	SETCHAR(eObjectTlist2.MgtrecGen,"");
	SETCHAR(eObjectTlist2.GenNew,"");
	SETCHAR(eObjectTlist2.GenDialog,"");
	SETCHAR(eObjectTlistA.Active,"");
	SETCHAR(eObjectTlistA.Locked,"");
	SETCHAR(eObjectTlistA.ObjRequ,"");
	SETCHAR(eObjectTlistA.MgtrecGen,"");
	SETCHAR(eObjectTlistA.GenNew,"");
	SETCHAR(eObjectTlistA.GenDialog,"");
	SETCHAR(eObjectTlistE.Active,"");
	SETCHAR(eObjectTlistE.Locked,"");
	SETCHAR(eObjectTlistE.ObjRequ,"");
	SETCHAR(eObjectTlistE.MgtrecGen,"");
	SETCHAR(eObjectTlistE.GenNew,"");
	SETCHAR(eObjectTlistE.GenDialog,"");
	SETCHAR(eObjectTlistM.Active,"");
	SETCHAR(eObjectTlistM.Locked,"");
	SETCHAR(eObjectTlistM.ObjRequ,"");
	SETCHAR(eObjectTlistM.MgtrecGen,"");
	SETCHAR(eObjectTlistM.GenNew,"");
	SETCHAR(eObjectTlistM.GenDialog,"");
	SETCHAR(eObjectTlistN.Active,"");
	SETCHAR(eObjectTlistN.Locked,"");
	SETCHAR(eObjectTlistN.ObjRequ,"");
	SETCHAR(eObjectTlistN.MgtrecGen,"");
	SETCHAR(eObjectTlistN.GenNew,"");
	SETCHAR(eObjectTlistN.GenDialog,"");
	SETCHAR(eObjectTlistQ.Active,"");
	SETCHAR(eObjectTlistQ.Locked,"");
	SETCHAR(eObjectTlistQ.ObjRequ,"");
	SETCHAR(eObjectTlistQ.MgtrecGen,"");
	SETCHAR(eObjectTlistQ.GenNew,"");
	SETCHAR(eObjectTlistQ.GenDialog,"");
	SETCHAR(eObjectTlistR.Active,"");
	SETCHAR(eObjectTlistR.Locked,"");
	SETCHAR(eObjectTlistR.ObjRequ,"");
	SETCHAR(eObjectTlistR.MgtrecGen,"");
	SETCHAR(eObjectTlistR.GenNew,"");
	SETCHAR(eObjectTlistR.GenDialog,"");
	SETCHAR(eObjectTlistS.Active,"");
	SETCHAR(eObjectTlistS.Locked,"");
	SETCHAR(eObjectTlistS.ObjRequ,"");
	SETCHAR(eObjectTlistS.MgtrecGen,"");
	SETCHAR(eObjectTlistS.GenNew,"");
	SETCHAR(eObjectTlistS.GenDialog,"");
	SETCHAR(eObjectTlistT.Active,"");
	SETCHAR(eObjectTlistT.Locked,"");
	SETCHAR(eObjectTlistT.ObjRequ,"");
	SETCHAR(eObjectTlistT.MgtrecGen,"");
	SETCHAR(eObjectTlistT.GenNew,"");
	SETCHAR(eObjectTlistT.GenDialog,"");
	SETCHAR(eObjectValidMatvers.Active,"");
	SETCHAR(eObjectValidMatvers.Locked,"");
	SETCHAR(eObjectValidMatvers.ObjRequ,"");
	SETCHAR(eObjectValidMatvers.MgtrecGen,"");
	SETCHAR(eObjectValidMatvers.GenNew,"");
	SETCHAR(eObjectValidMatvers.GenDialog,"");
	SETCHAR(eObjectVarTab.Active,"");
	SETCHAR(eObjectVarTab.Locked,"");
	SETCHAR(eObjectVarTab.ObjRequ,"");
	SETCHAR(eObjectVarTab.MgtrecGen,"");
	SETCHAR(eObjectVarTab.GenNew,"");
	SETCHAR(eObjectVarTab.GenDialog,"");
	SETCHAR(eValueAssign.ValidFrom,"");
	SETCHAR(eValueAssign.ValidTo,"");
	SETCHAR(eValueAssign.DateMark,"");
	SETCHAR(eValueAssign.Material,"");
	SETCHAR(eValueAssign.SerialnrLow,"");
	SETCHAR(eValueAssign.SerialnrHigh,"");
	SETCHAR(eValueAssign.Class,"");
	SETCHAR(eValueAssign.Classty,"");
	SETCHAR(eValueAssign.Startup,"");
	SETCHAR(eValueAssign.Plant,"");
	SETCHAR(eValueAssign.SernrOi,"");
	SETCHAR(eValueAssign.FlDelete,"");


    if (thAltDates==ITAB_NULL)
	{
		thAltDates = ItCreate("ALT_DATES", sizeof(AEDT_API01), 0, 0);
		if (thAltDates == ITAB_NULL)
			printf("\nItCreate ALT_DATES");
	}
    else if (ItFree(thAltDates) != 0)
		printf("\nItFree ALT_DATES");

    if (thEffectivity==ITAB_NULL)
	{
		thEffectivity = ItCreate("EFFECTIVITY", sizeof(AEEF_API01), 0, 0);
		if (thEffectivity == ITAB_NULL)
			printf("\nItCreate EFFECTIVITY");
	}
    else if (ItFree(thEffectivity) != 0)
		printf("\nItFree EFFECTIVITY");

	if (thObjmgrec==ITAB_NULL)
	{
		thObjmgrec = ItCreate("OBJMGREC", sizeof(AEOI_API01), 0, 0);
		if (thObjmgrec==ITAB_NULL)
			printf("\nItCreate OBJMGREC");
	}
    else if (ItFree(thObjmgrec) != 0)
		printf("\nItFree OBJMGREC");

    if (thTextheader==ITAB_NULL)
	{
		thTextheader = ItCreate("TEXTHEADER", sizeof(CCTHEAD), 0, 0);
		if (thTextheader==ITAB_NULL)
			printf("\nItCreate TEXTHEADER");
	}
    else if (ItFree(thTextheader) != 0)
		printf("\nItFree TEXTHEADER");

    if (thTextlines==ITAB_NULL)
	{
		thTextlines = ItCreate("TEXTLINES", sizeof(CCTLINE), 0, 0);
		if (thTextlines==ITAB_NULL)
			printf("\nItCreate TEXTLINES");
	}
    else if (ItFree(thTextlines) != 0)
		printf("\nItFree TEXTLINES");

	printf("\nTaskCnt in Displaying Object %d",tcount);
	//fprintf(fsuccess,"\nTaskCnt in Displaying Object %d",tcount);

	for (Cnt=0;Cnt<tcount ;Cnt++ )
	{
		TaskRevTag = TaskRevision[Cnt];
		ITK_CALL(AOM_ask_value_string(TaskRevTag,"item_id",&taskIdStr));

		pCnt=0;
		ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&pCnt,&ChPartTags));
		printf("\nTask To Part Count : %d",pCnt);fflush(stdout);
			
		if(pCnt>0)
		{
			for(PartCnt=0;PartCnt<pCnt;PartCnt++)
			{
				PartTag1=ChPartTags[PartCnt];
				ITK_CALL(AOM_ask_value_string(PartTag1,"item_id",&PartNumC));
				ITK_CALL(AOM_ask_value_string(PartTag1,"t5_PartType",&part_typeC));

				//Skipping Dummy,Dummy Assembly/Component,Info Fit Drw Parts
				if(	tc_strcmp(part_typeC,"D")==0 ||
					tc_strcmp(part_typeC,"DA")==0 ||
					tc_strcmp(part_typeC,"DC")==0 ||
					tc_strcmp(part_typeC,"IFD")==0 ||
					tc_strcmp(part_typeC,"IM")==0 ||
					tc_strcmp(part_typeC,"CP")==0)
				{	continue;	}

				printf("\nAdding partno As Part is %s %s", PartNumC,part_typeC);
				fprintf(fsuccess,"\nAdding partno As Part is %s %s", PartNumC,part_typeC);

				tObjmgrec = ItAppLine(thObjmgrec);
				if (tObjmgrec == NULL)
					printf("\nItAppLine OBJMGREC");

				SETCHAR(tObjmgrec->AltDate,"");
				SETNUM(tObjmgrec->ChgObjtyp,"");
				SETNUM(tObjmgrec->ChgObjtyp,"4");
				SETCHAR(tObjmgrec->BomCat,"");
				SETCHAR(tObjmgrec->BomStdObject,"");
				SETCHAR(tObjmgrec->BomUsage,"");
				SETNUM(tObjmgrec->Chgtypeobj,"");
				SETCHAR(tObjmgrec->DescrObj,"");
				SETCHAR(tObjmgrec->DocType,"");
				SETCHAR(tObjmgrec->DocNumber,"");
				SETCHAR(tObjmgrec->DocVers,"");
				SETCHAR(tObjmgrec->DocPart,"");
				SETCHAR(tObjmgrec->Equipment,"");
				SETCHAR(tObjmgrec->FuncLoc,"");
				SETCHAR(tObjmgrec->Material,PartNumC);
				SETCHAR(tObjmgrec->Plant,"");
				SETCHAR(tObjmgrec->PspElement,"");
				SETCHAR(tObjmgrec->PvsType,"");
				SETCHAR(tObjmgrec->PvsNode,"");
				SETCHAR(tObjmgrec->PvsClassNumber,"");
				SETCHAR(tObjmgrec->PvsClassType,"");
				SETCHAR(tObjmgrec->PvsVariant,"");
				SETCHAR(tObjmgrec->SdOrder,"");
				SETNUM(tObjmgrec->SdOrderI,"");
				SETNUM(tObjmgrec->Textkey,"");
				SETCHAR(tObjmgrec->TlistType,"");
				SETCHAR(tObjmgrec->TlistGrp,"");
				SETCHAR(tObjmgrec->ObjChglock,"");
				SETCHAR(tObjmgrec->StatusProfObj,"");
				SETCHAR(tObjmgrec->FlDelete,"");
			}
		}
	}
	RfcRc = ccap_ecn_create(hRfc,&eChangeHeader,&eFlAle,&eFlCommitAndWait,&eFlNoCommitWork,&eObjectBom,&eObjectBomCus,&eObjectBomDoc,&eObjectBomEqui,&eObjectBomLoc,&eObjectBomMat,&eObjectBomPsp,&eObjectBomStd,&eObjectChar,&eObjectCls,&eObjectClsMaint,&eObjectConfProf,&eObjectDep,&eObjectDoc,&eObjectHazmat,&eObjectMat,&eObjectPhrase,&eObjectPvs,&eObjectPvsAlt,&eObjectPvsRel,&eObjectPvsVar,&eObjectSubstance,&eObjectTlist,&eObjectTlist2,&eObjectTlistA,&eObjectTlistE,&eObjectTlistM,&eObjectTlistN,&eObjectTlistQ,&eObjectTlistR,&eObjectTlistS,&eObjectTlistT,&eObjectValidMatvers,&eObjectVarTab,&eValueAssign,&iChangeNo,thAltDates,thEffectivity,thObjmgrec,thTextheader,thTextlines,xException);
	switch (RfcRc)
	{
		case RFC_OK:
			printf("\necn create: %u",RFC_OK);
			fprintf(fsuccess,"\necn create: %u",RFC_OK);
		break;
		case RFC_EXCEPTION :
			printf("\nRFC Exception: %s",xException);
			fprintf(fsuccess,"\nRFC Exception: %s",xException);
		break;
		default:;
	}
	EXIT:
	printf("\nexit from ecn create");
	return RfcRc;
}

FetchPlantSpecificData(char* DMLNumber,char* ProjCode)
{
	char	*DMLNo			= NULL;
	char	*SAPLivFlg		= NULL;
	
	int     n_entry			= 3;
	int     p_entry			= 2;
	int		ContObjCnt		= 0;

	tag_t   PlantCodeQryTag     = NULLTAG;
	tag_t   MakeBuyQryTag		= NULLTAG;
	tag_t   PlantDataQryTag     = NULLTAG;
	tag_t   *ContorlObjTag		= NULLTAG;

	char    *qry_entryApl[3]  = {"SYSCD","SUBSYSCD","Information-1"};
	char    *qry_entryStd[3]  = {"SYSCD","SUBSYSCD","Information-2"};
	char    *qry_entryMake[2] = {"SYSCD","SUBSYSCD"};

	bl_mkbuy_string = (char *)malloc(500 * sizeof(char));
	profit_centre_sap = (char *)malloc(100 * sizeof(char));

	DMLNo = strtok(DMLNumber, "_" );
	PlantSuffix  = strtok ( NULL, "_" );
	
	tc_strcpy(dml_no_arg,DMLNo);
	tc_strcpy(dml_numAP1,DMLNo);

	printf("\nDMLNo [%s]	PlantSuffix [%s]	Project Code [%s]", DMLNo,PlantSuffix,ProjCode);

	char	*qry_value[3] = {"XFRDML",ProjCode,PlantSuffix};
	
	if(QRY_find("Control Objects...", &PlantCodeQryTag));

	if(PlantCodeQryTag)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		if(QRY_execute(PlantCodeQryTag,n_entry,qry_entryApl,qry_value,&ContObjCnt,&ContorlObjTag));

		if (ContObjCnt==0)
		{
			if(QRY_execute(PlantCodeQryTag,n_entry,qry_entryStd,qry_value,&ContObjCnt,&ContorlObjTag));
		}

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&plantcode);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&SAPLivFlg);
			printf("\nPlantSuffix [%s]	Plant Code [%s]",PlantSuffix,plantcode);
		}
		else
		{
			printf("\nProjectCode [%s] do not have entry in Control Object PlantDML for Suffix [%s] hence exiting!",ProjCode,PlantSuffix); fflush(stdout);
			goto CLEANUP;
		}

		char    *qry_MakeValue[2]  = {"MAKEBUY",plantcode};
		
		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_MakeValue,&ContObjCnt,&ContorlObjTag));

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&Plant_StoreLoc);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&Plant_MakeBuy);
			printf("\nPlant Code [%s]	Plant_MakeBuy [%s]	Plant_StoreLoc [%s]",plantcode,Plant_MakeBuy,Plant_StoreLoc);

			tc_strcpy(bl_mkbuy_string,"bl_Design Revision_");
			tc_strcat(bl_mkbuy_string,Plant_MakeBuy);
			printf("\nbl_mkbuy_string [%s]",bl_mkbuy_string);
		}
		else
		{
			printf("\nPlantcode [%s] do not have entry in Control Object MAKEBUY hence exiting!",plantcode); fflush(stdout);
			goto CLEANUP;
		}



		char    *qry_PlantValue[2]  = {"PLANTDATA",plantcode};

		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_PlantValue,&ContObjCnt,&ContorlObjTag));

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&profit_centre2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&plan_calendar2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&overhd_grp2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&origin_group2);

			tc_strcpy(profit_centre_sap,"000");
			tc_strcat(profit_centre_sap,profit_centre2);
			tc_strdup(plan_calendar2,&plan_calendar);
			tc_strdup(overhd_grp2,&overhd_grp);
			tc_strdup(origin_group2,&origin_group);

			printf("\nplantcode      :[%s]",plantcode);
			printf("\nprofit_centre  :[%s]",profit_centre_sap);
			printf("\nplan_calendar  :[%s]",plan_calendar);
			printf("\noverhd_grp     :[%s]",overhd_grp);
			printf("\norigin_group   :[%s]",origin_group);
		}
		
		if (tc_strlen(PlantSuffix)>3)
		{
			dml_no_arg[10] = PlantSuffix[3];
			dml_no_arg[11] = 'T';
			dml_no_arg[12] = '\0';

			dml_numAP1[10] = PlantSuffix[3];
			dml_numAP1[11] = 'T';
			dml_numAP1[12] = '\0';
		}
		else
		{
			tc_strcat(dml_no_arg,"ST");
			tc_strcat(dml_numAP1,"ST");
		}
	}

	CLEANUP:
	return ContObjCnt;
}


int pstat_basicFun(void)
{
	//printf("\n In pstat_basicFun function..[%s]\n",sappstat); fflush(stdout);
	if(tc_strlen(tc_strstr(SAPpstat,"K"))>0)
	{
		pstat = 'K';
	}
	else
	{
		pstat = '0';
	}

	
   if(tc_strlen(tc_strstr(MRPpstat,"D"))>0)
	{
		pstat_mrp = 'D';
	}
	else
	{
		pstat_mrp = '0';
	}

	
  if(tc_strlen(tc_strstr(MRPpstat,"B"))>0)
	{
		pstat_acc = 'B';
	}
	else
	{
		pstat_acc = '0';
	}
	//printf("\n..%c:%c:%c..\n",pstat,pstat_mrp,pstat_acc); fflush(stdout);
	return 0;
}


int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3])
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;
	AENNR eAennr;
	CCMATNR eMatnr;
	CC_REVLV eRevlv;

	MESSAGEINF iMessg;
	SYST_SUBRC iRetval;
	char xException[256];



	hRfc = BapiLogon();

	printf("\nValues received: \nDml No.: %s\nPart No.: %s\nRev_Sheet_status: %s",sap_dml_no,sap_part_no,sap_rev_sheet_status); fflush(stdout);
	fprintf(fsuccess,"\nValues received: \nDml No.: %s\nPart No.: %s\nRev_Sheet_status: %s",sap_dml_no,sap_part_no,sap_rev_sheet_status); fflush(fsuccess);

	SETCHAR(eAennr.Aennr,sap_dml_no);
	SETCHAR(eMatnr.Ccmatnr,sap_part_no);
	SETCHAR(eRevlv.CcRevlv,sap_rev_sheet_status);


	RfcRc = zpprfc_revisionnum_change(hRfc,&eAennr,&eMatnr,&eRevlv,&iMessg,&iRetval,xException);
	switch (RfcRc)
	{
		case RFC_OK:
			printf("\nRevision Creation Message :%s",iMessg.Msgtx); fflush(stdout);
			fprintf(fsuccess,"\nRevision Creation Message :%s",iMessg.Msgtx); fflush(fsuccess);
			break;
		case RFC_EXCEPTION:
			printf("\nRFC_EXCEPTION raised"); fflush(stdout);
			fprintf(fsuccess,"\nRFC_EXCEPTION raised"); fflush(fsuccess);
			break;
		case RFC_SYS_EXCEPTION:
			printf("\nsystem exception raised"); fflush(stdout);
			fprintf(fsuccess,"\nsystem exception raised"); fflush(fsuccess);
			break;
		case RFC_FAILURE:
			printf("\nfailure"); fflush(stdout);
			break;
		default:
			printf("\nother failure"); fflush(stdout);
	}

	RfcClose(hRfc);
	return 0;
}

BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;

	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}


int findNextRelRev(tag_t CurRevTag)
{
	int status;
	tag_t	NextRelRev	= NULLTAG;
	tag_t	CurRevMas	= NULLTAG;
	tag_t	*allRevTag	= NULLTAG;
	char*	revNum	= NULL;
	char*	PrtRelStat	= NULL;
	char*	CurRevSeq	= NULL;
	char*	CurRev		= NULL;
	char*	nxtRevSeq	= NULL;
	char*	nxtRev		= NULL;

	int i = 0, revCnt = 0,nextOffFound = 0;

	printf("\n****Finding Next Official Revision****\n");fflush(stdout);
	ITK_CALL(AOM_UIF_ask_value(CurRevTag,"item_id",&revNum));
	printf("\nChecking Next Offcial Revision for : %s", revNum);fflush(stdout);

	ITK_CALL(ITEM_find_item(revNum, &CurRevMas));
	ITK_CALL(ITEM_list_all_revs(CurRevMas, &revCnt, &allRevTag));
	ITK_CALL(AOM_UIF_ask_value(CurRevTag,"item_revision_id",&CurRevSeq));
	CurRev = strtok(CurRevSeq,";");
	printf("\nTotal Revision Found : %d", revCnt);fflush(stdout);

	if(revCnt > 0)
	{
		for(i = revCnt-1; i >= 0 ; i--)
		{
			ITK_CALL(AOM_UIF_ask_value(allRevTag[i],"item_revision_id",&nxtRevSeq));
			nxtRev = strtok(nxtRevSeq,";");
			printf("\nCurrent Rev %s Latest Rev: %s",CurRev,nxtRev);fflush(stdout);

			if(tc_strcmp(CurRev,nxtRev)!=0)
			{
				ITK_CALL(AOM_UIF_ask_value(allRevTag[i],"release_status_list",&PrtRelStat));
				printf("\n%d Release Status : %s ",i,PrtRelStat);fflush(stdout);
				if(tc_strstr(PrtRelStat,"STDSIC Released")!=NULL)
				{

					NextRelRev = allRevTag[i];
					nextOffFound = 1;
					printf("\nNext Official Revision found...Current Rev %s Latest Rev: %s",CurRev,nxtRev);fflush(stdout);
					fprintf(fsuccess,"\nNext Official Revision found...Current Rev %s Latest Rev: %s",CurRev,nxtRev);fflush(stdout);
					break;
				}
			}
			else
			{
				printf("\nNext Official Revision not found...Current Rev %s Latest Rev: %s",CurRev,nxtRev);fflush(stdout);
				fprintf(fsuccess,"\nNext Official Revision not found...Current Rev %s Latest Rev: %s",CurRev,nxtRev);fflush(stdout);
				break;
			}
		}
	}

	return nextOffFound;
}

int ExpandBomForCreate(tag_t LatestRev,char *DML_Numb)
{
	int status;
	static int sr_no1 = 0;
	int pCnt=0;
	int CntChildP = 0;
	int ChildItemTag = 0;
	int Item_ID=0,Item_UoM=0,Item_Owner=0;
	int ret;
	int n_closure_tags;

	float floatQty= 0.000;
	struct usgProbnode *pUP = NULLTAG;

	struct node *start = NULL;
	struct node *p = NULL;
	struct node *q = NULL;

	tag_t		window			= NULLTAG;
	tag_t		rule			= NULLTAG;
	tag_t		PerentLine		= NULLTAG;
	tag_t		*ChildPartLine		= NULLTAG;
	tag_t		ChildItemRevTag		= NULLTAG;
	tag_t		*closure_tags		= NULLTAG;
	tag_t		closure_tag			= NULLTAG;
	tag_t		ChildOPtr			= NULLTAG;
	tag_t		*RwPartItemMst		= NULLTAG;
	tag_t		RwPartMstTag		= NULLTAG;
	tag_t		RwPartRel			= NULLTAG;
	tag_t		RawPartRelTag		= NULLTAG;

	char *LatRevName		= NULL;
	char *part_type			= NULL;
	char *unitDup			= NULL;
	char *ChildRevName		= NULL;
	char *ChildRevNameDup	= NULL;
	char *ChildOwnName		= NULL;
	char *ChildPrtType		= NULL;
	char *ChildPrtQty		= NULL;
	char *ChildQtyDup		= NULL;
	char *qty_req_info		= NULL;
	char *qty_req_infoDup	= NULL;
	char *ChildPrtUoM		= NULL;
	char *ChildPartType		= NULL;
	char *make_buy_ind		= NULL;
	char *make_buy_indDup	= NULL;
	char *meas_unit			= NULL;
	char *tempcsrel			= NULL;
	char *mat_prov_ind		= NULL;
	char *sr_no				= NULL;
	char* PartRelStatus		= NULL;
	char* ChildRelStatus	= NULL;
	char *AssemblyRevision	= NULL;
	char *SequenceRevision	= NULL;
	char *OrganizationID	= NULL;
	char *ClosureRule		= NULL;
	
	//ClosureRule = (char *) MEM_alloc(100 * sizeof(char ));
	sr_no		= (char *) malloc(500 * sizeof(char));
	meas_unit	= (char *) malloc(500 * sizeof(char));

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"object_string",&LatRevName));
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"owning_user",&OwnerName));
	tc_strdup(OwnerName,&OwnerNameDup);
	ITK_CALL(AOM_ask_value_string(LatestRev,"t5_PartType",&part_type));
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_id",&assy_noDup));
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_revision_id",&PrtRev));
	PrtRevDup = strtok(PrtRev,";");
	PrtSeqDup = strtok(NULL, ";" );

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));

	tc_strdup(PrtRevDup,&AssemblyRevision);
	tc_strdup(PrtSeqDup,&SequenceRevision);
	tc_strdup("ERC",&OrganizationID);

	printf("\n\n\nLatRevName:%s",LatRevName);fflush(stdout);
	fprintf(fsuccess,"\n\n\nLatRevName:%s",LatRevName);fflush(stdout);
	printf("\nPart Type: %s",part_type);
	fprintf(fsuccess,"\nPart Type: %s",part_type);
	printf("\npart_noDup: %s",assy_noDup);
	fprintf(fsuccess,"\npart_noDup: %s",assy_noDup);
	printf("\nOwnerName: %s",OwnerNameDup);

	if(	tc_strcmp(part_type,"D")==0 ||
		tc_strcmp(part_type,"DA")==0 ||
		tc_strcmp(part_type,"DC")==0 ||
		tc_strcmp(part_type,"IFD")==0 ||
		tc_strcmp(part_type,"IM")==0 ||
		tc_strcmp(part_type,"CP")==0)
	{
		printf("\nSkipping from Bom Transfer as Part Type is %s : %s\n",part_type,assy_noDup);
		fprintf(fsuccess,"\nSkipping from Bom Transfer as Part Type is %s : %s\n",part_type,assy_noDup);
		goto CLEANUP;
	}

	if(tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)
	{
		printf("\nPartRelStatus: %s\n",PartRelStatus);
		fprintf(fsuccess,"\nPartRelStatus: %s\n",PartRelStatus);
	}
	else
	{
		printf("\nPart %s PartRelStatus: %s Part not STD Released...Skipping\n",LatRevName,PartRelStatus);
		fprintf(fsuccess,"\nPart %s PartRelStatus: %s Part not STD Released...Skipping\n",LatRevName,PartRelStatus);
		goto CLEANUP;
	}

	if (findNextRelRev(LatestRev)==1)
	{
		printf("\nNext Official Revision Found for Part %s ...Skipping Bom Transfer\n",LatRevName);
		fprintf(fsuccess,"\nNext Official Revision Found for Part %s ...Skipping Bom Transfer\n",LatRevName);
		goto CLEANUP;
	}

	if( tc_strcmp(part_type,"M")==0 ||
		tc_strcmp(part_type,"EM")==0 ||
		tc_strcmp(part_type,"V")==0 ||
		tc_strcmp(part_type,"VC")==0 ||
		tc_strcmp(part_type,"T")==0 ||
		tc_strcmp(part_type,"A")==0 ||
		tc_strcmp(part_type,"C")==0 ||
		tc_strcmp(part_type,"G")==0 ||
		tc_strcmp(part_type,"SA")==0 ||
		tc_strcmp(part_type,"SP")==0 ||
		tc_strcmp(part_type,"R")==0)
	{
		printf("\nExpanding %s BOM...",assy_noDup);
		fprintf(fsuccess,"\nExpanding %s BOM...",assy_noDup);
		//Setting BOM Window
		ITK_CALL(BOM_create_window (&window));
		//CFM_find("Latest Working", &rule );
		//ITK_CALL(CFM_find("STDC Release and above", &rule ));
		ITK_CALL(CFM_find("STDC Released and Above", &rule ));
		ITK_CALL(BOM_set_window_config_rule( window, rule ));
		//Setting Closure Rule Start
		tc_strdup("BOMViewClosureRuleSTDC",&ClosureRule);
		printf("\nSetting ClosureRule : %s",ClosureRule);
		fprintf(fsuccess,"\nSetting ClosureRule : %s",ClosureRule);
		ITK_CALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &n_closure_tags, &closure_tags ));
		printf("\nn_closure_tags :%d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags > 0)
		{
			closure_tag=closure_tags[0];
			ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
		}
		//Setting Closure Rule End

		BOM_set_window_pack_all (window, true);
		BOM_set_window_top_line (window, null_tag, LatestRev, null_tag, &PerentLine);
		BOM_line_ask_child_lines(PerentLine, &CntChildP, &ChildPartLine);
		printf("\nNo of Child Parts : [%d]\n",CntChildP);
		fprintf(fsuccess,"\nNo of Child Parts : [%d]\n",CntChildP);

		if(tc_strcmp(part_type,"SP")==0 || tc_strcmp(part_type,"R")==0)
		{
			ITK_CALL(GRM_find_relation_type("T5_RPtRel",&RwPartRel));
			ITK_CALL(AOM_ask_value_tags(LatestRev,"T5_RPtRel",&CntChildP,&RwPartItemMst));
			printf("\nChild Raw Part Count : %d",CntChildP);fflush(stdout);
			fprintf(fsuccess,"\nChild Raw Part Count : %d",CntChildP);fflush(stdout);
		}

		if(CntChildP>0)
		{
			for(pCnt=0;pCnt<CntChildP;pCnt++)
			{
				if (tc_strcmp(part_type,"SP")==0 || tc_strcmp(part_type,"R")==0)
				{
					RwPartMstTag=RwPartItemMst[pCnt];
					ITK_CALL(ITEM_ask_latest_rev(RwPartMstTag,&ChildOPtr));
					
					ITK_CALL(AOM_ask_value_string(ChildOPtr,"item_id",&ChildRevName));
					ITK_CALL(AOM_ask_value_string(ChildOPtr,"t5_uom",&ChildPrtUoM));
					ITK_CALL(AOM_ask_value_string(ChildOPtr,"t5_PartType",&ChildPartType));
					ITK_CALL(AOM_UIF_ask_value(ChildOPtr,"release_status_list",&ChildRelStatus));
					ITK_CALL(AOM_ask_value_string(ChildOPtr,Plant_MakeBuy,&make_buy_ind));

					ITK_CALL(GRM_find_relation(LatestRev,RwPartMstTag,RwPartRel,&RawPartRelTag));
					ITK_CALL(AOM_UIF_ask_value(RawPartRelTag,"t5_UsageRT",&ChildPrtQty));
					tc_strdup(ChildPrtQty,&ChildQtyDup);
					printf("\nChild Raw Part :%s,%s,%s,%s",ChildRevName,ChildPrtUoM,ChildPartType,ChildPrtQty);
				}
				else
				{
					ChildOPtr=ChildPartLine[pCnt];

					BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID);
					BOM_line_ask_attribute_string(ChildOPtr, Item_ID, &ChildRevName);
					
					BOM_line_look_up_attribute ("bl_Design_t5_uom",&Item_UoM);
					BOM_line_ask_attribute_string(ChildOPtr,Item_UoM,&ChildPrtUoM);

					BOM_line_look_up_attribute ("awb0RevisionOwningUser",&Item_Owner);
					BOM_line_ask_attribute_string(ChildOPtr,Item_Owner,&ChildOwnName);

					AOM_ask_value_string(ChildOPtr,"bl_Design Revision_t5_PartType",&ChildPartType);
					AOM_ask_value_string(ChildOPtr,bl_mkbuy_string,&make_buy_ind);
					
					AOM_ask_value_string(ChildOPtr,"bl_quantity",&ChildPrtQty);
					tc_strdup(ChildPrtQty,&ChildQtyDup);

					AOM_ask_value_string(ChildOPtr,"bl_occ_t5_Qri",&qty_req_info);
					tc_strdup(qty_req_info,&qty_req_infoDup);

					ITK_CALL(AOM_UIF_ask_value(ChildOPtr,"bl_rev_release_status_list",&ChildRelStatus));
				}

				if(tc_strstr(ChildRelStatus,"STDSIC Released")==NULL)
				{
					printf("\nChild Part %s ChildRelStatus: %s Part not STD Released...Skipping\n",ChildRevName,ChildRelStatus);
					fprintf(fsuccess,"\nChild Part %s ChildRelStatus: %s Part not STD Released...Skipping\n",ChildRevName,ChildRelStatus);
					continue;
				}

				if (
					tc_strcmp(ChildPartType,"D")==0 ||
					tc_strcmp(ChildPartType,"DA")==0 ||
					tc_strcmp(ChildPartType,"DC")==0 ||
					tc_strcmp(ChildPartType,"IFD")==0 ||
					tc_strcmp(ChildPartType,"IM")==0 ||
					tc_strcmp(ChildPartType,"CP")==0
					)
				{
					printf("\nSkipping Child Part [%s] as Part Type [%s]",ChildRevName,ChildPartType);
					fprintf(fsuccess,"\nSkipping Child Part [%s] as Part Type [%s]",ChildRevName,ChildPartType);
					continue;
				}

				if(tc_strlen(make_buy_ind)==0 || tc_strcmp(make_buy_ind,"NA")==0)
				{
					printf("\nSkipping Child Part [%s] as Plant Make/Buy is NULL or NA",ChildRevName);
					fprintf(fsuccess,"\nSkipping Child Part [%s] as Plant Make/Buy is NULL or NA",ChildRevName);
					continue;
				}
				
				if(tc_strcmp(ChildQtyDup,"0")==0 || tc_strcmp(ChildQtyDup,"0.00000")==0)
				{
					printf("\nSkipping Child Part [%s] as ChildPart Qty [%s]",ChildRevName,ChildQtyDup);
					fprintf(fsuccess,"\nSkipping Child Part [%s] as ChildPart Qty [%s]",ChildRevName,ChildQtyDup);
					continue;
				}

				printf("\n[%s] [%s] [%s] [%s] [%s]",ChildRevName,ChildPrtQty,ChildPrtUoM,ChildPartType,make_buy_ind);
				fprintf(fsuccess,"\n[%s] [%s] [%s] [%s] [%s]",ChildRevName,ChildPrtQty,ChildPrtUoM,ChildPartType,make_buy_ind);

				if(tc_strlen(ChildPrtUoM)>0)
				{
					tc_strdup(ChildPrtUoM,&unitDup);
					if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
					else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
					else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
					else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
					else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
					else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
					else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
					else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
					else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
					else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
					else
					{
						tc_strdup("EA",&unitDup);
						tc_strcpy(meas_unit,"EA");
					}
				}
				else tc_strcpy(meas_unit,"EA");
					
				printf("\nunitDup [%s] meas_unit [%s]",unitDup,meas_unit);
				fprintf(fsuccess,"\nunitDup [%s] meas_unit [%s]",unitDup,meas_unit);

				//Quantity Conversion Logic Start
				if(tc_strlen(ChildPrtQty)<=0)
				{
					tc_strdup("999999",&ChildQtyDup);
					printf("\nConverting Part %s as quantity is %s Null quantity hence exiting",ChildRevName,ChildQtyDup);fflush(stdout);
					fprintf(fsuccess,"\nConverting  this Part %s as quantity %s Null quantity hence exiting",ChildRevName,ChildQtyDup);fflush(stdout);
					continue;
				}

				if(tc_strcmp(ChildPrtQty,"99")==0)
				{
					tc_strdup("999999",&ChildQtyDup);
					printf("\nConverting Part %s as quantity is %s ",ChildRevName,ChildQtyDup);fflush(stdout);
					fprintf(fsuccess,"\n Converting  this Part %s as quantity %s",ChildRevName,ChildQtyDup);fflush(stdout);

				}
				if(tc_strcmp(ChildPrtQty,"97")==0)
				{
					tc_strdup("0",&ChildQtyDup);
					printf("\nConverting Part %s as 97-quantity is %s ",ChildRevName,ChildQtyDup); fflush(stdout);
					fprintf(fsuccess,"\nConverting  this Part %s as 97-quantity %s",ChildRevName,ChildQtyDup); fflush(stdout);
				}


				if((tc_strcmp(ChildPrtQty,"0")==0) && ((tc_strcmp(qty_req_infoDup,"NA")==0) || (tc_strcmp(qty_req_infoDup,"+")==0)))
				{
					printf("\nSkipping this Part %s as quantity is %s and Quantity Required information  is %s",ChildRevName,ChildPrtQty,qty_req_infoDup);fflush(stdout);
					fprintf(fsuccess,"\nSkipping this Part %s as quantity is %s and Quantity Required information  is %s",ChildRevName,ChildPrtQty,qty_req_infoDup);fflush(stdout);
					continue;
				}
				
				if((tc_strcmp(ChildPrtQty,"1")==0) && ((tc_strcmp(qty_req_infoDup,"+")==0)))
				{
					printf("\nSkipping this Part %s as quantity is %s and Quantity Required information  is %s",ChildRevName,ChildPrtQty,qty_req_infoDup);fflush(stdout);
					fprintf(fsuccess,"\nSkipping this Part %s as quantity is %s and Quantity Required information  is %s",ChildRevName,ChildPrtQty,qty_req_infoDup);fflush(stdout);
					continue;
				}
				
				if((tc_strcmp(ChildPrtQty,"0")==0) && (tc_strcmp(qty_req_infoDup,"AR")==0))
				{
					tc_strdup("1",&ChildQtyDup);
					printf("\nquantity after AR logic %s,%s",ChildRevName,ChildPrtQty);fflush(stdout);
					fprintf(fsuccess,"\nquantity after AR logic %s,%s",ChildRevName,ChildPrtQty);fflush(stdout);
				}
				
				if(tc_strcmp(ChildPrtQty,"999999")==0)
				{
					if((tc_strcmp(meas_unit,"KG")==0) || (tc_strcmp(meas_unit,"L")==0) || (tc_strcmp(meas_unit,"M")==0) || (tc_strcmp(meas_unit,"M2")==0) || (tc_strcmp(meas_unit,"M3")==0))
					{
						tc_strdup("0.001",&ChildQtyDup);
					}
					else
					{
						tc_strdup("1",&ChildQtyDup);
					}
					printf("\nQuantity for 99 QTY:::[%s],[%s]",ChildPrtQty,meas_unit);fflush(stdout);
					fprintf(fsuccess,"\nQuantity for 99 QTY:::[%s],[%s]",ChildPrtQty,meas_unit);fflush(stdout);
				}

				if((tc_strcmp(ChildPrtQty,"1")==0) && (tc_strcmp(qty_req_infoDup,"AR")==0))
				{
					if((tc_strcmp(meas_unit,"KG")==0) || (tc_strcmp(meas_unit,"L")==0) || (tc_strcmp(meas_unit,"M")==0) || (tc_strcmp(meas_unit,"M2")==0) || (tc_strcmp(meas_unit,"M3")==0))
					{
						tc_strdup("0.001",&ChildQtyDup);
					}
					else
					{
						tc_strdup("1",&ChildQtyDup);
					}
					printf("\nQuantity for [1-AR] QTY:::[%s],[%s]",ChildPrtQty,meas_unit);fflush(stdout);
					fprintf(fsuccess,"\nQuantity for [1-AR] QTY:::[%s],[%s]",ChildPrtQty,meas_unit);fflush(stdout);
				}

				//Quantity Conversion Logic End

				if(tc_strlen(make_buy_ind)>0)
				{
					tc_strdup(make_buy_ind,&make_buy_indDup);

					if(tc_strcmp(make_buy_indDup,"F18") == 0)
					{
						tc_strdup("L",&mat_prov_ind);
						tc_strdup("1",&tempcsrel);
					}
					else
					{
						tc_strdup("",&mat_prov_ind);
						tc_strdup("X",&tempcsrel);
					}
				}

				tc_strdup(ChildRevName,&ChildRevNameDup);
				floatQty = atof(ChildQtyDup);
				printf("\nFinal Node String [%s][%7.3f][%s][%s][%s][%s]",ChildRevNameDup,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);
				fprintf(fsuccess,"\nFinal Node String [%s][%7.3f][%s][%s][%s][%s]",ChildRevNameDup,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);

				if(p==NULL)
				{
					sr_no1 = 1;
					sprintf(sr_no,"%04d",sr_no1);
					p = createnode(sr_no,ChildRevNameDup,&floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);
					start = p;
				}
				else
				{
					ret = search(start,ChildRevNameDup,&floatQty);
					if(ret==1)
					{
						 q=start;
						 while(q->next!=NULL)
						 {
							 q=q->next;
						 }
						sr_no1 = sr_no1 + 1 ;
						sprintf(sr_no,"%04d",sr_no1);
						q->next=createnode(sr_no,ChildRevNameDup,&floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);
					}
				}
			}//For Loop Child Part

			//BOM Creation Process Start
			if(sr_no1 < 1)
			{
				printf("\nDo not have structure in PLM %s",assy_noDup);
				fprintf(fsuccess,"\nDo not have structure in PLM %s",assy_noDup);
				goto CLEANUP;
			}
			else
			{
				SapBomCreate(start,assy_noDup,AssemblyRevision,SequenceRevision,OrganizationID);

				if(*assy_noDup=='G')
				{
					printf("\nMain::Part %s is G-part, hence going to check Usage Probability..", assy_noDup);
					fprintf(fsuccess,"\nMain::Part %s is G-part, hence going to check Usage Probability..", assy_noDup);

					pUP = GetUsageProb(assy_noDup);
					compareUsage(pUP,start);
					my_free2(pUP);
				}

				SapBomChange(start,assy_noDup,AssemblyRevision,SequenceRevision,OrganizationID);
				//display1(start,assy_noDup);
				my_free(start);
			}
		}
	}
	else
	{
		printf("\nSkipping from Bom Transfer as Part Type is %s : %s\n",part_type,assy_noDup);
		fprintf(fsuccess,"\nSkipping from Bom Transfer as Part Type is %s : %s\n",part_type,assy_noDup);
	}
	
	CLEANUP:
	return 0;
}

extern int ITK_user_main (int argc, char ** argv )
{
    int status;
	int len=0;
	int resultCount =0;
	int n_entries = 1;
	int	count_DML = 0;

	tag_t		queryTag			= NULLTAG;
	tag_t		docOPtr				= NULLTAG;
	tag_t		*outTag				= NULLTAG;
	tag_t		DMLTag				= NULLTAG;
	tag_t		objTypeTag			= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;
	tag_t		resultOutputTag		= NULLTAG;
	tag_t		LatestRev			= NULLTAG;
	tag_t		relation_type		= NULLTAG;
	tag_t		DmlTaskRelTag		= NULLTAG;
	tag_t*		DMLRevTags			= NULLTAG;
			
	char* sUserName		= NULL;
	char* sPassword		= NULL;
	char* inputDml		= NULL;
	char* iDmlTask		= NULL;

	char* DMLNum			= NULL;
	char* DMLNumDup			= NULL;
	char* DMLDesc			= NULL;
	char* DMLRelStatus		= NULL;
	char* TaskRelStatus     = NULL;
	char* DMLProjCode		= NULL;
	char* DMLProjCodeDup	= NULL;
	char* DMLRelType		= NULL;
	char* DMLEcnType		= NULL;
	char* SMDMLType			= NULL;
	char* DML_Owner			= NULL;
	char* object_type		= NULL;
	char* taskId			= NULL;
	char* DateStr			= NULL;
	char* PRTaskStr			= NULL;

	char  type_name[TCTYPE_name_size_c+1];

	static RFC_RC RfcRc;

	date_t APLRelDate;
	date_t STDRelDate;

	char* APLRelDateStr = NULL;
	char* STDRelDateStr = NULL;

	int three = 3,CntObjCnt=0;
	tag_t   CntObjQryTag		= NULLTAG;
	tag_t   *CntObjTag			= NULLTAG;
	char    *CntObjEntry[3]		= {"SYSCD","SUBSYSCD","Information-1"};

	plantcode=(char *) malloc (500 * sizeof(char));
	apl_release_date=(char *) MEM_alloc(40 * sizeof(char));
	DMLDescription=(char *) MEM_alloc(40 * sizeof(char));
	profit_centre2 = (char *)malloc(500 * sizeof(char));
	plan_calendar2 = (char *)malloc(500 * sizeof(char));
	overhd_grp2 = (char *)malloc(500 * sizeof(char));
	origin_group2 = (char *)malloc(500 * sizeof(char));
	origin_group = (char *)malloc(500 * sizeof(char));
	SAPpstat = (char *)malloc(500 * sizeof(char));
	MRPpstat = (char *)malloc(500 * sizeof(char));

	//char *qry_entries[1] = {"Name"};
	//char *qry_entries[1] = {"item_id"};
	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	//inputDml = ITK_ask_cli_argument("-d=");
	iSapServer = ITK_ask_cli_argument("-s=");
	iDmlTask = ITK_ask_cli_argument("-t=");

	if(tc_strcmp(sUserName,"")==0 || tc_strcmp(sPassword,"")==0 || tc_strcmp(iSapServer,"")==0 || tc_strcmp(iDmlTask,"")==0)
	{
		printf("\nSAPBomCreateChangeUA -u=userid -p=password -s=PVP -t=iDmlTask\n");fflush(stdout);
		goto CLEANUP;
	}

	if(inputDml)
	{
		sprintf(fsuccess_name,"/user/plmsap/PLMSAP/PLM_SAP_APL_LOG/STD_Sap_BOM_%s.log",inputDml);
		//sprintf(fsuccess_name,"SAP_BOM_DML_%s.log",inputDml);
		fsuccess = fopen(fsuccess_name,"a");

		//if(QRY_find("APLDML_Query", &queryTag));
		if(QRY_find("Control Objects...", &CntObjQryTag));

		printf("\nInput DML : %s\n", inputDml);fflush(stdout);

		if(CntObjQryTag)
		{
			char	*SkipDML[3] = {"SAPSKIP",inputDml,inputDml};

			if(QRY_execute(CntObjQryTag,three,CntObjEntry,SkipDML,&CntObjCnt,&CntObjTag));

			if (CntObjCnt>0)
			{
				printf("\nDML %s Entry Found in Control Object to skip transfer\n",inputDml);
				fprintf(fsuccess,"DML %s Entry Found in Control Object to skip transfer\n",inputDml);
				goto CLEANUP;
			}
		}

		if(QRY_find("APLDMLRevisionQry", &queryTag));
		if (queryTag)
		{
			printf("\nQuery Found : APLDMLRevisionQry\n");fflush(stdout);
		}
		else
		{
			printf("\nQuery NotFound : APLDMLRevisionQry\n");fflush(stdout);
			goto CLEANUP;
		}

		qry_values[0] = inputDml;

		if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));

		printf("\nResultCount :%d:\n", resultCount);fflush(stdout);

		if(resultCount>0)
		{

			DMLTag=outTag[resultCount-1];
			if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
			if(TCTYPE_ask_name(objTypeTag,type_name));
			printf("\nInput APL DML Object Type : %s\n",type_name);fflush(stdout);
			printf("\nQuery Executed...\n");fflush(stdout);

			ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_id",&DMLNum));
			ITK_CALL(AOM_UIF_ask_value(DMLTag,"t5_cprojectcode",&DMLProjCode));
			ITK_CALL(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLRelType));
			ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_desc",&DMLDesc));
			ITK_CALL(AOM_UIF_ask_value(DMLTag,"release_status_list",&DMLRelStatus));
			ITK_CALL(AOM_UIF_ask_value(DMLTag,"owning_user",&DML_Owner));

			ITK_CALL(AOM_ask_value_date(DMLTag,"t5_APLReleaseDate",&APLRelDate));
			ITK_CALL(DATE_date_to_string(APLRelDate,"%d/%m/%Y",&APLRelDateStr));
			
			ITK_CALL(AOM_ask_value_date(DMLTag,"date_released",&STDRelDate));
			ITK_CALL(DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr));

			//T5_SMDMLRevision
			if (tc_strcmp(type_name,"T5_SMDMLRevision")==0)
			{
				ITK_CALL(AOM_ask_value_date(DMLTag,"t5_RescTimeStamp",&STDRelDate));
				ITK_CALL(DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr));
			}
			
			ITK_CALL(ITK_date_to_string(STDRelDate,&DateStr));
			
			printf("\nDML [%s] Release Type is [%s]\n",DMLNum,DMLRelType);
			fprintf(fsuccess,"\nDML [%s] Release Type is [%s]\n",DMLNum,DMLRelType);

			if (tc_strcmp(DMLRelType,"TODR")==0)
			{
				printf("\nDML [%s] Release Type is [%s] Skipping DML Transfer\n",DMLNum,DMLRelType);
				fprintf(fsuccess,"\nDML [%s] Release Type is [%s] Skipping DML Transfer\n",DMLNum,DMLRelType);
				goto CLEANUP;
			}

			if (tc_strlen(STDRelDateStr)!=10)
			{
				printf("\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DMLNum,tc_strlen(DateStr));
				fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DMLNum,tc_strlen(DateStr));
				goto CLEANUP;
			}

			if(tc_strstr(DMLNum,"AM")!=NULL)
			{
				ITK_CALL(AOM_ask_value_string(DMLTag,"t5_EcnType",&DMLEcnType));

				char	*Ecn_value[3] = {"ECNTYPE","AMDML",DMLEcnType};
				if(CntObjQryTag)
				{
					if(QRY_execute(CntObjQryTag,three,CntObjEntry,Ecn_value,&CntObjCnt,&CntObjTag));

					if (CntObjCnt>0)
					{
						printf("\nDML [%s] ECN Type is [%s] Ok!\n",DMLNum,DMLEcnType);
						fprintf(fsuccess,"\nDML [%s] ECN Type is [%s] Ok!\n",DMLNum,DMLEcnType);
					}
					else
					{
						printf("\nDML [%s] ECN Type is [%s] Exiting!\n",DMLNum,DMLEcnType);
						fprintf(fsuccess,"\nDML [%s] ECN Type is [%s] Exiting!\n",DMLNum,DMLEcnType);
						goto CLEANUP;
					}
				}
			}

			if(tc_strstr(DMLNum,"SM")!=NULL)
			{
				ITK_CALL(AOM_ask_value_string(DMLTag,"t5_SMDMLType",&SMDMLType));

				char	*SM_value[3] = {"DMLTYPE","SMDML",SMDMLType};

				if(CntObjQryTag)
				{
					if(QRY_execute(CntObjQryTag,three,CntObjEntry,SM_value,&CntObjCnt,&CntObjTag));

					if (CntObjCnt>0)
					{
						printf("\nDML [%s] SMDML Type is [%s] Ok!\n",DMLNum,SMDMLType);
						fprintf(fsuccess,"\nDML [%s] SMDML Type is [%s] Ok!\n",DMLNum,SMDMLType);
					}
					else
					{
						printf("\nDML [%s] SMDML Type is [%s] Exiting!\n",DMLNum,SMDMLType);
						fprintf(fsuccess,"\nDML [%s] SMDML Type is [%s] Exiting!\n",DMLNum,SMDMLType);
						goto CLEANUP;
					}
				}
			}

			//if [APLloader (aplloader)] skip DML transfer. - Check removed on 23-09-2020 as confirmed by APL/STD Team
			if(tc_strstr(DML_Owner,"APLloader")!=NULL || tc_strstr(DML_Owner,"aplloader")!=NULL)
			{
				printf("\nDML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
				fprintf(fsuccess,"\nDML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
				//goto CLEANUP;
			}

			tc_strdup(DMLNum,&DMLNumDup);
			tc_strdup(DMLProjCode,&DMLProjCodeDup);
			tc_strdup(DMLProjCode,&projectcode);

			if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL || tc_strstr(DMLRelStatus,"STDSIC Restructured")!=NULL)
			{
				printf("\nDML Number [%s] Release Type [%s] Project Code [%s]\n",DMLNum,DMLRelType,DMLProjCode);fflush(stdout);
				printf("\nRelease Status [%s] APLReleaseDate [%s] STD Released Date [%s]\n",DMLRelStatus,APLRelDateStr,STDRelDateStr);fflush(stdout);
				printf("\nDML Desc :%s\n",DMLDesc);fflush(stdout);
				printf("\nDMLNumDup :%s	DMLProjCodeDup : %s\n",DMLNumDup,DMLProjCodeDup);fflush(stdout);
			}
			else
			{
				printf("\nDML Number [%s] Release Status [%s] Not STDSIC Released...\n",DMLNum,DMLRelStatus);fflush(stdout);
				fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] Not STDSIC Released...\n",DMLNum,DMLRelStatus);fflush(stdout);
				goto CLEANUP;
			}


			if(FetchPlantSpecificData(DMLNumDup,DMLProjCodeDup)>0)
			{
				printf("\nGot Plant Specific Data...\n");fflush(stdout);
			}
			else
			{
				printf("\nError in Fetching Plant Specific Data...\n");fflush(stdout);
				fprintf(fsuccess,"\nError in Fetching Plant Specific Data...\n");fflush(stdout);
				goto CLEANUP;
			}
			
			if(tc_strcmp(plantcode,"")==0)
			{
				printf("\nPlant code is null hence exit"); fflush(stdout);
				fprintf(fsuccess,"\nPlant code is null hence exit"); fflush(fsuccess);
				goto CLEANUP;
			}

			if(tc_strlen(DMLDesc)<=5)
			{
				tc_strcpy(DMLDescription,DMLNum);
			}
			else
			{
				tc_strncpy(DMLDescription,DMLDesc,80);
			}
			//tc_strdup(DMLDesc,&DMLDescription);

			//DmlReleasedDate [11/04/2018]
			strcpy(apl_release_date,"");
			strcpy(apl_release_date,strtok(STDRelDateStr,"/"));
			strcat(apl_release_date,".");
			strcat(apl_release_date,strtok(NULL,"/"));
			strcat(apl_release_date,".");
			strcat(apl_release_date,strtok(NULL,"/"));

			printf("\ndml_no_arg :%s",dml_no_arg);fflush(stdout);
			printf("\napl_release_date :%s",apl_release_date);fflush(stdout);
			printf("\nDMLDescription :%s",DMLDescription);fflush(stdout);

			/// Solution Item start
			GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
			ITK_CALL(GRM_list_secondary_objects_only(DMLTag,relation_type,&tcount,&TaskRevision));
			printf("\nAPL DML Revision to Task Count : %d",tcount);fflush(stdout);
			
			//change number creation
			if(tcount>0)
			{
				displaying_objects();
			}

			for (TaskCnt=0;TaskCnt<tcount ;TaskCnt++ )
			{
				TaskRevTag = TaskRevision[TaskCnt];
				ITK_CALL(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
				ITK_CALL(AOM_ask_value_string(TaskRevTag,"item_id",&taskId));
				ITK_CALL(AOM_UIF_ask_value(TaskRevTag,"t5_PrTaskRelSTD",&PRTaskStr));

				printf("\nTask ID [%s]	object_type : %s\n",taskId,object_type);fflush(stdout);
				fprintf(fsuccess,"\nTask ID [%s]	object_type : %s\n",taskId,object_type);fflush(stdout);

				if (tc_strcmp(DMLEcnType,"TOODMLR")==0 && tc_strstr(taskId,"PR")!=NULL) //As per Pasha's mail on 14-May-2020
				{
					printf("\nECN Type TOO DML Dependency Release hence Skipping PR Task transfer : %s\n",taskId);fflush(stdout);
					fprintf(fsuccess,"\nECN Type TOO DML Dependency Release hence Skipping PR Task transfer : %s\n",taskId);fflush(stdout);
					continue;
				}

				printf("\nPRTaskStr : %s	DML Task : %s\n",PRTaskStr,taskId);fflush(stdout);
				//if (tc_strstr(taskId,"PR")!=NULL)
				if (tc_strcmp(PRTaskStr,"True")==0)
				{
					printf("\nSkipping PR Task transfer from DML : %s\n",taskId);fflush(stdout);
					fprintf(fsuccess,"\nSkipping PR Task transfer from DML : %s\n",taskId);fflush(stdout);
					continue;
				}

				ITK_CALL(AOM_UIF_ask_value(TaskRevTag,"release_status_list",&TaskRelStatus));

				if(tc_strstr(TaskRelStatus,"STDSIC Released")==NULL && tc_strstr(TaskRelStatus,"STDSIC Restructured")==NULL)
				{
					printf("\nDML Task : %s is not STDSIC Released ... skipping from transfer.\n",taskId);fflush(stdout);
					fprintf(fsuccess,"\nDML Task : %s is not STDSIC Released ... skipping from transfer.\n",taskId);fflush(stdout);
					continue;
				}
				
				pcount=0;
				ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&pcount,&PartTags));
				printf("\nTask To Part Count : %d",pcount);fflush(stdout);
				
				for (PartCnt=0;PartCnt<pcount;PartCnt++)
				{
					LatestRev=PartTags[PartCnt];
					ExpandBomForCreate(LatestRev,DMLNum);

				}//Part loop
			}//Task Loop
		}//DML Revision Found
		else
		{
			printf("\n\nDML [%s] Not Found in TCUA...Exiting!!",inputDml); fflush(stdout);
			fprintf(fsuccess,"\n\nDML [%s] Not Found in TCUA...Exiting!!",inputDml); fflush(fsuccess);		
		}
	}
	
	//******************** Task Wise Transfer **********************
	if (iDmlTask)
	{
		sprintf(fsuccess_name,"/user/plmsap/PLMSAP/PLM_SAP_APL_LOG/SAP_BOM_Task_%s.log",iDmlTask);
		//sprintf(fsuccess_name,"SAP_BOM_Task_%s.log",iDmlTask);
		fsuccess = fopen(fsuccess_name,"a");

		if(QRY_find("Control Objects...", &CntObjQryTag));

		if(CntObjQryTag)
		{
			char	*SkipDML[3] = {"SAPSKIP",iDmlTask,iDmlTask};

			if(QRY_execute(CntObjQryTag,three,CntObjEntry,SkipDML,&CntObjCnt,&CntObjTag));

			if (CntObjCnt>0)
			{
				printf("\nDML %s Entry Found in Control Object to skip transfer\n",iDmlTask);
				fprintf(fsuccess,"DML %s Entry Found in Control Object to skip transfer\n",iDmlTask);
				goto CLEANUP;
			}
		}

		if(QRY_find("APLTaskRevisionQry", &queryTag));
		if (queryTag)
		{
			printf("\nQuery Found : APLTaskRevisionQry\n");fflush(stdout);
		}
		else
		{
			printf("\nQuery NotFound : APLTaskRevisionQry\n");fflush(stdout);
			goto CLEANUP;
		}

		printf("\nInput DML Task : %s\n ", iDmlTask);fflush(stdout);

		qry_values[0] = iDmlTask;

		if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &tcount, &TaskRevision));

		printf("\nResultCount :%d:\n", tcount);fflush(stdout);
		if (tcount>0)
		{
			TaskRevTag = TaskRevision[tcount-1];

			ITK_CALL(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
			ITK_CALL(AOM_ask_value_string(TaskRevTag,"item_id",&taskId));
			ITK_CALL(AOM_UIF_ask_value(TaskRevTag,"owning_user",&DML_Owner));
			ITK_CALL(AOM_ask_value_date(TaskRevTag,"date_released",&STDRelDate));
			ITK_CALL(DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr));
			ITK_CALL(AOM_UIF_ask_value(TaskRevTag,"t5_PrTaskRelSTD",&PRTaskStr));

			printf("\nTask ID %s	object_type %s",taskId,object_type);fflush(stdout);
			fprintf(fsuccess,"\nTask ID : %s object_type %s",taskId,object_type);fflush(stdout);

			//if [APLloader (aplloader)] skip DML transfer. - Check removed on 23-09-2020 as confirmed by APL/STD Team
			if(tc_strstr(DML_Owner,"APLloader")!=NULL || tc_strstr(DML_Owner,"aplloader")!=NULL)
			{
				printf("\nDML [%s] as DML Owner [%s]",taskId,DML_Owner);
				fprintf(fsuccess,"\nDML [%s] as DML Owner [%s]",taskId,DML_Owner);
				//goto CLEANUP;
			}

			//T5_SMDMLRevision
			if (tc_strcmp(object_type,"T5_SMDMLRevision")==0)
			{
				ITK_CALL(AOM_ask_value_date(TaskRevTag,"t5_RescTimeStamp",&STDRelDate));
				ITK_CALL(DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr));
			}

			printf("\nPRTaskStr : %s	DML Task : %s\n",PRTaskStr,taskId);fflush(stdout);
			//As per discussion with APL Team task wise bom to be transferred to SAP.
			/*if (tc_strcmp(PRTaskStr,"True")==0)
			{
				printf("\nPrTaskRelSTD : YES	DML Task : %s\n",taskId);fflush(stdout);
				fprintf(fsuccess,"\nPrTaskRelSTD : YES	DML Task : %s\n",taskId);fflush(stdout);
			}
			else
			{
				printf("\nTask is not Partial Released skipping transfer : %s\n",taskId);fflush(stdout);
				fprintf(fsuccess,"\nTask is not Partial Released skipping transfer : %s\n",taskId);fflush(stdout);
				goto CLEANUP;
			}*/

			ITK_CALL(AOM_UIF_ask_value(TaskRevTag,"release_status_list",&TaskRelStatus));

			if(tc_strstr(TaskRelStatus,"STDSIC Released")==NULL && tc_strstr(TaskRelStatus,"STDSIC Restructured")==NULL)
			{
				printf("\nDML Task : %s is not STDSIC Released ... skipping from transfer.\n",taskId);fflush(stdout);
				fprintf(fsuccess,"\nDML Task : %s is not STDSIC Released ... skipping from transfer.\n",taskId);fflush(stdout);
				goto CLEANUP;
			}
			else
			{
				printf("\nDML Task : %s Release Status %s\n",taskId,TaskRelStatus);fflush(stdout);
				fprintf(fsuccess,"\nDML Task : %s Release Status %s\n",taskId,TaskRelStatus);fflush(stdout);
			}
			
			ITK_CALL(ITK_date_to_string(STDRelDate,&DateStr));
			if (tc_strlen(DateStr)==0)
			{
				printf("\nDML Number [%s] STD Release Date is NULL..Exiting!\n",taskId,tc_strlen(DateStr));
				fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",taskId,tc_strlen(DateStr));
				goto CLEANUP;
			}
			else
			{
				printf("\nDML Number [%s] STD Release Date [%s]\n",taskId,DateStr);
				fprintf(fsuccess,"\nDML Number [%s] STD Release Date [%s]\n",taskId,DateStr);
			}

			GRM_find_relation_type("T5_DMLTaskRelation",&DmlTaskRelTag);
			GRM_list_primary_objects_only(TaskRevTag,DmlTaskRelTag,&count_DML,&DMLRevTags);
			printf("\nDML Count : %d",count_DML);fflush(stdout);
			if (count_DML>0)
			{
				DMLTag	=	DMLRevTags[0];

				ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_id",&DMLNum));
				tc_strdup(DMLNum,&DMLNumDup);

				ITK_CALL(AOM_UIF_ask_value(DMLTag,"t5_cprojectcode",&DMLProjCode));
				tc_strdup(DMLProjCode,&DMLProjCodeDup);
				tc_strdup(DMLProjCode,&projectcode);

				ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_desc",&DMLDesc));
				ITK_CALL(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLRelType));
				
				

				ITK_CALL(ITK_date_to_string(STDRelDate,&DateStr));
				printf("\nDML [%s]\n",DMLNum);
				fprintf(fsuccess,"\nDML [%s]\n",DMLNum);

				if (tc_strcmp(DMLRelType,"TODR")==0)
				{
					printf("\nDML [%s] Release Type is [%s] Skipping DML Transfer\n",DMLNum,DMLRelType);
					fprintf(fsuccess,"\nDML [%s] Release Type is [%s] Skipping DML Transfer\n",DMLNum,DMLRelType);
					goto CLEANUP;
				}

				if(tc_strstr(DMLNum,"AM")!=NULL)
				{
					ITK_CALL(AOM_ask_value_string(DMLTag,"t5_EcnType",&DMLEcnType));

					char	*Ecn_value[3] = {"ECNTYPE","AMDML",DMLEcnType};
					if(CntObjQryTag)
					{
						if(QRY_execute(CntObjQryTag,three,CntObjEntry,Ecn_value,&CntObjCnt,&CntObjTag));

						if (CntObjCnt>0)
						{
							printf("\nDML [%s] ECN Type is [%s] Ok!\n",DMLNum,DMLEcnType);
							fprintf(fsuccess,"\nDML [%s] ECN Type is [%s] Ok!\n",DMLNum,DMLEcnType);
						}
						else
						{
							printf("\nDML [%s] ECN Type is [%s] Exiting!\n",DMLNum,DMLEcnType);
							fprintf(fsuccess,"\nDML [%s] ECN Type is [%s] Exiting!\n",DMLNum,DMLEcnType);
							goto CLEANUP;
						}
					}
				}

				if(tc_strstr(DMLNum,"SM")!=NULL)
				{
					ITK_CALL(AOM_ask_value_string(DMLTag,"t5_SMDMLType",&SMDMLType));

					char	*SM_value[3] = {"DMLTYPE","SMDML",SMDMLType};

					if(CntObjQryTag)
					{
						if(QRY_execute(CntObjQryTag,three,CntObjEntry,SM_value,&CntObjCnt,&CntObjTag));

						if (CntObjCnt>0)
						{
							printf("\nDML [%s] SMDML Type is [%s] Ok!\n",DMLNum,SMDMLType);
							fprintf(fsuccess,"\nDML [%s] SMDML Type is [%s] Ok!\n",DMLNum,SMDMLType);
						}
						else
						{
							printf("\nDML [%s] SMDML Type is [%s] Exiting!\n",DMLNum,SMDMLType);
							fprintf(fsuccess,"\nDML [%s] SMDML Type is [%s] Exiting!\n",DMLNum,SMDMLType);
							goto CLEANUP;
						}
					}
				}

				if (tc_strcmp(DMLEcnType,"TOODMLR")==0 && tc_strstr(taskId,"PR")!=NULL) //As per Pasha's mail on 14-May-2020
				{
					printf("\nECN Type TOO DML Dependency Release hence Skipping PR Task transfer : %s\n",taskId);fflush(stdout);
					fprintf(fsuccess,"\nECN Type TOO DML Dependency Release hence Skipping PR Task transfer : %s\n",taskId);fflush(stdout);
					goto CLEANUP;
				}

				if(FetchPlantSpecificData(DMLNumDup,DMLProjCodeDup)>0)
				{
					printf("\nGot Plant Specific Data...\n");fflush(stdout);
				}
				else
				{
					printf("\nError in Fetching Plant Specific Data...\n");fflush(stdout);
					fprintf(fsuccess,"\nError in Fetching Plant Specific Data...\n");fflush(stdout);
					goto CLEANUP;
				}
				
				if(tc_strcmp(plantcode,"")==0)
				{
					printf("\nPlant code is null hence exit"); fflush(stdout);
					fprintf(fsuccess,"\nPlant code is null hence exit"); fflush(fsuccess);
					goto CLEANUP;
				}
			}
			
			if (tc_strlen(taskId)==18)
			{
				dml_no_arg[10] = taskId[11];
				dml_no_arg[11] = taskId[12];
				dml_no_arg[12] = '\0';

				dml_numAP1[10] = taskId[11];
				dml_numAP1[11] = taskId[12];
				dml_numAP1[12] = '\0';
			}
			else if (tc_strlen(taskId)==20)
			{

				dml_no_arg[10] = taskId[13];
				dml_no_arg[11] = taskId[14];
				dml_no_arg[12] = '\0';

				dml_numAP1[10] = taskId[13];
				dml_numAP1[11] = taskId[14];
				dml_numAP1[12] = '\0';
			}
			else
			{
				tc_strcat(dml_no_arg,"CT");
				tc_strcat(dml_numAP1,"CT");
			}

			printf("\ndml_no_arg %s and dml_numAP1 %s",dml_no_arg,dml_numAP1);fflush(stdout);
			fprintf(fsuccess,"\ndml_no_arg %s and dml_numAP1 %s",dml_no_arg,dml_numAP1);fflush(stdout);

			if(tc_strcmp(plantcode,"")==0)
			{
				printf("\nPlant code is null hence exit"); fflush(stdout);
				fprintf(fsuccess,"\nPlant code is null hence exit"); fflush(fsuccess);
				goto CLEANUP;
			}

			if(tc_strlen(DMLDesc)<=5)
			{
				tc_strcpy(DMLDescription,DMLNum);
			}
			else
			{
				tc_strncpy(DMLDescription,DMLDesc,80);
			}
			//tc_strdup(DMLDesc,&DMLDescription);

			//DmlReleasedDate [11/04/2018]
			strcpy(apl_release_date,"");
			strcpy(apl_release_date,strtok(STDRelDateStr,"/"));
			strcat(apl_release_date,".");
			strcat(apl_release_date,strtok(NULL,"/"));
			strcat(apl_release_date,".");
			strcat(apl_release_date,strtok(NULL,"/"));

			printf("\ndml_no_arg :%s",dml_no_arg);fflush(stdout);
			fprintf(fsuccess,"\ndml_no_arg :%s",dml_no_arg);fflush(stdout);
			printf("\nchange_release_date :%s",apl_release_date);fflush(stdout);
			fprintf(fsuccess,"\nchange_release_date :%s",apl_release_date);fflush(stdout);
			printf("\nDMLDescription :%s",DMLDescription);fflush(stdout);
			fprintf(fsuccess,"\nDMLDescription :%s",DMLDescription);fflush(stdout);

			pcount=0;
			ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&pcount,&PartTags));
			printf("\nTask To Part Count : %d",pcount);fflush(stdout);
			fprintf(fsuccess,"\nTask To Part Count : %d",pcount);fflush(stdout);
			
			//Change Number Creation.
			if (pcount>0)
			{
				displaying_objects();
			}
			
			//Going for BOM Creation 
			for (PartCnt=0;PartCnt<pcount;PartCnt++)
			{
				LatestRev=PartTags[PartCnt];
				ExpandBomForCreate(LatestRev,DMLNum);

			}//Part loop

			//Colour Sync case
			pcount=0;
			ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMReferences",&pcount,&PartTags));
			printf("\nTask To CMReferences Part Count : %d",pcount);fflush(stdout);
			fprintf(fsuccess,"\nTask To CMReferences Part Count : %d",pcount);fflush(stdout);
			
			//Going for BOM Creation 
			for (PartCnt=0;PartCnt<pcount;PartCnt++)
			{
				LatestRev=PartTags[PartCnt];
				ExpandBomForCreate(LatestRev,DMLNum);

			}//Part loop

		}
	}

	ITK_CALL(POM_logout(false));
	return status;

	CLEANUP:
	printf("\nCLEANUP...\n"); fflush(stdout);
	ITK_CALL(POM_logout(false));
}
;
