/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : AssyMismatchUA.c
* Created By                   : Amol Narke
* Created On                   : 11/05/2020
* Project                      : Tata Motors PLM-SAP Interface
* Methods Defined              :
* Description                  : TCUA - SAP BOM Mismatch report
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>

#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)


#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index 		= 0;			\
			int				n_ifails 		= 0;		\
			const int*		severities 		= 0;		\
			const int*		ifails 		= 0;			\
			const char**	texts 		= NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

char cpydml_no[50]={0};
char *PlmDmlSuff 		= NULL;
char *PlmDmlSuffOrig 		= NULL;
char *meas_unit		= NULL;
char fsuccess_name[200]={0};

struct node
{
char part[15];
int dupind;
struct node *next;
};

char recstring_sap[25000];
char crecstring_sap[25000];

struct usgProbnode
{
	char sr_no[5];
	char *part;
	float *usgProb;
	struct usgProbnode *next;
};
struct DmlEpaNode
{
	char DmlEpa[50];
	char ClosureTimeStamp[11];
	char DmlLifeCycleState[30];
	struct DmlEpaNode *next;
};

static char CMakeBuy1[45]={0};
static char CTmpMakeBuy1[45]={0};

char *plantcode			= NULL;
char *iSapServer		= NULL;
char *nomenclatureDup	= NULL;
char *apl_release_date 	= NULL;
char *Current_date_time = NULL;
tag_t MypartObjs		= NULLTAG;
char fsuccess_name[200];
char DMLDescription[100];
FILE *fsuccess;

char *dml_numAP			= NULL;
char *dml_numAP1 		= NULL;
static char projectcode[5]={0};

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);
void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str);
void my_free(struct node* start);
void display1(struct node *head1);
struct node* createnode(char *part);
int search(struct node* start,char *part);
void  rfc_error(char *operation);
RFC_HANDLE BapiLogon(void);
void cll_cad_display_bom_with_sub_items(char *assy_noDup);
RFC_RC cad_display_bom_with_sub_items(RFC_HANDLE hRfc,RC29L_STLAL *eIBomAlternative,RC29L_STLAN *eIBomType,RC29L_AENNR *eIChangeNumber,DRAW_LOEDK *eIDisplayFlag,RC29L_MATNR *eIMaterial,RC29L_WERKS *eIPlant,RC29L_REVLV *eIRevisionLevel,BICSK_DATUV *eIValidFrom,CAD_BICSK *iEBomHeader,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_RETURN_VALUE *iEReturn,ITAB_H thBomItem,ITAB_H thBomSubItem,ITAB_H thDmsClassData,ITAB_H thSapFieldData,char *xException);
void compare(struct node *p1,struct node *p2,char *AssyNo);
struct usgProbnode* createnode2(char sr_no[5],char *part,float* usgProb);
struct usgProbnode* GetUsageProb(char *assy_noDup);
void my_free2(struct usgProbnode* start);
void compareUsage(struct usgProbnode *pUP,struct node *start);
void display2(struct usgProbnode *head,char *assy_noDup);
void trimString(char * str);
int tm_fnd_DML_PART(char	*PLT_CODE,tag_t t_currentRevision, tag_t* t_DMLRevision);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);

void trimString(char * str)
{
	int i = 0;
    for (i = 0; i < tc_strlen(str); i++)
	{
		//printf("\n%d %c",i,str[i]);
		if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
		{
			str[i] = '\0';
		}     
	}
}
;

struct usgProbnode* createnode2(char sr_no[5],char *part,float* usgProb)
{
	struct usgProbnode* q		= NULL;

	//printf("In createnode2 Function....\n");

	q=(struct usgProbnode*)malloc(sizeof(struct usgProbnode));
	q->part=part;
	strcpy(q->sr_no,sr_no);
	q->usgProb = usgProb;
	q->next		= NULL;
	return q;
}


void my_free2(struct usgProbnode* start)
{
	struct usgProbnode* prev;
	struct usgProbnode* ptr;
	printf("\nErazing Linklist Started...\n");
	fprintf(fsuccess,"\nErazing Linklist Started...\n");
	for(prev = start, ptr = start; ptr != NULLTAG, prev = ptr;ptr = ptr->next)
	{
		printf("#");
		fprintf(fsuccess,"#");
		free(prev);
	}
	start = NULLTAG;
	printf("\nErazing Linklist Completed.\n");
	fprintf(fsuccess,"\nErazing Linklist Completed.\n");

}

void my_free(struct node* start)
{
	struct node* prev;
	struct node* ptr;
	printf("\nErazing Linklist Started...\n");
	fprintf(fsuccess,"\nErazing Linklist Started...\n");
	//for(prev = start, ptr = start; ptr != NULL, prev = ptr;ptr = ptr->next)
	for(prev = start, ptr = start; ptr != NULL, prev = ptr;ptr = ptr->next)
	{
		printf("#");
		fprintf(fsuccess,"#");
		free(prev);
	}
	start 		= NULL;
	printf("\nErazing Linklist Completed.\n");
	fprintf(fsuccess,"\nErazing Linklist Completed.\n");

}

void display1(struct node *head1)
{
	struct node *p2=NULL;
	for(p2=head1; p2!=NULL; p2 = p2->next)
	{

		printf("\t:%s:",p2->part);fflush(stdout);
	}
}

struct node* createnode(char *part)
{
	struct node* p=NULL;

	p=(struct node*)malloc(sizeof(struct node));

	trimString(part);

	strcpy(p->part ,part);
	p->dupind = 1;
	/*printf("\n:Create%s:%d",p->part,strlen(part));fflush(stdout);*/
	p->next=NULL;
	return p;
}

int search(struct node* start,char *part)
{
	struct node* p;
	int found = 1 ;
	
	p=start;
	//printf("\nIn search %s",part); fflush(stdout);
	/*while(p->next!=NULL)*/
	while(p!=NULL)
	{
			if(strcmp(p->part,part)==0)
			{
					/*p->qty = p->qty + qty;*/
					p->dupind = p->dupind + 1;
					found = 0;
					break;
			}
			else
			{
				p=p->next;
				found = 1 ;
			}

		}
	return found;
}
void display(struct node *head,char *assy_noDup)
{
	struct node *p=NULL;
	printf("\nAssembly: %s -> %s",assy_noDup,plantcode);fflush(stdout);
	fprintf(fsuccess,"\nAssembly: %s -> %s",assy_noDup,plantcode);fflush(stdout);
	for(p = head; p != NULL; p = p -> next)
	{
		printf("\n\t:%-15s:%d:",p -> part,p->dupind);fflush(stdout);
		fprintf(fsuccess,"\n\t%15s:%d:",p -> part,p->dupind);fflush(stdout);
	}
	/*printf("\nList ends");*/
}

void compare(struct node *p1,struct node *p2,char *AssyNo)
{
	int	found = 1;
	struct node *s1 = NULL;
	struct node *s2 = NULL;
	int iMisCnt = 0;
	printf("\nIn compare");fflush(stdout);
	s1 = p1;
	s2 = p2;
	while(s1!=NULL)
	{
		s2=p2;

		while(s2!=NULL)
		{
			//printf("Lenght %d %d",tc_strlen(s2->part),tc_strlen(s1->part));
			if(tc_strcmp(s2->part,s1->part)==0)
			{
				found = 0;
				break;
			}
			else
			{
				found = 1;
			}
			s2=s2->next;
		}
		if(found == 1)
		{
			iMisCnt = iMisCnt + 1;
			printf("\nfor assembly %15s Part present in PLM not in SAP %s for plant [%s]",AssyNo,s1->part,plantcode);fflush(stdout);
			fprintf(fsuccess,"\nfor assembly %15s Part present in PLM not in SAP %s for plant [%s]",AssyNo,s1->part,plantcode);fflush(stdout);
		}

		s1=s1->next;
	}


	s1 = p1;
	s2 = p2;
	while(s2!=NULL)
	{
	s1=p1;

	while(s1!=NULL)
	{
		if(tc_strcmp(s1->part,s2->part)==0)
		{
			found = 0;
			break;
		}
		else
		{
			found = 1;
		}
		s1=s1->next;
	}
	if(found == 1)
	{
		iMisCnt = iMisCnt + 1;
		printf("\nfor assembly %15s Part present in SAP not in PLM %s for plant [%s]",AssyNo,s2->part,plantcode);fflush(stdout);
		fprintf(fsuccess,"\nfor assembly %15s Part present in SAP not in PLM %s for plant [%s]",AssyNo,s2->part,plantcode);fflush(stdout);
	}

		s2=s2->next;
	}
	if ( iMisCnt > 0 )
	{
		printf("\nMismatch found for Assembly:%s",AssyNo);
		fprintf(fsuccess,"\nMismatch found for Assembly:%s",AssyNo);
	}
	else
	{
	 	printf("\nNo mismatch found for_Assembly:%s",AssyNo);
        fprintf(fsuccess,"\nNo mismatch found for_Assembly:%s",AssyNo);
	}
}

int tm_fnd_DML_PART(char *PLT_CODE,tag_t t_currentRevision,tag_t* t_DMLRevision)
{
	int     status;
	int     ifail;
	int		count_tsk				=	0;
	int		count_DML				=	0;
	int		iPPPM					=	0;
	int		itsk					=	0;
	int		idml					=	0;
	int		iDMLFnd					=	0;

	char	*c_PartNumber			=	NULL;
	char	*Part_Rev				=	NULL;
	char	*object_type			=	NULL;
	char	*type_name				=	NULL;
	char	*type_dml_name			=	NULL;
	char	*task_name				=	NULL;
	char	*DML_name				=	NULL;
	char	*DML_Owner				= NULL;
	char	*DMLRelStatus			= NULL;
	char	*DateStr				= NULL;
	char	*STDRelDateStr			= NULL;
	char	*DMLEcnType				= NULL;

	date_t STDRelDate;

	tag_t	tsk_part_sol_rel_type	=	NULLTAG;
	tag_t	dml_task_rel_type		=	NULLTAG;
	tag_t	*TaskRevision			=	NULLTAG;
	tag_t	*DMLRevision			=	NULLTAG;
	tag_t	TaskRevTag				=	NULLTAG;
	tag_t	DMLRevTag				=	NULLTAG;
	tag_t	objTaskTypeTag			=	NULLTAG;
	tag_t	objDMLTypeTag			=	NULLTAG;

	//printf("\nInside tm_fnd_DML_PART %s",PLT_CODE);fflush(stdout);

	AOM_ask_value_string(t_currentRevision,"current_id",&c_PartNumber);
	//printf("\nPart_Number: %s\n",c_PartNumber);fflush(stdout);

	AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev);
	//printf("\nPart_Rev: %s\n",Part_Rev);fflush(stdout);

	AOM_ask_value_string(t_currentRevision,"object_type",&object_type);
	//printf("\nobject_type : %s",object_type);fflush(stdout);

	GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);

	if(tsk_part_sol_rel_type!=NULLTAG)
	{
		GRM_list_primary_objects_only(t_currentRevision,tsk_part_sol_rel_type,&count_tsk,&TaskRevision);
		printf("\nTask Count  : %d",count_tsk);fflush(stdout);

		if(count_tsk>0)
		{
			for(itsk=0;itsk<count_tsk;itsk++)
			{
				iDMLFnd		=	0;
				TaskRevTag	=	NULLTAG;
				TaskRevTag	=	TaskRevision[itsk];

				if(TCTYPE_ask_object_type(TaskRevTag,&objTaskTypeTag));
				if(TCTYPE_ask_name2(objTaskTypeTag,&type_name));
				printf("\nTask Object Type : %s\n", type_name);fflush(stdout);

				if(tc_strcmp(type_name,"T5_APLTaskRevision")==0)
				{
					//item_id
					AOM_ask_value_string(TaskRevTag,"item_id",&task_name);
					printf("\nTask Id : %s",task_name);fflush(stdout);

					if(tc_strstr(task_name,"PP")!=NULL || tc_strstr(task_name,"PM")!=NULL || tc_strstr(task_name,"AM")!=NULL || tc_strstr(task_name,"MC")!=NULL)
					{
						//printf("\nPP Task found for DML.");fflush(stdout);
						iPPPM	=	1;
						if(strstr(task_name,PLT_CODE))
						{
							//printf("\nMatch found...!!!");fflush(stdout);

							//if (tc_strstr(task_name,"PR")!=NULL)
							{
								AOM_ask_value_string(TaskRevTag,"item_id",&DML_name);
								AOM_UIF_ask_value(TaskRevTag,"owning_user",&DML_Owner);
								AOM_UIF_ask_value(TaskRevTag,"release_status_list",&DMLRelStatus);
								AOM_ask_value_date(TaskRevTag,"date_released",&STDRelDate);
								DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr);
								
								ITK_date_to_string(STDRelDate,&DateStr);
								
								if(tc_strstr(DMLRelStatus,"STDSIC Released")==NULL)
								{
									printf("\nAssy [%s/%s] PR Task Number [%s] Release Status [%s] PR Task Not STDSIC Released...\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
									//fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] Not STDSIC Released...\n",DMLNum,DMLRelStatus);fflush(stdout);
									continue;
								}
								else
								{
									printf("\nAssy [%s/%s] PR Task Number [%s] Task Release Status [%s] Found Released Task\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
									fprintf(fsuccess,"\nAssy [%s/%s] PR Task Number [%s] Task Release Status [%s] Found Released Task\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
								}

								if(tc_strstr(DML_Owner,"APLloader")!=NULL || tc_strstr(DML_Owner,"aplloader")!=NULL)
								{
									printf("\nAssy [%s/%s] DML [%s] as DML Owner [%s]",c_PartNumber,Part_Rev,DML_name,DML_Owner);
									//fprintf(fsuccess,"\nSkiping DML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
									//continue;
								}

								if (tc_strlen(DateStr)==0)
								{
									printf("\nAssy [%s/%s] DML Number [%s] STD Release Date is NULL..Exiting!\n",c_PartNumber,Part_Rev,DML_name,tc_strlen(DateStr));
									//fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DML_name,tc_strlen(DateStr));
									continue;
								}

								if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL && tc_strlen(DateStr)!=0)
								{
									iDMLFnd	=	1;
									printf("\nAssy [%s/%s] Found DML Number [%s] Release Status [%s] STD Released Date [%s]\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus,STDRelDateStr);fflush(stdout);
									break;
								}

							}
							/*else
							{
								GRM_find_relation_type("T5_DMLTaskRelation",&dml_task_rel_type);
								if(dml_task_rel_type!=NULLTAG)
								{
									GRM_list_primary_objects_only(TaskRevTag,dml_task_rel_type,&count_DML,&DMLRevision);
									//printf("\nDML Count : %d",count_DML);fflush(stdout);
									if(count_DML>0)
									{
										for(idml=0;idml<count_DML;idml++)
										{
											DMLRevTag	=	NULLTAG;
											DMLRevTag	=	DMLRevision[idml];
											
											if(TCTYPE_ask_object_type(DMLRevTag,&objDMLTypeTag));
											if(TCTYPE_ask_name2(objDMLTypeTag,&type_dml_name));
											//printf("\ntype_dml_name : %s",type_dml_name);fflush(stdout);

											if (tc_strcmp(type_dml_name,"T5_APLDMLRevision")==0)
											{
												
												AOM_ask_value_string(DMLRevTag,"item_id",&DML_name);
												printf("\nDML Id : %s",DML_name);fflush(stdout);
												AOM_UIF_ask_value(DMLRevTag,"owning_user",&DML_Owner);
												AOM_UIF_ask_value(DMLRevTag,"release_status_list",&DMLRelStatus);
												AOM_UIF_ask_value(DMLRevTag,"t5_EcnType",&DMLEcnType);

												AOM_ask_value_date(DMLRevTag,"date_released",&STDRelDate);
												DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr);
												
												ITK_date_to_string(STDRelDate,&DateStr);

												if (tc_strcmp(DMLEcnType,"AMDML")==0)
												{
													printf("\nAssy [%s/%s] DML Number [%s] ECN Type [%s] Checking Next DML...\n",c_PartNumber,Part_Rev,DML_name,DMLEcnType);fflush(stdout);
													continue;
												}

												if(tc_strstr(DMLRelStatus,"STDSIC Released")==NULL)
												{
													printf("\nAssy [%s/%s] DML Number [%s] Release Status [%s] DML Not STDSIC Released...\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
													//fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] Not STDSIC Released...\n",DMLNum,DMLRelStatus);fflush(stdout);
													continue;
												}
												else
												{
													printf("\nAssy [%s/%s] DML Number [%s] DML Release Status [%s] Found Released DML\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
													fprintf(fsuccess,"\nAssy [%s/%s] DML Number [%s] DML Release Status [%s] Found Released DML\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
												}

												if(tc_strstr(DML_Owner,"APLloader")!=NULL || tc_strstr(DML_Owner,"aplloader")!=NULL)
												{
													printf("\nAssy [%s/%s] DML [%s] as DML Owner [%s]",c_PartNumber,Part_Rev,DML_name,DML_Owner);
													//fprintf(fsuccess,"\nSkiping DML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
													//continue;
												}

												if (tc_strlen(DateStr)==0)
												{
													printf("\nAssy [%s/%s] DML Number [%s] STD Release Date is NULL..Exiting!\n",c_PartNumber,Part_Rev,DML_name,tc_strlen(DateStr));
													//fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DML_name,tc_strlen(DateStr));
													continue;
												}

												if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL && tc_strlen(DateStr)!=0)
												{
													iDMLFnd	=	1;
													*t_DMLRevision	=	DMLRevTag;
													printf("\nAssy [%s/%s] Found DML Number [%s] Release Status [%s] STD Released Date [%s]\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus,STDRelDateStr);fflush(stdout);
													break;
												}
											}
										}
									}
									else
									{
										printf("\nNo DML found...!!!");fflush(stdout);
									}
								}
							}*/
						}
					}
				}
				if(iDMLFnd==1)
				{
					printf("\nTask Loop break...!!!");fflush(stdout);
					break;
				}
				else
				{
					//printf("\nChecking Next Task...!!!");fflush(stdout);
					continue;
				}
			}

		}
		else
		{
			printf("\nNo task found");fflush(stdout);
		}
	}

	return iDMLFnd;

}

extern int ITK_user_main (int argc, char ** argv )
{
    int status;
	struct usgProbnode *pUP = NULLTAG;

	char *part_noDup1	= NULL;
	char my_denis[14] = {0};

	tag_t ChildOPtr		= NULLTAG;
	tag_t ChildOPtrCpy	= NULLTAG;
	tag_t PartOPtr		= NULLTAG;
	tag_t *partObjs		= NULLTAG;

	char *sUserName		= NULL;
	char *sPassword 	= NULL;
	char *AssyNo		= NULL;
	char *sRevision		= NULL;
	char *sSequence		= NULL;
	char *mat_prov_ind	= NULL;
	char *meas_unit		= NULL;
	char *sr_no			= NULL;
	char *tempcsrel		= NULL;
	int ci			= 0;
	int ei			= 0;
	int grind		= 0;
	int iPartIndex;
	int ret;
	int failflag		= 0;
	int i				= 0;
	int noOfChilds		= 0;
	int stat			= 0;
	int taskCount		= 0;
	static int sr_no1 		= 0;
	int ia=0;
	int ja=0;
	int ka=0;
	int la=0;
	int ret1=0;

	char *AssyPrttype 		= NULL;
	char *AssyPrttypeDup 	= NULL;
	char *Revision 			= NULL;
	char *RevisionDup 		= NULL;
	char *assy_no 			= NULL;
	char *assy_noDup 		= NULL;
	char *date_updated 		= NULL;
	char *date_updatedDup 	= NULL;
	char *epaowner 			= NULL;
	char *epaownerDup 		= NULL;
	char *eparelzstate 		= NULL;
	char *eparelzstateDup 	= NULL;
	char *epataskId 		= NULL;
	char *epataskIdDup 		= NULL;
	char *make_buy_ind 		= NULL;
	char *make_buy_indDup 	= NULL;
	char *part_no 			= NULL;
	char *part_noDup 		= NULL;
	char *taskId 			= NULL;
	char *taskIdDup 		= NULL;
	char *unit 				= NULL;
	char *unitDup 			= NULL;
	char *DispName 			= NULL;
	char *DispNameDup 		= NULL;
	char *PrtCls 			= NULL;
	char *PrtClsDup 		= NULL;
	char *cPrtCls			= NULL;
	char *owner				= NULL;
	char *ownerDup			= NULL;
	char *prjcode			= NULL;
	char *prjcodeDup 		= NULL;
	char *prtType 			= NULL;
	char *prtTypeDup 		= NULL;
	char *qty 				= NULL;
	char *qtyDup 			= NULL;
	char *qty_req_info 		= NULL;
	char *qty_req_infoDup 	= NULL;
	char *relzstate 		= NULL;
	char *relzstateDup 		= NULL;
	struct node *start		= NULL;
	struct node *start1		= NULL;
	struct node *p			= NULL;
	struct node *p1			= NULL;
	struct node *q			= NULL;
	struct node *q1			= NULL;

	float floatQty= 0.000;
	char *iOrganizationID	= NULL;
	char *StdDate			= NULL;
	char *MonYear			= NULL;
	char *inputDmlNumber	= NULL;
	char *inputPlantCode	= NULL;
	char *ChildPartType		= NULL;
	char *my_comp_part_sap	= NULL;

	int cnt = 0 ;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};


	char *AssemblyRevision 		= NULL;
	char *AssemblyRevisionDup 	= NULL;
	char *SequenceRevision 		= NULL;
	char *SequenceRevisionDup 	= NULL;
	
	int n_entries			= 0;
	int resultCount 		= 0;
	int CntChildP 			= 0;
	int ChildItemTag 		= 0;
	int n_closure_tags 		= 0;
	int Item_ID=0,Item_UoM=0,Item_Owner=0;

	char *LatRevName			= NULL;
	char *Plant_MakeBuy			= NULL;
	char *bl_mkbuy_string		= NULL;
	char *POwnerName			= NULL;
	char *POwnerNameDup			= NULL;
	char *InpRevSeq				= NULL;
	char *ChildRevName			= NULL;
	char *ChildOwnName			= NULL;
	char *ChildPrtType			= NULL;
	char *ChildPrtQty			= NULL;
	char *ChildQtyDup			= NULL;
	char *ChildPrtUoM			= NULL;
	char *PartRelStatus			= NULL;
	char *ChildRelStatus		= NULL;
	char *PartRevSeq			= NULL;
	char *PlantSuffix			= NULL;

	tag_t		queryTag		= NULLTAG;
	tag_t		LatestPRev		= NULLTAG;
	tag_t		window			= NULLTAG;
	tag_t		rule			= NULLTAG;
	char		*ClosureRule	= NULL;
	tag_t		*closure_tags	= NULLTAG;
	tag_t		closure_tag		= NULLTAG;
	tag_t		t_DMLRevision	= NULLTAG;

	tag_t		*outTag = NULLTAG;
	tag_t		PerentLine = NULLTAG;
	tag_t		*ChildPartLine = NULLTAG;
	tag_t		ChildItemRevTag = NULLTAG;
	tag_t		*RwPartItemMst		= NULLTAG;
	tag_t		RwPartMstTag		= NULLTAG;
	tag_t		RwPartRel			= NULLTAG;
	tag_t		RawPartRelTag		= NULLTAG;

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	meas_unit	= (char *) malloc(500 * sizeof(char));
	sr_no		= (char *) malloc(500 * sizeof(char));
	//ClosureRule = (char *) MEM_alloc(100 * sizeof(char ));


	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName		= ITK_ask_cli_argument("-u=");
	sPassword		= ITK_ask_cli_argument("-p=");
	AssyNo			= ITK_ask_cli_argument("-a=");
	//sRevision		= ITK_ask_cli_argument("-r=");
	//sSequence		= ITK_ask_cli_argument("-s=");
	plantcode		= ITK_ask_cli_argument("-t=");
	iSapServer		= ITK_ask_cli_argument("-c=");

	printf("\nInput Assay %s	plantcode [%s]\n", AssyNo,plantcode);

	tc_strdup(sRevision,&AssemblyRevisionDup);
	tc_strdup(sSequence,&SequenceRevisionDup);

	sprintf(fsuccess_name,"TCUA_SAP_BOM_Mismatch_%s.log",AssyNo);
	fsuccess = fopen(fsuccess_name,"a");
	if(fsuccess == NULL)
	printf("\nUnable To open Or Create Log  file");

	//char *qry_entries[1] = {"ID"};
	n_entries=2;
	//char *qry_entries[2] = {"Item ID","Revision"};
	char *qry_entries[2] = {"Item ID","Release Status"};

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	/*InpRevSeq 		= NULL;
	InpRevSeq=(char *) MEM_alloc(50);
	strcpy(InpRevSeq,sRevision);
	strcat(InpRevSeq,"*");
	strcat(InpRevSeq,sSequence);

	qry_values[0] = AssyNo;
	qry_values[1] = InpRevSeq;*/

	qry_values[0] = AssyNo;
    //qry_values[1] = "T5_LcsAplRlzd";
    qry_values[1] = "T5_LcsStdRlzd";

	//if(QRY_find("PartMatQ", &queryTag));
	//if(QRY_find("Unique RevSeq", &queryTag));
	if(QRY_find("Driver VC Query", &queryTag));
	/*if(queryTag)
	{
		printf("\nFound Query PartMatQuery\n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query PartMatQuery\n");fflush(stdout);
	}*/
	
	//Executing query
	//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));
	ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &partObjs));

	printf("\nresultCount :%d:\n",resultCount);fflush(stdout);



	if (tc_strcmp(plantcode,"1100")==0)
	{
		tc_strdup("t5_CarMakeBuyIndicator",&Plant_MakeBuy);
		tc_strdup("bl_Design Revision_t5_CarMakeBuyIndicator",&bl_mkbuy_string);
		tc_strdup("BOMViewClosureRuleSTDC",&ClosureRule);
		tc_strdup("APLC",&PlantSuffix);
	}

	if(resultCount>0)
	{
		printf("\nPart Found : %s Query Executed Succesfully",AssyNo);fflush(stdout);

		for (cnt=0;cnt< resultCount;cnt++ )
		{
			PartOPtr=partObjs[cnt];

			//ITK_CALL(ITEM_ask_latest_rev(PartOPtr,&LatestPRev));	
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"object_string",&LatRevName));
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"owning_user",&POwnerName));
			tc_strdup(POwnerName,&POwnerNameDup);
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"release_status_list",&PartRelStatus));
			ITK_CALL(AOM_ask_value_string(PartOPtr,"t5_PartType",&prtType));
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"item_id",&assy_no));
			ITK_CALL(AOM_ask_value_string(PartOPtr,"item_revision_id",&PartRevSeq));
			tc_strdup(prtType,&prtTypeDup);
			tc_strdup(assy_no,&assy_noDup);

			printf("\nPart Number: %s	Part Type: %s",assy_no,prtType);fflush(stdout);

			if (
				tc_strcmp(prtTypeDup,"D")==0 ||
				tc_strcmp(prtTypeDup,"DA")==0 ||
				tc_strcmp(prtTypeDup,"DC")==0 ||
				tc_strcmp(prtTypeDup,"IFD")==0 ||
				tc_strcmp(prtTypeDup,"IM")==0 ||
				tc_strcmp(prtTypeDup,"CP")==0
				)
			{
				printf("\nDesign Revision [%s] has Type %s Exiting...",assy_no,prtType);
				goto CLEANUP;
			}

			if(tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)
			{
				printf("\nPartName: %s	ReleaseStatus: %s",LatRevName,PartRelStatus);fflush(stdout);
				fprintf(fsuccess,"\nPartName: %s	ReleaseStatus: %s",LatRevName,PartRelStatus);fflush(stdout);
			}
			else
			{
				printf("\nPart %s PartRelStatus: %s Part not STDSIC Released...\n",LatRevName,PartRelStatus);
				fprintf(fsuccess,"\nPart %s PartRelStatus: %s Part not STDSIC Released...\n",LatRevName,PartRelStatus);
				//goto CLEANUP;
				continue;
			}


			//Checking plant DML released
			if (tm_fnd_DML_PART(PlantSuffix,PartOPtr, &t_DMLRevision)!=1)
			{
				printf("\nValid Released DML not found for %s/%s, Checking Previous Revision\n",assy_no,PartRevSeq);
				//continue;
				goto CLEANUP;
			}


			if( tc_strcmp(prtTypeDup, "M") == 0 ||
				tc_strcmp(prtTypeDup, "SA") == 0 ||
				tc_strcmp(prtTypeDup, "SP")==0 ||
				tc_strcmp(prtTypeDup, "EM")==0 ||
				tc_strcmp(prtTypeDup, "A") == 0 ||
				tc_strcmp(prtTypeDup, "V") == 0 ||
				tc_strcmp(prtTypeDup, "T") == 0 ||
				tc_strcmp(prtTypeDup, "VC") == 0 ||
				tc_strcmp(prtTypeDup, "G") == 0 ||
				tc_strcmp(prtTypeDup, "C") == 0 ||
				tc_strcmp(prtTypeDup, "R") == 0)
			{
				printf("\nExpanding %s/%s BOM...",assy_no,PartRevSeq);

				BOM_create_window (&window);		
				//CFM_find( "STDC Release and above", &rule );
				CFM_find( "STDC Released and Above", &rule );
				BOM_set_window_config_rule( window, rule );	
				
				//Setting Closure Rule Start
				printf("\nSetting ClosureRule : %s",ClosureRule);
				ITK_CALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &n_closure_tags, &closure_tags ));
				printf("\nn_closure_tags found %d",n_closure_tags);fflush(stdout);
				if(n_closure_tags > 0)
				{
					closure_tag=closure_tags[0];
					ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
				}
				else
				{
					goto CLEANUP;
				}
				//Setting Closure Rule End

				BOM_set_window_pack_all (window, true);
				BOM_set_window_top_line (window, null_tag, PartOPtr, null_tag, &PerentLine);
				BOM_line_ask_child_lines(PerentLine, &CntChildP, &ChildPartLine);
				printf("\nNo of Child Parts are %d\n",CntChildP);

				if (tc_strcmp(prtTypeDup,"R")==0 || tc_strcmp(prtTypeDup,"SP")==0)
				{
					ITK_CALL(GRM_find_relation_type("T5_RPtRel",&RwPartRel));
					ITK_CALL(AOM_ask_value_tags(PartOPtr,"T5_RPtRel",&CntChildP,&RwPartItemMst));
					printf("\nChild Raw Part Count : %d",CntChildP);fflush(stdout);
					fprintf(fsuccess,"\nChild Raw Part Count : %d",CntChildP);fflush(stdout);
				}
			
				if(CntChildP>0)
				{
					//Child part loop
					for(i=0;i<CntChildP;i++)
					{
						if (tc_strcmp(prtTypeDup,"R")==0 || tc_strcmp(prtTypeDup,"SP")==0)
						{
							RwPartMstTag=RwPartItemMst[i];
							ITK_CALL(ITEM_ask_latest_rev(RwPartMstTag,&ChildOPtr));
							
							ITK_CALL(AOM_ask_value_string(ChildOPtr,"item_id",&ChildRevName));
							ITK_CALL(AOM_ask_value_string(ChildOPtr,"t5_uom",&ChildPrtUoM));
							ITK_CALL(AOM_ask_value_string(ChildOPtr,"t5_PartType",&ChildPartType));
							ITK_CALL(AOM_UIF_ask_value(ChildOPtr,"release_status_list",&ChildRelStatus));
							ITK_CALL(AOM_ask_value_string(ChildOPtr,Plant_MakeBuy,&make_buy_ind));

							ITK_CALL(GRM_find_relation(PartOPtr,RwPartMstTag,RwPartRel,&RawPartRelTag));
							ITK_CALL(AOM_UIF_ask_value(RawPartRelTag,"t5_UsageRT",&ChildPrtQty));
							tc_strdup(ChildPrtQty,&ChildQtyDup);
							printf("\nChild Raw Part :%s,%s,%s,%s",ChildRevName,ChildPrtUoM,ChildPartType,ChildPrtQty);
						}
						else
						{
							ChildOPtr=ChildPartLine[i];

							BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID);
							BOM_line_ask_attribute_string(ChildOPtr, Item_ID, &ChildRevName);
							
							BOM_line_look_up_attribute ("bl_item_uom_tag",&Item_UoM);
							BOM_line_ask_attribute_string(ChildOPtr,Item_UoM,&ChildPrtUoM);

							BOM_line_look_up_attribute ("awb0RevisionOwningUser",&Item_Owner);
							BOM_line_ask_attribute_string(ChildOPtr,Item_Owner,&ChildOwnName);

							ITK_CALL(AOM_UIF_ask_value(ChildOPtr,"bl_rev_release_status_list",&ChildRelStatus));
							AOM_ask_value_string(ChildOPtr,"bl_quantity",&ChildPrtQty);
							AOM_ask_value_string(ChildOPtr,"bl_Design Revision_t5_PartType",&ChildPartType);
							AOM_ask_value_string(ChildOPtr,bl_mkbuy_string,&make_buy_ind);

						}

						if(tc_strstr(ChildRelStatus,"STDSIC Released")==NULL)
						{
							printf("\nChild Part %s ChildRelStatus: %s Part not STDSIC Released...Skipping\n",ChildRevName,ChildRelStatus);
							fprintf(fsuccess,"\nChild Part %s ChildRelStatus: %s Part not STDSIC Released...Skipping\n",ChildRevName,ChildRelStatus);
							continue;
						}

						tc_strdup(ChildPrtQty,&ChildQtyDup);
						//printf("\nChild Part Number [%s] Part Qty [%s]	UoM [%s]	Owner [%s]",ChildRevName,ChildPrtQty,ChildPrtUoM,ChildOwnName);
						
						if(tc_strcmp(ChildPrtQty, "") == 0 || tc_strcmp(ChildPrtQty,"0") == 0 || tc_strcmp(ChildPrtQty,"0.00000") == 0)
						{
							printf("\nChild Part Number [%s] Part Qty [%s] hence skipping",ChildRevName,ChildPrtQty);
							continue;
						}

						if (
							tc_strcmp(ChildPartType,"D")==0 ||
							tc_strcmp(ChildPartType,"DA")==0 ||
							tc_strcmp(ChildPartType,"DC")==0 ||
							tc_strcmp(ChildPartType,"IFD")==0 ||
							tc_strcmp(ChildPartType,"IM")==0 ||
							tc_strcmp(ChildPartType,"CP")==0 ||
							tc_strstr(ChildRevName,"_") !=NULL
							)
						{
							printf("\nSkipping Child Part [%s] as Part Type [%s]",ChildRevName,ChildPartType);
							continue;
						}

						tc_strdup(make_buy_ind,&make_buy_indDup);

						if(tc_strlen(make_buy_ind)==0 || tc_strcmp(make_buy_ind,"NA")==0)
						{
							printf("\nSkipping Child Part [%s] as Plant Make/Buy is NULL or NA",ChildRevName);
							continue;
						}

						if(tc_strlen(make_buy_ind)>0)
						{
							tc_strdup(make_buy_ind,&make_buy_indDup);

							if(tc_strcmp(make_buy_indDup,"F18") == 0)
							{
								tc_strdup("L",&mat_prov_ind);
								tc_strdup("1",&tempcsrel);
							}
							else
							{
								tc_strdup("",&mat_prov_ind);
								tc_strdup("X",&tempcsrel);
							}
						}
					
						if(tc_strlen(ChildPrtUoM)>0)
						{
							tc_strdup(ChildPrtUoM,&unitDup);
							if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
							else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
							else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
							else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
							else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
							else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
							else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
							else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
							else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
							else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
							else
							{
								tc_strdup("EA",&unitDup);
								tc_strcpy(meas_unit,"EA");
							}
						}
						else tc_strcpy(meas_unit,"EA");
							
						tc_strdup(ChildRevName,&part_noDup);
						floatQty = atof(ChildQtyDup);

						printf("\nFinal Node [%s][%7.3f][%s][%s][%s][%s]",part_noDup,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);

						if(p==NULL)
						{
							sr_no1 = 1 ;
							sprintf(sr_no,"%04d",sr_no1);
							tc_strdup(part_noDup,&part_noDup1);
							p = createnode(part_noDup1);
							start = p;
						}
						else
						{
							ret = search(start,part_noDup);
							if(ret==1)
							{
								 q=start;
								 while(q->next!=NULL)
								 {
									 q=q->next;
								 }
								 sr_no1 = sr_no1 + 1 ;
								 sprintf(sr_no,"%04d",sr_no1);
								//strcpy(part_noDup1,part_noDup);
								tc_strdup(part_noDup,&part_noDup1);
								q->next=createnode(part_noDup1);
							}
						}
					}//for loop child parts

					if(sr_no1 < 1)
					{
						printf("\nAssembly %s do not have structure in PLM",assy_no);fflush(stdout);
						goto CLEANUP;
					}
					else
					{
						cll_cad_display_bom_with_sub_items(assy_noDup);
						//my_comp_part_sap=(char *) malloc (sizeof(my_denis));

						if(strlen(crecstring_sap)>0)
						{
							for(ia=0;ia<=(strlen(crecstring_sap)-17);ia=ia+17)
							{

								ja=ia;
								memset(my_denis,0,sizeof(my_denis));
								for(ka=ja,la=0;ka<=ja+16;ka=ka+1,la=la+1)
								{
									my_denis[la]=crecstring_sap[ka];
								}
								my_denis[la++]='\0';
								tc_strdup(my_denis,&my_comp_part_sap);

								if(p1==NULL)
								{
										p1 = createnode(my_comp_part_sap);
										start1 = p1;

								}
								else
								{
										 q1=start1;
										 ret1 = search(start1,my_comp_part_sap);
										 if(ret1==0)
										 {
											 printf("\nIn SAP assembly %s Duplicate comp_partno found :%s: for plantcode [%s]",assy_noDup,my_comp_part_sap,plantcode);fflush(stdout);
											 fprintf(fsuccess,"\nIn SAP assembly %s Duplicate comp_partno found :%s: for plantcode [%s]",assy_noDup,my_comp_part_sap,plantcode);fflush(stdout);
										 }
										 while(q1->next!=NULL)
										 {
											 q1=q1->next;
										 }
										 q1->next=createnode(my_comp_part_sap);
								}
							}

						}
						printf("\n\nSAP DATA..............\n");fflush(stdout);
						fprintf(fsuccess,"\n\nSAP DATA..............\n");fflush(stdout);
						display(start1,assy_noDup);
						printf("\n\nPLM DATA..............\n");fflush(stdout);
						fprintf(fsuccess,"\n\nPLM DATA..............\n");fflush(stdout);
						display(start,assy_noDup);
						printf("\nMismatch Report.........\n");fflush(stdout);
						fprintf(fsuccess,"\nMismatch Report.........\n");fflush(stdout);
						compare(start,start1,AssyNo);
						printf("\nBOM Mismatch competeled for %s/%s BOM...",assy_no,PartRevSeq);
						printf("\n.....................................\n");fflush(stdout);
						fprintf(fsuccess,"\n.....................................\n");fflush(stdout);

						my_free(start);
						my_free(start1);
						goto CLEANUP;
					}
				}
				else
				{
				 printf("\nNO BOM found for %s assembly in PLM",assy_noDup);fflush(stdout);
				 fprintf(fsuccess,"\nMSG RCVD:NO BOM found for %s assembly in PLM",assy_noDup);fflush(stdout);
				 goto CLEANUP;
				}
			}//If Module
			else
			{
				printf("\nDesign Revision [%s] has PartType %s Exiting...",assy_no,prtType);
				goto CLEANUP;
			}

		}//part objects for loop

	}
	else
	{ 
		printf("Part %s not found STD Released in TCUA",AssyNo); 
		goto CLEANUP;
	}

	CLEANUP:
		printf("\nCLEANUP..."); fflush(stdout);
		ITK_CALL(POM_logout(false));
		return status;

	EXIT:
		printf("\nExiting...\n");
		ITK_CALL(POM_logout(false));
		return status;
}


RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

void cll_cad_display_bom_with_sub_items(char *assy_noDup)
{
	static RFC_RC RfcRc;
	RFC_HANDLE hRfc;
	char s[1024];
	/*char comp_part_sap[15];*/
	char comp_part_sap[15];

	RC29L_STLAL eIBomAlternative;
	RC29L_STLAN eIBomType;
	RC29L_AENNR eIChangeNumber;
	DRAW_LOEDK eIDisplayFlag;
	RC29L_MATNR eIMaterial;
	RC29L_WERKS eIPlant;
	RC29L_REVLV eIRevisionLevel;
	BICSK_DATUV eIValidFrom;
	CAD_BICSK iEBomHeader;
	MESSAGE_MSGTX iEMessage;
	CAD_RETURN_MESSAGE_LEN iEMessageLen;
	CAD_RETURN_VALUE iEReturn;
	ITAB_H thBomItem = ITAB_NULL;
	ITAB_H thBomSubItem = ITAB_NULL;
	ITAB_H thDmsClassData = ITAB_NULL;
	ITAB_H thSapFieldData = ITAB_NULL;
	char xException[256];

	int i_sap=0,j_sap=0,k_sap=0,m_sap=0;

	/* table row variables */
	CAD_BOM_ITEM *tBomItem;
	unsigned crow;
	char t;
	/*char plant_code[5]={0};*/

    /*strcpy(plant_code,"3100");*/
	/*strcpy(plantcode,"1001");*/
    printf("\nBOM data received for :%s: ",plantcode);fflush(stdout);

    SETCHAR(eIBomAlternative,"01");
    SETCHAR(eIBomType,"1");
    SETCHAR(eIChangeNumber,"");
    SETCHAR(eIDisplayFlag,"X");
    SETCHAR(eIMaterial,assy_noDup);
    SETCHAR(eIPlant,plantcode);
    SETCHAR(eIRevisionLevel,"");
    SETCHAR(eIValidFrom,"");

	hRfc = BapiLogon( );

    if (thBomItem==ITAB_NULL)
	{
      thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
      if (thBomItem==ITAB_NULL)
		  rfc_error("ItCreateBOM_ITEM");
	}
    else
	{
      if (ItFree(thBomItem) != 0)
		  rfc_error("ItFreeBOM_ITEM");
	}
    if (thBomSubItem==ITAB_NULL)
	{
      thBomSubItem = ItCreate("BOM_SUB_ITEM",sizeof(CSSUBITEM),0,0);
      if (thBomSubItem==ITAB_NULL)
		  rfc_error("ItCreateBOM_SUB_ITEM");
	}
    else
	{
      if (ItFree(thBomSubItem) != 0)
		  rfc_error("ItFreeBOM_SUB_ITEM");
	}
    if (thDmsClassData==ITAB_NULL)
	{
      thDmsClassData = ItCreate("DMS_CLASS_DATA",sizeof(CLS_CHARAC),0,0);
      if (thDmsClassData==ITAB_NULL)
		  rfc_error("ItCreateDMS_CLASS_DATA");
	}
    else
	{
      if (ItFree(thDmsClassData) != 0)
		  rfc_error("ItFreeDMS_CLASS_DATA");
	}
    if (thSapFieldData==ITAB_NULL)
	{
      thSapFieldData = ItCreate("SAP_FIELD_DATA",sizeof(RFCDMSDATA),0,0);
      if (thSapFieldData==ITAB_NULL)
		  rfc_error("ItCreateSAP_FIELD_DATA");
	}
    else
	{
      if (ItFree(thSapFieldData) != 0)
		  rfc_error("ItFreeSAP_FIELD_DATA");
	}



      /* call RFC function */
	RfcRc = cad_display_bom_with_sub_items(hRfc,&eIBomAlternative,&eIBomType,&eIChangeNumber,&eIDisplayFlag,&eIMaterial,&eIPlant,&eIRevisionLevel,&eIValidFrom,&iEBomHeader,&iEMessage,&iEMessageLen,&iEReturn,thBomItem,thBomSubItem,thDmsClassData,thSapFieldData,xException);
	switch (RfcRc) 
	{

	case RFC_OK :
				  memset(crecstring_sap,0,sizeof(crecstring_sap));
				  memset(recstring_sap,0,sizeof(recstring_sap));
				  strcpy(recstring_sap,"");
				  sprintf(s,"%d lines",ItFill(thBomItem));
				  printf("\nNo of row fetched :%s:",s); fflush(stdout);
				  t=0;

				  for (crow = 1;crow <= ItFill(thBomItem); crow++)
				  {
					tBomItem = ItGetLine(thBomItem,crow);
					if (tBomItem == NULL)
						rfc_error("ItGetLineBOM_ITEM");
					strcpy(comp_part_sap,"");
					GETCHAR(tBomItem->Idnrk,s);
					strcpy(comp_part_sap,s);
					strcat(recstring_sap,comp_part_sap);
				  }

				  for(i_sap=0;i_sap<strlen(recstring_sap);i_sap=i_sap+18)
				  {
					m_sap=i_sap;

					for(j_sap=0;j_sap<17;j_sap++)
					{
						crecstring_sap[k_sap]=recstring_sap[m_sap];
						k_sap++;
						m_sap++;
					}
				 }

				  sprintf(s,"\nchild parts fetched from sap : %d ",ItFill(thBomItem ));

			         break;

        case RFC_EXCEPTION :
			         /* exception raised */
					 printf("exception"); fflush(stdout);
			         break;
        case RFC_SYS_EXCEPTION :
			         rfc_error("system exception raised");

        case RFC_FAILURE :
					 rfc_error("failure");

        default :
					 rfc_error("other failure");

      }
    /* delete tables */
    if (ItDelete(thBomItem) != 0)
      rfc_error("ItDelete BOM_ITEM");
    if (ItDelete(thBomSubItem) != 0)
      rfc_error("ItDelete BOM_SUB_ITEM");
    if (ItDelete(thDmsClassData) != 0)
      rfc_error("ItDelete DMS_CLASS_DATA");
    if (ItDelete(thSapFieldData) != 0)
      rfc_error("ItDelete SAP_FIELD_DATA");

	RfcClose (hRfc);
}

RFC_RC cad_display_bom_with_sub_items(RFC_HANDLE hRfc,RC29L_STLAL *eIBomAlternative,RC29L_STLAN *eIBomType,RC29L_AENNR *eIChangeNumber,DRAW_LOEDK *eIDisplayFlag,RC29L_MATNR *eIMaterial,RC29L_WERKS *eIPlant,RC29L_REVLV *eIRevisionLevel,BICSK_DATUV *eIValidFrom,CAD_BICSK *iEBomHeader,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_RETURN_VALUE *iEReturn,ITAB_H thBomItem,ITAB_H thBomSubItem,ITAB_H thDmsClassData,ITAB_H thSapFieldData,char *xException)
{

  RFC_PARAMETER Exporting[9];
  RFC_PARAMETER Importing[5];
  RFC_TABLE Tables[5];
  RFC_RC RfcRc;
  char *RfcException = NULL;

  Exporting[0].name = "I_BOM_ALTERNATIVE";
  Exporting[0].nlen = 17;
  Exporting[0].type = TYPC;
  Exporting[0].leng = sizeof(RC29L_STLAL);
  Exporting[0].addr = eIBomAlternative;

  Exporting[1].name = "I_BOM_TYPE";
  Exporting[1].nlen = 10;
  Exporting[1].type = TYPC;
  Exporting[1].leng = sizeof(RC29L_STLAN);
  Exporting[1].addr = eIBomType;

  Exporting[2].name = "I_CHANGE_NUMBER";
  Exporting[2].nlen = 15;
  Exporting[2].type = TYPC;
  Exporting[2].leng = sizeof(RC29L_AENNR);
  Exporting[2].addr = eIChangeNumber;

  Exporting[3].name = "I_DISPLAY_FLAG";
  Exporting[3].nlen = 14;
  Exporting[3].type = TYPC;
  Exporting[3].leng = sizeof(DRAW_LOEDK);
  Exporting[3].addr = eIDisplayFlag;

  Exporting[4].name = "I_MATERIAL";
  Exporting[4].nlen = 10;
  Exporting[4].type = TYPC;
  Exporting[4].leng = sizeof(RC29L_MATNR);
  Exporting[4].addr = eIMaterial;

  Exporting[5].name = "I_PLANT";
  Exporting[5].nlen = 7;
  Exporting[5].type = TYPC;
  Exporting[5].leng = sizeof(RC29L_WERKS);
  Exporting[5].addr = eIPlant;

  Exporting[6].name = "I_REVISION_LEVEL";
  Exporting[6].nlen = 16;
  Exporting[6].type = TYPC;
  Exporting[6].leng = sizeof(RC29L_REVLV);
  Exporting[6].addr = eIRevisionLevel;

  Exporting[7].name = "I_VALID_FROM";
  Exporting[7].nlen = 12;
  Exporting[7].type = TYPC;
  Exporting[7].leng = sizeof(BICSK_DATUV);
  Exporting[7].addr = eIValidFrom;

  Exporting[8].name = NULL;

  Tables[0].name     = "BOM_ITEM";
  Tables[0].nlen     = 8;
  Tables[0].type     = handleOfCAD_BOM_ITEM;
  Tables[0].ithandle = thBomItem;

  Tables[1].name     = "BOM_SUB_ITEM";
  Tables[1].nlen     = 12;
  Tables[1].type     = handleOfCSSUBITEM;
  Tables[1].ithandle = thBomSubItem;

  Tables[2].name     = "DMS_CLASS_DATA";
  Tables[2].nlen     = 14;
  Tables[2].type     = handleOfCLS_CHARAC;
  Tables[2].ithandle = thDmsClassData;

  Tables[3].name     = "SAP_FIELD_DATA";
  Tables[3].nlen     = 14;
  Tables[3].type     = handleOfRFCDMSDATA;
  Tables[3].ithandle = thSapFieldData;

  Tables[4].name = NULL;

  RfcRc = RfcCall(hRfc,"CAD_DISPLAY_BOM_WITH_SUB_ITEMS",Exporting,Tables);

  switch (RfcRc)
  {
    case RFC_OK :

      Importing[0].name = "E_BOM_HEADER";
      Importing[0].nlen = 12;
      Importing[0].type = handleOfCAD_BICSK;
      Importing[0].leng = sizeof(CAD_BICSK);
      Importing[0].addr = iEBomHeader;

      Importing[1].name = "E_MESSAGE";
      Importing[1].nlen = 9;
      Importing[1].type = TYPC;
      Importing[1].leng = sizeof(MESSAGE_MSGTX);
      Importing[1].addr = iEMessage;

      Importing[2].name = "E_MESSAGE_LEN";
      Importing[2].nlen = 13;
      Importing[2].type = TYPC;
      Importing[2].leng = sizeof(CAD_RETURN_MESSAGE_LEN);
      Importing[2].addr = iEMessageLen;

      Importing[3].name = "E_RETURN";

      Importing[3].nlen = 8;
      Importing[3].type = TYPC;
      Importing[3].leng = sizeof(CAD_RETURN_VALUE);
      Importing[3].addr = iEReturn;

      Importing[4].name = NULL;

      RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
      switch (RfcRc)
      {
        case RFC_SYS_EXCEPTION :
				strcpy(xException,RfcException);
				break;
        case RFC_EXCEPTION :
				strcpy(xException,RfcException);
				break;
		default:;
       }

		break;
	default :
		printf("Error occured");fflush(stdout);
  }

  return RfcRc;
}