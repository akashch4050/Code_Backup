//#include "saprfc.h"
//#include "sapitab.h"
//#include "wmhelpe.h"
//#include "bapi.h"
#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "ClassAttrRel.h"
#include "bapi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
//#include <cl.h>
//#include <msgomf.h>
//#include <msgapc.h>
//#include <ZZ_sqlerr.h>
//#include <AZ_ato.h>
#include <stdio.h>
#include <stdlib.h>
//#include <string.h>
//#include <Mtimsgh.h>
//#include <usc.h>
//#include <sc.h>
//#include <pdmsessn.h>
//#include <tel.h>
#include <sa/sa.h>
#include <unidefs.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <stdarg.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <unidefs.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#include <pie/pie.h>

char *iSapServer = NULL;

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
RFC_HANDLE hRfc;
RFC_RC RfcRc;
RFC_RC BAPI_CLASS_CHANGE(
//	RFC_HANDLE hRfc,
	CLASSNUM*eCLASSNUM
	,CLASSTYPE*eCLASSTYPE
	,CHANGENUMBER*eCHANGENUMBER
	,KEYDATE*eKEYDATE
	,CLASSBASICDATA*eCLASSBASICDATA
	,CLASSBASICDATANEW*eCLASSBASICDATANEW
    ,CLASSDOCUMENT*eCLASSDOCUMENT
	,CLASSDOCUMENTNEW*eCLASSDOCUMENTNEW
	,CLASSADDITIONAL*eCLASSADDITIONAL
	,CLASSADDITIONALNEW*eCLASSADDITIONALNEW
	,CLASSSTANDARD*eCLASSSTANDARD
	,CLASSSTANDARDNEW*eCLASSSTANDARDNEW
    ,ITAB_H thRETURN
	,ITAB_H thCLASSDESCRIPTIONS
	,ITAB_H thCLASSLONGTEXTS
    ,ITAB_H thCLASSCHARACTERISTICS
	,ITAB_H thCHARACTERISTICOVERWRITE
	,ITAB_H thCHARACTVALUEOVERWRIT
	,ITAB_H thCHARACTERISTICVALUETEXTOVR
	,ITAB_H thCLASSDESCRIPTIONSNEW
	,ITAB_H thCLASSLONGTEXTSNEW
    ,ITAB_H thCLASSCHARACTERISTICSNEW
    ,ITAB_H thCHARACTERISTICOVERWRITENEW
    ,ITAB_H thCHARACTVALUEOVERWRITNEW
	,ITAB_H thCHARACTERISTICVALUETEXTOVRNEW,
    char *xException
	);
RFC_HANDLE BapiLogon(void);

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("%*.0s",pos,text); printf("%-*s : %s\n",len,text,str);fflush(stdout);
  //if (stdout!=NULL) fprintf(stdout,"=%s\n>%s\n",text,str);
  return;
}
void trimTrailing(char * str)
{
    int index, i;

    /* Set default index */
    index = -1;

    /* Find last index of non-white space character */
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }

        i++;
    }

    /* Mark next character to last non-white space character as NULL */
    str[index + 1] = '\0';
}

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

void rfc_error(char *operation);

void  rfc_error(char *operation)
{
#ifdef SAPonNT
  char s[16];
#endif
  RFC_ERROR_INFO RfcErrorInfo;
  printf("\nRFC error");
  printf("\noperation/code: %s",operation);
  memset(&RfcErrorInfo,0,sizeof(RfcErrorInfo));
  RfcLastError(&RfcErrorInfo);
  printf("\nkey				%s",RfcErrorInfo.key);
  printf("\nstatus			%s",RfcErrorInfo.status);
  printf("\nmessage			%s",RfcErrorInfo.message);
  printf("\ninternal status %s",RfcErrorInfo.intstat);
  RfcClose (RFC_HANDLE_NULL);
  exit(1);
}

RFC_RC BAPI_TRANSACTION_COMMIT(
//		RFC_HANDLE hRfc,
		BAPITA_WAIT *eBAPITA_WAIT,
		RETURN *iRETURN,
		char* xException)
{
	RFC_PARAMETER Exporting[2];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[1];
//	RFC_HANDLE hRfc;
//	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "BAPITA_WAIT";
	Exporting[0].nlen = strlen("BAPITA_WAIT");
	Exporting[0].type = TYPC;
	Exporting[0].leng = sizeof(BAPITA_WAIT);
	Exporting[0].addr = eBAPITA_WAIT;

	Exporting[1].name = NULL;

	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_TRANSACTION_COMMIT",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:


			Importing[0].name = "RETURN";
			Importing[0].nlen = strlen("RETURN");
			Importing[0].type = handleOfRETURN;
			Importing[0].leng = sizeof(RETURN);
			Importing[0].addr = iRETURN;

			Importing[1].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			//printf("\nRfcException3:%s",RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
		break;
	}
	return RfcRc;

}


RFC_RC BAPI_CLASS_CHANGE(
//	RFC_HANDLE hRfc,
	CLASSNUM*eCLASSNUM,
	CLASSTYPE*eCLASSTYPE,
	CHANGENUMBER*eCHANGENUMBER,
	KEYDATE*eKEYDATE,
	CLASSBASICDATA*eCLASSBASICDATA,
	CLASSBASICDATANEW*eCLASSBASICDATANEW,
    CLASSDOCUMENT*eCLASSDOCUMENT,
	CLASSDOCUMENTNEW*eCLASSDOCUMENTNEW,
	CLASSADDITIONAL*eCLASSADDITIONAL,
	CLASSADDITIONALNEW*eCLASSADDITIONALNEW,
	CLASSSTANDARD*eCLASSSTANDARD,
	CLASSSTANDARDNEW*eCLASSSTANDARDNEW,
    ITAB_H thRETURN,
	ITAB_H thCLASSDESCRIPTIONS,
	ITAB_H thCLASSLONGTEXTS,
    ITAB_H thCLASSCHARACTERISTICS,
	ITAB_H thCHARACTERISTICOVERWRITE,
	ITAB_H thCHARACTVALUEOVERWRIT,
	ITAB_H thCHARACTERISTICVALUETEXTOVR,
	ITAB_H thCLASSDESCRIPTIONSNEW,
	ITAB_H thCLASSLONGTEXTSNEW,
    ITAB_H thCLASSCHARACTERISTICSNEW,
    ITAB_H thCHARACTERISTICOVERWRITENEW,
    ITAB_H thCHARACTVALUEOVERWRITNEW,
	ITAB_H thCHARACTERISTICVALUETEXTOVRNEW,
	char *xException
	)
{

//RFC_RC RfcRc;
RFC_PARAMETER Exporting[13];
RFC_PARAMETER Importing[1];
RFC_TABLE Tables[14];
char *RfcException = NULL;


Exporting[0].name = "CLASSNUM";
Exporting[0].nlen = 8;
Exporting[0].type = handleOfCLASSNUM;
Exporting[0].leng = sizeof(CLASSNUM);
Exporting[0].addr = eCLASSNUM;

Exporting[1].name = "CLASSTYPE";
Exporting[1].nlen = 9;
Exporting[1].type = handleOfCLASSTYPE;
Exporting[1].leng = sizeof(CLASSTYPE);
Exporting[1].addr = eCLASSTYPE;

Exporting[2].name = "CHANGENUMBER";
Exporting[2].nlen = 12;
Exporting[2].type = handleOfCHANGENUMBER;
Exporting[2].leng = sizeof(CHANGENUMBER);
Exporting[2].addr = eCHANGENUMBER;

Exporting[3].name = "KEYDATE";
Exporting[3].nlen = 7;
Exporting[3].type = handleOfKEYDATE;
Exporting[3].leng = sizeof(KEYDATE);
Exporting[3].addr = eKEYDATE;

Exporting[4].name = "CLASSBASICDATA";
Exporting[4].nlen = 14;
Exporting[4].type = handleOfCLASSBASICDATA;
Exporting[4].leng = sizeof(CLASSBASICDATA);
Exporting[4].addr = eCLASSBASICDATA;

Exporting[5].name = "CLASSBASICDATANEW";
Exporting[5].nlen = 17;
Exporting[5].type = handleOfCLASSBASICDATANEW;
Exporting[5].leng = sizeof(CLASSBASICDATANEW);
Exporting[5].addr = eCLASSBASICDATANEW;

Exporting[6].name = "CLASSDOCUMENT";
Exporting[6].nlen = 13;
Exporting[6].type = handleOfCLASSDOCUMENT;
Exporting[6].leng = sizeof(CLASSDOCUMENT);
Exporting[6].addr = eCLASSDOCUMENT;

Exporting[7].name = "CLASSDOCUMENTNEW";
Exporting[7].nlen = 16;
Exporting[7].type = handleOfCLASSDOCUMENTNEW;
Exporting[7].leng = sizeof(CLASSDOCUMENTNEW);
Exporting[7].addr = eCLASSDOCUMENTNEW;

Exporting[8].name = "CLASSADDITIONAL";
Exporting[8].nlen = 15;
Exporting[8].type = handleOfCLASSADDITIONAL;
Exporting[8].leng = sizeof(CLASSADDITIONAL);
Exporting[8].addr = eCLASSADDITIONAL;

Exporting[9].name = "CLASSADDITIONALNEW";
Exporting[9].nlen = 18;
Exporting[9].type = handleOfCLASSADDITIONALNEW;
Exporting[9].leng = sizeof(CLASSADDITIONALNEW);
Exporting[9].addr = eCLASSADDITIONALNEW;

Exporting[10].name = "CLASSSTANDARD";
Exporting[10].nlen = 13;
Exporting[10].type = handleOfCLASSSTANDARD;
Exporting[10].leng = sizeof(CLASSSTANDARD);
Exporting[10].addr = eCLASSSTANDARD;

Exporting[11].name = "CLASSSTANDARDNEW";
Exporting[11].nlen = 16;
Exporting[11].type = handleOfCLASSSTANDARDNEW;
Exporting[11].leng = sizeof(CLASSSTANDARDNEW);
Exporting[11].addr = eCLASSSTANDARDNEW;

Exporting[12].name = NULL;

Tables[0].name     = "RETURN";
Tables[0].nlen     = 6;
Tables[0].type     = handleOfRETURN;
Tables[0].ithandle = thRETURN;

Tables[1].name     = "CLASSDESCRIPTIONS";
Tables[1].nlen     = 17;
Tables[1].type     = handleOfCLASSDESCRIPTIONS;
Tables[1].ithandle = thCLASSDESCRIPTIONS;

Tables[2].name     = "CLASSLONGTEXTS";
Tables[2].nlen     = 14;
Tables[2].type     = handleOfCLASSLONGTEXTS;
Tables[2].ithandle = thCLASSLONGTEXTS;

Tables[3].name     = "CLASSCHARACTERISTICS";
Tables[3].nlen     = 20;
Tables[3].type     = handleOfCLASSCHARACTERISTICS;
Tables[3].ithandle = thCLASSCHARACTERISTICS;

Tables[4].name     = "CHARACTERISTICOVERWRITE";
Tables[4].nlen     = 23;
Tables[4].type     = handleOfCHARACTERISTICOVERWRITE;
Tables[4].ithandle = thCHARACTERISTICOVERWRITE;

Tables[5].name     = "CHARACTVALUEOVERWRIT";
Tables[5].nlen     = 20;
Tables[5].type     = handleOfCHARACTVALUEOVERWRIT;
Tables[5].ithandle = thCHARACTVALUEOVERWRIT;

Tables[6].name     = "CHARACTERISTICVALUETEXTOVR";
Tables[6].nlen     = 26;
Tables[6].type     = handleOfCHARACTERISTICVALUETEXTOVR;
Tables[6].ithandle = thCHARACTERISTICVALUETEXTOVR;

Tables[7].name     = "CLASSDESCRIPTIONSNEW";
Tables[7].nlen     = 25;
Tables[7].type     = handleOfCLASSDESCRIPTIONSNEW;
Tables[7].ithandle = thCLASSDESCRIPTIONSNEW;

Tables[8].name     = "CLASSLONGTEXTSNEW";
Tables[8].nlen     = 17;
Tables[8].type     = handleOfCLASSLONGTEXTSNEW;
Tables[8].ithandle = thCLASSLONGTEXTSNEW;

Tables[9].name     = "CLASSCHARACTERISTICSNEW";
Tables[9].nlen     = 23;
Tables[9].type     = handleOfCLASSCHARACTERISTICSNEW;
Tables[9].ithandle = thCLASSCHARACTERISTICSNEW;

Tables[10].name     = "CHARACTERISTICOVERWRITENEW";
Tables[10].nlen     = 26;
Tables[10].type     = handleOfCHARACTERISTICOVERWRITENEW;
Tables[10].ithandle = thCHARACTERISTICOVERWRITENEW;

Tables[11].name     = "CHARACTVALUEOVERWRITNEW";
Tables[11].nlen     = 23;
Tables[11].type     = handleOfCHARACTVALUEOVERWRITNEW;
Tables[11].ithandle = thCHARACTVALUEOVERWRITNEW;

Tables[12].name     = "CHARACTERISTICVALUETEXTOVRNEW";
Tables[12].nlen     = 29;
Tables[12].type     = handleOfCHARACTERISTICVALUETEXTOVRNEW;
Tables[12].ithandle = thCHARACTERISTICVALUETEXTOVRNEW;

Tables[13].name = NULL;

RfcRc = RfcCall(hRfc,"BAPI_CLASS_CHANGE",Exporting,Tables);

switch (RfcRc)
{
	case RFC_OK :
                Importing[0].name = NULL;


		RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
		//printf("\n%s",RfcException);

		switch (RfcRc)
		{
			case RFC_SYS_EXCEPTION:
				strcpy(xException,RfcException);
			break;
			case RFC_EXCEPTION:
				strcpy(xException,RfcException);
			break;
		}
	break;
	default :
		printf("\nin default");
}
return RfcRc;
}
void getTodayDate(char StdDate[9])
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;

	time_t Tval = 0;
	Tval = time(NULL);
	Sys_T = localtime(&Tval);
	Day= Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;
	//sprintf(StdDate,"%02d.%02d.%04d",Day,Month,Year);
	sprintf(StdDate,"%04d%02d%02d",Year,Month,Day);
	printf("Date:[%s]",StdDate);
}
void getMonthYear(char MonYear[7])
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;

	time_t Tval = 0;
	Tval = time(NULL);
	Sys_T = localtime(&Tval);
	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;

	sprintf(MonYear,"%02d.%04d",Month,Year);
	printf("Date:[%s]",MonYear);
}

/*cll_BAPI_TRANSACTION_COMMIT(RFC_RC RfcRc)
{
	char *xException = NULL;
	BAPITA_WAIT eBAPITA_WAIT;
	RETURN iRETURN;
	RFC_HANDLE hRfc;
	SETCHAR(eBAPITA_WAIT,"X");

	RfcRc = BAPI_TRANSACTION_COMMIT(hRfc,
				&eBAPITA_WAIT,
				&iRETURN,
				xException
			);
	switch (RfcRc)
	{
		case RFC_OK:
			printf("\nCommitted...");
			break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			exit(0);
		break;
		default:
			printf("\nOther Failure!");
			exit(0);
	}
}*/

extern int ITK_user_main(int argc, char ** argv )
{


int status = ITK_ok;
//status dstat = OKAY;
int stat = 0;
//int mfail = OKAY;
//RFC_RC RfcRc;
//RFC_HANDLE hRfc;
tag_t platfrm_tag=NULLTAG;

CLASSNUM eCLASSNUM;
CLASSTYPE eCLASSTYPE;
CHANGENUMBER eCHANGENUMBER;
KEYDATE eKEYDATE;
CLASSBASICDATA eCLASSBASICDATA;
CLASSBASICDATANEW eCLASSBASICDATANEW;
CLASSDOCUMENT eCLASSDOCUMENT;
CLASSDOCUMENTNEW eCLASSDOCUMENTNEW;
CLASSADDITIONAL eCLASSADDITIONAL;
CLASSADDITIONALNEW eCLASSADDITIONALNEW;
CLASSSTANDARD eCLASSSTANDARD;
CLASSSTANDARDNEW eCLASSSTANDARDNEW;

ITAB_H thRETURN= ITAB_NULL;
RETURN *tRETURN;
RETURN iRETURN;

ITAB_H thCLASSDESCRIPTIONS= ITAB_NULL;
CLASSDESCRIPTIONS *tCLASSDESCRIPTIONS;

ITAB_H thCLASSLONGTEXTS= ITAB_NULL;
CLASSLONGTEXTS *tCLASSLONGTEXTS;

ITAB_H thCLASSCHARACTERISTICS= ITAB_NULL;
CLASSCHARACTERISTICS *tCLASSCHARACTERISTICS;

ITAB_H thCHARACTERISTICOVERWRITE= ITAB_NULL;
CHARACTERISTICOVERWRITE *tCHARACTERISTICOVERWRITE;

ITAB_H thCHARACTVALUEOVERWRIT= ITAB_NULL;
CHARACTVALUEOVERWRIT *tCHARACTVALUEOVERWRIT;

ITAB_H thCHARACTERISTICVALUETEXTOVR= ITAB_NULL;
CHARACTERISTICVALUETEXTOVR *tCHARACTERISTICVALUETEXTOVR;

ITAB_H thCLASSDESCRIPTIONSNEW= ITAB_NULL;
CLASSDESCRIPTIONSNEW *tCLASSDESCRIPTIONSNEW;

ITAB_H thCLASSLONGTEXTSNEW= ITAB_NULL;
CLASSLONGTEXTSNEW *tCLASSLONGTEXTSNEW;

ITAB_H thCLASSCHARACTERISTICSNEW= ITAB_NULL;
CLASSCHARACTERISTICSNEW *tCLASSCHARACTERISTICSNEW;

ITAB_H thCHARACTERISTICOVERWRITENEW= ITAB_NULL;
CHARACTERISTICOVERWRITENEW *tCHARACTERISTICOVERWRITENEW;

ITAB_H thCHARACTVALUEOVERWRITNEW= ITAB_NULL;
CHARACTVALUEOVERWRITNEW *tCHARACTVALUEOVERWRITNEW;

ITAB_H thCHARACTERISTICVALUETEXTOVRNEW= ITAB_NULL;
CHARACTERISTICVALUETEXTOVRNEW *tCHARACTERISTICVALUETEXTOVRNEW;

char xException[256]={0};
FILE *fptr = NULL;
FILE *fp = NULL;

//string jtmemFile = NULL;
//string DMLClsurS = NULL;
//jtmemFile=nlsStrAlloc(100);
//DMLClsurS=nlsStrAlloc(100);
char cMaterial[100]={0};
int crow = 0;
char s[1028] = { 0 };
char ZiPartNumber[18] = { 0 };
char cPartNumber[15] = { 0 };
char cPlant[5] = { 0 };
char trDmlno[13] = { 0 };
char ExplPartListfname[200] = { 0 };
char ZiPartListfname[200] = { 0 };
FILE *flog = NULL;
char Logfname[200] = { 0 };
char StdDate[9] = { 0 };
char MonYear[7] = { 0 };
char *platfrm = NULL;
char *OptValClass = NULL;
char *item_type = NULL;
char *platfrm_name = NULL;
tag_t relation_dep = NULLTAG;
int countConfigCtx = 0;
tag_t *ConfigCtxSecObject = NULLTAG;
tag_t ConfigCtx = NULLTAG;
tag_t ConfigCtxObjTypeTag = NULLTAG;
char Config_CtxType[TCTYPE_name_size_c+1];
char *SmVCContext = NULL;
char *Context_Str = NULL;
char *SmCrIDContext = NULL;
tag_t queryTag = NULLTAG;
char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
int n_entries = 1;
char *qry_entries[1] = {"ID"};
int resultCount = 0;
tag_t *familtopttag = NULLTAG;
int j1 =0 ;
tag_t Optfmly_tag = NULLTAG;
char *OptfmlyName=NULL;
char *OptfmlyDesc=NULL;
char *Optfmly_type = NULL;


ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
ITK_CALL(ITK_auto_login( ));
ITK_CALL(ITK_set_journalling( TRUE ));

platfrm = ITK_ask_cli_argument("-i=");
OptValClass = ITK_ask_cli_argument("-c=");
iSapServer = ITK_ask_cli_argument("-s=");


getTodayDate(StdDate);

printf("\nOptValClass:%s",OptValClass);

SETCHAR(eCLASSNUM.CLASSNUM,OptValClass);//"X4_OPTIONMASTER"
SETCHAR(eCLASSTYPE.CLASSTYPE,"300");
SETCHAR(eCHANGENUMBER.CHANGENUMBER,"");
//SETDATE(eKEYDATE.KEYDATE,"20190522");//date
SETDATE(eKEYDATE.KEYDATE,StdDate);//date

SETCHAR(eCLASSBASICDATA.STATUS,"1");
SETCHAR(eCLASSBASICDATA.CLASSGROUP,"");
SETCHAR(eCLASSBASICDATA.DEPARTMENT_VIEW,"");
SETDATE(eCLASSBASICDATA.VALID_FROM,StdDate);
//SETDATE(eCLASSBASICDATA.VALID_FROM,"20190522");
SETDATE(eCLASSBASICDATA.VALID_TO,"99991231");
SETCHAR(eCLASSBASICDATA.AUTHMAINTAIN,"");
SETCHAR(eCLASSBASICDATA.AUTHCLASSIFY,"");
SETCHAR(eCLASSBASICDATA.AUTHSEARCH,"");
SETCHAR(eCLASSBASICDATA.SAME_VALUE_NO,"");
SETCHAR(eCLASSBASICDATA.SAME_VALUE_W,"");
SETCHAR(eCLASSBASICDATA.SAME_VALUE_E,"");
SETCHAR(eCLASSBASICDATA.LOCAL_CLASS,"");
SETCHAR(eCLASSBASICDATA.KATALOG,"");

SETCHAR(eCLASSBASICDATANEW.STATUS,"");
SETCHAR(eCLASSBASICDATANEW.CLASSGROUP,"");
SETCHAR(eCLASSBASICDATANEW.DEPARTMENT_VIEW,"");
SETDATE(eCLASSBASICDATANEW.VALID_FROM,"");
SETDATE(eCLASSBASICDATANEW.VALID_TO,"");
SETCHAR(eCLASSBASICDATANEW.AUTHMAINTAIN,"");
SETCHAR(eCLASSBASICDATANEW.AUTHCLASSIFY,"");
SETCHAR(eCLASSBASICDATANEW.AUTHSEARCH,"");
SETCHAR(eCLASSBASICDATANEW.SAME_VALUE_NO,"");
SETCHAR(eCLASSBASICDATANEW.SAME_VALUE_W,"");
SETCHAR(eCLASSBASICDATANEW.SAME_VALUE_E,"");
SETCHAR(eCLASSBASICDATANEW.LOCAL_CLASS,"");
SETCHAR(eCLASSBASICDATANEW.KATALOG,"");


SETCHAR(eCLASSDOCUMENT.DOCUMENT_NUMBER,"");
SETCHAR(eCLASSDOCUMENT.DOCUMENT_TYPE,"");
SETCHAR(eCLASSDOCUMENT.DOCUMENT_PART,"");
SETCHAR(eCLASSDOCUMENT.DOCUMENT_VERSION,"");

SETCHAR(eCLASSDOCUMENTNEW.DOCUMENT_NUMBER,"");
SETCHAR(eCLASSDOCUMENTNEW.DOCUMENT_TYPE,"");
SETCHAR(eCLASSDOCUMENTNEW.DOCUMENT_PART,"");
SETCHAR(eCLASSDOCUMENTNEW.DOCUMENT_VERSION,"");

SETCHAR(eCLASSADDITIONAL.BOM_USAGE_OK,"");
SETCHAR(eCLASSADDITIONAL.ISOCODE_UNIT,"");
SETCHAR(eCLASSADDITIONAL.BASE_UOM,"");
SETCHAR(eCLASSADDITIONAL.RES_POSTYPE,"");
SETCHAR(eCLASSADDITIONAL.DEPARTMENT_VIEW,"");
SETCHAR(eCLASSADDITIONAL.REQ_COMPONENT,"");
SETCHAR(eCLASSADDITIONAL.MULTIPLE_SELECT,"");

SETCHAR(eCLASSADDITIONALNEW.BOM_USAGE_OK,"");
SETCHAR(eCLASSADDITIONALNEW.ISOCODE_UNIT,"");
SETCHAR(eCLASSADDITIONALNEW.BASE_UOM,"");
SETCHAR(eCLASSADDITIONALNEW.RES_POSTYPE,"");
SETCHAR(eCLASSADDITIONALNEW.DEPARTMENT_VIEW,"");
SETCHAR(eCLASSADDITIONALNEW.REQ_COMPONENT,"");
SETCHAR(eCLASSADDITIONALNEW.MULTIPLE_SELECT,"");

SETCHAR(eCLASSSTANDARD.STANDARD_NAME,"");
SETCHAR(eCLASSSTANDARD.STANDARD_NO,"");
SETDATE(eCLASSSTANDARD.DATE_OF_ISSUE,"");
SETDATE(eCLASSSTANDARD.DATE_OF_VERSION,"");
SETNUM(eCLASSSTANDARD.NO_OF_VERSION,"00");
SETCHAR(eCLASSSTANDARD.TABULAR_LAYOUT,"");

SETCHAR(eCLASSSTANDARDNEW.STANDARD_NAME,"");
SETCHAR(eCLASSSTANDARDNEW.STANDARD_NO,"");
SETDATE(eCLASSSTANDARDNEW.DATE_OF_ISSUE,"");
SETDATE(eCLASSSTANDARDNEW.DATE_OF_VERSION,"");
SETNUM(eCLASSSTANDARDNEW.NO_OF_VERSION,"00");
SETCHAR(eCLASSSTANDARDNEW.TABULAR_LAYOUT,"");

//--------1
if (thRETURN==ITAB_NULL)
{
	//printf("\ncreating table RETURN");fflush(stdout);
	thRETURN = ItCreate("RETURN",sizeof(RETURN),0,0);
	if (thRETURN==ITAB_NULL)
		rfc_error("ItCreate RETURN");
}
else if (ItFree(thRETURN) != 0)
		rfc_error("ItFree RETURN");
//--------2
if (thCLASSDESCRIPTIONS==ITAB_NULL)
{
	//printf("\ncreating table CLASSDESCRIPTIONS");fflush(stdout);
	thCLASSDESCRIPTIONS = ItCreate("CLASSDESCRIPTIONS",sizeof(CLASSDESCRIPTIONS),0,0);
	if (thCLASSDESCRIPTIONS==ITAB_NULL)
		rfc_error("ItCreate CLASSDESCRIPTIONS");
}
else if (ItFree(thCLASSDESCRIPTIONS) != 0)
	rfc_error("ItFree CLASSDESCRIPTIONS");
//--------3
if (thCLASSLONGTEXTS==ITAB_NULL)
{
	//printf("\ncreating table CLASSLONGTEXTS");fflush(stdout);
	thCLASSLONGTEXTS = ItCreate("CLASSLONGTEXTS",sizeof(CLASSLONGTEXTS),0,0);
	if (thCLASSLONGTEXTS==ITAB_NULL)
		rfc_error("ItCreate CLASSLONGTEXTS");
}
else if (ItFree(thCLASSLONGTEXTS) != 0)
	rfc_error("ItFree CLASSLONGTEXTS");
//--------4
if (thCLASSCHARACTERISTICS==ITAB_NULL)
{
	//printf("\ncreating table CLASSCHARACTERISTICS");fflush(stdout);
	thCLASSCHARACTERISTICS = ItCreate("CLASSCHARACTERISTICS",sizeof(CLASSCHARACTERISTICS),0,0);
	if (thCLASSCHARACTERISTICS==ITAB_NULL)
		rfc_error("ItCreate CLASSCHARACTERISTICS");
}
else if (ItFree(thCLASSCHARACTERISTICS) != 0)
	rfc_error("ItFree CLASSCHARACTERISTICS");
//--------5
if (thCHARACTVALUEOVERWRIT==ITAB_NULL)
{
	//printf("\ncreating table CHARACTVALUEOVERWRIT");fflush(stdout);
	thCHARACTVALUEOVERWRIT = ItCreate("CHARACTVALUEOVERWRIT",sizeof(CHARACTVALUEOVERWRIT),0,0);
	if (thCHARACTVALUEOVERWRIT==ITAB_NULL)
		rfc_error("ItCreate CHARACTVALUEOVERWRIT");
}
else if (ItFree(thCHARACTVALUEOVERWRIT) != 0)
	rfc_error("ItFree CHARACTVALUEOVERWRIT");
//--------1
if (thCHARACTERISTICOVERWRITE==ITAB_NULL)
{
	//printf("\ncreating table CHARACTERISTICOVERWRITE");fflush(stdout);
	thCHARACTERISTICOVERWRITE = ItCreate("CHARACTERISTICOVERWRITE",sizeof(CHARACTERISTICOVERWRITE),0,0);
	if (thCHARACTERISTICOVERWRITE==ITAB_NULL)
		rfc_error("ItCreate CHARACTERISTICOVERWRITE");
}
else if (ItFree(thCHARACTERISTICOVERWRITE) != 0)
	rfc_error("ItFree CHARACTERISTICOVERWRITE");
//--------1
if (thCHARACTERISTICVALUETEXTOVR==ITAB_NULL)
{
	//printf("\ncreating table CHARACTERISTICVALUETEXTOVR");fflush(stdout);
	thCHARACTERISTICVALUETEXTOVR = ItCreate("CHARACTERISTICVALUETEXTOVR",sizeof(CHARACTERISTICVALUETEXTOVR),0,0);
	if (thCHARACTERISTICVALUETEXTOVR==ITAB_NULL)
		rfc_error("ItCreate CHARACTERISTICVALUETEXTOVR");
}
else if (ItFree(thCHARACTERISTICVALUETEXTOVR) != 0)
	rfc_error("ItFree CHARACTERISTICVALUETEXTOVR");
//--------1
if (thCLASSDESCRIPTIONSNEW==ITAB_NULL)
{
	//printf("\ncreating table CLASSDESCRIPTIONSNEW");fflush(stdout);
	thCLASSDESCRIPTIONSNEW = ItCreate("CLASSDESCRIPTIONSNEW",sizeof(CLASSDESCRIPTIONSNEW),0,0);
	if (thCLASSDESCRIPTIONSNEW==ITAB_NULL)
		rfc_error("ItCreate CLASSDESCRIPTIONSNEW");
}
else if (ItFree(thCLASSDESCRIPTIONSNEW) != 0)
	rfc_error("ItFree CLASSDESCRIPTIONSNEW");
//--------1
if (thCLASSLONGTEXTSNEW==ITAB_NULL)
{
	//printf("\ncreating table CLASSLONGTEXTSNEW");fflush(stdout);
	thCLASSLONGTEXTSNEW = ItCreate("CLASSLONGTEXTSNEW",sizeof(CLASSLONGTEXTSNEW),0,0);
	if (thCLASSLONGTEXTSNEW==ITAB_NULL)
		rfc_error("ItCreate CLASSLONGTEXTSNEW");
}
else if (ItFree(thCLASSLONGTEXTSNEW) != 0)
	rfc_error("ItFree CLASSLONGTEXTSNEW");
//--------1
if (thCLASSCHARACTERISTICSNEW==ITAB_NULL)
{
	//printf("\ncreating table CLASSCHARACTERISTICSNEW");fflush(stdout);
	thCLASSCHARACTERISTICSNEW = ItCreate("CLASSCHARACTERISTICSNEW",sizeof(CLASSCHARACTERISTICSNEW),0,0);
	if (thCLASSCHARACTERISTICSNEW==ITAB_NULL)
		rfc_error("ItCreate CLASSCHARACTERISTICSNEW");
}
else if (ItFree(thCLASSCHARACTERISTICSNEW) != 0)
	rfc_error("ItFree CLASSCHARACTERISTICSNEW");
//--------1
if (thCHARACTERISTICOVERWRITENEW==ITAB_NULL)
{
	//printf("\ncreating table CHARACTERISTICOVERWRITENEW");fflush(stdout);
	thCHARACTERISTICOVERWRITENEW = ItCreate("CHARACTERISTICOVERWRITENEW",sizeof(CHARACTERISTICOVERWRITENEW),0,0);
	if (thCHARACTERISTICOVERWRITENEW==ITAB_NULL)
		rfc_error("ItCreate CHARACTERISTICOVERWRITENEW");
}
else if (ItFree(thCHARACTERISTICOVERWRITENEW) != 0)
	rfc_error("ItFree CHARACTERISTICOVERWRITENEW");
//--------1
if (thCHARACTVALUEOVERWRITNEW==ITAB_NULL)
{
	//printf("\ncreating table CHARACTVALUEOVERWRITNEW");fflush(stdout);
	thCHARACTVALUEOVERWRITNEW = ItCreate("CHARACTVALUEOVERWRITNEW",sizeof(CHARACTVALUEOVERWRITNEW),0,0);
	if (thCHARACTVALUEOVERWRITNEW==ITAB_NULL)
		rfc_error("ItCreate CHARACTVALUEOVERWRITNEW");
}
else if (ItFree(thCHARACTVALUEOVERWRITNEW) != 0)
	rfc_error("ItFree CHARACTVALUEOVERWRITNEW");
//--------1
if (thCHARACTERISTICVALUETEXTOVRNEW==ITAB_NULL)
{
	//printf("\ncreating table CHARACTERISTICVALUETEXTOVRNEW");fflush(stdout);
	thCHARACTERISTICVALUETEXTOVRNEW = ItCreate("CHARACTERISTICVALUETEXTOVRNEW",sizeof(CHARACTERISTICVALUETEXTOVRNEW),0,0);
	if (thCHARACTERISTICVALUETEXTOVRNEW==ITAB_NULL)
		rfc_error("ItCreate CHARACTERISTICVALUETEXTOVRNEW");
}
else if (ItFree(thCHARACTERISTICVALUETEXTOVRNEW) != 0)
	rfc_error("ItFree CHARACTERISTICVALUETEXTOVRNEW");

//----------

tCLASSDESCRIPTIONS = ItAppLine(thCLASSDESCRIPTIONS);
if (tCLASSDESCRIPTIONS == NULL)
	printf("\nItAppLine CLASSDESCRIPTIONS");

SETCHAR(tCLASSDESCRIPTIONS->LANGU,"EN");
SETCHAR(tCLASSDESCRIPTIONS->LANGU_ISO,"EN");
SETCHAR(tCLASSDESCRIPTIONS->CATCHWORD,OptValClass);//"X4_OPTIONMASTER"
SETCHAR(tCLASSDESCRIPTIONS->DELETE_FLAG,"");
SETCHAR(tCLASSDESCRIPTIONS->INSERT_BEFORE,"");

//---

ITK_CALL(ITEM_find_item( platfrm, &platfrm_tag ));


if (platfrm_tag != NULLTAG)
{
	printf("\nPlatForm : %s Found",platfrm);fflush(stdout);

	ITK_CALL(ITEM_ask_type2 (platfrm_tag, &item_type));
	printf("\nMain item_typeS [%s] \n",item_type);  fflush(stdout);
	//PartOPtr=partObjs[0];
	//goto CLEANUP;
}
else
{
	printf("\nPlatForm %s not found in TCUA",platfrm);
	ITK_CALL(POM_logout(false));
	return 0;
}

if(tc_strcmp(item_type,"T5_Platform")==0)
{
	printf("\nOK");
	ITK_CALL(AOM_ask_value_string(platfrm_tag,"item_id",&platfrm_name));
	printf("\n\n\t\tPlatform Name ==> %s\n", platfrm_name);fflush(stdout);

	ITK_CALL(GRM_find_relation_type( "Smc0HasVariantConfigContext", &relation_dep ));
	if(relation_dep != NULLTAG)
	{
		printf("\n\tVariant ConfigContext relation found......");	fflush(stdout);
	}
	else
	{
		printf("\n\tVariant ConfigContext relation not found......");	fflush(stdout);
		ITK_CALL(POM_logout(false));
		return 0;
	}
	ITK_CALL( GRM_list_secondary_objects_only( platfrm_tag, relation_dep, &countConfigCtx, &ConfigCtxSecObject ) );
	printf("\n\tConfiguration Context count is : %d",countConfigCtx);
	if ( countConfigCtx > 0 )
	{
		ConfigCtx = ConfigCtxSecObject[0];
		ITK_CALL( TCTYPE_ask_object_type ( ConfigCtx, &ConfigCtxObjTypeTag) );
		ITK_CALL( TCTYPE_ask_name ( ConfigCtxObjTypeTag, Config_CtxType) );
		printf( "\n\tConfig relation Config_CtxType :%s ..",Config_CtxType);

		ITK_CALL( AOM_ask_value_string( ConfigCtx, "object_string", &SmVCContext) );
		printf("\n\tSmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

		ITK_CALL( AOM_ask_value_string( ConfigCtx, "item_id", &Context_Str) );
		printf("\n\tContext_Str :%s",Context_Str);	fflush(stdout);

		ITK_CALL( AOM_ask_value_string( ConfigCtx, "current_id", &SmCrIDContext) );
		printf("\n\tSmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

		ITK_CALL( QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
		if (queryTag)
		{
			printf("\n\tFound Query");fflush(stdout);
		}
		else
		{
			printf("\n\tNot Found Query");fflush(stdout);
		}
		qry_values[0] = SmCrIDContext;
		ITK_CALL( QRY_execute ( queryTag, n_entries, qry_entries, qry_values, &resultCount, &familtopttag));
		printf("\n\tresultCount: %d\n", resultCount); fflush(stdout);
		
		if ( resultCount > 0 )
		{
			OptfmlyName= (char *) malloc ( 50 * sizeof( char ) );
			OptfmlyDesc= (char *) malloc ( 50 * sizeof( char ) );
		}
		else
		{
			ITK_CALL(POM_logout(false));
			return 0;
		}

		for ( j1 = 0; j1 < resultCount; j1++ )
		{
			printf("\n\tProcessing option [%d]",j1);
			Optfmly_tag = familtopttag[j1];
			ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyDesc));
			ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_desc",&OptfmlyName));
			printf("\tOptfmlyName:%-50s length:[%-03d] OptfmlyDesc:%-50s",OptfmlyName,tc_strlen(OptfmlyName),OptfmlyDesc); fflush(stdout);   //Drive, Fuel is a Name if Option family

			ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_type",&Optfmly_type));
			printf("\tOptfmly type:[%-30s]",Optfmly_type);  fflush(stdout);

			if ( tc_strcmp(Optfmly_type, "Cfg0PackageOptionFamily" ) == 0 )
			{
				printf("\tSkipping"); fflush(stdout);
				continue;
			}

			if(tc_strlen(OptfmlyName) == 0)
			{
				printf("\nError:object_desc is null for object_name:%s raise error with BOM process team",OptfmlyDesc);
				continue;
			}

			if ( tc_strlen ( OptfmlyName ) > 30 )
			{
				printf("\nError:Can not create characteristic for option name [%s] length is more than 30 character contact BOM process team length:%d",OptfmlyName,tc_strlen ( OptfmlyName ));
				exit ( 0 ); //it should show error and come out
				//continue;
			}


			tCLASSCHARACTERISTICSNEW = ItAppLine(thCLASSCHARACTERISTICSNEW);
			if (tCLASSCHARACTERISTICSNEW == NULL)
				printf("\nItAppLine CLASSCHARACTERISTICSNEW");

			//SETCHAR(tCLASSCHARACTERISTICSNEW->NAME_CHAR,"VEHICLE_AGGREGATE");
			SETCHAR(tCLASSCHARACTERISTICSNEW->NAME_CHAR,OptfmlyName);
			SETCHAR(tCLASSCHARACTERISTICSNEW->CODE_LETTER,"");
			SETCHAR(tCLASSCHARACTERISTICSNEW->CHARACT_ORIGIN,"");
			SETCHAR(tCLASSCHARACTERISTICSNEW->DEPARTMENT_VIEW,"");
			SETCHAR(tCLASSCHARACTERISTICSNEW->INSERT_BEFORE,"");
			SETCHAR(tCLASSCHARACTERISTICSNEW->DELETEVALUE,"");
			SETCHAR(tCLASSCHARACTERISTICSNEW->PRINT_RELEV,"");
			SETCHAR(tCLASSCHARACTERISTICSNEW->SELECT_RELEV,"");
			SETCHAR(tCLASSCHARACTERISTICSNEW->DISPLAY_RELEV,"");
			SETCHAR(tCLASSCHARACTERISTICSNEW->INDEX_RELEV,"");

		}
				  
	}

}
else
{
	printf("\nNot OK");
}

/*can test for below one attr by commenting above itk code*/
/*
tCLASSCHARACTERISTICSNEW = ItAppLine(thCLASSCHARACTERISTICSNEW);
if (tCLASSCHARACTERISTICSNEW == NULL)
	printf("\nItAppLine CLASSCHARACTERISTICSNEW");

SETCHAR(tCLASSCHARACTERISTICSNEW->NAME_CHAR,"VEHICLE_AGGREGATE");
//SETCHAR(tCLASSCHARACTERISTICSNEW->NAME_CHAR,OptfmlyName);
SETCHAR(tCLASSCHARACTERISTICSNEW->CODE_LETTER,"");
SETCHAR(tCLASSCHARACTERISTICSNEW->CHARACT_ORIGIN,"");
SETCHAR(tCLASSCHARACTERISTICSNEW->DEPARTMENT_VIEW,"");
SETCHAR(tCLASSCHARACTERISTICSNEW->INSERT_BEFORE,"");
SETCHAR(tCLASSCHARACTERISTICSNEW->DELETEVALUE,"");
SETCHAR(tCLASSCHARACTERISTICSNEW->PRINT_RELEV,"");
SETCHAR(tCLASSCHARACTERISTICSNEW->SELECT_RELEV,"");
SETCHAR(tCLASSCHARACTERISTICSNEW->DISPLAY_RELEV,"");
SETCHAR(tCLASSCHARACTERISTICSNEW->INDEX_RELEV,"");
*/


hRfc = BapiLogon();
RfcRc = BAPI_CLASS_CHANGE(
							//hRfc,
							&eCLASSNUM,
							&eCLASSTYPE,
							&eCHANGENUMBER,
							&eKEYDATE,
							&eCLASSBASICDATA,
							&eCLASSBASICDATANEW,
							&eCLASSDOCUMENT,
							&eCLASSDOCUMENTNEW,
							&eCLASSADDITIONAL,
							&eCLASSADDITIONALNEW,
							&eCLASSSTANDARD,
							&eCLASSSTANDARDNEW,
							thRETURN,
							thCLASSDESCRIPTIONS,
							thCLASSLONGTEXTS,
							thCLASSCHARACTERISTICS,
							thCHARACTERISTICOVERWRITE,
							thCHARACTVALUEOVERWRIT,
							thCHARACTERISTICVALUETEXTOVR,
							thCLASSDESCRIPTIONSNEW,
							thCLASSLONGTEXTSNEW,
							thCLASSCHARACTERISTICSNEW,
							thCHARACTERISTICOVERWRITENEW,
							thCHARACTVALUEOVERWRITNEW,
							thCHARACTERISTICVALUETEXTOVRNEW,
							xException
						);
	switch (RfcRc)
	{
		case RFC_OK:


			NL;

			NL;
			NL;
			printf("\nItFill(thRETURN) : %d",ItFill(thRETURN));
			printf("\nItFill(thCLASSDESCRIPTIONS) : %d",ItFill(thCLASSDESCRIPTIONS));
			printf("\nItFill(thCLASSLONGTEXTS) : %d",ItFill(thCLASSLONGTEXTS));
			printf("\nItFill(thCLASSCHARACTERISTICS) : %d",ItFill(thCLASSCHARACTERISTICS));
			printf("\nItFill(thCHARACTERISTICOVERWRITE) : %d",ItFill(thCHARACTERISTICOVERWRITE));
			printf("\nItFill(thCHARACTVALUEOVERWRIT) : %d",ItFill(thCHARACTVALUEOVERWRIT));
			printf("\nItFill(thCHARACTERISTICVALUETEXTOVR) : %d",ItFill(thCHARACTERISTICVALUETEXTOVR));
			printf("\nItFill(thCLASSDESCRIPTIONSNEW) : %d",ItFill(thCLASSDESCRIPTIONSNEW));
			printf("\nItFill(thCLASSLONGTEXTSNEW) : %d",ItFill(thCLASSLONGTEXTSNEW));
			printf("\nItFill(thCLASSCHARACTERISTICSNEW) : %d",ItFill(thCLASSCHARACTERISTICSNEW));
			printf("\nItFill(thCHARACTERISTICOVERWRITENEW) : %d",ItFill(thCHARACTERISTICOVERWRITENEW));
			printf("\nItFill(thCHARACTVALUEOVERWRITNEW) : %d",ItFill(thCHARACTVALUEOVERWRITNEW));
			printf("\nItFill(thCHARACTERISTICVALUETEXTOVRNEW) : %d",ItFill(thCHARACTERISTICVALUETEXTOVRNEW));
			NL;NL;
			for (crow = 1;crow <= ItFill(thRETURN); crow++)
			{
				tRETURN = ItGetLine(thRETURN,crow);
				if (tRETURN == NULL)
				{
					printf("\nItGetLine RETURN\n");fflush(stdout);
				}

				GETCHAR(tRETURN->TYPE,s);
				OUTS("TYPE",10,30,s);
				GETCHAR(tRETURN->ID,s);
				OUTS("ID",10,30,s);
				GETNUM(tRETURN->NUMBER,s);
				OUTS("NUMBER",10,30,s);
				GETCHAR(tRETURN->MESSAGE,s);	trimTrailing(s);
				OUTS("MESSAGE",10,30,s);
				GETCHAR(tRETURN->LOG_NO,s);
				OUTS("LOG_NO",10,30,s);
				GETNUM(tRETURN->LOG_MSG_NO,s);
				OUTS("LOG_MSG_NO",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V1,s);
				OUTS("MESSAGE_V1",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V2,s);
				OUTS("MESSAGE_V2",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V3,s);
				OUTS("MESSAGE_V3",10,30,s);
				GETCHAR(tRETURN->MESSAGE_V4,s);
				OUTS("MESSAGE_V4",10,30,s);
				GETCHAR(tRETURN->PARAMETER,s);
				OUTS("PARAMETER",10,30,s);
				GETINT2(tRETURN->ROW,s);
				OUTS("ROW",10,30,s);
				GETCHAR(tRETURN->FIELD,s);
				OUTS("FIELD",10,30,s);
				GETCHAR(tRETURN->SYSTEM,s);
				OUTS("SYSTEM",10,30,s);
				NL;
				NL;
			}

		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
		break;
		default:
			printf("\nOther Failure!");
	}
	//cll_BAPI_TRANSACTION_COMMIT(RfcRc);
	printf("\n\tcalling BAPI_TRANSACTION_COMMIT\n\n");
	BAPITA_WAIT eBAPITA_WAIT;
	SETCHAR(eBAPITA_WAIT,"X");

	RfcRc = BAPI_TRANSACTION_COMMIT(
				//hRfc,
				&eBAPITA_WAIT,
				&iRETURN,
				xException
			);
	switch (RfcRc)
	{
		case RFC_OK:
			NL;NL;
			GETCHAR(iRETURN.TYPE,s);
			OUTS("TYPE",10,30,s);
			GETCHAR(iRETURN.ID,s);
			OUTS("ID",10,30,s);
			GETNUM(iRETURN.NUMBER,s);
			OUTS("NUMBER",10,30,s);
			GETCHAR(iRETURN.MESSAGE,s);
			OUTS("MESSAGE",10,30,s);
			GETCHAR(iRETURN.LOG_NO,s);
			OUTS("LOG_NO",10,30,s);
			GETNUM(iRETURN.LOG_MSG_NO,s);
			OUTS("LOG_MSG_NO",10,30,s);
			GETCHAR(iRETURN.MESSAGE_V1,s);
			OUTS("MESSAGE_V1",10,30,s);
			GETCHAR(iRETURN.MESSAGE_V2,s);
			OUTS("MESSAGE_V2",10,30,s);
			GETCHAR(iRETURN.MESSAGE_V3,s);
			OUTS("MESSAGE_V3",10,30,s);
			GETCHAR(iRETURN.MESSAGE_V4,s);
			OUTS("MESSAGE_V4",10,30,s);
			GETCHAR(iRETURN.PARAMETER,s);
			OUTS("PARAMETER",10,30,s);
			GETINT2(iRETURN.ROW,s);
			OUTS("ROW",10,30,s);
			GETCHAR(iRETURN.FIELD,s);
			OUTS("FIELD",10,30,s);
			GETCHAR(iRETURN.SYSTEM,s);
			OUTS("SYSTEM",10,30,s);
			printf("\nCommitted...");
			break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			exit(0);
		break;
		default:
			printf("\nOther Failure!");
			exit(0);
	}

	if (ItDelete(thCHARACTERISTICOVERWRITE) != 0) 
		rfc_error("ItDelete thCHARACTERISTICOVERWRITE");
	if (ItDelete(thCHARACTERISTICOVERWRITENEW) != 0) 
		rfc_error("ItDelete thCHARACTERISTICOVERWRITENEW");
	if (ItDelete(thCHARACTERISTICVALUETEXTOVR) != 0) 
		rfc_error("ItDelete thCHARACTERISTICVALUETEXTOVR");
	if (ItDelete(thCHARACTERISTICVALUETEXTOVRNEW) != 0) 
		rfc_error("ItDelete thCHARACTERISTICVALUETEXTOVRNEW");
	if (ItDelete(thCHARACTVALUEOVERWRIT) != 0) 
		rfc_error("ItDelete thCHARACTVALUEOVERWRIT");
	if (ItDelete(thCHARACTVALUEOVERWRITNEW) != 0) 
		rfc_error("ItDelete thCHARACTVALUEOVERWRITNEW");
	if (ItDelete(thCLASSCHARACTERISTICS) != 0) 
		rfc_error("ItDelete thCLASSCHARACTERISTICS");
	if (ItDelete(thCLASSCHARACTERISTICSNEW) != 0) 
		rfc_error("ItDelete thCLASSCHARACTERISTICSNEW");
	if (ItDelete(thCLASSDESCRIPTIONS) != 0) 
		rfc_error("ItDelete thCLASSDESCRIPTIONS");
	if (ItDelete(thCLASSDESCRIPTIONSNEW) != 0) 
		rfc_error("ItDelete thCLASSDESCRIPTIONSNEW");
	if (ItDelete(thCLASSLONGTEXTS) != 0) 
		rfc_error("ItDelete thCLASSLONGTEXTS");
	if (ItDelete(thCLASSLONGTEXTSNEW) != 0) 
		rfc_error("ItDelete thCLASSLONGTEXTSNEW");
	if (ItDelete(thRETURN) != 0) 
		rfc_error("ItDelete thRETURN");

	RfcClose(hRfc);
	ITK_CALL(POM_logout(false));
	return status;
}
