//Usage : GetRelDmlList -u=ercpsup -p=XYT1ESA -d=$inptime
//Usage : GetRelDmlList -u=ercpsup -p=XYT1ESA -d="01-Jul-2018 00:00"

#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#define Debug TRUE

char* subString (char* mainStringf ,int fromCharf,int toCharf);


#define ITK_CALL(x) {               \
  int stat;                     \
  char *err_string = NULL;             \
  if( (stat = (x)) != ITK_ok)   \
  {                             \
    EMH_ask_error_text (stat, &err_string);              \
    if(err_string != NULL) {\
	printf ("ERROR: %d ERROR MSG: %s \n", stat, err_string);        \
    printf ("Function: %s FILE: %s LINE: %d \n",#x, __FILE__, __LINE__);             \
	TC_write_syslog("Arcelik Workflow ERROR[%d]: %s\n\t(FILE: %s, LINE:%d)\n", stat, err_string, __FILE__, __LINE__);\
	MEM_free (err_string);\
	err_string=NULL;\
	}\
    return (stat);          \
  }                         \
 }                                                                              \

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

static int report_wso_object_string_and_owning_user(tag_t object)
{
    char *object_string = NULL;
    char *owning_user = NULL;
    char *item_id = NULL;
    char *date_released = NULL;
    //ITK_CALL(WSOM_ask_object_id_string(object, &object_string));
    //ITK_CALL(AOM_UIF_ask_value(object, "owning_user", &owning_user));
    ITK_CALL(AOM_UIF_ask_value(object, "item_id", &item_id));
    ITK_CALL(AOM_UIF_ask_value(object, "date_released", &date_released));
    //printf("       %s - %s \n", object_string, owning_user);
    printf("%s %s\n", item_id,date_released);
    //MEM_free(object_string);
    //MEM_free(owning_user);
	MEM_free(item_id);
	MEM_free(date_released);
	return ITK_ok;
}
extern int ITK_user_main (int argc, char ** argv )
{
	FILE* fsuccess = NULL;
	FILE* AplDmlFile = NULL;
	FILE* StdDmlFile = NULL;
	FILE* PRTaskFile = NULL;

	char fsuccess_name[200];
	char AplDmlFile_name[200];
	char StdDmlFile_name[200];
	char PRTaskFile_name[200];

	//char* dFromDate = NULL;
	//char* dToDate = NULL;
	//char* missing = NULL;
	int sret = 0;
	int LineLength = 0;

	int count = 0;
	tag_t* tags;
	char* sUserName	= NULL;
	char* sPassword = NULL;
	char* dDateReleased = NULL;
	char *date=NULL;
	int two_entries = 2;
	int one_entries = 1;
    
    char *entries[2] = {"Name", "Date Released"};
    char *PRTaskQryAttr[2] = {"Partial Task Release", "Date Released"};
    char **values = NULL;
	char *ErcDmlNo = NULL;
	char *APLDmlNo = NULL;
	tag_t ERC_Query = NULLTAG;
	tag_t APL_Query = NULLTAG;
	tag_t STD_Query = NULLTAG;
	tag_t PRTask_Query = NULLTAG;
	int n_items = 0;
    tag_t *items = NULL;
	int ii = 0;

	char *Apl_Entries[1] = {"APL Release Date"};
	char *Std_Entries[1] = {"Date Released"};
	char **APlQ_Values = NULL;

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	dDateReleased = ITK_ask_cli_argument("-d=");
	//dFromDate = ITK_ask_cli_argument("-f=");
	//dToDate = ITK_ask_cli_argument("-d=");
	//missing = ITK_ask_cli_argument("-m=");
	
	date=strtok(dDateReleased," ");

	values = (char **) MEM_alloc(two_entries * sizeof(char *));
	APlQ_Values = (char **) MEM_alloc(one_entries * sizeof(char *));

	APlQ_Values[0] = (char *)MEM_alloc( strlen( dDateReleased ) + 1);
	strcpy(APlQ_Values[0], dDateReleased  );

    ITK_CALL(QRY_find("ERCDMLReleased_DateWise", &ERC_Query));

	if(ERC_Query)
	{
		printf("\nFound Query : ERCDMLReleased_DateWise\n"); fflush(stdout);

		sprintf(fsuccess_name,"/user/plmsap/PLMSAP/ErcReleasedDmlList/ErcDmlList_%s.txt",date);
		//sprintf(fsuccess_name,"ErcDmlList_%s.txt",date);
		fsuccess = fopen(fsuccess_name,"a");

		values[0] = (char *)MEM_alloc( strlen( "T5_LcsErcRlzd" ) + 1);
		strcpy(values[0], "T5_LcsErcRlzd" );

		//values[1] = (char *)MEM_alloc( strlen( "01-Jul-2018 00:00" ) + 1);
		values[1] = (char *)MEM_alloc( strlen( dDateReleased ) + 1);
		//strcpy(values[1], "01-Jul-2018 00:00"  );
		strcpy(values[1], dDateReleased  );

		ITK_CALL(QRY_execute(ERC_Query, two_entries, entries, values, &n_items, &items));
		
		printf("\nToday's Date : [%s]	ERC DML Found : [%d]\n",dDateReleased,n_items); fflush(stdout);
		if (n_items>0)
		{
			for ( ii = 0; ii < n_items; ii++)
			{
				report_wso_object_string_and_owning_user(items[ii]);
				if(AOM_ask_value_string(items[ii],"item_id",&ErcDmlNo)!=ITK_ok) PrintErrorStack();
				printf("%s\n",ErcDmlNo); fflush(stdout);
				fprintf(fsuccess,"%s\n",ErcDmlNo);
			}
			if(values) MEM_free(values);
			if(items) MEM_free(items);
		}
	}
	else
	{
		printf("\nQuery Not Found : ERCDMLReleased_DateWise\n"); fflush(stdout);
	}

    ITK_CALL(QRY_find("APLDML_APLReleaseDateWise", &APL_Query));

	if(APL_Query)
	{
		printf("\nFound Query : APLDML_APLReleaseDateWise\n"); fflush(stdout);

		sprintf(AplDmlFile_name,"/user/plmsap/PLMSAP/AplReleasedDmlList/AplDmlList_%s.txt",date);
		//sprintf(AplDmlFile_name,"AplDmlList_%s.txt",date);
		AplDmlFile = fopen(AplDmlFile_name,"a");

		ITK_CALL(QRY_execute(APL_Query, one_entries, Apl_Entries, APlQ_Values, &n_items, &items));
		printf("\nToday's Date : [%s]	APL DML Found : [%d]\n",dDateReleased,n_items); fflush(stdout);

		if (n_items>0)
		{
			for ( ii = 0; ii < n_items; ii++)
			{
				report_wso_object_string_and_owning_user(items[ii]);
				if(AOM_ask_value_string(items[ii],"item_id",&APLDmlNo)!=ITK_ok) PrintErrorStack();
				printf("%s\n",APLDmlNo); fflush(stdout);
				fprintf(AplDmlFile,"%s\n",APLDmlNo);
			}
			
			if(items) MEM_free(items);
		}
	}
	else
	{
		printf("\nQuery Not Found : APLDML_APLReleaseDateWise\n"); fflush(stdout);
	}

	ITK_CALL(QRY_find("APLDML_STDReleaseDateWise", &STD_Query));

	if(STD_Query)
	{
		printf("\nFound Query : APLDML_STDReleaseDateWise\n"); fflush(stdout);

		sprintf(StdDmlFile_name,"/user/plmsap/PLMSAP/StdReleasedDmlList/StdDmlList_%s.txt",date);
		//sprintf(StdDmlFile_name,"StdDmlList_%s.txt",date);
		StdDmlFile = fopen(StdDmlFile_name,"a");

		ITK_CALL(QRY_execute(STD_Query, one_entries, Std_Entries, APlQ_Values, &n_items, &items));
		printf("\nToday's Date : [%s]	STD Released DML Found : [%d]\n",dDateReleased,n_items); fflush(stdout);

		if (n_items>0)
		{
			for ( ii = 0; ii < n_items; ii++)
			{
				report_wso_object_string_and_owning_user(items[ii]);
				if(AOM_ask_value_string(items[ii],"item_id",&APLDmlNo)!=ITK_ok) PrintErrorStack();
				printf("%s\n",APLDmlNo); fflush(stdout);
				fprintf(AplDmlFile,"%s\n",APLDmlNo);
				fprintf(StdDmlFile,"%s\n",APLDmlNo);
			}
			
			if(items) MEM_free(items);
		}
	}
	else
	{
		printf("\nQuery Not Found : APLDML_STDReleaseDateWise\n"); fflush(stdout);
	}

	ITK_CALL(QRY_find("tm_APLPRTaskReleased", &PRTask_Query));

	if(PRTask_Query)
	{
		printf("\nFound Query : tm_APLPRTaskReleased\n"); fflush(stdout);

		sprintf(PRTaskFile_name,"/user/plmsap/PLMSAP/StdReleasedDmlList/PRTaskList_%s.txt",date);
		//sprintf(PRTaskFile_name,"PRTaskList_%s.txt",date);
		PRTaskFile = fopen(PRTaskFile_name,"a");

		values[0] = (char *)MEM_alloc( strlen( "TRUE" ) + 1);
		strcpy(values[0], "TRUE" );

		//values[1] = (char *)MEM_alloc( strlen( "01-Jul-2018 00:00" ) + 1);
		values[1] = (char *)MEM_alloc( strlen( dDateReleased ) + 1);
		//strcpy(values[1], "01-Jul-2018 00:00"  );
		strcpy(values[1], dDateReleased  );

		ITK_CALL(QRY_execute(PRTask_Query, two_entries, PRTaskQryAttr, values, &n_items, &items));
		printf("\nToday's Date : [%s]	STD Released PR Task Found : [%d]\n",dDateReleased,n_items); fflush(stdout);

		if (n_items>0)
		{
			for ( ii = 0; ii < n_items; ii++)
			{
				report_wso_object_string_and_owning_user(items[ii]);
				if(AOM_ask_value_string(items[ii],"item_id",&APLDmlNo)!=ITK_ok) PrintErrorStack();
				printf("%s\n",APLDmlNo); fflush(stdout);
				fprintf(PRTaskFile,"%s\n",APLDmlNo);
			}
			
			if(items) MEM_free(items);
		}
	}
	else
	{
		printf("\nQuery Not Found : tm_APLPRTaskReleased\n"); fflush(stdout);
	}

	if(APlQ_Values) MEM_free(APlQ_Values);
	if(values) MEM_free(values);
	return ITK_ok;
}
