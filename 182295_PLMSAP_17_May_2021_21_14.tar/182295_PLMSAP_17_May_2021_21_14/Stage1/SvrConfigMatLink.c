#include <tccore/aom.h>
#include <textsrv/textserver.h>
//#include <tcinit/tcinit.h>
#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
//#include "bapi.h"

#define NL printf("\n")
//#define SETCHAR(var,str)memcpy(var,str,__min(strlen(str),sizeof(var))); if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define GETCHAR(var,str) sprintf(str,"%.*s",sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define GETINT(var,str) sprintf(str,"%ld",var);
//#define OUT(text,pos) printf("%*.0s",pos,text); printf("%s\n",text); if(outfile!=NULL) fprintf(outfile,"=%s\n",text)
/*#ifndef SAP_FT_SY_SUBRC
#define SAP_FT_SY_SUBRC
typedef RFC_INT SY_SUBRC[10];
#endif*/

#ifndef SAP_ST_SY_RETVAL
#define SAP_ST_SY_RETVAL
typedef struct {
  RFC_INT RETVAL;
 }RETVAL;
#endif

#ifndef SAP_TH_SY_RETVAL
#define SAP_TH_SY_RETVAL
static RFC_TYPEHANDLE handleOfRETVAL;

static RFC_TYPE_ELEMENT typeOfRETVAL[] = {
  { "RETVAL", TYPINT, sizeof(RFC_INT), 0 },
 } ;
#endif

#ifndef SAP_ST_BAPIRET2
#define SAP_ST_BAPIRET2
typedef struct {
  RFC_CHAR Type[1];
  RFC_CHAR Id[20];
  RFC_NUM Number[3];
  RFC_CHAR Message[220];
  RFC_CHAR LogNo[20];
  RFC_NUM LogMsgNo[6];
  RFC_CHAR MessageV1[50];
  RFC_CHAR MessageV2[50];
  RFC_CHAR MessageV3[50];
  RFC_CHAR MessageV4[50];
  RFC_CHAR Parameter[32];
  RFC_INT Row;
  RFC_CHAR Field[30];
  RFC_CHAR System[10];  } BAPIRET2;
#endif

#ifndef SAP_TH_BAPIRET2
#define SAP_TH_BAPIRET2
static RFC_TYPEHANDLE handleOfBAPIRET2;

static RFC_TYPE_ELEMENT typeOfBAPIRET2[] = {
  {"TYPE", TYPC, 1, 0},

  {"ID", TYPC, 20, 0},
  {"NUMBER", TYPNUM, 3, 0},
  {"MESSAGE", TYPC, 220, 0},
  {"LOG_NO", TYPC, 20, 0},
  {"LOG_MSG_NO", TYPNUM, 6, 0},
  {"MESSAGE_V1", TYPC, 50, 0},
  {"MESSAGE_V2", TYPC, 50, 0},
  {"MESSAGE_V3", TYPC, 50, 0},
  {"MESSAGE_V4", TYPC, 50, 0},
  {"PARAMETER", TYPC, 32, 0},
  {"ROW", TYPINT, sizeof(RFC_INT), 0},
  {"FIELD", TYPC, 30, 0},
  {"SYSTEM", TYPC, 10, 0},  };
#endif

//MATNR
#ifndef SAP_ST_MATNR_DK
#define SAP_ST_MATNR_DK
typedef struct {
  RFC_CHAR MATERIAL[18];
 }MATNR_DK;
#endif

#ifndef SAP_TH_MATNR_DK
#define SAP_TH_MATNR_DK
static RFC_TYPEHANDLE handleOfMATNR_DK ;

static RFC_TYPE_ELEMENT typeOfMATNR_DK[] = {
  { "MATERIAL", TYPC, 18, 0 },
 };
#endif

//PLANT
#ifndef SAP_ST_WERKS_D_DK
#define SAP_ST_WERKS_D_DK
typedef struct {
  RFC_CHAR PLANT[4];
 }WERKS_D_DK;
#endif

#ifndef SAP_TH_WERKS_D_DK
#define SAP_TH_WERKS_D_DK
static RFC_TYPEHANDLE handleOfWERKS_D_DK;

static RFC_TYPE_ELEMENT typeOfWERKS_D_DK[] = {
  { "PLANT", TYPC, 4, 0 },
 };
#endif

//BOM_USAGE
#ifndef SAP_ST_STLAN_DK
#define SAP_ST_STLAN_DK
typedef struct {
  RFC_CHAR BOM_USAGE[1] ;
 }STLAN_DK;
#endif

#ifndef SAP_TH_STLAN_DK
#define SAP_TH_STLAN_DK
static RFC_TYPEHANDLE handleOfSTLAN_DK ;

static RFC_TYPE_ELEMENT typeOfSTLAN_DK[] = {
  {"BOM_USAGE", TYPC, 1, 0},
 };
#endif

//ALTERNATE_BOM
#ifndef SAP_ST_STLAL_DK
#define SAP_ST_STLAL_DK
typedef struct {
  RFC_CHAR ALTERNATE_BOM[2] ;
 }STLAL_DK;
#endif

#ifndef SAP_TH_STLAL_DK
#define SAP_TH_STLAL_DK
static RFC_TYPEHANDLE handleOfSTLAL_DK ;

static RFC_TYPE_ELEMENT typeOfSTLAL_DK[] = {
  {"ALTERNATE_BOM", TYPC, 2, 0},
 };
#endif



char *iSapServer = NULL;

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %s",len,text,str);fflush(stdout);
  return;
}

void rfc_error(char *operation)
{
#ifdef SAPonNT
  char s[16];
#endif
  RFC_ERROR_INFO RfcErrorInfo;
  //OUT("RFC error TEST",0);
  OUTS("operation/code",0,15,operation);
  memset(&RfcErrorInfo,0,sizeof(RfcErrorInfo));
  RfcLastError(&RfcErrorInfo);
  OUTS("key",0,15,RfcErrorInfo.key);
  OUTS("status",0,15,RfcErrorInfo.status);
  OUTS("message",0,15,RfcErrorInfo.message);
  OUTS("internal status",0,15,RfcErrorInfo.intstat); NL;
  RfcClose (RFC_HANDLE_NULL);
#ifdef SAPonNT
  INS("","","Quit? [y]",4,24,s);
#endif
  exit(1);
}

RFC_RC zpprfc_config_mat_linking(
						RFC_HANDLE hRfc,
						MATNR_DK *eMATNR_DK,
						WERKS_D_DK *eWERKS_D_DK,
						STLAN_DK *eSTLAN_DK,
						STLAL_DK *eSTLAL_DK,
						BAPIRET2 *iRETURN,
						RETVAL *iSy_subrc_DK,
						char *xException)
{
RFC_PARAMETER Exporting[5];
// RFC_PARAMETER Exporting[1];
// RFC_PARAMETER Importing[3];
 RFC_PARAMETER Importing[3];
 RFC_TABLE Tables[1];
 RFC_RC RfcRc;
 char *RfcException = NULL;

		Exporting[0].name = "MATERIAL";
		Exporting[0].nlen = 8;
		Exporting[0].type = handleOfMATNR_DK ;
		Exporting[0].leng = sizeof ( MATNR_DK ) ;
		Exporting[0].addr = eMATNR_DK ;

		Exporting[1].name = "PLANT";
		Exporting[1].nlen = 5;
		Exporting[1].type = handleOfWERKS_D_DK ;
		Exporting[1].leng = sizeof ( WERKS_D_DK ) ;
		Exporting[1].addr = eWERKS_D_DK ;

		Exporting[2].name = "BOM_USAGE";
		Exporting[2].nlen = 9;
		Exporting[2].type = handleOfSTLAN_DK ;
		Exporting[2].leng = sizeof (STLAN_DK ) ;
		Exporting[2].addr = eSTLAN_DK ;

		Exporting[3].name = "ALTERNATE_BOM";
		Exporting[3].nlen = 13;
		Exporting[3].type = handleOfSTLAL_DK ;
		Exporting[3].leng = sizeof ( STLAL_DK ) ;
		Exporting[3].addr = eSTLAL_DK ;

		Exporting[4].name = NULL;
		//Exporting[0].name = NULL;

		Tables[0].name = NULL;

		RfcRc = RfcCall(hRfc,"ZPPRFC_CONFIG_MAT_LINKING",Exporting,Tables);

		switch (RfcRc)
		{
			case RFC_OK :

				Importing[0].name = "RETVAL";
				Importing[0].nlen = 6;
				Importing[0].type = handleOfRETVAL;
				Importing[0].leng = sizeof(RETVAL);
				Importing[0].addr = iSy_subrc_DK;

				Importing[1].name = "MESSG";
				Importing[1].nlen = 5;
				Importing[1].type = handleOfBAPIRET2;
				Importing[1].leng = sizeof(BAPIRET2);
				Importing[1].addr = iRETURN;

				Importing[2].name = NULL;

				RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

				switch (RfcRc)
				{
					case RFC_SYS_EXCEPTION :
						strcpy(xException,RfcException);
					break;
					case RFC_EXCEPTION :
						strcpy(xException,RfcException);
					break;
					default:;
				}
			break;
			default :
				printf("\nNOT RFC OK");
		}
  return RfcRc;
}

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}



int cll_zpprfc_config_mat_linking ( char *VcNumber, char *Plant )
{
	RFC_HANDLE hRfc ;
	RFC_RC RfcRc ;
	char xException[256]  = { 0 } ;
	char s[1024]  = { 0 } ;
	MATNR_DK eMATNR_DK ;
	WERKS_D_DK eWERKS_D_DK ;
	STLAN_DK eSTLAN_DK ;
	STLAL_DK eSTLAL_DK ;
	RETVAL iSy_subrc_DK ;
	BAPIRET2 iReturn ;

	hRfc = BapiLogon ( ) ;

	SETCHAR(eMATNR_DK.MATERIAL,VcNumber);
	SETCHAR(eWERKS_D_DK.PLANT,Plant);
	SETCHAR(eSTLAN_DK.BOM_USAGE,"1");
	SETCHAR(eSTLAL_DK.ALTERNATE_BOM,"01");

	printf("\ncalling ZPPRFC_CONFIG_MAT_LINKING");

	RfcRc = zpprfc_config_mat_linking 
					( 
						hRfc,
						&eMATNR_DK,
						&eWERKS_D_DK,
						&eSTLAN_DK,
						&eSTLAL_DK,
						&iReturn,
						&iSy_subrc_DK,
						xException
					);
	switch (RfcRc)
	{
		case RFC_OK :

			

			
			GETINT(iSy_subrc_DK.RETVAL,s);
			OUTS("RETVAL",10,30,s);

			GETCHAR(iReturn.Type,s);
            OUTS("TYPE",10,30,s);
            GETCHAR(iReturn.Id,s);
            OUTS("ID",10,30,s);
            GETNUM(iReturn.Number,s);
            OUTS("NUMBER",10,30,s);
            GETCHAR(iReturn.Message,s);
            OUTS("MESSAGE",10,30,s);
            GETCHAR(iReturn.LogNo,s);
            OUTS("LOG_NO",10,30,s);
            GETNUM(iReturn.LogMsgNo,s);
            OUTS("LOG_MSG_NO",10,30,s);
            GETCHAR(iReturn.MessageV1,s);
            OUTS("MESSAGE_V1",10,30,s);
            GETCHAR(iReturn.MessageV2,s);
            OUTS("MESSAGE_V2",10,30,s);
            GETCHAR(iReturn.MessageV3,s);
            OUTS("MESSAGE_V3",10,30,s);
            GETCHAR(iReturn.MessageV4,s);
            OUTS("MESSAGE_V4",10,30,s);
            GETCHAR(iReturn.Parameter,s);
            OUTS("PARAMETER",10,30,s);
            GETINT(iReturn.Row,s);
            OUTS("ROW",10,30,s);
            GETCHAR(iReturn.Field,s);
            OUTS("FIELD",10,30,s);
            GETCHAR(iReturn.System,s);
            OUTS("SYSTEM",10,30,s);
            //OUT("RETURN",8); 
			NL;
			
		break;
		case RFC_EXCEPTION :
			printf("\n");
			rfc_error("RFC_EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION :
			printf("\n");
			rfc_error("RFC_SYS_EXCEPTION");
		break;
		case RFC_FAILURE :
			printf("\n");
			rfc_error("RFC_FAILURE");
		break;
		default :
			printf("\nOTHER FAILURE");
			rfc_error("default");
	}
	RfcClose(hRfc);
	return 0 ;
}

extern int ITK_user_main( int argc, char **argv)
{
	int status = ITK_ok ;
	char *VcNumber = NULL ; 
	char *Plant = NULL ; 
	ITK_CALL ( ITK_initialize_text_services ( ITK_BATCH_TEXT_MODE ) ) ;
	ITK_CALL ( ITK_auto_login () ) ;
	ITK_CALL ( ITK_set_journalling ( TRUE ) ) ;
		
	VcNumber = ITK_ask_cli_argument ( "-v=" ) ;
	Plant = ITK_ask_cli_argument ( "-t=" ) ;
	iSapServer = ITK_ask_cli_argument ( "-s=" ) ;

	cll_zpprfc_config_mat_linking ( VcNumber, Plant );

	ITK_CALL ( POM_logout ( FALSE ) ) ;
	return status;
}